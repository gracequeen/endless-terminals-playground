# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the DNS log analysis script fix task.
"""

import os
import re
import subprocess
import pytest


class TestLogFileExists:
    """Tests for the DNS query log file."""

    def test_query_log_exists(self):
        """Verify /var/log/named/query.log exists."""
        log_path = "/var/log/named/query.log"
        assert os.path.exists(log_path), (
            f"DNS query log file not found at {log_path}. "
            "The log file must exist for this task."
        )

    def test_query_log_is_file(self):
        """Verify /var/log/named/query.log is a regular file."""
        log_path = "/var/log/named/query.log"
        assert os.path.isfile(log_path), (
            f"{log_path} exists but is not a regular file."
        )

    def test_query_log_is_readable(self):
        """Verify /var/log/named/query.log is readable."""
        log_path = "/var/log/named/query.log"
        assert os.access(log_path, os.R_OK), (
            f"{log_path} exists but is not readable. "
            "The log file must be readable for analysis."
        )

    def test_query_log_has_content(self):
        """Verify the log file has approximately 50k lines."""
        log_path = "/var/log/named/query.log"
        result = subprocess.run(
            ["wc", "-l", log_path],
            capture_output=True,
            text=True
        )
        line_count = int(result.stdout.split()[0])
        assert line_count >= 40000, (
            f"Log file has only {line_count} lines, expected ~50,000 lines. "
            "The log file should contain approximately 50k DNS query entries."
        )
        assert line_count <= 60000, (
            f"Log file has {line_count} lines, expected ~50,000 lines."
        )

    def test_query_log_format(self):
        """Verify log file contains BIND-style DNS query log format."""
        log_path = "/var/log/named/query.log"
        # Expected format: DD-Mon-YYYY HH:MM:SS.mmm client @0xHEX IP#PORT (DOMAIN): query: DOMAIN IN TYPE +FLAGS (SERVER)
        bind_pattern = re.compile(
            r'\d{2}-\w{3}-\d{4}\s+\d{2}:\d{2}:\d{2}\.\d+\s+client\s+@0x[a-fA-F0-9]+\s+[\d.]+#\d+\s+\([^)]+\):\s+query:\s+\S+\s+IN\s+\w+'
        )

        with open(log_path, 'r') as f:
            # Check first 100 lines for format compliance
            matching_lines = 0
            for i, line in enumerate(f):
                if i >= 100:
                    break
                if bind_pattern.search(line):
                    matching_lines += 1

        assert matching_lines >= 90, (
            f"Only {matching_lines}/100 sampled lines match expected BIND DNS query log format. "
            "Expected format: 'DD-Mon-YYYY HH:MM:SS.mmm client @0xHEX IP#PORT (DOMAIN): query: DOMAIN IN TYPE +FLAGS (SERVER)'"
        )


class TestAnalyzeScriptExists:
    """Tests for the analyze.py script."""

    def test_analyze_script_exists(self):
        """Verify /home/user/analyze.py exists."""
        script_path = "/home/user/analyze.py"
        assert os.path.exists(script_path), (
            f"Analysis script not found at {script_path}. "
            "The buggy script must exist for the student to fix."
        )

    def test_analyze_script_is_file(self):
        """Verify /home/user/analyze.py is a regular file."""
        script_path = "/home/user/analyze.py"
        assert os.path.isfile(script_path), (
            f"{script_path} exists but is not a regular file."
        )

    def test_analyze_script_is_readable(self):
        """Verify /home/user/analyze.py is readable."""
        script_path = "/home/user/analyze.py"
        assert os.access(script_path, os.R_OK), (
            f"{script_path} exists but is not readable."
        )

    def test_analyze_script_is_writable(self):
        """Verify /home/user/analyze.py is writable (student needs to fix it)."""
        script_path = "/home/user/analyze.py"
        assert os.access(script_path, os.W_OK), (
            f"{script_path} exists but is not writable. "
            "The student needs write access to fix the script."
        )

    def test_analyze_script_is_python(self):
        """Verify the script is a Python file."""
        script_path = "/home/user/analyze.py"
        with open(script_path, 'r') as f:
            content = f.read()

        # Check for Python indicators
        is_python = (
            'import' in content or 
            'def ' in content or 
            'python' in content.lower()
        )
        assert is_python, (
            f"{script_path} does not appear to be a Python script."
        )

    def test_analyze_script_has_bugs(self):
        """Verify the script contains the expected buggy patterns."""
        script_path = "/home/user/analyze.py"
        with open(script_path, 'r') as f:
            content = f.read()

        # Check for re.match usage (Bug 1)
        has_re_match = 'pattern.match' in content or 're.match' in content
        assert has_re_match, (
            "Script does not contain 'pattern.match' or 're.match'. "
            "The buggy script should use re.match instead of re.search."
        )

        # Check for xfr filter (Bug 3)
        has_xfr_filter = "'xfr'" in content.lower() or '"xfr"' in content.lower()
        assert has_xfr_filter, (
            "Script does not contain an 'xfr' filter. "
            "The buggy script should have an overbroad xfr substring filter."
        )


class TestLogContainsExpectedDomains:
    """Tests to verify the log contains domains needed for verification."""

    def test_log_contains_cdn_example_com(self):
        """Verify log contains cdn.example.com queries."""
        log_path = "/var/log/named/query.log"
        result = subprocess.run(
            ["grep", "-c", "cdn.example.com", log_path],
            capture_output=True,
            text=True
        )
        count = int(result.stdout.strip()) if result.returncode == 0 else 0
        assert count > 0, (
            "Log file does not contain any queries for 'cdn.example.com'. "
            "This domain is needed for count verification."
        )

    def test_log_contains_xfr_substring_domains(self):
        """Verify log contains domains with 'xfr' substring (like xfinity.com)."""
        log_path = "/var/log/named/query.log"
        # Look for domains containing xfr that aren't AXFR/IXFR record types
        result = subprocess.run(
            ["grep", "-i", "xfr", log_path],
            capture_output=True,
            text=True
        )
        lines_with_xfr = result.stdout.strip().split('\n') if result.stdout.strip() else []

        # Filter to find lines with xfr in domain name (not just AXFR/IXFR type)
        domain_xfr_count = 0
        for line in lines_with_xfr:
            # Check if xfr appears in domain part, not just as record type
            if 'xfinity' in line.lower() or 'transfer' in line.lower():
                domain_xfr_count += 1

        assert domain_xfr_count > 0 or len(lines_with_xfr) > 100, (
            "Log file should contain domains with 'xfr' substring that get incorrectly filtered. "
            "Expected domains like 'xfinity.com', 'transferwise.com', etc."
        )


class TestHomeDirectoryWritable:
    """Tests for home directory permissions."""

    def test_home_user_exists(self):
        """Verify /home/user directory exists."""
        home_path = "/home/user"
        assert os.path.exists(home_path), (
            f"Home directory {home_path} does not exist."
        )

    def test_home_user_is_directory(self):
        """Verify /home/user is a directory."""
        home_path = "/home/user"
        assert os.path.isdir(home_path), (
            f"{home_path} exists but is not a directory."
        )

    def test_home_user_is_writable(self):
        """Verify /home/user is writable for output file creation."""
        home_path = "/home/user"
        assert os.access(home_path, os.W_OK), (
            f"{home_path} is not writable. "
            "The script needs to write report.txt to this directory."
        )


class TestRequiredToolsAvailable:
    """Tests for required command-line tools."""

    def test_python3_available(self):
        """Verify Python 3 is available."""
        result = subprocess.run(
            ["python3", "--version"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "Python 3 is not available. "
            "The analysis script requires Python 3."
        )

    def test_grep_available(self):
        """Verify grep is available for count verification."""
        result = subprocess.run(
            ["which", "grep"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "grep is not available. "
            "grep is needed for verifying domain counts."
        )

    def test_wc_available(self):
        """Verify wc is available."""
        result = subprocess.run(
            ["which", "wc"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "wc is not available."
        )


class TestLogDirectoryStructure:
    """Tests for the log directory structure."""

    def test_var_log_named_exists(self):
        """Verify /var/log/named directory exists."""
        dir_path = "/var/log/named"
        assert os.path.exists(dir_path), (
            f"Directory {dir_path} does not exist. "
            "The BIND log directory structure must exist."
        )

    def test_var_log_named_is_directory(self):
        """Verify /var/log/named is a directory."""
        dir_path = "/var/log/named"
        assert os.path.isdir(dir_path), (
            f"{dir_path} exists but is not a directory."
        )
