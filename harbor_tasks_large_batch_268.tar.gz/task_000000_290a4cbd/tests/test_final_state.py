# test_final_state.py
"""
Tests to validate the final state of the OS/filesystem after the student
has fixed the DNS log analysis script.
"""

import os
import re
import subprocess
import pytest


class TestScriptExistsAndRunnable:
    """Tests that the script exists and can be executed."""

    def test_analyze_script_exists(self):
        """Verify /home/user/analyze.py still exists."""
        script_path = "/home/user/analyze.py"
        assert os.path.exists(script_path), (
            f"Analysis script not found at {script_path}. "
            "The script must remain at the original location."
        )

    def test_analyze_script_is_python(self):
        """Verify the script is still a Python file (not replaced with shell)."""
        script_path = "/home/user/analyze.py"
        with open(script_path, 'r') as f:
            content = f.read()

        # Must contain Python-specific constructs
        has_python_imports = 'import' in content
        has_python_syntax = ('def ' in content or 'with ' in content or 
                            'for ' in content or 'Counter' in content)

        assert has_python_imports or has_python_syntax, (
            f"{script_path} does not appear to be a Python script. "
            "The script must remain as Python code, not replaced with shell."
        )

    def test_script_runs_without_error(self):
        """Verify python3 /home/user/analyze.py exits with code 0."""
        script_path = "/home/user/analyze.py"
        result = subprocess.run(
            ["python3", script_path],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"Script failed to run. Exit code: {result.returncode}\n"
            f"Stderr: {result.stderr}\n"
            f"Stdout: {result.stdout}"
        )


class TestReportFileGenerated:
    """Tests for the output report file."""

    def test_report_file_exists(self):
        """Verify /home/user/report.txt exists after running the script."""
        # First run the script to generate the report
        subprocess.run(["python3", "/home/user/analyze.py"], capture_output=True)

        report_path = "/home/user/report.txt"
        assert os.path.exists(report_path), (
            f"Report file not found at {report_path}. "
            "The script should generate output at /home/user/report.txt"
        )

    def test_report_has_header(self):
        """Verify report.txt contains the expected header."""
        subprocess.run(["python3", "/home/user/analyze.py"], capture_output=True)

        report_path = "/home/user/report.txt"
        with open(report_path, 'r') as f:
            content = f.read()

        assert "top 20" in content.lower() or "top20" in content.lower(), (
            "Report file does not contain 'Top 20' header. "
            f"Content starts with: {content[:200]}"
        )

    def test_report_has_domain_counts(self):
        """Verify report contains domain names and counts."""
        subprocess.run(["python3", "/home/user/analyze.py"], capture_output=True)

        report_path = "/home/user/report.txt"
        with open(report_path, 'r') as f:
            content = f.read()

        # Look for lines with domain: count or domain count format
        count_pattern = re.compile(r'[\w.-]+\.\w+.*\d+')
        matches = count_pattern.findall(content)

        assert len(matches) >= 10, (
            f"Report should contain at least 10 domain entries with counts. "
            f"Found {len(matches)} matching lines."
        )


class TestCountAccuracy:
    """Tests that verify the counts match grep output."""

    def _get_grep_count(self, domain):
        """Get the count of a domain using grep."""
        log_path = "/var/log/named/query.log"
        result = subprocess.run(
            ["grep", "-c", f"query: {domain} IN", log_path],
            capture_output=True,
            text=True
        )
        if result.returncode == 0:
            return int(result.stdout.strip())
        return 0

    def _get_report_count(self, domain):
        """Get the count of a domain from the report file."""
        report_path = "/home/user/report.txt"
        with open(report_path, 'r') as f:
            content = f.read()

        # Look for the domain and its count in various formats
        # Format could be "domain: count" or "domain count" or "count domain"
        for line in content.split('\n'):
            if domain.lower() in line.lower():
                # Extract numbers from the line
                numbers = re.findall(r'\d+', line)
                if numbers:
                    # Return the largest number (likely the count)
                    return max(int(n) for n in numbers)
        return None

    def test_cdn_example_com_count_accuracy(self):
        """Verify cdn.example.com count matches grep within ±1."""
        # Run the script first
        subprocess.run(["python3", "/home/user/analyze.py"], capture_output=True)

        domain = "cdn.example.com"
        grep_count = self._get_grep_count(domain)

        # Skip if domain not in log
        if grep_count == 0:
            pytest.skip(f"Domain {domain} not found in log file")

        report_count = self._get_report_count(domain)

        assert report_count is not None, (
            f"Domain {domain} not found in report.txt. "
            f"grep shows {grep_count} occurrences in the log."
        )

        assert abs(report_count - grep_count) <= 1, (
            f"Count mismatch for {domain}: "
            f"report shows {report_count}, grep shows {grep_count}. "
            f"Difference: {abs(report_count - grep_count)} (allowed: ±1)"
        )

    def test_multiple_domains_count_accuracy(self):
        """Verify at least 3 domains from top 20 have accurate counts."""
        # Run the script first
        subprocess.run(["python3", "/home/user/analyze.py"], capture_output=True)

        report_path = "/home/user/report.txt"
        with open(report_path, 'r') as f:
            content = f.read()

        # Extract domains from report
        # Pattern to match domain names
        domain_pattern = re.compile(r'([a-zA-Z0-9][-a-zA-Z0-9]*\.)+[a-zA-Z]{2,}')

        domains_checked = 0
        domains_accurate = 0
        errors = []

        for line in content.split('\n'):
            match = domain_pattern.search(line)
            if match:
                domain = match.group(0).lower()
                grep_count = self._get_grep_count(domain)

                if grep_count > 0:
                    report_count = self._get_report_count(domain)
                    if report_count is not None:
                        domains_checked += 1
                        if abs(report_count - grep_count) <= 1:
                            domains_accurate += 1
                        else:
                            errors.append(
                                f"{domain}: report={report_count}, grep={grep_count}"
                            )

                        if domains_checked >= 5:
                            break

        assert domains_checked >= 3, (
            f"Could not verify enough domains. Only checked {domains_checked}."
        )

        assert domains_accurate >= 3, (
            f"Count accuracy check failed. "
            f"Only {domains_accurate}/{domains_checked} domains had accurate counts. "
            f"Errors: {'; '.join(errors)}"
        )


class TestXfrSubstringDomainsNotFiltered:
    """Tests that domains containing 'xfr' substring are not incorrectly filtered."""

    def test_xfr_substring_domains_included(self):
        """Verify domains with 'xfr' in name are counted (if they exist in log)."""
        log_path = "/var/log/named/query.log"

        # Find domains containing 'xfr' or 'xfi' that aren't AXFR/IXFR types
        result = subprocess.run(
            ["grep", "-i", "-E", "query: [^ ]*xf[a-z]*[^ ]* IN (A|AAAA|MX|CNAME|TXT)", log_path],
            capture_output=True,
            text=True
        )

        if result.returncode != 0 or not result.stdout.strip():
            # Try alternative patterns
            result = subprocess.run(
                ["grep", "-i", "xfinity", log_path],
                capture_output=True,
                text=True
            )

        if result.returncode != 0 or not result.stdout.strip():
            # No domains with xfr substring found, skip this test
            pytest.skip("No domains with 'xfr' substring found in log")

        # Run the script
        subprocess.run(["python3", "/home/user/analyze.py"], capture_output=True)

        # Check if any xfr-containing domain appears in the report or
        # at least verify the script doesn't have the overbroad filter
        script_path = "/home/user/analyze.py"
        with open(script_path, 'r') as f:
            script_content = f.read()

        # The fix should either:
        # 1. Remove the xfr filter entirely, or
        # 2. Make it specific to AXFR/IXFR record types, not domain substrings

        # Check for overbroad filter patterns that would still be buggy
        has_bad_filter = (
            ("'xfr' in line" in script_content.lower() and 
             "IN AXFR" not in script_content and 
             "IN IXFR" not in script_content and
             " AXFR" not in script_content and
             " IXFR" not in script_content) or
            ('"xfr" in line' in script_content.lower() and
             "IN AXFR" not in script_content and
             "IN IXFR" not in script_content and
             " AXFR" not in script_content and
             " IXFR" not in script_content)
        )

        # If the script still has an xfr filter, it should be type-specific
        if "'xfr'" in script_content.lower() or '"xfr"' in script_content.lower():
            # Check if it's properly scoped to record types
            assert not has_bad_filter or "AXFR" in script_content or "IXFR" in script_content, (
                "Script still contains overbroad 'xfr' filter that would exclude "
                "domains like 'xfinity.com'. The filter should only exclude "
                "AXFR/IXFR record types, not domains containing 'xfr' substring."
            )


class TestBugsFixed:
    """Tests that verify the specific bugs have been fixed."""

    def test_uses_search_not_match(self):
        """Verify the script uses re.search instead of re.match for mid-line patterns."""
        script_path = "/home/user/analyze.py"
        with open(script_path, 'r') as f:
            content = f.read()

        # The fix should change pattern.match to pattern.search
        # or use re.search instead of re.match
        uses_match_incorrectly = (
            'pattern.match(line)' in content or
            '.match(line)' in content
        )

        uses_search = (
            '.search(' in content or
            're.search(' in content or
            'pattern.search(' in content or
            're.findall(' in content or
            '.findall(' in content
        )

        # Either they switched to search/findall, or they modified the approach
        assert uses_search or not uses_match_incorrectly, (
            "Script still uses 'pattern.match(line)' which won't match "
            "patterns in the middle of lines. Should use 'pattern.search(line)' "
            "or 're.search()' instead."
        )

    def test_significant_count_improvement(self):
        """Verify the total counts have improved significantly from the buggy version."""
        # Run the script
        subprocess.run(["python3", "/home/user/analyze.py"], capture_output=True)

        report_path = "/home/user/report.txt"
        with open(report_path, 'r') as f:
            content = f.read()

        # Extract all counts from report
        counts = [int(n) for n in re.findall(r'\d+', content) if int(n) > 10]

        if not counts:
            pytest.fail("No significant counts found in report")

        # Get total lines in log for reference
        log_path = "/var/log/named/query.log"
        result = subprocess.run(
            ["wc", "-l", log_path],
            capture_output=True,
            text=True
        )
        total_lines = int(result.stdout.split()[0])

        # The top domain should have a reasonable count
        # With ~50k lines, top domains should have at least hundreds of queries
        max_count = max(counts)

        assert max_count > 100, (
            f"Top domain count ({max_count}) seems too low for a ~{total_lines} line log. "
            "The bugs may not be fully fixed."
        )


class TestLogFileUnchanged:
    """Tests that the log file was not modified."""

    def test_log_file_unchanged(self):
        """Verify /var/log/named/query.log still exists and has expected size."""
        log_path = "/var/log/named/query.log"

        assert os.path.exists(log_path), (
            f"Log file {log_path} no longer exists. It should not be modified."
        )

        result = subprocess.run(
            ["wc", "-l", log_path],
            capture_output=True,
            text=True
        )
        line_count = int(result.stdout.split()[0])

        assert 40000 <= line_count <= 60000, (
            f"Log file has {line_count} lines, expected ~50,000. "
            "The log file should not have been modified."
        )
