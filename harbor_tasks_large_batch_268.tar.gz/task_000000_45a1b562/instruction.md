I've been chasing a weird pattern in our log ingestion pipeline at /home/user/logpipe — about 15% of lines from the raw input are vanishing somewhere between intake and the final jsonl output. The pipeline's three stages: parse.py reads raw logs, enrich.py adds geo data, then output.py writes the jsonl. Each stage dumps to an intermediate file so I can debug, but I haven't had time to actually diff them properly.

    The raw input is /home/user/logpipe/data/access.log (1000 lines), and the final output lands in /home/user/logpipe/data/final.jsonl. Running `./run_pipeline.sh` does the whole thing sequentially. Last run gave me 847 lines out, which is way off.

    Pretty sure it's not a parsing regex issue because I tested that months ago, but honestly could be anything at this point. Just need all 1000 lines making it through.
