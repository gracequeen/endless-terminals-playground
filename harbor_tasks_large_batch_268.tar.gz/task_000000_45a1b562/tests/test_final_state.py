# test_final_state.py
"""
Tests to validate the final state of the OS/filesystem after the student
has completed the log pipeline debugging task.

The task requires fixing the pipeline so that all 1000 lines from access.log
make it through to final.jsonl without duplicates.
"""

import os
import subprocess
import json
import hashlib
import sqlite3
import pytest


BASE_DIR = "/home/user/logpipe"
DATA_DIR = os.path.join(BASE_DIR, "data")
CONFIG_DIR = os.path.join(BASE_DIR, "config")


class TestDirectoryStructurePreserved:
    """Verify the expected directory structure still exists."""

    def test_logpipe_directory_exists(self):
        assert os.path.isdir(BASE_DIR), f"Directory {BASE_DIR} does not exist"

    def test_data_directory_exists(self):
        assert os.path.isdir(DATA_DIR), f"Directory {DATA_DIR} does not exist"

    def test_config_directory_exists(self):
        assert os.path.isdir(CONFIG_DIR), f"Directory {CONFIG_DIR} does not exist"


class TestPipelineScriptsPreserved:
    """Verify the three-stage pipeline structure remains intact."""

    def test_run_pipeline_script_exists(self):
        script_path = os.path.join(BASE_DIR, "run_pipeline.sh")
        assert os.path.isfile(script_path), f"Pipeline script {script_path} does not exist"

    def test_run_pipeline_script_is_executable(self):
        script_path = os.path.join(BASE_DIR, "run_pipeline.sh")
        assert os.access(script_path, os.X_OK), f"Pipeline script {script_path} is not executable"

    def test_parse_py_exists(self):
        script_path = os.path.join(BASE_DIR, "parse.py")
        assert os.path.isfile(script_path), f"Script {script_path} does not exist"

    def test_enrich_py_exists(self):
        script_path = os.path.join(BASE_DIR, "enrich.py")
        assert os.path.isfile(script_path), f"Script {script_path} does not exist"

    def test_output_py_exists(self):
        script_path = os.path.join(BASE_DIR, "output.py")
        assert os.path.isfile(script_path), f"Script {script_path} does not exist"


class TestInvariantFilesUnmodified:
    """Verify that files that should not be modified remain unchanged."""

    def test_access_log_has_1000_lines(self):
        """access.log must remain unmodified with exactly 1000 lines."""
        log_path = os.path.join(DATA_DIR, "access.log")
        assert os.path.isfile(log_path), f"Input log file {log_path} does not exist"

        with open(log_path, 'r') as f:
            line_count = sum(1 for _ in f)
        assert line_count == 1000, (
            f"access.log should have 1000 lines (must remain unmodified), "
            f"but has {line_count}"
        )

    def test_geo_db_exists_and_is_valid(self):
        """geo.db must remain unmodified and be a valid SQLite database."""
        db_path = os.path.join(DATA_DIR, "geo.db")
        assert os.path.isfile(db_path), f"Geo database {db_path} does not exist"

        try:
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
            tables = cursor.fetchall()
            conn.close()
            assert len(tables) > 0, f"Geo database {db_path} has no tables"
        except sqlite3.Error as e:
            pytest.fail(f"Geo database {db_path} is not a valid SQLite database: {e}")


class TestPipelineExecution:
    """Verify the pipeline runs successfully and produces correct output."""

    @pytest.fixture(scope="class")
    def pipeline_result(self):
        """Run the pipeline once and return the result."""
        result = subprocess.run(
            ["./run_pipeline.sh"],
            cwd=BASE_DIR,
            capture_output=True,
            text=True
        )
        return result

    def test_pipeline_exits_with_zero(self, pipeline_result):
        """Pipeline must complete with exit code 0."""
        assert pipeline_result.returncode == 0, (
            f"Pipeline failed with return code {pipeline_result.returncode}\n"
            f"stdout: {pipeline_result.stdout}\n"
            f"stderr: {pipeline_result.stderr}"
        )


class TestIntermediateFiles:
    """Verify all intermediate files have exactly 1000 lines."""

    @pytest.fixture(scope="class", autouse=True)
    def run_pipeline(self):
        """Ensure pipeline has been run before testing intermediate files."""
        subprocess.run(["./run_pipeline.sh"], cwd=BASE_DIR, capture_output=True)

    def test_parsed_jsonl_has_1000_lines(self):
        """parsed.jsonl must have exactly 1000 lines."""
        parsed_path = os.path.join(DATA_DIR, "parsed.jsonl")
        assert os.path.isfile(parsed_path), (
            f"Intermediate file {parsed_path} was not created. "
            "The three-stage pipeline structure must be preserved."
        )

        with open(parsed_path, 'r') as f:
            line_count = sum(1 for _ in f)
        assert line_count == 1000, (
            f"parsed.jsonl must have exactly 1000 lines, but has {line_count}"
        )

    def test_enriched_jsonl_has_1000_lines(self):
        """enriched.jsonl must have exactly 1000 lines (fix for enrich.py bug)."""
        enriched_path = os.path.join(DATA_DIR, "enriched.jsonl")
        assert os.path.isfile(enriched_path), (
            f"Intermediate file {enriched_path} was not created. "
            "The three-stage pipeline structure must be preserved."
        )

        with open(enriched_path, 'r') as f:
            line_count = sum(1 for _ in f)
        assert line_count == 1000, (
            f"enriched.jsonl must have exactly 1000 lines after fixing enrich.py, "
            f"but has {line_count}. The bug in enrich.py that silently drops lines "
            "when geo lookup fails must be fixed."
        )

    def test_final_jsonl_has_1000_lines(self):
        """final.jsonl must have exactly 1000 lines."""
        final_path = os.path.join(DATA_DIR, "final.jsonl")
        assert os.path.isfile(final_path), f"Output file {final_path} was not created"

        with open(final_path, 'r') as f:
            line_count = sum(1 for _ in f)
        assert line_count == 1000, (
            f"final.jsonl must have exactly 1000 lines, but has {line_count}. "
            "Both bugs must be fixed: enrich.py dropping lines on geo lookup failure, "
            "and output.yaml exclude_statuses filtering out valid entries."
        )


class TestFinalJsonlContent:
    """Verify the content of final.jsonl is valid and complete."""

    @pytest.fixture(scope="class")
    def final_records(self):
        """Load all records from final.jsonl."""
        subprocess.run(["./run_pipeline.sh"], cwd=BASE_DIR, capture_output=True)
        final_path = os.path.join(DATA_DIR, "final.jsonl")
        records = []
        with open(final_path, 'r') as f:
            for line_num, line in enumerate(f, 1):
                line = line.strip()
                if line:
                    try:
                        record = json.loads(line)
                        records.append(record)
                    except json.JSONDecodeError as e:
                        pytest.fail(
                            f"Line {line_num} in final.jsonl is not valid JSON: {e}\n"
                            f"Content: {line[:100]}..."
                        )
        return records

    def test_all_lines_are_valid_json(self, final_records):
        """Each line must be valid JSON."""
        # This is implicitly tested by the fixture loading
        assert len(final_records) == 1000, (
            f"Expected 1000 valid JSON records, got {len(final_records)}"
        )

    def test_records_have_required_fields(self, final_records):
        """Each record must have timestamp, ip, method, path, and status fields."""
        required_fields = {'timestamp', 'ip', 'method', 'path', 'status'}

        for i, record in enumerate(final_records):
            missing = required_fields - set(record.keys())
            assert not missing, (
                f"Record {i+1} is missing required fields: {missing}\n"
                f"Record: {record}"
            )

    def test_no_duplicate_records(self, final_records):
        """Each output line must correspond to exactly one input line (no duplicates)."""
        # Create a unique key for each record based on ip and path
        seen = {}
        duplicates = []

        for i, record in enumerate(final_records):
            # Use ip + path as a unique identifier (as per the grader check)
            key = f"{record.get('ip', '')} {record.get('path', '')}"
            if key in seen:
                duplicates.append((i + 1, seen[key], key))
            else:
                seen[key] = i + 1

        assert not duplicates, (
            f"Found duplicate records (same ip + path combination):\n"
            + "\n".join(
                f"  Lines {dup[0]} and {dup[1]}: {dup[2]}"
                for dup in duplicates[:10]
            )
            + (f"\n  ... and {len(duplicates) - 10} more" if len(duplicates) > 10 else "")
        )

    def test_status_field_is_numeric(self, final_records):
        """Status field should be numeric (HTTP status code)."""
        for i, record in enumerate(final_records):
            status = record.get('status')
            assert status is not None, f"Record {i+1} has null status"
            # Status could be int or string representation of int
            try:
                status_int = int(status)
                assert 100 <= status_int <= 599, (
                    f"Record {i+1} has invalid HTTP status code: {status}"
                )
            except (ValueError, TypeError):
                pytest.fail(f"Record {i+1} has non-numeric status: {status}")

    def test_ip_field_is_present(self, final_records):
        """IP field should be present and non-empty."""
        for i, record in enumerate(final_records):
            ip = record.get('ip')
            assert ip is not None and ip != '', (
                f"Record {i+1} has missing or empty IP field"
            )


class TestGeoFieldHandling:
    """Verify that geo field handling is correct (can be null for private IPs)."""

    @pytest.fixture(scope="class")
    def final_records(self):
        """Load all records from final.jsonl."""
        subprocess.run(["./run_pipeline.sh"], cwd=BASE_DIR, capture_output=True)
        final_path = os.path.join(DATA_DIR, "final.jsonl")
        records = []
        with open(final_path, 'r') as f:
            for line in f:
                line = line.strip()
                if line:
                    records.append(json.loads(line))
        return records

    def test_private_ips_are_included(self, final_records):
        """Records with private IPs (10.x.x.x) must be included in output."""
        private_ip_records = [
            r for r in final_records
            if r.get('ip', '').startswith('10.')
        ]
        # There should be some private IP records (the bug was dropping these)
        # We don't know the exact count, but there should be some
        assert len(private_ip_records) > 0, (
            "No records with private IPs (10.x.x.x) found in final.jsonl. "
            "The fix for enrich.py should preserve lines even when geo lookup fails."
        )


class TestPipelineStructureIntegrity:
    """Verify the pipeline still follows the three-stage structure."""

    def test_run_pipeline_calls_all_three_scripts(self):
        """run_pipeline.sh should still call parse.py, enrich.py, and output.py."""
        script_path = os.path.join(BASE_DIR, "run_pipeline.sh")
        with open(script_path, 'r') as f:
            content = f.read()

        assert 'parse.py' in content or 'parse' in content, (
            "run_pipeline.sh should call parse.py"
        )
        assert 'enrich.py' in content or 'enrich' in content, (
            "run_pipeline.sh should call enrich.py"
        )
        assert 'output.py' in content or 'output' in content, (
            "run_pipeline.sh should call output.py"
        )


class TestAntiShortcutGuards:
    """Additional tests to prevent shortcut solutions."""

    @pytest.fixture(scope="class")
    def run_and_get_files(self):
        """Run pipeline and return file contents."""
        subprocess.run(["./run_pipeline.sh"], cwd=BASE_DIR, capture_output=True)
        return {
            'parsed': os.path.join(DATA_DIR, "parsed.jsonl"),
            'enriched': os.path.join(DATA_DIR, "enriched.jsonl"),
            'final': os.path.join(DATA_DIR, "final.jsonl"),
        }

    def test_all_intermediate_files_exist(self, run_and_get_files):
        """All intermediate files must be created by the pipeline."""
        for name, path in run_and_get_files.items():
            assert os.path.isfile(path), (
                f"Intermediate file {path} does not exist. "
                "The three-stage pipeline must produce all intermediate files."
            )

    def test_enriched_is_not_copy_of_parsed(self, run_and_get_files):
        """enriched.jsonl should have additional geo data, not be identical to parsed.jsonl."""
        parsed_path = run_and_get_files['parsed']
        enriched_path = run_and_get_files['enriched']

        with open(parsed_path, 'r') as f:
            parsed_first = f.readline().strip()

        with open(enriched_path, 'r') as f:
            enriched_first = f.readline().strip()

        if parsed_first and enriched_first:
            parsed_record = json.loads(parsed_first)
            enriched_record = json.loads(enriched_first)

            # Enriched should have geo field (even if null)
            # or at least be processed differently
            assert 'geo' in enriched_record or enriched_record != parsed_record, (
                "enriched.jsonl appears to be unprocessed. "
                "enrich.py should add geo data to records."
            )

    def test_final_records_match_input_count(self, run_and_get_files):
        """Final output must have exactly as many records as input."""
        access_log = os.path.join(DATA_DIR, "access.log")
        final_path = run_and_get_files['final']

        with open(access_log, 'r') as f:
            input_count = sum(1 for _ in f)

        with open(final_path, 'r') as f:
            output_count = sum(1 for _ in f)

        assert output_count == input_count, (
            f"Final output has {output_count} lines but input has {input_count} lines. "
            "All input lines must make it through the pipeline."
        )
