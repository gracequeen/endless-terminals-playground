# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the log pipeline debugging task.
"""

import os
import subprocess
import sqlite3
import pytest


BASE_DIR = "/home/user/logpipe"
DATA_DIR = os.path.join(BASE_DIR, "data")
CONFIG_DIR = os.path.join(BASE_DIR, "config")


class TestDirectoryStructure:
    """Verify the expected directory structure exists."""

    def test_logpipe_directory_exists(self):
        assert os.path.isdir(BASE_DIR), f"Directory {BASE_DIR} does not exist"

    def test_data_directory_exists(self):
        assert os.path.isdir(DATA_DIR), f"Directory {DATA_DIR} does not exist"

    def test_config_directory_exists(self):
        assert os.path.isdir(CONFIG_DIR), f"Directory {CONFIG_DIR} does not exist"


class TestPipelineScripts:
    """Verify the pipeline scripts exist and are properly configured."""

    def test_run_pipeline_script_exists(self):
        script_path = os.path.join(BASE_DIR, "run_pipeline.sh")
        assert os.path.isfile(script_path), f"Pipeline script {script_path} does not exist"

    def test_run_pipeline_script_is_executable(self):
        script_path = os.path.join(BASE_DIR, "run_pipeline.sh")
        assert os.access(script_path, os.X_OK), f"Pipeline script {script_path} is not executable"

    def test_parse_py_exists(self):
        script_path = os.path.join(BASE_DIR, "parse.py")
        assert os.path.isfile(script_path), f"Script {script_path} does not exist"

    def test_enrich_py_exists(self):
        script_path = os.path.join(BASE_DIR, "enrich.py")
        assert os.path.isfile(script_path), f"Script {script_path} does not exist"

    def test_output_py_exists(self):
        script_path = os.path.join(BASE_DIR, "output.py")
        assert os.path.isfile(script_path), f"Script {script_path} does not exist"


class TestDataFiles:
    """Verify the required data files exist with expected properties."""

    def test_access_log_exists(self):
        log_path = os.path.join(DATA_DIR, "access.log")
        assert os.path.isfile(log_path), f"Input log file {log_path} does not exist"

    def test_access_log_has_1000_lines(self):
        log_path = os.path.join(DATA_DIR, "access.log")
        with open(log_path, 'r') as f:
            line_count = sum(1 for _ in f)
        assert line_count == 1000, f"access.log should have 1000 lines, but has {line_count}"

    def test_geo_db_exists(self):
        db_path = os.path.join(DATA_DIR, "geo.db")
        assert os.path.isfile(db_path), f"Geo database {db_path} does not exist"

    def test_geo_db_is_valid_sqlite(self):
        db_path = os.path.join(DATA_DIR, "geo.db")
        try:
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            # Check that we can query it (it should have some table)
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
            tables = cursor.fetchall()
            conn.close()
            assert len(tables) > 0, f"Geo database {db_path} has no tables"
        except sqlite3.Error as e:
            pytest.fail(f"Geo database {db_path} is not a valid SQLite database: {e}")


class TestConfigFiles:
    """Verify the configuration files exist."""

    def test_enrichment_yaml_exists(self):
        config_path = os.path.join(CONFIG_DIR, "enrichment.yaml")
        assert os.path.isfile(config_path), f"Config file {config_path} does not exist"

    def test_output_yaml_exists(self):
        config_path = os.path.join(CONFIG_DIR, "output.yaml")
        assert os.path.isfile(config_path), f"Config file {config_path} does not exist"


class TestPipelineRunsButProducesIncorrectOutput:
    """Verify the pipeline runs but produces the buggy output (847 lines)."""

    def test_pipeline_executes_successfully(self):
        """The pipeline should run without crashing."""
        result = subprocess.run(
            ["./run_pipeline.sh"],
            cwd=BASE_DIR,
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"Pipeline failed to execute. Return code: {result.returncode}\n"
            f"stdout: {result.stdout}\n"
            f"stderr: {result.stderr}"
        )

    def test_parsed_jsonl_has_1000_lines(self):
        """parse.py should correctly produce 1000 lines."""
        # First run the pipeline
        subprocess.run(["./run_pipeline.sh"], cwd=BASE_DIR, capture_output=True)

        parsed_path = os.path.join(DATA_DIR, "parsed.jsonl")
        assert os.path.isfile(parsed_path), f"Intermediate file {parsed_path} was not created"

        with open(parsed_path, 'r') as f:
            line_count = sum(1 for _ in f)
        assert line_count == 1000, (
            f"parsed.jsonl should have 1000 lines (parse.py works correctly), "
            f"but has {line_count}"
        )

    def test_enriched_jsonl_has_fewer_than_1000_lines(self):
        """enrich.py should be dropping lines (the bug)."""
        # First run the pipeline
        subprocess.run(["./run_pipeline.sh"], cwd=BASE_DIR, capture_output=True)

        enriched_path = os.path.join(DATA_DIR, "enriched.jsonl")
        assert os.path.isfile(enriched_path), f"Intermediate file {enriched_path} was not created"

        with open(enriched_path, 'r') as f:
            line_count = sum(1 for _ in f)
        # Should be around 920 lines (dropping ~80 private IPs)
        assert line_count < 1000, (
            f"enriched.jsonl should have fewer than 1000 lines due to the bug in enrich.py, "
            f"but has {line_count}"
        )
        assert line_count > 800, (
            f"enriched.jsonl should have around 920 lines, but has {line_count}"
        )

    def test_final_jsonl_has_847_lines(self):
        """output.py should produce approximately 847 lines (the buggy state)."""
        # First run the pipeline
        subprocess.run(["./run_pipeline.sh"], cwd=BASE_DIR, capture_output=True)

        final_path = os.path.join(DATA_DIR, "final.jsonl")
        assert os.path.isfile(final_path), f"Output file {final_path} was not created"

        with open(final_path, 'r') as f:
            line_count = sum(1 for _ in f)
        # Should be around 847 lines as stated in the task
        assert 840 <= line_count <= 860, (
            f"final.jsonl should have approximately 847 lines in the buggy state, "
            f"but has {line_count}"
        )


class TestPythonEnvironment:
    """Verify Python and required packages are available."""

    def test_python3_available(self):
        result = subprocess.run(
            ["python3", "--version"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "Python 3 is not available"

    def test_pyyaml_available(self):
        result = subprocess.run(
            ["python3", "-c", "import yaml"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"PyYAML is not available: {result.stderr}"
        )

    def test_sqlite3_available(self):
        result = subprocess.run(
            ["python3", "-c", "import sqlite3"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"sqlite3 module is not available: {result.stderr}"
        )


class TestFilesAreWritable:
    """Verify that files under /home/user/logpipe are writable."""

    def test_logpipe_directory_is_writable(self):
        assert os.access(BASE_DIR, os.W_OK), f"Directory {BASE_DIR} is not writable"

    def test_data_directory_is_writable(self):
        assert os.access(DATA_DIR, os.W_OK), f"Directory {DATA_DIR} is not writable"

    def test_config_directory_is_writable(self):
        assert os.access(CONFIG_DIR, os.W_OK), f"Directory {CONFIG_DIR} is not writable"

    def test_enrich_py_is_writable(self):
        script_path = os.path.join(BASE_DIR, "enrich.py")
        assert os.access(script_path, os.W_OK), f"Script {script_path} is not writable"

    def test_output_py_is_writable(self):
        script_path = os.path.join(BASE_DIR, "output.py")
        assert os.access(script_path, os.W_OK), f"Script {script_path} is not writable"

    def test_output_yaml_is_writable(self):
        config_path = os.path.join(CONFIG_DIR, "output.yaml")
        assert os.access(config_path, os.W_OK), f"Config file {config_path} is not writable"
