# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the task of finding and removing the setgid reapplication mechanism.
"""

import os
import pwd
import grp
import stat
import subprocess
import pytest


class TestInitialState:
    """Validate the initial state matches the expected setup."""

    def test_webapp_uploads_directory_exists(self):
        """Verify /home/user/webapp/uploads directory exists."""
        path = "/home/user/webapp/uploads"
        assert os.path.exists(path), f"Directory {path} does not exist"
        assert os.path.isdir(path), f"{path} exists but is not a directory"

    def test_webuser_exists(self):
        """Verify webuser exists in /etc/passwd."""
        try:
            pwd.getpwnam("webuser")
        except KeyError:
            pytest.fail("User 'webuser' does not exist in /etc/passwd")

    def test_webgroup_exists(self):
        """Verify webgroup exists in /etc/group."""
        try:
            grp.getgrnam("webgroup")
        except KeyError:
            pytest.fail("Group 'webgroup' does not exist in /etc/group")

    def test_uploads_owned_by_webuser_webgroup(self):
        """Verify /home/user/webapp/uploads is owned by webuser:webgroup."""
        path = "/home/user/webapp/uploads"
        st = os.stat(path)

        # Get expected uid/gid
        expected_uid = pwd.getpwnam("webuser").pw_uid
        expected_gid = grp.getgrnam("webgroup").gr_gid

        assert st.st_uid == expected_uid, (
            f"{path} is owned by uid {st.st_uid}, expected uid {expected_uid} (webuser)"
        )
        assert st.st_gid == expected_gid, (
            f"{path} has gid {st.st_gid}, expected gid {expected_gid} (webgroup)"
        )

    def test_uploads_has_setgid_bit_set(self):
        """Verify /home/user/webapp/uploads has setgid bit set (mode 2755)."""
        path = "/home/user/webapp/uploads"
        st = os.stat(path)
        mode = stat.S_IMODE(st.st_mode)

        # Check for setgid bit (0o2000)
        has_setgid = bool(mode & stat.S_ISGID)
        assert has_setgid, (
            f"{path} does not have setgid bit set. "
            f"Current mode: {oct(mode)}, expected mode with setgid: 2755"
        )

        # Verify the full mode is 2755
        assert mode == 0o2755, (
            f"{path} has mode {oct(mode)}, expected 2755 (0o2755)"
        )

    def test_fix_perms_script_exists(self):
        """Verify /home/user/.local/bin/fix-perms.sh exists."""
        path = "/home/user/.local/bin/fix-perms.sh"
        assert os.path.exists(path), f"Script {path} does not exist"
        assert os.path.isfile(path), f"{path} exists but is not a file"

    def test_fix_perms_script_is_executable(self):
        """Verify /home/user/.local/bin/fix-perms.sh is executable."""
        path = "/home/user/.local/bin/fix-perms.sh"
        assert os.access(path, os.X_OK), f"Script {path} is not executable"

    def test_fix_perms_script_contains_setgid_command(self):
        """Verify the fix-perms.sh script contains the setgid command."""
        path = "/home/user/.local/bin/fix-perms.sh"
        with open(path, "r") as f:
            content = f.read()

        assert "chmod g+s /home/user/webapp/uploads" in content, (
            f"Script {path} does not contain the expected 'chmod g+s /home/user/webapp/uploads' command"
        )

    def test_user_crontab_exists_with_fix_perms_entry(self):
        """Verify user's crontab contains the fix-perms.sh entry."""
        crontab_path = "/var/spool/cron/crontabs/user"

        # Check if crontab file exists
        if os.path.exists(crontab_path):
            with open(crontab_path, "r") as f:
                content = f.read()
            assert "fix-perms.sh" in content, (
                f"Crontab at {crontab_path} does not contain fix-perms.sh entry"
            )
        else:
            # Try using crontab -l command as fallback
            try:
                result = subprocess.run(
                    ["crontab", "-l"],
                    capture_output=True,
                    text=True,
                    timeout=5
                )
                assert "fix-perms.sh" in result.stdout, (
                    "User crontab does not contain fix-perms.sh entry"
                )
            except (subprocess.TimeoutExpired, FileNotFoundError) as e:
                pytest.fail(f"Could not verify crontab: {e}")

    def test_cron_service_is_running(self):
        """Verify cron daemon is running."""
        # Try multiple methods to check if cron is running
        cron_running = False

        # Method 1: Check with pgrep
        try:
            result = subprocess.run(
                ["pgrep", "-x", "cron"],
                capture_output=True,
                timeout=5
            )
            if result.returncode == 0:
                cron_running = True
        except (subprocess.TimeoutExpired, FileNotFoundError):
            pass

        # Method 2: Check with pgrep for crond (some systems use crond)
        if not cron_running:
            try:
                result = subprocess.run(
                    ["pgrep", "-x", "crond"],
                    capture_output=True,
                    timeout=5
                )
                if result.returncode == 0:
                    cron_running = True
            except (subprocess.TimeoutExpired, FileNotFoundError):
                pass

        # Method 3: Check process list
        if not cron_running:
            try:
                result = subprocess.run(
                    ["ps", "aux"],
                    capture_output=True,
                    text=True,
                    timeout=5
                )
                if "cron" in result.stdout.lower():
                    cron_running = True
            except (subprocess.TimeoutExpired, FileNotFoundError):
                pass

        assert cron_running, "Cron daemon is not running"

    def test_webapp_cache_does_not_exist(self):
        """Verify /home/user/webapp/cache does not exist."""
        path = "/home/user/webapp/cache"
        assert not os.path.exists(path), (
            f"{path} exists but should not exist according to initial state"
        )

    def test_user_has_write_access_to_fix_perms_script(self):
        """Verify agent user has write access to fix-perms.sh."""
        path = "/home/user/.local/bin/fix-perms.sh"
        assert os.access(path, os.W_OK), (
            f"User does not have write access to {path}"
        )

    def test_user_home_directory_exists(self):
        """Verify /home/user directory exists."""
        path = "/home/user"
        assert os.path.exists(path), f"Home directory {path} does not exist"
        assert os.path.isdir(path), f"{path} exists but is not a directory"

    def test_local_bin_directory_exists(self):
        """Verify /home/user/.local/bin directory exists."""
        path = "/home/user/.local/bin"
        assert os.path.exists(path), f"Directory {path} does not exist"
        assert os.path.isdir(path), f"{path} exists but is not a directory"
