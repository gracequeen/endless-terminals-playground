# test_final_state.py
"""
Tests to validate the final state of the OS/filesystem after the student
has completed the task of removing the setgid reapplication mechanism.
"""

import os
import pwd
import grp
import stat
import subprocess
import time
import pytest


class TestFinalState:
    """Validate the final state matches the expected outcome."""

    def test_webapp_uploads_directory_exists(self):
        """Verify /home/user/webapp/uploads directory still exists."""
        path = "/home/user/webapp/uploads"
        assert os.path.exists(path), f"Directory {path} does not exist - it should not have been deleted"
        assert os.path.isdir(path), f"{path} exists but is not a directory"

    def test_uploads_owned_by_webuser_webgroup(self):
        """Verify /home/user/webapp/uploads is still owned by webuser:webgroup."""
        path = "/home/user/webapp/uploads"
        st = os.stat(path)

        # Get expected uid/gid
        expected_uid = pwd.getpwnam("webuser").pw_uid
        expected_gid = grp.getgrnam("webgroup").gr_gid

        assert st.st_uid == expected_uid, (
            f"{path} is owned by uid {st.st_uid}, expected uid {expected_uid} (webuser). "
            "Ownership should not have changed."
        )
        assert st.st_gid == expected_gid, (
            f"{path} has gid {st.st_gid}, expected gid {expected_gid} (webgroup). "
            "Ownership should not have changed."
        )

    def test_uploads_has_mode_755_no_special_bits(self):
        """Verify /home/user/webapp/uploads has mode exactly 0755 (no setgid, setuid, or sticky)."""
        path = "/home/user/webapp/uploads"
        st = os.stat(path)
        mode = stat.S_IMODE(st.st_mode)

        # Check that no special bits are set
        has_setuid = bool(mode & stat.S_ISUID)
        has_setgid = bool(mode & stat.S_ISGID)
        has_sticky = bool(mode & stat.S_ISVTX)

        assert not has_setuid, (
            f"{path} has setuid bit set (mode {oct(mode)}). "
            "The setuid bit should not be present."
        )
        assert not has_setgid, (
            f"{path} still has setgid bit set (mode {oct(mode)}). "
            "The setgid bit should have been removed."
        )
        assert not has_sticky, (
            f"{path} has sticky bit set (mode {oct(mode)}). "
            "The sticky bit should not be present."
        )

        # Verify the full mode is exactly 0755
        assert mode == 0o755, (
            f"{path} has mode {oct(mode)}, expected exactly 0755 (0o755). "
            "Mode should be plain 755 with no special bits."
        )

    def test_stat_command_returns_755(self):
        """Verify stat -c '%a' returns 755."""
        path = "/home/user/webapp/uploads"
        result = subprocess.run(
            ["stat", "-c", "%a", path],
            capture_output=True,
            text=True,
            timeout=5
        )

        assert result.returncode == 0, f"stat command failed: {result.stderr}"
        mode_str = result.stdout.strip()
        assert mode_str == "755", (
            f"stat -c '%a' {path} returned '{mode_str}', expected '755'. "
            "The directory should have plain 755 permissions."
        )

    def test_cron_job_disabled_or_script_neutered(self):
        """Verify the cron job is disabled or the script no longer applies setgid."""
        crontab_path = "/var/spool/cron/crontabs/user"
        script_path = "/home/user/.local/bin/fix-perms.sh"

        cron_entry_active = False
        script_applies_setgid = False

        # Check if crontab still has active entry for fix-perms.sh
        if os.path.exists(crontab_path):
            with open(crontab_path, "r") as f:
                for line in f:
                    line = line.strip()
                    # Skip comments and empty lines
                    if line.startswith("#") or not line:
                        continue
                    if "fix-perms.sh" in line:
                        cron_entry_active = True
                        break
        else:
            # Try crontab -l as fallback
            try:
                result = subprocess.run(
                    ["crontab", "-l"],
                    capture_output=True,
                    text=True,
                    timeout=5
                )
                if result.returncode == 0:
                    for line in result.stdout.splitlines():
                        line = line.strip()
                        if line.startswith("#") or not line:
                            continue
                        if "fix-perms.sh" in line:
                            cron_entry_active = True
                            break
            except (subprocess.TimeoutExpired, FileNotFoundError):
                pass

        # Check if script still applies setgid to uploads
        if os.path.exists(script_path):
            with open(script_path, "r") as f:
                content = f.read()
            # Check if the script still has active setgid command for uploads
            for line in content.splitlines():
                line = line.strip()
                if line.startswith("#"):
                    continue
                if "chmod" in line and "g+s" in line and "/home/user/webapp/uploads" in line:
                    script_applies_setgid = True
                    break

        # The task is complete if either:
        # 1. The cron entry is removed/commented out, OR
        # 2. The script is deleted, OR
        # 3. The script no longer applies setgid to uploads

        if cron_entry_active and script_applies_setgid:
            pytest.fail(
                "The cron job is still active AND the script still applies setgid. "
                "Either remove/comment the cron entry, delete the script, or modify "
                "the script to not apply setgid to /home/user/webapp/uploads."
            )

    def test_cron_daemon_still_running(self):
        """Verify cron daemon is still running (shouldn't be killed entirely)."""
        cron_running = False

        # Method 1: Check with pgrep for cron
        try:
            result = subprocess.run(
                ["pgrep", "-x", "cron"],
                capture_output=True,
                timeout=5
            )
            if result.returncode == 0:
                cron_running = True
        except (subprocess.TimeoutExpired, FileNotFoundError):
            pass

        # Method 2: Check with pgrep for crond
        if not cron_running:
            try:
                result = subprocess.run(
                    ["pgrep", "-x", "crond"],
                    capture_output=True,
                    timeout=5
                )
                if result.returncode == 0:
                    cron_running = True
            except (subprocess.TimeoutExpired, FileNotFoundError):
                pass

        # Method 3: Check process list
        if not cron_running:
            try:
                result = subprocess.run(
                    ["ps", "aux"],
                    capture_output=True,
                    text=True,
                    timeout=5
                )
                for line in result.stdout.lower().splitlines():
                    # Look for cron daemon process (not just any process with 'cron' in name)
                    if "cron" in line and ("sbin" in line or "/cron" in line or "crond" in line):
                        cron_running = True
                        break
            except (subprocess.TimeoutExpired, FileNotFoundError):
                pass

        assert cron_running, (
            "Cron daemon is not running. The task was to disable the specific cron job, "
            "not to kill the cron daemon entirely."
        )

    def test_setgid_does_not_reappear_after_delay(self):
        """
        Verify that after waiting 90 seconds, the setgid bit does not reappear.
        This confirms the cron job has been properly disabled.
        """
        path = "/home/user/webapp/uploads"

        # First verify current state is correct
        st = os.stat(path)
        mode = stat.S_IMODE(st.st_mode)
        assert mode == 0o755, (
            f"Before delay check: {path} has mode {oct(mode)}, expected 0755"
        )

        # Wait 90 seconds for any cron job to potentially run
        time.sleep(90)

        # Check the mode again
        st = os.stat(path)
        mode = stat.S_IMODE(st.st_mode)

        has_setgid = bool(mode & stat.S_ISGID)
        assert not has_setgid, (
            f"After 90 second delay, {path} has setgid bit set again (mode {oct(mode)}). "
            "The cron job that reapplies setgid is still active. "
            "You need to disable or remove the cron entry, or neuter the script."
        )

        assert mode == 0o755, (
            f"After 90 second delay, {path} has mode {oct(mode)}, expected 0755. "
            "Something is still modifying the permissions."
        )

    def test_stat_returns_755_after_delay(self):
        """
        Additional verification using stat command after the delay.
        This test runs after the delay test to confirm final state.
        """
        path = "/home/user/webapp/uploads"
        result = subprocess.run(
            ["stat", "-c", "%a", path],
            capture_output=True,
            text=True,
            timeout=5
        )

        assert result.returncode == 0, f"stat command failed: {result.stderr}"
        mode_str = result.stdout.strip()
        assert mode_str == "755", (
            f"Final check: stat -c '%a' {path} returned '{mode_str}', expected '755'. "
            "The setgid bit may have been reapplied by the cron job."
        )
