I'm doing a permissions audit on /home/user/webapp and something's off. There's a setgid bit on the uploads directory that shouldn't be there — we don't use group inheritance for new files, never have. I cleared it with chmod yesterday but it's back this morning. Pretty sure there's a cron or script somewhere that's resetting it, but I haven't found it yet.

Need you to track down whatever's reapplying that setgid and kill it, then clear the bit for real. The uploads dir should just be plain 755 owned by webuser:webgroup, no special bits.
