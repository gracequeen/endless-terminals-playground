Users in /home/user/managed_accounts keep complaining their pip installs "work" but then imports fail. I've got three test accounts set up there — alice, bob, carol — each with their own venv. Running `pip install requests` inside each venv exits 0, says "Successfully installed", but then `python -c "import requests"` throws ModuleNotFoundError. Same story for any package.

I checked and pip is definitely the venv's pip (which pip shows the venv path), python is the venv's python, the site-packages dirs exist and have write perms. Honestly stumped. Something's misconfigured in how these venvs were created but I can't figure out what — they all have the same weird behavior so it's probably systematic.

Fix whatever's broken so that for all three accounts, activating the venv and pip-installing actually makes packages importable. Don't just recreate the venvs from scratch, I need to understand what went wrong.
