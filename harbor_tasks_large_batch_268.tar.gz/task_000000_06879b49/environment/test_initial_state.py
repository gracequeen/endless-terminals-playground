# test_initial_state.py
"""
Tests to validate the initial state before the student performs the fix.
Verifies the broken venv configuration that causes pip installs to succeed
but imports to fail.
"""

import os
import subprocess
import pytest

MANAGED_ACCOUNTS_DIR = "/home/user/managed_accounts"
ACCOUNTS = ["alice", "bob", "carol"]
SYSTEM_PYTHON_PATH = "/usr/bin/python3"
BROKEN_HOME_PATH = "/opt/python3.10/bin"


class TestDirectoryStructure:
    """Test that the basic directory structure exists."""

    def test_managed_accounts_directory_exists(self):
        """The managed_accounts directory must exist."""
        assert os.path.isdir(MANAGED_ACCOUNTS_DIR), \
            f"Directory {MANAGED_ACCOUNTS_DIR} does not exist"

    @pytest.mark.parametrize("account", ACCOUNTS)
    def test_account_directory_exists(self, account):
        """Each account directory must exist."""
        account_dir = os.path.join(MANAGED_ACCOUNTS_DIR, account)
        assert os.path.isdir(account_dir), \
            f"Account directory {account_dir} does not exist"

    @pytest.mark.parametrize("account", ACCOUNTS)
    def test_venv_directory_exists(self, account):
        """Each account must have a venv directory."""
        venv_dir = os.path.join(MANAGED_ACCOUNTS_DIR, account, "venv")
        assert os.path.isdir(venv_dir), \
            f"Venv directory {venv_dir} does not exist"

    @pytest.mark.parametrize("account", ACCOUNTS)
    def test_venv_bin_directory_exists(self, account):
        """Each venv must have a bin directory."""
        bin_dir = os.path.join(MANAGED_ACCOUNTS_DIR, account, "venv", "bin")
        assert os.path.isdir(bin_dir), \
            f"Venv bin directory {bin_dir} does not exist"

    @pytest.mark.parametrize("account", ACCOUNTS)
    def test_venv_lib_directory_exists(self, account):
        """Each venv must have a lib directory."""
        lib_dir = os.path.join(MANAGED_ACCOUNTS_DIR, account, "venv", "lib")
        assert os.path.isdir(lib_dir), \
            f"Venv lib directory {lib_dir} does not exist"

    @pytest.mark.parametrize("account", ACCOUNTS)
    def test_site_packages_exists(self, account):
        """Each venv must have a site-packages directory."""
        site_packages = os.path.join(
            MANAGED_ACCOUNTS_DIR, account, "venv", "lib", "python3.10", "site-packages"
        )
        assert os.path.isdir(site_packages), \
            f"Site-packages directory {site_packages} does not exist"


class TestVenvFiles:
    """Test that required venv files exist."""

    @pytest.mark.parametrize("account", ACCOUNTS)
    def test_venv_python_exists(self, account):
        """Each venv must have a python executable."""
        python_path = os.path.join(MANAGED_ACCOUNTS_DIR, account, "venv", "bin", "python")
        assert os.path.exists(python_path), \
            f"Venv python {python_path} does not exist"

    @pytest.mark.parametrize("account", ACCOUNTS)
    def test_venv_pip_exists(self, account):
        """Each venv must have a pip executable."""
        pip_path = os.path.join(MANAGED_ACCOUNTS_DIR, account, "venv", "bin", "pip")
        assert os.path.exists(pip_path), \
            f"Venv pip {pip_path} does not exist"

    @pytest.mark.parametrize("account", ACCOUNTS)
    def test_pyvenv_cfg_exists(self, account):
        """Each venv must have a pyvenv.cfg file."""
        cfg_path = os.path.join(MANAGED_ACCOUNTS_DIR, account, "venv", "pyvenv.cfg")
        assert os.path.isfile(cfg_path), \
            f"pyvenv.cfg {cfg_path} does not exist"

    @pytest.mark.parametrize("account", ACCOUNTS)
    def test_original_marker_exists(self, account):
        """Each venv must have the .original_marker file (anti-recreation guard)."""
        marker_path = os.path.join(MANAGED_ACCOUNTS_DIR, account, "venv", ".original_marker")
        assert os.path.isfile(marker_path), \
            f"Original marker file {marker_path} does not exist - venv may have been recreated"


class TestBrokenConfiguration:
    """Test that the broken configuration is in place."""

    @pytest.mark.parametrize("account", ACCOUNTS)
    def test_pyvenv_cfg_has_broken_home(self, account):
        """The pyvenv.cfg must have the broken home path pointing to nonexistent directory."""
        cfg_path = os.path.join(MANAGED_ACCOUNTS_DIR, account, "venv", "pyvenv.cfg")

        with open(cfg_path, 'r') as f:
            content = f.read()

        # Check that the broken home path is present
        assert "home" in content.lower(), \
            f"pyvenv.cfg at {cfg_path} does not contain 'home' key"

        # Parse the home value
        home_value = None
        for line in content.splitlines():
            if line.strip().lower().startswith("home"):
                parts = line.split("=", 1)
                if len(parts) == 2:
                    home_value = parts[1].strip()
                    break

        assert home_value is not None, \
            f"Could not parse 'home' value from pyvenv.cfg at {cfg_path}"

        assert home_value == BROKEN_HOME_PATH, \
            f"pyvenv.cfg home should be '{BROKEN_HOME_PATH}' but is '{home_value}'"

    @pytest.mark.parametrize("account", ACCOUNTS)
    def test_broken_home_path_does_not_exist(self, account):
        """The broken home path should not exist on the system."""
        assert not os.path.exists(BROKEN_HOME_PATH), \
            f"The broken path {BROKEN_HOME_PATH} should not exist"

    @pytest.mark.parametrize("account", ACCOUNTS)
    def test_pip_conf_exists(self, account):
        """Each venv must have a pip.conf file with target directive."""
        pip_conf_path = os.path.join(MANAGED_ACCOUNTS_DIR, account, "venv", "pip.conf")
        assert os.path.isfile(pip_conf_path), \
            f"pip.conf {pip_conf_path} does not exist"

    @pytest.mark.parametrize("account", ACCOUNTS)
    def test_pip_conf_has_target_directive(self, account):
        """The pip.conf must have the target directive."""
        pip_conf_path = os.path.join(MANAGED_ACCOUNTS_DIR, account, "venv", "pip.conf")

        with open(pip_conf_path, 'r') as f:
            content = f.read()

        assert "[install]" in content, \
            f"pip.conf at {pip_conf_path} does not contain [install] section"

        expected_target = f"/home/user/managed_accounts/{account}/venv/lib/python3.10/site-packages"
        assert "target" in content.lower(), \
            f"pip.conf at {pip_conf_path} does not contain 'target' directive"
        assert expected_target in content, \
            f"pip.conf at {pip_conf_path} does not contain expected target path {expected_target}"


class TestSystemPython:
    """Test that system Python is properly installed."""

    def test_system_python_exists(self):
        """System python3 must exist at /usr/bin/python3."""
        assert os.path.exists(SYSTEM_PYTHON_PATH), \
            f"System Python not found at {SYSTEM_PYTHON_PATH}"

    def test_system_python_is_executable(self):
        """System python3 must be executable."""
        assert os.access(SYSTEM_PYTHON_PATH, os.X_OK), \
            f"System Python at {SYSTEM_PYTHON_PATH} is not executable"

    def test_system_python_version(self):
        """System Python should be Python 3.10."""
        result = subprocess.run(
            [SYSTEM_PYTHON_PATH, "--version"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            f"Failed to get Python version: {result.stderr}"
        assert "3.10" in result.stdout or "3.10" in result.stderr, \
            f"Expected Python 3.10, got: {result.stdout}{result.stderr}"


class TestPermissions:
    """Test that files are writable."""

    @pytest.mark.parametrize("account", ACCOUNTS)
    def test_pyvenv_cfg_is_writable(self, account):
        """pyvenv.cfg must be writable."""
        cfg_path = os.path.join(MANAGED_ACCOUNTS_DIR, account, "venv", "pyvenv.cfg")
        assert os.access(cfg_path, os.W_OK), \
            f"pyvenv.cfg at {cfg_path} is not writable"

    @pytest.mark.parametrize("account", ACCOUNTS)
    def test_pip_conf_is_writable(self, account):
        """pip.conf must be writable."""
        pip_conf_path = os.path.join(MANAGED_ACCOUNTS_DIR, account, "venv", "pip.conf")
        assert os.access(pip_conf_path, os.W_OK), \
            f"pip.conf at {pip_conf_path} is not writable"

    @pytest.mark.parametrize("account", ACCOUNTS)
    def test_venv_directory_is_writable(self, account):
        """Venv directory must be writable."""
        venv_dir = os.path.join(MANAGED_ACCOUNTS_DIR, account, "venv")
        assert os.access(venv_dir, os.W_OK), \
            f"Venv directory {venv_dir} is not writable"


class TestRequestsNotInstalled:
    """Test that requests is not yet installed in any venv."""

    @pytest.mark.parametrize("account", ACCOUNTS)
    def test_requests_not_in_site_packages(self, account):
        """requests package should not be installed yet."""
        site_packages = os.path.join(
            MANAGED_ACCOUNTS_DIR, account, "venv", "lib", "python3.10", "site-packages"
        )
        requests_dir = os.path.join(site_packages, "requests")
        assert not os.path.exists(requests_dir), \
            f"requests is already installed at {requests_dir} - should not be present initially"
