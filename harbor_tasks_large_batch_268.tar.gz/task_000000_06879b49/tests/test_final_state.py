# test_final_state.py
"""
Tests to validate the final state after the student has fixed the venv configuration.
Verifies that pip installs work correctly and packages are importable.
"""

import os
import subprocess
import pytest

MANAGED_ACCOUNTS_DIR = "/home/user/managed_accounts"
ACCOUNTS = ["alice", "bob", "carol"]


class TestVenvStructurePreserved:
    """Test that the original venv structure is preserved (not recreated from scratch)."""

    @pytest.mark.parametrize("account", ACCOUNTS)
    def test_venv_directory_exists(self, account):
        """Each account must still have a venv directory."""
        venv_dir = os.path.join(MANAGED_ACCOUNTS_DIR, account, "venv")
        assert os.path.isdir(venv_dir), \
            f"Venv directory {venv_dir} does not exist"

    @pytest.mark.parametrize("account", ACCOUNTS)
    def test_original_marker_exists(self, account):
        """Each venv must still have the .original_marker file (proves venv wasn't recreated)."""
        marker_path = os.path.join(MANAGED_ACCOUNTS_DIR, account, "venv", ".original_marker")
        assert os.path.isfile(marker_path), \
            f"Original marker file {marker_path} does not exist - venv may have been recreated from scratch, which violates the task requirements"

    @pytest.mark.parametrize("account", ACCOUNTS)
    def test_venv_python_exists(self, account):
        """Each venv must still have a python executable."""
        python_path = os.path.join(MANAGED_ACCOUNTS_DIR, account, "venv", "bin", "python")
        assert os.path.exists(python_path), \
            f"Venv python {python_path} does not exist"

    @pytest.mark.parametrize("account", ACCOUNTS)
    def test_venv_pip_exists(self, account):
        """Each venv must still have a pip executable."""
        pip_path = os.path.join(MANAGED_ACCOUNTS_DIR, account, "venv", "bin", "pip")
        assert os.path.exists(pip_path), \
            f"Venv pip {pip_path} does not exist"

    @pytest.mark.parametrize("account", ACCOUNTS)
    def test_site_packages_exists(self, account):
        """Each venv must still have a site-packages directory."""
        site_packages = os.path.join(
            MANAGED_ACCOUNTS_DIR, account, "venv", "lib", "python3.10", "site-packages"
        )
        assert os.path.isdir(site_packages), \
            f"Site-packages directory {site_packages} does not exist"


class TestPyvenvCfgFixed:
    """Test that pyvenv.cfg has been fixed with correct home path."""

    @pytest.mark.parametrize("account", ACCOUNTS)
    def test_pyvenv_cfg_exists(self, account):
        """pyvenv.cfg must still exist."""
        cfg_path = os.path.join(MANAGED_ACCOUNTS_DIR, account, "venv", "pyvenv.cfg")
        assert os.path.isfile(cfg_path), \
            f"pyvenv.cfg {cfg_path} does not exist"

    @pytest.mark.parametrize("account", ACCOUNTS)
    def test_pyvenv_cfg_home_points_to_valid_path(self, account):
        """The pyvenv.cfg home must point to a valid directory containing python."""
        cfg_path = os.path.join(MANAGED_ACCOUNTS_DIR, account, "venv", "pyvenv.cfg")

        with open(cfg_path, 'r') as f:
            content = f.read()

        # Parse the home value
        home_value = None
        for line in content.splitlines():
            line_stripped = line.strip()
            if line_stripped.lower().startswith("home"):
                parts = line_stripped.split("=", 1)
                if len(parts) == 2:
                    home_value = parts[1].strip()
                    break

        assert home_value is not None, \
            f"Could not parse 'home' value from pyvenv.cfg at {cfg_path}"

        # The home path must exist
        assert os.path.isdir(home_value), \
            f"pyvenv.cfg home path '{home_value}' does not exist or is not a directory"

        # The home path must not be the broken path
        assert home_value != "/opt/python3.10/bin", \
            f"pyvenv.cfg home still points to broken path '/opt/python3.10/bin'"

        # The home path should contain a python executable
        python_in_home = os.path.join(home_value, "python3")
        python_in_home_alt = os.path.join(home_value, "python")
        assert os.path.exists(python_in_home) or os.path.exists(python_in_home_alt), \
            f"pyvenv.cfg home path '{home_value}' does not contain python3 or python executable"


class TestPipConfFixed:
    """Test that pip.conf target directive has been removed or file deleted."""

    @pytest.mark.parametrize("account", ACCOUNTS)
    def test_pip_conf_no_target_directive(self, account):
        """pip.conf should either not exist or not have a target directive."""
        pip_conf_path = os.path.join(MANAGED_ACCOUNTS_DIR, account, "venv", "pip.conf")

        if not os.path.exists(pip_conf_path):
            # File deleted - this is acceptable
            return

        with open(pip_conf_path, 'r') as f:
            content = f.read().lower()

        # Check that there's no target directive
        assert "target" not in content, \
            f"pip.conf at {pip_conf_path} still contains 'target' directive which should be removed"


class TestVenvPythonSysPrefix:
    """Test that the venv python correctly reports its sys.prefix."""

    @pytest.mark.parametrize("account", ACCOUNTS)
    def test_sys_prefix_is_venv_path(self, account):
        """python -c 'import sys; print(sys.prefix)' should print the venv path."""
        venv_path = os.path.join(MANAGED_ACCOUNTS_DIR, account, "venv")
        activate_script = os.path.join(venv_path, "bin", "activate")

        cmd = f"source {activate_script} && python -c \"import sys; print(sys.prefix)\""
        result = subprocess.run(
            cmd,
            shell=True,
            executable="/bin/bash",
            capture_output=True,
            text=True
        )

        assert result.returncode == 0, \
            f"Failed to get sys.prefix for {account}: {result.stderr}"

        sys_prefix = result.stdout.strip()
        # sys.prefix should be the venv path, not /usr or system path
        assert sys_prefix == venv_path, \
            f"sys.prefix for {account} is '{sys_prefix}', expected '{venv_path}'. The venv python is not properly configured."


class TestPipInstallAndImport:
    """Test that pip install works and packages are importable."""

    @pytest.mark.parametrize("account", ACCOUNTS)
    def test_pip_install_requests_succeeds(self, account):
        """pip install requests should succeed."""
        venv_path = os.path.join(MANAGED_ACCOUNTS_DIR, account, "venv")
        activate_script = os.path.join(venv_path, "bin", "activate")

        cmd = f"source {activate_script} && pip install requests"
        result = subprocess.run(
            cmd,
            shell=True,
            executable="/bin/bash",
            capture_output=True,
            text=True,
            timeout=120
        )

        assert result.returncode == 0, \
            f"pip install requests failed for {account}: {result.stderr}"

    @pytest.mark.parametrize("account", ACCOUNTS)
    def test_import_requests_succeeds(self, account):
        """python -c 'import requests' should succeed after pip install."""
        venv_path = os.path.join(MANAGED_ACCOUNTS_DIR, account, "venv")
        activate_script = os.path.join(venv_path, "bin", "activate")

        # First ensure requests is installed
        install_cmd = f"source {activate_script} && pip install requests"
        subprocess.run(
            install_cmd,
            shell=True,
            executable="/bin/bash",
            capture_output=True,
            text=True,
            timeout=120
        )

        # Now test import
        import_cmd = f"source {activate_script} && python -c \"import requests\""
        result = subprocess.run(
            import_cmd,
            shell=True,
            executable="/bin/bash",
            capture_output=True,
            text=True
        )

        assert result.returncode == 0, \
            f"import requests failed for {account} with ModuleNotFoundError. stderr: {result.stderr}. The fix is incomplete - pip installs but import still fails."

    @pytest.mark.parametrize("account", ACCOUNTS)
    def test_requests_version_printable(self, account):
        """python -c 'import requests; print(requests.__version__)' should print a version."""
        venv_path = os.path.join(MANAGED_ACCOUNTS_DIR, account, "venv")
        activate_script = os.path.join(venv_path, "bin", "activate")

        # First ensure requests is installed
        install_cmd = f"source {activate_script} && pip install requests"
        subprocess.run(
            install_cmd,
            shell=True,
            executable="/bin/bash",
            capture_output=True,
            text=True,
            timeout=120
        )

        # Now test version
        version_cmd = f"source {activate_script} && python -c \"import requests; print(requests.__version__)\""
        result = subprocess.run(
            version_cmd,
            shell=True,
            executable="/bin/bash",
            capture_output=True,
            text=True
        )

        assert result.returncode == 0, \
            f"Failed to print requests version for {account}: {result.stderr}"

        version = result.stdout.strip()
        assert version, \
            f"requests.__version__ is empty for {account}"

        # Version should look like a version string (contains digits and dots)
        assert any(c.isdigit() for c in version), \
            f"requests.__version__ '{version}' doesn't look like a version string for {account}"


class TestFullWorkflow:
    """Test the complete workflow as described in the task."""

    @pytest.mark.parametrize("account", ACCOUNTS)
    def test_complete_workflow(self, account):
        """
        Test the full workflow:
        source activate && pip install requests && python -c "import requests; print(requests.__version__)"
        """
        venv_path = os.path.join(MANAGED_ACCOUNTS_DIR, account, "venv")
        activate_script = os.path.join(venv_path, "bin", "activate")

        cmd = (
            f"source {activate_script} && "
            f"pip install requests && "
            f"python -c \"import requests; print(requests.__version__)\""
        )

        result = subprocess.run(
            cmd,
            shell=True,
            executable="/bin/bash",
            capture_output=True,
            text=True,
            timeout=120
        )

        assert result.returncode == 0, \
            f"Complete workflow failed for {account}. stdout: {result.stdout}, stderr: {result.stderr}"

        # The last line of stdout should be the version
        output_lines = result.stdout.strip().split('\n')
        version_line = output_lines[-1] if output_lines else ""

        assert version_line and any(c.isdigit() for c in version_line), \
            f"Expected version string in output for {account}, got: '{version_line}'"


class TestNoSystemWideChanges:
    """Test that no system-wide Python or pip configuration was changed."""

    def test_system_python_unchanged(self):
        """System python3 should still work normally."""
        result = subprocess.run(
            ["/usr/bin/python3", "-c", "import sys; print(sys.prefix)"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            f"System python3 is broken: {result.stderr}"

        # System python prefix should be /usr or similar, not a venv
        sys_prefix = result.stdout.strip()
        assert "managed_accounts" not in sys_prefix, \
            f"System python sys.prefix incorrectly points to managed_accounts: {sys_prefix}"

    def test_no_global_pip_conf_target(self):
        """Global pip.conf should not have a target directive."""
        global_pip_conf_paths = [
            "/etc/pip.conf",
            os.path.expanduser("~/.config/pip/pip.conf"),
            os.path.expanduser("~/.pip/pip.conf"),
        ]

        for pip_conf_path in global_pip_conf_paths:
            if os.path.exists(pip_conf_path):
                with open(pip_conf_path, 'r') as f:
                    content = f.read().lower()
                assert "target" not in content or "managed_accounts" not in content, \
                    f"Global pip.conf at {pip_conf_path} has been modified with target directive"
