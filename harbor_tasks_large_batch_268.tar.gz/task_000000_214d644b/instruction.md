I need to install jq on this box — just the standard apt package. Was going to parse some AWS cost explorer JSON exports but realized jq isn't here. Should be at /usr/bin/jq when you're done.
