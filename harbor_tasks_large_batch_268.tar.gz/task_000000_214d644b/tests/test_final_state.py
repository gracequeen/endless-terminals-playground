# test_final_state.py
"""
Tests to validate the final state after the student has installed jq.
Verifies that jq is properly installed via apt and functional.
"""

import os
import subprocess
import stat
import pytest


class TestJqInstallation:
    """Tests to verify jq is properly installed."""

    def test_jq_binary_exists(self):
        """Verify that /usr/bin/jq exists."""
        assert os.path.exists("/usr/bin/jq"), (
            "/usr/bin/jq does not exist. "
            "jq must be installed so that the binary is at /usr/bin/jq."
        )

    def test_jq_binary_is_file(self):
        """Verify that /usr/bin/jq is a regular file (not a directory or symlink to nothing)."""
        assert os.path.isfile("/usr/bin/jq"), (
            "/usr/bin/jq is not a regular file. "
            "jq must be properly installed as a binary file."
        )

    def test_jq_binary_is_executable(self):
        """Verify that /usr/bin/jq is executable."""
        assert os.access("/usr/bin/jq", os.X_OK), (
            "/usr/bin/jq is not executable. "
            "The jq binary must have execute permissions."
        )

    def test_jq_is_elf_executable(self):
        """Verify that /usr/bin/jq is a real ELF binary, not a script or alias."""
        result = subprocess.run(
            ["file", "/usr/bin/jq"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"Failed to run 'file' command on /usr/bin/jq: {result.stderr}"
        )
        output = result.stdout.lower()
        assert "elf" in output, (
            f"/usr/bin/jq is not an ELF executable. "
            f"'file' command output: {result.stdout.strip()}. "
            "jq must be the real apt package binary, not a shell script or wrapper."
        )

    def test_jq_version_runs_successfully(self):
        """Verify that 'jq --version' exits with code 0."""
        result = subprocess.run(
            ["/usr/bin/jq", "--version"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"'jq --version' failed with exit code {result.returncode}. "
            f"stderr: {result.stderr}"
        )

    def test_jq_version_outputs_version_string(self):
        """Verify that 'jq --version' outputs a version string like 'jq-1.6'."""
        result = subprocess.run(
            ["/usr/bin/jq", "--version"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"'jq --version' failed: {result.stderr}"
        )
        version_output = result.stdout.strip()
        # Version string should contain 'jq' and a version number
        assert "jq" in version_output.lower(), (
            f"'jq --version' output does not contain 'jq': {version_output}"
        )
        # Check for version pattern (e.g., jq-1.6 or jq-1.7)
        import re
        version_pattern = re.compile(r'jq-\d+\.\d+', re.IGNORECASE)
        assert version_pattern.search(version_output), (
            f"'jq --version' output does not match expected version pattern (e.g., jq-1.6): {version_output}"
        )

    def test_jq_can_parse_json(self):
        """Verify that jq can parse JSON and extract values."""
        result = subprocess.run(
            ["bash", "-c", "echo '{\"cost\": 42}' | /usr/bin/jq '.cost'"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"jq failed to parse JSON. Exit code: {result.returncode}, "
            f"stderr: {result.stderr}"
        )
        output = result.stdout.strip()
        assert output == "42", (
            f"jq did not extract the correct value. "
            f"Expected '42', got '{output}'."
        )

    def test_jq_installed_via_apt(self):
        """Verify that jq is installed as an apt package."""
        result = subprocess.run(
            ["dpkg", "-l", "jq"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"dpkg -l jq failed. jq may not be installed via apt. "
            f"stderr: {result.stderr}"
        )
        # Check that the package status shows it's installed (starts with 'ii')
        lines = result.stdout.strip().split('\n')
        installed = False
        for line in lines:
            if line.startswith('ii') and 'jq' in line.split()[1]:
                installed = True
                break
        assert installed, (
            f"jq package is not properly installed according to dpkg. "
            f"Output: {result.stdout}"
        )


class TestSystemIntegrity:
    """Tests to verify the system remains functional."""

    def test_apt_still_works(self):
        """Verify that apt is still functional."""
        result = subprocess.run(
            ["apt", "--version"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"apt is not functional after jq installation. "
            f"stderr: {result.stderr}"
        )

    def test_home_user_still_exists(self):
        """Verify that /home/user directory still exists."""
        assert os.path.isdir("/home/user"), (
            "/home/user directory no longer exists. "
            "The system should remain in a functional state."
        )

    def test_jq_in_path(self):
        """Verify that jq is available in PATH."""
        result = subprocess.run(
            ["which", "jq"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "jq is not available in PATH. "
            "After installation, jq should be accessible from the command line."
        )
        # The path should be /usr/bin/jq
        jq_path = result.stdout.strip()
        assert jq_path == "/usr/bin/jq", (
            f"jq is at {jq_path}, but expected /usr/bin/jq."
        )


class TestJqFunctionality:
    """Additional tests to verify jq works correctly for common use cases."""

    def test_jq_handles_complex_json(self):
        """Verify jq can handle more complex JSON structures."""
        json_input = '{"aws": {"cost_explorer": {"total": 123.45, "currency": "USD"}}}'
        result = subprocess.run(
            ["bash", "-c", f"echo '{json_input}' | /usr/bin/jq '.aws.cost_explorer.total'"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"jq failed to parse complex JSON: {result.stderr}"
        )
        output = result.stdout.strip()
        assert output == "123.45", (
            f"jq extracted wrong value from complex JSON. "
            f"Expected '123.45', got '{output}'."
        )

    def test_jq_handles_arrays(self):
        """Verify jq can handle JSON arrays."""
        json_input = '[{"name": "ec2", "cost": 100}, {"name": "s3", "cost": 50}]'
        result = subprocess.run(
            ["bash", "-c", f"echo '{json_input}' | /usr/bin/jq '.[0].cost'"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"jq failed to parse JSON array: {result.stderr}"
        )
        output = result.stdout.strip()
        assert output == "100", (
            f"jq extracted wrong value from array. "
            f"Expected '100', got '{output}'."
        )
