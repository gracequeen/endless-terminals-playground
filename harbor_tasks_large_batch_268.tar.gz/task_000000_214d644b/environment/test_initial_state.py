# test_initial_state.py
"""
Tests to validate the initial state before the student installs jq.
Verifies that jq is NOT installed and the system is ready for installation.
"""

import os
import subprocess
import pytest


class TestInitialState:
    """Tests to verify the system is in the expected initial state."""

    def test_jq_binary_does_not_exist(self):
        """Verify that /usr/bin/jq does not exist before installation."""
        assert not os.path.exists("/usr/bin/jq"), (
            "/usr/bin/jq already exists! "
            "The initial state requires jq to NOT be installed."
        )

    def test_jq_command_not_available(self):
        """Verify that jq command is not available in PATH."""
        result = subprocess.run(
            ["which", "jq"],
            capture_output=True,
            text=True
        )
        assert result.returncode != 0, (
            f"jq is already available in PATH at: {result.stdout.strip()}. "
            "The initial state requires jq to NOT be installed."
        )

    def test_apt_is_available(self):
        """Verify that apt package manager is available."""
        result = subprocess.run(
            ["which", "apt"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "apt package manager is not available. "
            "This task requires an Ubuntu/Debian system with apt."
        )

    def test_apt_get_is_available(self):
        """Verify that apt-get is available."""
        result = subprocess.run(
            ["which", "apt-get"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "apt-get is not available. "
            "This task requires an Ubuntu/Debian system with apt."
        )

    def test_home_user_exists(self):
        """Verify that /home/user directory exists."""
        assert os.path.isdir("/home/user"), (
            "/home/user directory does not exist. "
            "The initial state requires this directory to exist."
        )

    def test_home_user_is_writable(self):
        """Verify that /home/user is writable."""
        assert os.access("/home/user", os.W_OK), (
            "/home/user is not writable. "
            "The initial state requires this directory to be writable."
        )

    def test_sudo_is_available(self):
        """Verify that sudo command is available."""
        result = subprocess.run(
            ["which", "sudo"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "sudo is not available. "
            "This task requires sudo access for package installation."
        )

    def test_dpkg_shows_jq_not_installed(self):
        """Verify that dpkg doesn't show jq as installed."""
        result = subprocess.run(
            ["dpkg", "-l", "jq"],
            capture_output=True,
            text=True
        )
        # dpkg -l returns 0 even if package is not installed but was queried before
        # We need to check if it's actually installed (status starts with 'ii')
        if result.returncode == 0:
            # Check if the output indicates the package is installed
            lines = result.stdout.strip().split('\n')
            for line in lines:
                if line.startswith('ii') and 'jq' in line:
                    pytest.fail(
                        "jq package is already installed according to dpkg. "
                        "The initial state requires jq to NOT be installed."
                    )

    def test_no_jq_alias_exists(self):
        """Verify that there's no shell alias for jq."""
        result = subprocess.run(
            ["bash", "-c", "alias jq 2>/dev/null"],
            capture_output=True,
            text=True
        )
        # If alias exists, the command would succeed
        if result.returncode == 0 and result.stdout.strip():
            pytest.fail(
                f"A shell alias for jq exists: {result.stdout.strip()}. "
                "The initial state should not have any jq alias."
            )
