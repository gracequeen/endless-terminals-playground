# test_final_state.py
"""
Tests to validate the final state of the OS/filesystem after the student
has completed the firmware verification script task.
"""

import os
import subprocess
import shutil
import pytest


class TestFinalState:
    """Validate the final filesystem state for the firmware verification task."""

    def test_verify_sh_exists(self):
        """Verify /home/user/firmware/verify.sh exists."""
        verify_sh = "/home/user/firmware/verify.sh"
        assert os.path.isfile(verify_sh), (
            f"File {verify_sh} does not exist. "
            "The verification script must be created."
        )

    def test_verify_sh_is_executable(self):
        """Verify /home/user/firmware/verify.sh is executable."""
        verify_sh = "/home/user/firmware/verify.sh"
        assert os.path.isfile(verify_sh), (
            f"File {verify_sh} does not exist."
        )
        assert os.access(verify_sh, os.X_OK), (
            f"File {verify_sh} is not executable. "
            "The script must have execute permissions."
        )

    def test_update_bin_unchanged(self):
        """Verify /home/user/firmware/update.bin still exists and is 2048 bytes."""
        update_bin = "/home/user/firmware/update.bin"
        assert os.path.isfile(update_bin), (
            f"File {update_bin} does not exist. "
            "The firmware blob must not be deleted."
        )
        file_size = os.path.getsize(update_bin)
        assert file_size == 2048, (
            f"File {update_bin} is {file_size} bytes, expected 2048 bytes. "
            "The firmware blob should remain unchanged."
        )

    def test_update_sha256_unchanged(self):
        """Verify /home/user/firmware/update.sha256 still exists with correct format."""
        sha256_file = "/home/user/firmware/update.sha256"
        assert os.path.isfile(sha256_file), (
            f"File {sha256_file} does not exist. "
            "The hash file must not be deleted."
        )

        with open(sha256_file, "r") as f:
            content = f.read()

        lines = content.strip().split('\n')
        assert len(lines) == 1, (
            f"File {sha256_file} should contain exactly one line."
        )

        line = lines[0]
        parts = line.split("  ")
        assert len(parts) == 2, (
            f"File {sha256_file} format appears corrupted."
        )

    def test_hash_still_matches(self):
        """Verify the hash in update.sha256 still matches update.bin."""
        firmware_dir = "/home/user/firmware"
        result = subprocess.run(
            ["sha256sum", "update.bin"],
            cwd=firmware_dir,
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"sha256sum failed: {result.stderr}"
        )

        computed_hash = result.stdout.strip()

        sha256_file = "/home/user/firmware/update.sha256"
        with open(sha256_file, "r") as f:
            expected_hash = f.read().strip()

        assert computed_hash == expected_hash, (
            "Hash mismatch - the files appear to have been modified."
        )

    def test_verify_sh_exits_0_on_match(self):
        """Verify running verify.sh exits 0 when hash matches."""
        firmware_dir = "/home/user/firmware"
        result = subprocess.run(
            ["./verify.sh"],
            cwd=firmware_dir,
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"verify.sh exited with code {result.returncode}, expected 0. "
            f"The script should exit 0 when the hash matches.\n"
            f"stdout: {result.stdout}\n"
            f"stderr: {result.stderr}"
        )

    def test_verify_sh_exits_1_on_mismatch(self):
        """
        Verify running verify.sh exits 1 when hash does NOT match.
        This is the anti-shortcut guard to ensure the script actually checks the hash.
        """
        firmware_dir = "/home/user/firmware"
        update_bin = os.path.join(firmware_dir, "update.bin")
        backup_bin = os.path.join(firmware_dir, "update.bin.backup")

        # Create a backup of the original file
        shutil.copy2(update_bin, backup_bin)

        try:
            # Corrupt the file by appending a byte
            with open(update_bin, "ab") as f:
                f.write(b"x")

            # Run the verification script - should fail now
            result = subprocess.run(
                ["./verify.sh"],
                cwd=firmware_dir,
                capture_output=True,
                text=True
            )

            assert result.returncode == 1, (
                f"verify.sh exited with code {result.returncode}, expected 1. "
                f"The script should exit 1 when the hash does NOT match. "
                f"This suggests the script may not actually be checking the hash "
                f"(e.g., it might just be 'exit 0').\n"
                f"stdout: {result.stdout}\n"
                f"stderr: {result.stderr}"
            )
        finally:
            # Restore the original file
            shutil.move(backup_bin, update_bin)

    def test_verify_sh_works_after_restore(self):
        """
        Verify that after restoring update.bin, verify.sh still exits 0.
        This confirms the file was properly restored and the script works correctly.
        """
        firmware_dir = "/home/user/firmware"

        # First verify the file is back to original size
        update_bin = os.path.join(firmware_dir, "update.bin")
        file_size = os.path.getsize(update_bin)
        assert file_size == 2048, (
            f"update.bin should be 2048 bytes after restore, got {file_size}"
        )

        # Run verification again
        result = subprocess.run(
            ["./verify.sh"],
            cwd=firmware_dir,
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"verify.sh exited with code {result.returncode} after restore, expected 0.\n"
            f"stdout: {result.stdout}\n"
            f"stderr: {result.stderr}"
        )
