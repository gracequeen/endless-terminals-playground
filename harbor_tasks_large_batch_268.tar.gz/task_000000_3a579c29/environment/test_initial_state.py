# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the firmware verification script task.
"""

import os
import subprocess
import pytest


class TestInitialState:
    """Validate the initial filesystem state for the firmware verification task."""

    def test_firmware_directory_exists(self):
        """Verify /home/user/firmware/ directory exists."""
        firmware_dir = "/home/user/firmware"
        assert os.path.isdir(firmware_dir), (
            f"Directory {firmware_dir} does not exist. "
            "The firmware directory must be present."
        )

    def test_firmware_directory_writable(self):
        """Verify /home/user/firmware/ is writable."""
        firmware_dir = "/home/user/firmware"
        assert os.access(firmware_dir, os.W_OK), (
            f"Directory {firmware_dir} is not writable. "
            "The agent needs write access to create verify.sh."
        )

    def test_update_bin_exists(self):
        """Verify /home/user/firmware/update.bin exists."""
        update_bin = "/home/user/firmware/update.bin"
        assert os.path.isfile(update_bin), (
            f"File {update_bin} does not exist. "
            "The firmware blob must be present."
        )

    def test_update_bin_size(self):
        """Verify /home/user/firmware/update.bin is 2048 bytes."""
        update_bin = "/home/user/firmware/update.bin"
        file_size = os.path.getsize(update_bin)
        assert file_size == 2048, (
            f"File {update_bin} is {file_size} bytes, expected 2048 bytes. "
            "The firmware blob should be exactly 2048 bytes of random data."
        )

    def test_update_sha256_exists(self):
        """Verify /home/user/firmware/update.sha256 exists."""
        sha256_file = "/home/user/firmware/update.sha256"
        assert os.path.isfile(sha256_file), (
            f"File {sha256_file} does not exist. "
            "The expected hash file must be present."
        )

    def test_update_sha256_format(self):
        """Verify /home/user/firmware/update.sha256 has correct format."""
        sha256_file = "/home/user/firmware/update.sha256"
        with open(sha256_file, "r") as f:
            content = f.read()

        # Format should be "<hash>  update.bin\n" (two spaces before filename)
        # SHA256 hash is 64 hex characters
        lines = content.strip().split('\n')
        assert len(lines) == 1, (
            f"File {sha256_file} should contain exactly one line, "
            f"found {len(lines)} lines."
        )

        line = lines[0]
        parts = line.split("  ")  # Split on two spaces
        assert len(parts) == 2, (
            f"File {sha256_file} should have format '<hash>  <filename>' "
            f"(with two spaces). Got: {repr(line)}"
        )

        hash_part, filename_part = parts
        assert len(hash_part) == 64, (
            f"SHA256 hash should be 64 hex characters, got {len(hash_part)} characters."
        )
        assert all(c in "0123456789abcdef" for c in hash_part.lower()), (
            f"SHA256 hash should contain only hex characters. Got: {hash_part}"
        )
        assert filename_part == "update.bin", (
            f"Filename in hash file should be 'update.bin', got: {filename_part}"
        )

    def test_sha256_matches_update_bin(self):
        """Verify the hash in update.sha256 matches the actual hash of update.bin."""
        firmware_dir = "/home/user/firmware"
        result = subprocess.run(
            ["sha256sum", "update.bin"],
            cwd=firmware_dir,
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"sha256sum failed to compute hash of update.bin: {result.stderr}"
        )

        computed_hash = result.stdout.strip()

        sha256_file = "/home/user/firmware/update.sha256"
        with open(sha256_file, "r") as f:
            expected_hash = f.read().strip()

        assert computed_hash == expected_hash, (
            f"Hash mismatch! The hash in {sha256_file} does not match "
            f"the actual hash of update.bin.\n"
            f"Expected (from file): {expected_hash}\n"
            f"Computed (from bin):  {computed_hash}"
        )

    def test_verify_sh_does_not_exist(self):
        """Verify /home/user/firmware/verify.sh does NOT exist initially."""
        verify_sh = "/home/user/firmware/verify.sh"
        assert not os.path.exists(verify_sh), (
            f"File {verify_sh} already exists but should not exist initially. "
            "The student needs to create this file."
        )

    def test_sha256sum_available(self):
        """Verify sha256sum command is available."""
        result = subprocess.run(
            ["which", "sha256sum"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "sha256sum command is not available. "
            "It is required for this task."
        )

    def test_bash_available(self):
        """Verify bash is available."""
        result = subprocess.run(
            ["which", "bash"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "bash is not available. "
            "It is required for this task."
        )

    def test_coreutils_available(self):
        """Verify standard coreutils are available (test with common commands)."""
        for cmd in ["cat", "echo", "test", "cd"]:
            # For builtins like cd, we check if bash can use them
            if cmd == "cd":
                result = subprocess.run(
                    ["bash", "-c", "type cd"],
                    capture_output=True,
                    text=True
                )
            else:
                result = subprocess.run(
                    ["which", cmd],
                    capture_output=True,
                    text=True
                )
            assert result.returncode == 0, (
                f"Command '{cmd}' is not available. "
                "Standard coreutils are required for this task."
            )
