# test_initial_state.py
"""
Tests to validate the initial state of the system before the student fixes the disk monitoring script.
"""

import os
import subprocess
import stat
import pytest


class TestMonitorDirectoryAndScript:
    """Tests for the monitor directory and check_disk.py script."""

    def test_monitor_directory_exists(self):
        """Verify /home/user/monitor directory exists."""
        monitor_dir = "/home/user/monitor"
        assert os.path.isdir(monitor_dir), f"Directory {monitor_dir} does not exist"

    def test_check_disk_script_exists(self):
        """Verify check_disk.py script exists."""
        script_path = "/home/user/monitor/check_disk.py"
        assert os.path.isfile(script_path), f"Script {script_path} does not exist"

    def test_check_disk_script_is_readable(self):
        """Verify check_disk.py is readable."""
        script_path = "/home/user/monitor/check_disk.py"
        assert os.access(script_path, os.R_OK), f"Script {script_path} is not readable"

    def test_monitor_directory_is_writable(self):
        """Verify /home/user/monitor is writable."""
        monitor_dir = "/home/user/monitor"
        assert os.access(monitor_dir, os.W_OK), f"Directory {monitor_dir} is not writable"


class TestScriptContent:
    """Tests for the content of check_disk.py script."""

    def test_script_has_threshold_85(self):
        """Verify script contains THRESHOLD = 85."""
        script_path = "/home/user/monitor/check_disk.py"
        with open(script_path, 'r') as f:
            content = f.read()
        assert "THRESHOLD = 85" in content, "Script does not contain 'THRESHOLD = 85'"

    def test_script_has_mount_data(self):
        """Verify script targets /data mount point."""
        script_path = "/home/user/monitor/check_disk.py"
        with open(script_path, 'r') as f:
            content = f.read()
        assert 'MOUNT = "/data"' in content or "MOUNT = '/data'" in content, \
            "Script does not contain MOUNT = '/data' or MOUNT = \"/data\""

    def test_script_uses_df_command(self):
        """Verify script uses df command."""
        script_path = "/home/user/monitor/check_disk.py"
        with open(script_path, 'r') as f:
            content = f.read()
        assert "df" in content, "Script does not appear to use 'df' command"

    def test_script_has_buggy_substring_match(self):
        """Verify script has the buggy substring match that causes false positives."""
        script_path = "/home/user/monitor/check_disk.py"
        with open(script_path, 'r') as f:
            content = f.read()
        # The bug is using 'if "/data" in line' which matches /data_archive
        assert '"/data" in line' in content or "'/data' in line" in content, \
            "Script does not contain the expected buggy pattern: '\"/data\" in line'"

    def test_script_is_valid_python(self):
        """Verify script is valid Python syntax."""
        script_path = "/home/user/monitor/check_disk.py"
        result = subprocess.run(
            ["python3", "-m", "py_compile", script_path],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, f"Script has Python syntax errors: {result.stderr}"


class TestLogFile:
    """Tests for the disk alerts log file."""

    def test_log_file_exists(self):
        """Verify /var/log/disk_alerts.log exists."""
        log_path = "/var/log/disk_alerts.log"
        assert os.path.isfile(log_path), f"Log file {log_path} does not exist"

    def test_log_file_is_writable(self):
        """Verify /var/log/disk_alerts.log is writable."""
        log_path = "/var/log/disk_alerts.log"
        assert os.access(log_path, os.W_OK), f"Log file {log_path} is not writable"

    def test_log_file_contains_alerts(self):
        """Verify log file contains alert entries indicating the false positive issue."""
        log_path = "/var/log/disk_alerts.log"
        with open(log_path, 'r') as f:
            content = f.read()
        assert "ALERT:" in content, "Log file does not contain any ALERT entries"
        assert "/data at" in content, "Log file does not contain '/data at' entries"
        assert "92%" in content, "Log file does not show 92% usage (the false positive from /data_archive)"

    def test_log_has_multiple_entries(self):
        """Verify log file has multiple alert entries (indicating recurring false positives)."""
        log_path = "/var/log/disk_alerts.log"
        with open(log_path, 'r') as f:
            content = f.read()
        alert_count = content.count("ALERT:")
        assert alert_count >= 3, f"Log file should have multiple ALERT entries (found {alert_count}), indicating recurring false positives"


class TestFilesystemMounts:
    """Tests for the filesystem mounts that create the ambiguity."""

    def test_data_mount_exists(self):
        """Verify /data mount point exists."""
        assert os.path.isdir("/data"), "/data mount point does not exist"

    def test_data_archive_mount_exists(self):
        """Verify /data_archive mount point exists (this causes the bug)."""
        assert os.path.isdir("/data_archive"), "/data_archive mount point does not exist"

    def test_df_shows_both_mounts(self):
        """Verify df output shows both /data and /data_archive."""
        result = subprocess.run(["df", "-h"], capture_output=True, text=True)
        assert result.returncode == 0, "df -h command failed"

        output = result.stdout
        has_data = False
        has_data_archive = False

        for line in output.split('\n'):
            if line.strip().endswith('/data'):
                has_data = True
            if '/data_archive' in line:
                has_data_archive = True

        assert has_data, "df output does not show /data mount"
        assert has_data_archive, "df output does not show /data_archive mount"

    def test_data_usage_is_low(self):
        """Verify /data is actually at low usage (around 40%, well below 85% threshold)."""
        result = subprocess.run(["df", "-h", "/data"], capture_output=True, text=True)
        assert result.returncode == 0, "df -h /data command failed"

        # Parse the output to get usage percentage
        lines = result.stdout.strip().split('\n')
        assert len(lines) >= 2, "df output is malformed"

        # The data line should be the second line
        data_line = lines[1]
        parts = data_line.split()
        assert len(parts) >= 5, f"Cannot parse df output line: {data_line}"

        usage_str = parts[4].rstrip('%')
        usage = int(usage_str)
        assert usage < 85, f"/data is at {usage}% which is >= 85% threshold - this should be below threshold for the test scenario"

    def test_data_archive_usage_is_high(self):
        """Verify /data_archive is at high usage (around 92%, above 85% threshold)."""
        result = subprocess.run(["df", "-h", "/data_archive"], capture_output=True, text=True)
        assert result.returncode == 0, "df -h /data_archive command failed"

        lines = result.stdout.strip().split('\n')
        assert len(lines) >= 2, "df output is malformed"

        data_line = lines[1]
        parts = data_line.split()
        assert len(parts) >= 5, f"Cannot parse df output line: {data_line}"

        usage_str = parts[4].rstrip('%')
        usage = int(usage_str)
        assert usage > 85, f"/data_archive is at {usage}% which should be > 85% to demonstrate the false positive bug"


class TestPythonEnvironment:
    """Tests for Python environment."""

    def test_python3_available(self):
        """Verify Python 3 is available."""
        result = subprocess.run(["python3", "--version"], capture_output=True, text=True)
        assert result.returncode == 0, "python3 is not available"
        assert "Python 3" in result.stdout or "Python 3" in result.stderr, \
            f"python3 --version did not return Python 3.x: {result.stdout} {result.stderr}"


class TestScriptExecutability:
    """Tests for script execution."""

    def test_script_runs_without_error(self):
        """Verify the script can be executed (even if it produces false positive)."""
        script_path = "/home/user/monitor/check_disk.py"
        result = subprocess.run(
            ["python3", script_path],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, f"Script failed to run: {result.stderr}"
