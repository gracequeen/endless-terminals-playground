# test_final_state.py
"""
Tests to validate the final state of the system after the student fixes the disk monitoring script.
The script should no longer produce false positives by matching /data_archive when checking /data.
"""

import os
import subprocess
import re
import pytest


class TestScriptExists:
    """Tests that the script still exists and is valid."""

    def test_check_disk_script_exists(self):
        """Verify check_disk.py script still exists."""
        script_path = "/home/user/monitor/check_disk.py"
        assert os.path.isfile(script_path), f"Script {script_path} does not exist"

    def test_script_is_valid_python(self):
        """Verify script is still valid Python syntax."""
        script_path = "/home/user/monitor/check_disk.py"
        result = subprocess.run(
            ["python3", "-m", "py_compile", script_path],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, f"Script has Python syntax errors: {result.stderr}"


class TestScriptPreservesRequiredSettings:
    """Tests that required settings are preserved in the script."""

    def test_threshold_remains_85(self):
        """Verify THRESHOLD = 85 is still in the script (anti-shortcut guard)."""
        script_path = "/home/user/monitor/check_disk.py"
        result = subprocess.run(
            ["grep", "-c", "THRESHOLD = 85", script_path],
            capture_output=True,
            text=True
        )
        count = int(result.stdout.strip()) if result.returncode == 0 else 0
        assert count == 1, f"Script must contain exactly one 'THRESHOLD = 85' line, found {count}"

    def test_mount_remains_data(self):
        """Verify MOUNT is still set to /data."""
        script_path = "/home/user/monitor/check_disk.py"
        with open(script_path, 'r') as f:
            content = f.read()
        # Check for MOUNT = "/data" or MOUNT = '/data'
        has_mount_data = ('MOUNT = "/data"' in content or "MOUNT = '/data'" in content)
        assert has_mount_data, "Script must still have MOUNT = '/data' or MOUNT = \"/data\""

    def test_script_still_uses_df(self):
        """Verify script still uses df command (not completely replaced with different approach)."""
        script_path = "/home/user/monitor/check_disk.py"
        with open(script_path, 'r') as f:
            content = f.read()
        assert "df" in content, "Script must still use 'df' command for disk checking"


class TestLogFilePreserved:
    """Tests that existing log entries are preserved."""

    def test_log_file_exists(self):
        """Verify /var/log/disk_alerts.log still exists."""
        log_path = "/var/log/disk_alerts.log"
        assert os.path.isfile(log_path), f"Log file {log_path} does not exist"

    def test_log_file_has_historical_entries(self):
        """Verify log file still contains historical alert entries (not truncated)."""
        log_path = "/var/log/disk_alerts.log"
        with open(log_path, 'r') as f:
            content = f.read()
        # Should still have the old false positive alerts
        alert_count = content.count("ALERT:")
        assert alert_count >= 3, f"Log file should still contain historical ALERT entries (found {alert_count})"


class TestBugFix:
    """Tests that verify the bug is actually fixed."""

    def test_buggy_substring_match_removed(self):
        """Verify the buggy substring match pattern is no longer present."""
        script_path = "/home/user/monitor/check_disk.py"
        with open(script_path, 'r') as f:
            content = f.read()
        # The original bug was: if "/data" in line
        # This should be replaced with an exact match approach
        # Check that the naive substring match is gone or properly constrained
        has_naive_match = ('"/data" in line' in content or "'/data' in line" in content)
        if has_naive_match:
            # If the pattern is still there, it might be in a comment or modified context
            # Let's do a more thorough check
            lines = content.split('\n')
            for line in lines:
                # Skip comments
                stripped = line.strip()
                if stripped.startswith('#'):
                    continue
                if '"/data" in line' in line or "'/data' in line" in line:
                    pytest.fail("Script still contains the buggy naive substring match: '\"/data\" in line'")

    def test_script_runs_without_error(self):
        """Verify the fixed script can be executed without errors."""
        script_path = "/home/user/monitor/check_disk.py"
        result = subprocess.run(
            ["python3", script_path],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, f"Script failed to run: {result.stderr}"

    def test_no_false_positive_alert_generated(self):
        """Verify running the script does NOT generate a new alert (since /data is at ~40%)."""
        log_path = "/var/log/disk_alerts.log"
        script_path = "/home/user/monitor/check_disk.py"

        # Get the current log content and line count
        with open(log_path, 'r') as f:
            content_before = f.read()
        lines_before = len(content_before.strip().split('\n')) if content_before.strip() else 0
        alerts_before = content_before.count("ALERT:")

        # Run the script
        result = subprocess.run(
            ["python3", script_path],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, f"Script failed to run: {result.stderr}"

        # Check log content after
        with open(log_path, 'r') as f:
            content_after = f.read()
        alerts_after = content_after.count("ALERT:")

        # No new alerts should be added since /data is below threshold
        assert alerts_after == alerts_before, \
            f"Script generated a false positive! Alerts before: {alerts_before}, after: {alerts_after}. " \
            f"The /data partition is at ~40% which is below the 85% threshold."

    def test_idempotent_no_duplicate_alerts(self):
        """Verify running the script twice doesn't produce duplicate alerts when under threshold."""
        log_path = "/var/log/disk_alerts.log"
        script_path = "/home/user/monitor/check_disk.py"

        # Get initial alert count
        with open(log_path, 'r') as f:
            content_before = f.read()
        alerts_before = content_before.count("ALERT:")

        # Run the script twice
        for _ in range(2):
            result = subprocess.run(
                ["python3", script_path],
                capture_output=True,
                text=True
            )
            assert result.returncode == 0, f"Script failed to run: {result.stderr}"

        # Check alert count after
        with open(log_path, 'r') as f:
            content_after = f.read()
        alerts_after = content_after.count("ALERT:")

        assert alerts_after == alerts_before, \
            f"Script is not idempotent - generated alerts when run multiple times. " \
            f"Alerts before: {alerts_before}, after: {alerts_after}"


class TestExactMountMatching:
    """Tests that verify the script correctly distinguishes /data from /data_archive."""

    def test_data_archive_not_matched_for_data(self):
        """Verify that /data_archive (at 92%) doesn't trigger alerts for /data."""
        log_path = "/var/log/disk_alerts.log"
        script_path = "/home/user/monitor/check_disk.py"

        # Get initial state
        with open(log_path, 'r') as f:
            content_before = f.read()
        alerts_before = content_before.count("ALERT:")

        # Run the script
        result = subprocess.run(
            ["python3", script_path],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, f"Script failed: {result.stderr}"

        # Verify no new alerts
        with open(log_path, 'r') as f:
            content_after = f.read()
        alerts_after = content_after.count("ALERT:")

        # If a new alert was added, check if it's incorrectly reporting 92%
        if alerts_after > alerts_before:
            # Get the new lines
            new_content = content_after[len(content_before):]
            if "92%" in new_content:
                pytest.fail(
                    "Script is still matching /data_archive instead of /data! "
                    "New alert shows 92% which is the /data_archive usage, not /data's ~40%."
                )
            pytest.fail(
                f"Script generated an unexpected alert. New content: {new_content}"
            )


class TestFilesystemState:
    """Tests that verify the filesystem state is as expected for the test."""

    def test_data_is_below_threshold(self):
        """Confirm /data is actually below 85% threshold."""
        result = subprocess.run(["df", "-h", "/data"], capture_output=True, text=True)
        assert result.returncode == 0, "df -h /data command failed"

        lines = result.stdout.strip().split('\n')
        if len(lines) >= 2:
            data_line = lines[1]
            parts = data_line.split()
            if len(parts) >= 5:
                usage_str = parts[4].rstrip('%')
                try:
                    usage = int(usage_str)
                    assert usage < 85, \
                        f"/data is at {usage}% which is >= 85%. " \
                        f"Test assumes /data is below threshold."
                except ValueError:
                    pass  # Can't parse, skip this check

    def test_data_archive_is_above_threshold(self):
        """Confirm /data_archive is above 85% threshold (the source of false positives)."""
        result = subprocess.run(["df", "-h", "/data_archive"], capture_output=True, text=True)
        assert result.returncode == 0, "df -h /data_archive command failed"

        lines = result.stdout.strip().split('\n')
        if len(lines) >= 2:
            data_line = lines[1]
            parts = data_line.split()
            if len(parts) >= 5:
                usage_str = parts[4].rstrip('%')
                try:
                    usage = int(usage_str)
                    assert usage > 85, \
                        f"/data_archive is at {usage}% which should be > 85% " \
                        f"to demonstrate the false positive scenario."
                except ValueError:
                    pass  # Can't parse, skip this check
