# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
creates the Makefile for the profiling task.
"""

import os
import subprocess
import pytest


class TestDirectoryStructure:
    """Test that the required directory exists and is writable."""

    def test_profiling_directory_exists(self):
        """The /home/user/profiling/ directory must exist."""
        path = "/home/user/profiling"
        assert os.path.exists(path), f"Directory {path} does not exist"
        assert os.path.isdir(path), f"{path} exists but is not a directory"

    def test_profiling_directory_is_writable(self):
        """The /home/user/profiling/ directory must be writable."""
        path = "/home/user/profiling"
        assert os.access(path, os.W_OK), f"Directory {path} is not writable"


class TestSourceFiles:
    """Test that the required C source files exist with correct content."""

    def test_main_c_exists(self):
        """main.c must exist in /home/user/profiling/."""
        path = "/home/user/profiling/main.c"
        assert os.path.exists(path), f"Source file {path} does not exist"
        assert os.path.isfile(path), f"{path} exists but is not a regular file"

    def test_main_c_content(self):
        """main.c must contain the expected minimal C code."""
        path = "/home/user/profiling/main.c"
        with open(path, 'r') as f:
            content = f.read()
        # Check for essential elements
        assert "#include <pthread.h>" in content, \
            f"main.c does not include pthread.h"
        assert "int main()" in content or "int main(" in content, \
            f"main.c does not contain main function"
        assert "return 0" in content, \
            f"main.c does not contain 'return 0'"

    def test_utils_c_exists(self):
        """utils.c must exist in /home/user/profiling/."""
        path = "/home/user/profiling/utils.c"
        assert os.path.exists(path), f"Source file {path} does not exist"
        assert os.path.isfile(path), f"{path} exists but is not a regular file"

    def test_utils_c_content(self):
        """utils.c must contain the expected minimal C code."""
        path = "/home/user/profiling/utils.c"
        with open(path, 'r') as f:
            content = f.read()
        assert "void util_func()" in content or "void util_func(" in content, \
            f"utils.c does not contain util_func function"

    def test_sampler_c_exists(self):
        """sampler.c must exist in /home/user/profiling/."""
        path = "/home/user/profiling/sampler.c"
        assert os.path.exists(path), f"Source file {path} does not exist"
        assert os.path.isfile(path), f"{path} exists but is not a regular file"

    def test_sampler_c_content(self):
        """sampler.c must contain the expected minimal C code."""
        path = "/home/user/profiling/sampler.c"
        with open(path, 'r') as f:
            content = f.read()
        assert "void sampler_func()" in content or "void sampler_func(" in content, \
            f"sampler.c does not contain sampler_func function"


class TestNoMakefileExists:
    """Test that no Makefile exists initially."""

    def test_no_makefile(self):
        """Makefile must NOT exist initially in /home/user/profiling/."""
        path = "/home/user/profiling/Makefile"
        assert not os.path.exists(path), \
            f"Makefile already exists at {path} - it should not exist initially"

    def test_no_makefile_lowercase(self):
        """makefile (lowercase) must NOT exist initially."""
        path = "/home/user/profiling/makefile"
        assert not os.path.exists(path), \
            f"makefile already exists at {path} - it should not exist initially"


class TestToolsAvailable:
    """Test that required build tools are available."""

    def test_gcc_installed(self):
        """gcc must be installed and available in PATH."""
        result = subprocess.run(
            ["which", "gcc"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            "gcc is not installed or not in PATH"

    def test_gcc_can_run(self):
        """gcc must be executable and show version."""
        result = subprocess.run(
            ["gcc", "--version"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            f"gcc --version failed: {result.stderr}"

    def test_make_installed(self):
        """make must be installed and available in PATH."""
        result = subprocess.run(
            ["which", "make"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            "make is not installed or not in PATH"

    def test_pthread_available(self):
        """pthread library must be available for linking."""
        # Create a simple test to check pthread is available
        test_code = '#include <pthread.h>\nint main() { return 0; }'
        result = subprocess.run(
            ["gcc", "-x", "c", "-", "-lpthread", "-o", "/dev/null"],
            input=test_code,
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            f"pthread library is not available: {result.stderr}"


class TestNoBinaryExists:
    """Test that the output binary does not exist initially."""

    def test_no_profile_runner(self):
        """profile_runner binary must NOT exist initially."""
        path = "/home/user/profiling/profile_runner"
        assert not os.path.exists(path), \
            f"Binary {path} already exists - it should not exist initially"
