# test_final_state.py
"""
Tests to validate the final state of the OS/filesystem after the student
has created the Makefile for the profiling task.
"""

import os
import subprocess
import pytest


class TestMakefileExists:
    """Test that the Makefile exists with required properties."""

    def test_makefile_exists(self):
        """Makefile must exist at /home/user/profiling/Makefile."""
        path = "/home/user/profiling/Makefile"
        assert os.path.exists(path), f"Makefile does not exist at {path}"
        assert os.path.isfile(path), f"{path} exists but is not a regular file"

    def test_makefile_has_all_target(self):
        """Makefile must have a target named 'all'."""
        path = "/home/user/profiling/Makefile"
        result = subprocess.run(
            ["grep", "-E", "^all:", path],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            f"Makefile does not have an 'all:' target. The Makefile must contain a line starting with 'all:'"


class TestMakeBuilds:
    """Test that make all succeeds."""

    def test_make_all_succeeds(self):
        """Running 'make all' in /home/user/profiling must exit with code 0."""
        result = subprocess.run(
            ["make", "all"],
            cwd="/home/user/profiling",
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            f"'make all' failed with exit code {result.returncode}.\nstdout: {result.stdout}\nstderr: {result.stderr}"


class TestBinaryExists:
    """Test that the profile_runner binary exists and is executable."""

    def test_profile_runner_exists(self):
        """profile_runner binary must exist at /home/user/profiling/profile_runner."""
        path = "/home/user/profiling/profile_runner"
        assert os.path.exists(path), \
            f"Binary {path} does not exist after 'make all'"

    def test_profile_runner_is_file(self):
        """profile_runner must be a regular file."""
        path = "/home/user/profiling/profile_runner"
        assert os.path.isfile(path), \
            f"{path} exists but is not a regular file"

    def test_profile_runner_is_executable(self):
        """profile_runner must be executable."""
        path = "/home/user/profiling/profile_runner"
        assert os.access(path, os.X_OK), \
            f"{path} exists but is not executable"

    def test_profile_runner_is_elf(self):
        """profile_runner must be an ELF executable."""
        path = "/home/user/profiling/profile_runner"
        result = subprocess.run(
            ["file", path],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            f"'file' command failed: {result.stderr}"
        assert "ELF" in result.stdout, \
            f"{path} is not an ELF executable. 'file' output: {result.stdout}"


class TestDebugSymbols:
    """Test that the binary contains debug symbols (-g flag was used)."""

    def test_debug_info_present(self):
        """profile_runner must contain debug information (compiled with -g)."""
        path = "/home/user/profiling/profile_runner"
        result = subprocess.run(
            ["readelf", "--debug-dump=info", path],
            capture_output=True,
            text=True
        )
        # Check for debug info indicators
        output = result.stdout + result.stderr
        has_debug = (
            "DW_TAG" in output or
            "Compilation Unit" in output or
            "debug_info" in output
        )
        assert has_debug, \
            f"Binary {path} does not contain debug symbols. Was it compiled with -g flag? readelf output: {output[:500]}"


class TestPthreadLinkage:
    """Test that pthread is properly linked."""

    def test_pthread_linked(self):
        """profile_runner must be linked against pthread or have pthread symbols resolved."""
        path = "/home/user/profiling/profile_runner"

        # First check with ldd for dynamic linking
        ldd_result = subprocess.run(
            ["ldd", path],
            capture_output=True,
            text=True
        )

        # Check if pthread is in ldd output (dynamic linking)
        if "pthread" in ldd_result.stdout.lower():
            return  # Test passes - pthread is dynamically linked

        # If not dynamically linked, verify the binary can run
        # (which would fail if pthread symbols are missing)
        run_result = subprocess.run(
            [path],
            capture_output=True,
            text=True,
            cwd="/home/user/profiling"
        )
        assert run_result.returncode == 0, \
            f"Binary does not appear to have pthread linked (not in ldd output) and fails to run. " \
            f"ldd output: {ldd_result.stdout}\nRun error: {run_result.stderr}"


class TestBinaryRuns:
    """Test that the binary runs successfully."""

    def test_profile_runner_runs(self):
        """Running ./profile_runner must exit with code 0."""
        path = "/home/user/profiling/profile_runner"
        result = subprocess.run(
            [path],
            capture_output=True,
            text=True,
            cwd="/home/user/profiling"
        )
        assert result.returncode == 0, \
            f"./profile_runner exited with code {result.returncode}.\nstdout: {result.stdout}\nstderr: {result.stderr}"


class TestSourceFilesUnchanged:
    """Test that source files remain unchanged (invariant)."""

    def test_main_c_unchanged(self):
        """main.c must remain with its original content."""
        path = "/home/user/profiling/main.c"
        assert os.path.exists(path), f"{path} no longer exists"
        with open(path, 'r') as f:
            content = f.read()
        assert "#include <pthread.h>" in content, \
            f"main.c has been modified - missing pthread.h include"
        assert "int main()" in content or "int main(" in content, \
            f"main.c has been modified - missing main function"
        assert "return 0" in content, \
            f"main.c has been modified - missing 'return 0'"

    def test_utils_c_unchanged(self):
        """utils.c must remain with its original content."""
        path = "/home/user/profiling/utils.c"
        assert os.path.exists(path), f"{path} no longer exists"
        with open(path, 'r') as f:
            content = f.read()
        assert "void util_func()" in content or "void util_func(" in content, \
            f"utils.c has been modified - missing util_func function"

    def test_sampler_c_unchanged(self):
        """sampler.c must remain with its original content."""
        path = "/home/user/profiling/sampler.c"
        assert os.path.exists(path), f"{path} no longer exists"
        with open(path, 'r') as f:
            content = f.read()
        assert "void sampler_func()" in content or "void sampler_func(" in content, \
            f"sampler.c has been modified - missing sampler_func function"
