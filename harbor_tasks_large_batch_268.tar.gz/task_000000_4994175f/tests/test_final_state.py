# test_final_state.py
"""
Tests to validate the final state after the student has fixed the deployment bug.
This verifies all three services are running correctly and communicating properly.
"""

import json
import os
import subprocess
import time
import pytest

DEPLOY_DIR = "/home/user/deploy"
GATEWAY_URL = "http://127.0.0.1:8080"
CONFIG_SERVER_URL = "http://127.0.0.1:9001"
HEALTH_AGGREGATOR_URL = "http://127.0.0.1:9090"


def curl_request(url, timeout=5):
    """Make a curl request and return (success, response_body, error_message)."""
    try:
        result = subprocess.run(
            ['curl', '-s', '-m', str(timeout), url],
            capture_output=True,
            text=True,
            timeout=timeout + 2
        )
        if result.returncode == 0:
            return True, result.stdout, None
        else:
            return False, result.stdout, result.stderr
    except subprocess.TimeoutExpired:
        return False, None, "Request timed out"
    except Exception as e:
        return False, None, str(e)


def check_port_listening(port):
    """Check if a port is listening."""
    result = subprocess.run(
        ['ss', '-tlnp'],
        capture_output=True,
        text=True
    )
    return f":{port}" in result.stdout


class TestServicesRunning:
    """Verify all three services are running."""

    def test_pids_directory_exists(self):
        """PIDs directory should exist after services are started."""
        pids_dir = os.path.join(DEPLOY_DIR, "pids")
        assert os.path.isdir(pids_dir), f"PIDs directory {pids_dir} does not exist - services may not have been started"

    def test_config_server_port_listening(self):
        """Config server should be listening on port 9001."""
        assert check_port_listening(9001), \
            "Port 9001 is not listening - config-server may not be running"

    def test_gateway_port_listening(self):
        """Gateway should be listening on port 8080."""
        assert check_port_listening(8080), \
            "Port 8080 is not listening - gateway may not be running"

    def test_health_aggregator_port_listening(self):
        """Health aggregator should be listening on port 9090."""
        assert check_port_listening(9090), \
            "Port 9090 is not listening - health-aggregator may not be running"

    def test_pid_files_have_live_processes(self):
        """PID files should correspond to running processes."""
        pids_dir = os.path.join(DEPLOY_DIR, "pids")
        if not os.path.isdir(pids_dir):
            pytest.skip("PIDs directory does not exist")

        pid_files = [f for f in os.listdir(pids_dir) if f.endswith('.pid')]
        if not pid_files:
            pytest.skip("No PID files found")

        live_count = 0
        for pid_file in pid_files:
            pid_path = os.path.join(pids_dir, pid_file)
            try:
                with open(pid_path, 'r') as f:
                    pid = int(f.read().strip())
                # Check if process is running
                result = subprocess.run(['kill', '-0', str(pid)], capture_output=True)
                if result.returncode == 0:
                    live_count += 1
            except (ValueError, FileNotFoundError):
                pass

        assert live_count >= 1, "No live processes found from PID files"


class TestConfigServerDirect:
    """Test config-server responds correctly when accessed directly."""

    def test_config_server_health_endpoint(self):
        """Config server /health endpoint should respond."""
        success, body, error = curl_request(f"{CONFIG_SERVER_URL}/health", timeout=3)
        assert success, f"Config server health check failed: {error}"

    def test_config_server_config_endpoint(self):
        """Config server /config/myapp should return valid JSON."""
        success, body, error = curl_request(f"{CONFIG_SERVER_URL}/config/myapp", timeout=3)
        assert success, f"Config server /config/myapp failed: {error}"
        assert body, "Config server returned empty response"

        try:
            data = json.loads(body)
        except json.JSONDecodeError as e:
            pytest.fail(f"Config server did not return valid JSON: {e}. Response: {body}")

        assert 'app' in data, f"Config server response missing 'app' key. Got: {data}"
        assert data['app'] == 'myapp', f"Config server response has wrong app value. Expected 'myapp', got: {data['app']}"


class TestGatewayProxy:
    """Test gateway correctly proxies to config-server (the main bug fix)."""

    def test_gateway_health_endpoint(self):
        """Gateway /health endpoint should respond."""
        success, body, error = curl_request(f"{GATEWAY_URL}/health", timeout=3)
        assert success, f"Gateway health check failed: {error}"

    def test_gateway_proxy_responds_quickly(self):
        """Gateway /config/myapp should respond within 2 seconds (not timeout)."""
        start_time = time.time()
        success, body, error = curl_request(f"{GATEWAY_URL}/config/myapp", timeout=5)
        elapsed = time.time() - start_time

        assert success, f"Gateway proxy request failed: {error}. This suggests the upstream resolution bug is not fixed."
        assert elapsed < 3, f"Gateway took {elapsed:.1f}s to respond - should be under 2s. The upstream timeout bug may not be fixed."

    def test_gateway_proxy_returns_valid_json(self):
        """Gateway /config/myapp should return valid JSON with app field."""
        success, body, error = curl_request(f"{GATEWAY_URL}/config/myapp", timeout=5)
        assert success, f"Gateway proxy request failed: {error}"
        assert body, "Gateway returned empty response"

        try:
            data = json.loads(body)
        except json.JSONDecodeError as e:
            pytest.fail(f"Gateway did not return valid JSON: {e}. Response: {body}")

        assert 'app' in data, f"Gateway response missing 'app' key. Got: {data}"
        assert data['app'] == 'myapp', f"Gateway response has wrong app value. Expected 'myapp', got: {data['app']}"

    def test_gateway_proxy_different_app(self):
        """Gateway should proxy requests for different app names."""
        success, body, error = curl_request(f"{GATEWAY_URL}/config/testapp", timeout=5)
        assert success, f"Gateway proxy request for testapp failed: {error}"

        try:
            data = json.loads(body)
        except json.JSONDecodeError as e:
            pytest.fail(f"Gateway did not return valid JSON for testapp: {e}")

        assert data.get('app') == 'testapp', f"Gateway response has wrong app value. Expected 'testapp', got: {data.get('app')}"


class TestHealthAggregator:
    """Test health aggregator reports correct status."""

    def test_health_aggregator_status_endpoint(self):
        """Health aggregator /status should respond."""
        success, body, error = curl_request(f"{HEALTH_AGGREGATOR_URL}/status", timeout=5)
        assert success, f"Health aggregator /status failed: {error}"
        assert body, "Health aggregator returned empty response"

    def test_health_aggregator_reports_json(self):
        """Health aggregator should return valid JSON."""
        success, body, error = curl_request(f"{HEALTH_AGGREGATOR_URL}/status", timeout=5)
        assert success, f"Health aggregator request failed: {error}"

        try:
            data = json.loads(body)
        except json.JSONDecodeError as e:
            pytest.fail(f"Health aggregator did not return valid JSON: {e}. Response: {body}")

    def test_health_aggregator_shows_config_server_healthy(self):
        """Health aggregator should show config-server as healthy."""
        success, body, error = curl_request(f"{HEALTH_AGGREGATOR_URL}/status", timeout=5)
        assert success, f"Health aggregator request failed: {error}"

        data = json.loads(body)

        # Check for config-server health status - flexible structure checking
        config_server_healthy = False
        if isinstance(data, dict):
            # Could be {"config-server": {"status": "healthy"}} or {"services": [...]} etc.
            if 'config-server' in data:
                status = data['config-server']
                if isinstance(status, dict):
                    config_server_healthy = status.get('status', '').lower() in ('healthy', 'ok', 'up')
                    if not config_server_healthy:
                        config_server_healthy = status.get('healthy', False)
                elif isinstance(status, str):
                    config_server_healthy = status.lower() in ('healthy', 'ok', 'up')
            elif 'services' in data or 'targets' in data:
                services = data.get('services') or data.get('targets') or []
                for svc in services:
                    if isinstance(svc, dict) and svc.get('name') == 'config-server':
                        config_server_healthy = svc.get('status', '').lower() in ('healthy', 'ok', 'up')
                        if not config_server_healthy:
                            config_server_healthy = svc.get('healthy', False)
            # Also check if all services are marked healthy at top level
            if not config_server_healthy and data.get('all_healthy'):
                config_server_healthy = True

        assert config_server_healthy, f"Health aggregator does not show config-server as healthy. Response: {data}"

    def test_health_aggregator_shows_gateway_healthy(self):
        """Health aggregator should show gateway as healthy."""
        success, body, error = curl_request(f"{HEALTH_AGGREGATOR_URL}/status", timeout=5)
        assert success, f"Health aggregator request failed: {error}"

        data = json.loads(body)

        # Check for gateway health status - flexible structure checking
        gateway_healthy = False
        if isinstance(data, dict):
            if 'gateway' in data:
                status = data['gateway']
                if isinstance(status, dict):
                    gateway_healthy = status.get('status', '').lower() in ('healthy', 'ok', 'up')
                    if not gateway_healthy:
                        gateway_healthy = status.get('healthy', False)
                elif isinstance(status, str):
                    gateway_healthy = status.lower() in ('healthy', 'ok', 'up')
            elif 'services' in data or 'targets' in data:
                services = data.get('services') or data.get('targets') or []
                for svc in services:
                    if isinstance(svc, dict) and svc.get('name') == 'gateway':
                        gateway_healthy = svc.get('status', '').lower() in ('healthy', 'ok', 'up')
                        if not gateway_healthy:
                            gateway_healthy = svc.get('healthy', False)
            if not gateway_healthy and data.get('all_healthy'):
                gateway_healthy = True

        assert gateway_healthy, f"Health aggregator does not show gateway as healthy. Response: {data}"


class TestConfigurationIntegrity:
    """Verify configuration files maintain required structure."""

    def test_services_yaml_still_exists(self):
        """services.yaml must still exist as source of truth."""
        yaml_path = os.path.join(DEPLOY_DIR, "services.yaml")
        assert os.path.isfile(yaml_path), f"services.yaml missing at {yaml_path}"

    def test_services_yaml_has_correct_ports(self):
        """services.yaml should still define correct ports."""
        yaml_path = os.path.join(DEPLOY_DIR, "services.yaml")
        with open(yaml_path, 'r') as f:
            content = f.read()

        assert '9001' in content, "services.yaml should still reference port 9001 for config-server"
        assert '8080' in content, "services.yaml should still reference port 8080 for gateway"
        assert '9090' in content, "services.yaml should still reference port 9090 for health-aggregator"

    def test_config_server_still_binds_localhost(self):
        """Config server must still bind to 127.0.0.1 (security requirement)."""
        # Check via ss that config-server is on 127.0.0.1, not 0.0.0.0
        result = subprocess.run(['ss', '-tlnp'], capture_output=True, text=True)

        # Look for port 9001 binding
        lines = result.stdout.split('\n')
        for line in lines:
            if ':9001' in line:
                # Should be 127.0.0.1:9001, not 0.0.0.0:9001 or *:9001
                if '0.0.0.0:9001' in line or '*:9001' in line:
                    pytest.fail(f"Config server is bound to 0.0.0.0:9001 - should be 127.0.0.1:9001 for security. Line: {line}")
                break


class TestAntiShortcutGuards:
    """Verify the fix was done correctly, not via shortcuts."""

    def test_no_hardcoded_upstream_in_gateway_code(self):
        """Gateway code must NOT have hardcoded 127.0.0.1:9001."""
        server_path = os.path.join(DEPLOY_DIR, "gateway", "server.py")
        result = subprocess.run(
            ['grep', '-E', r'127\.0\.0\.1.*9001|9001.*127\.0\.0\.1', server_path],
            capture_output=True,
            text=True
        )
        # grep returns 0 if found, 1 if not found
        assert result.returncode == 1, \
            f"gateway/server.py has hardcoded upstream address 127.0.0.1:9001 - must read from config. Found: {result.stdout}"

    def test_no_config_server_in_etc_hosts(self):
        """Fix must NOT be via /etc/hosts entry."""
        try:
            with open('/etc/hosts', 'r') as f:
                content = f.read()

            lines = content.split('\n')
            for line in lines:
                # Skip comments
                stripped = line.strip()
                if stripped.startswith('#'):
                    continue
                # Check for config-server hostname
                if 'config-server' in line.lower():
                    pytest.fail(f"Fix must not use /etc/hosts entry. Found: {line}")
        except PermissionError:
            # Can't read /etc/hosts, assume it's fine
            pass

    def test_gateway_still_reads_from_services_yaml(self):
        """Gateway should still read configuration from services.yaml."""
        server_path = os.path.join(DEPLOY_DIR, "gateway", "server.py")
        with open(server_path, 'r') as f:
            content = f.read()

        # Should reference services.yaml or yaml loading
        assert 'services.yaml' in content or 'yaml' in content.lower(), \
            "gateway/server.py should still read from services.yaml"


class TestEndToEndIntegration:
    """Full integration tests for the service chain."""

    def test_full_request_chain_works(self):
        """Complete request through gateway to config-server works."""
        # This is the main test - if this passes, the bug is fixed
        success, body, error = curl_request(f"{GATEWAY_URL}/config/integration_test", timeout=5)

        assert success, \
            f"End-to-end request failed: {error}. The gateway->config-server chain is broken."

        data = json.loads(body)
        assert data.get('app') == 'integration_test', \
            f"End-to-end response incorrect. Expected app='integration_test', got: {data}"

    def test_multiple_sequential_requests(self):
        """Multiple requests should all succeed quickly."""
        for i in range(3):
            start = time.time()
            success, body, error = curl_request(f"{GATEWAY_URL}/config/app{i}", timeout=3)
            elapsed = time.time() - start

            assert success, f"Request {i} failed: {error}"
            assert elapsed < 2, f"Request {i} took {elapsed:.1f}s - too slow"

            data = json.loads(body)
            assert data.get('app') == f'app{i}', f"Request {i} returned wrong app"
