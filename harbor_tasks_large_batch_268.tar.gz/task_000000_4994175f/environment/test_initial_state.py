# test_initial_state.py
"""
Tests to validate the initial state of the deployment setup before the student fixes the bug.
This verifies the buggy configuration exists as described in the task.
"""

import os
import subprocess
import pytest

DEPLOY_DIR = "/home/user/deploy"


class TestDeployDirectoryStructure:
    """Verify the deployment directory structure exists."""

    def test_deploy_directory_exists(self):
        """The main deploy directory must exist."""
        assert os.path.isdir(DEPLOY_DIR), f"Deploy directory {DEPLOY_DIR} does not exist"

    def test_launcher_script_exists(self):
        """launcher.sh must exist and be executable."""
        launcher_path = os.path.join(DEPLOY_DIR, "launcher.sh")
        assert os.path.isfile(launcher_path), f"launcher.sh not found at {launcher_path}"
        assert os.access(launcher_path, os.X_OK), f"launcher.sh at {launcher_path} is not executable"

    def test_config_server_directory_exists(self):
        """config-server directory must exist."""
        config_server_dir = os.path.join(DEPLOY_DIR, "config-server")
        assert os.path.isdir(config_server_dir), f"config-server directory not found at {config_server_dir}"

    def test_config_server_script_exists(self):
        """config-server/server.py must exist."""
        server_path = os.path.join(DEPLOY_DIR, "config-server", "server.py")
        assert os.path.isfile(server_path), f"config-server/server.py not found at {server_path}"

    def test_gateway_directory_exists(self):
        """gateway directory must exist."""
        gateway_dir = os.path.join(DEPLOY_DIR, "gateway")
        assert os.path.isdir(gateway_dir), f"gateway directory not found at {gateway_dir}"

    def test_gateway_script_exists(self):
        """gateway/server.py must exist."""
        server_path = os.path.join(DEPLOY_DIR, "gateway", "server.py")
        assert os.path.isfile(server_path), f"gateway/server.py not found at {server_path}"

    def test_health_aggregator_directory_exists(self):
        """health-aggregator directory must exist."""
        health_dir = os.path.join(DEPLOY_DIR, "health-aggregator")
        assert os.path.isdir(health_dir), f"health-aggregator directory not found at {health_dir}"

    def test_health_aggregator_script_exists(self):
        """health-aggregator/server.py must exist."""
        server_path = os.path.join(DEPLOY_DIR, "health-aggregator", "server.py")
        assert os.path.isfile(server_path), f"health-aggregator/server.py not found at {server_path}"

    def test_services_yaml_exists(self):
        """services.yaml must exist."""
        yaml_path = os.path.join(DEPLOY_DIR, "services.yaml")
        assert os.path.isfile(yaml_path), f"services.yaml not found at {yaml_path}"

    def test_pids_directory_exists_or_can_be_created(self):
        """pids directory should exist or parent should be writable."""
        pids_dir = os.path.join(DEPLOY_DIR, "pids")
        if not os.path.exists(pids_dir):
            # Check that we can create it (parent is writable)
            assert os.access(DEPLOY_DIR, os.W_OK), f"Cannot create pids directory - {DEPLOY_DIR} is not writable"
        else:
            assert os.path.isdir(pids_dir), f"{pids_dir} exists but is not a directory"


class TestServicesYamlConfiguration:
    """Verify services.yaml has the expected buggy configuration."""

    def test_services_yaml_is_readable(self):
        """services.yaml must be readable."""
        yaml_path = os.path.join(DEPLOY_DIR, "services.yaml")
        assert os.access(yaml_path, os.R_OK), f"services.yaml at {yaml_path} is not readable"

    def test_services_yaml_contains_config_server(self):
        """services.yaml must define config-server."""
        yaml_path = os.path.join(DEPLOY_DIR, "services.yaml")
        with open(yaml_path, 'r') as f:
            content = f.read()
        assert 'config-server' in content, "services.yaml does not contain config-server definition"

    def test_services_yaml_contains_gateway(self):
        """services.yaml must define gateway."""
        yaml_path = os.path.join(DEPLOY_DIR, "services.yaml")
        with open(yaml_path, 'r') as f:
            content = f.read()
        assert 'gateway' in content, "services.yaml does not contain gateway definition"

    def test_services_yaml_contains_health_aggregator(self):
        """services.yaml must define health-aggregator."""
        yaml_path = os.path.join(DEPLOY_DIR, "services.yaml")
        with open(yaml_path, 'r') as f:
            content = f.read()
        assert 'health-aggregator' in content, "services.yaml does not contain health-aggregator definition"

    def test_services_yaml_has_upstream_host_as_config_server(self):
        """Gateway's upstream_host should be 'config-server' (the bug)."""
        yaml_path = os.path.join(DEPLOY_DIR, "services.yaml")
        with open(yaml_path, 'r') as f:
            content = f.read()
        # The bug: upstream_host is set to 'config-server' hostname, not an IP
        assert 'upstream_host: config-server' in content or 'upstream_host: "config-server"' in content or "upstream_host: 'config-server'" in content, \
            "services.yaml should have upstream_host set to 'config-server' (the buggy configuration)"

    def test_config_server_port_is_9001(self):
        """Config server should be configured for port 9001."""
        yaml_path = os.path.join(DEPLOY_DIR, "services.yaml")
        with open(yaml_path, 'r') as f:
            content = f.read()
        assert '9001' in content, "services.yaml should reference port 9001 for config-server"

    def test_gateway_port_is_8080(self):
        """Gateway should be configured for port 8080."""
        yaml_path = os.path.join(DEPLOY_DIR, "services.yaml")
        with open(yaml_path, 'r') as f:
            content = f.read()
        assert '8080' in content, "services.yaml should reference port 8080 for gateway"

    def test_health_aggregator_port_is_9090(self):
        """Health aggregator should be configured for port 9090."""
        yaml_path = os.path.join(DEPLOY_DIR, "services.yaml")
        with open(yaml_path, 'r') as f:
            content = f.read()
        assert '9090' in content, "services.yaml should reference port 9090 for health-aggregator"


class TestGatewayBuggyCode:
    """Verify the gateway code has the bug as described."""

    def test_gateway_reads_upstream_host_from_config(self):
        """Gateway should read upstream_host from config (not hardcoded)."""
        server_path = os.path.join(DEPLOY_DIR, "gateway", "server.py")
        with open(server_path, 'r') as f:
            content = f.read()
        # Should reference upstream_host from config
        assert 'upstream_host' in content, \
            "gateway/server.py should reference upstream_host from configuration"

    def test_gateway_does_not_have_hardcoded_upstream_ip(self):
        """Gateway should NOT have hardcoded 127.0.0.1:9001 (maintainability requirement)."""
        server_path = os.path.join(DEPLOY_DIR, "gateway", "server.py")
        result = subprocess.run(
            ['grep', '-E', r'127\.0\.0\.1.*9001|9001.*127\.0\.0\.1', server_path],
            capture_output=True,
            text=True
        )
        # grep returns 0 if found, 1 if not found
        assert result.returncode == 1, \
            f"gateway/server.py should NOT have hardcoded upstream address 127.0.0.1:9001. Found: {result.stdout}"


class TestConfigServerCode:
    """Verify config-server is set up correctly."""

    def test_config_server_binds_to_localhost(self):
        """Config server should bind to 127.0.0.1 (security requirement)."""
        server_path = os.path.join(DEPLOY_DIR, "config-server", "server.py")
        with open(server_path, 'r') as f:
            content = f.read()
        # Should reference binding to localhost
        assert '127.0.0.1' in content or 'localhost' in content or 'bind' in content, \
            "config-server/server.py should bind to localhost"


class TestSystemPrerequisites:
    """Verify system tools and Python are available."""

    def test_python3_available(self):
        """Python 3 must be available."""
        result = subprocess.run(['python3', '--version'], capture_output=True, text=True)
        assert result.returncode == 0, "Python 3 is not available"
        assert 'Python 3' in result.stdout, f"Expected Python 3, got: {result.stdout}"

    def test_pyyaml_installed(self):
        """PyYAML must be installed."""
        result = subprocess.run(
            ['python3', '-c', 'import yaml; print(yaml.__version__)'],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, f"PyYAML is not installed: {result.stderr}"

    def test_curl_available(self):
        """curl must be available for testing."""
        result = subprocess.run(['which', 'curl'], capture_output=True, text=True)
        assert result.returncode == 0, "curl is not available"

    def test_deploy_directory_writable(self):
        """Deploy directory must be writable."""
        assert os.access(DEPLOY_DIR, os.W_OK), f"{DEPLOY_DIR} is not writable"


class TestNoEtcHostsEntry:
    """Verify there's no config-server entry in /etc/hosts (the bug relies on this)."""

    def test_no_config_server_in_etc_hosts(self):
        """There should be no 'config-server' hostname in /etc/hosts."""
        try:
            with open('/etc/hosts', 'r') as f:
                content = f.read()
            # Check that config-server is not defined as a hostname
            lines = content.split('\n')
            for line in lines:
                # Skip comments
                if line.strip().startswith('#'):
                    continue
                if 'config-server' in line:
                    pytest.fail(f"/etc/hosts should not have config-server entry (bug relies on unresolvable hostname). Found: {line}")
        except PermissionError:
            # If we can't read /etc/hosts, that's fine - we just can't verify
            pass


class TestPortsNotInUse:
    """Verify the required ports are not already in use (services not running yet)."""

    def test_port_8080_available_or_gateway_running(self):
        """Port 8080 should be available or used by gateway."""
        result = subprocess.run(
            ['ss', '-tlnp'],
            capture_output=True,
            text=True
        )
        # This test just verifies ss works - we don't fail if ports are in use
        # as the launcher might have been run already
        assert result.returncode == 0, "ss command failed"

    def test_port_9001_available_or_config_server_running(self):
        """Port 9001 should be available or used by config-server."""
        result = subprocess.run(
            ['ss', '-tlnp'],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "ss command failed"

    def test_port_9090_available_or_health_aggregator_running(self):
        """Port 9090 should be available or used by health-aggregator."""
        result = subprocess.run(
            ['ss', '-tlnp'],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "ss command failed"


class TestLauncherScript:
    """Verify launcher.sh has expected structure."""

    def test_launcher_starts_all_three_services(self):
        """launcher.sh should reference all three services."""
        launcher_path = os.path.join(DEPLOY_DIR, "launcher.sh")
        with open(launcher_path, 'r') as f:
            content = f.read()
        assert 'config-server' in content or 'config_server' in content, \
            "launcher.sh should reference config-server"
        assert 'gateway' in content, \
            "launcher.sh should reference gateway"
        assert 'health' in content.lower(), \
            "launcher.sh should reference health-aggregator"

    def test_launcher_writes_pids(self):
        """launcher.sh should write PIDs to track processes."""
        launcher_path = os.path.join(DEPLOY_DIR, "launcher.sh")
        with open(launcher_path, 'r') as f:
            content = f.read()
        assert 'pid' in content.lower() or 'PID' in content or '$!' in content, \
            "launcher.sh should track PIDs of started services"
