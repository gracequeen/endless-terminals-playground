# test_initial_state.py
"""
Tests to validate the initial state of the system before the student performs
the task of listing manually installed packages.
"""

import os
import subprocess
import pytest


class TestInitialState:
    """Tests to verify the system is in the expected initial state."""

    def test_home_user_directory_exists(self):
        """Verify /home/user directory exists."""
        assert os.path.isdir("/home/user"), \
            "/home/user directory does not exist"

    def test_home_user_directory_is_writable(self):
        """Verify /home/user directory is writable."""
        assert os.access("/home/user", os.W_OK), \
            "/home/user directory is not writable"

    def test_output_file_does_not_exist(self):
        """Verify /home/user/manual_packages.txt does not exist yet."""
        assert not os.path.exists("/home/user/manual_packages.txt"), \
            "/home/user/manual_packages.txt already exists - it should not exist before the task"

    def test_apt_mark_command_available(self):
        """Verify apt-mark command is available."""
        result = subprocess.run(
            ["which", "apt-mark"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            "apt-mark command is not available on this system"

    def test_dpkg_command_available(self):
        """Verify dpkg command is available."""
        result = subprocess.run(
            ["which", "dpkg"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            "dpkg command is not available on this system"

    def test_dpkg_query_command_available(self):
        """Verify dpkg-query command is available."""
        result = subprocess.run(
            ["which", "dpkg-query"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            "dpkg-query command is not available on this system"

    def test_apt_command_available(self):
        """Verify apt command is available."""
        result = subprocess.run(
            ["which", "apt"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            "apt command is not available on this system"

    def test_sort_command_available(self):
        """Verify sort command is available."""
        result = subprocess.run(
            ["which", "sort"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            "sort command is not available on this system"

    def test_apt_mark_showmanual_works(self):
        """Verify apt-mark showmanual command works and returns packages."""
        result = subprocess.run(
            ["apt-mark", "showmanual"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            f"apt-mark showmanual failed with error: {result.stderr}"

    def test_manual_packages_exist(self):
        """Verify there are manually installed packages on the system."""
        result = subprocess.run(
            ["apt-mark", "showmanual"],
            capture_output=True,
            text=True
        )
        packages = [p.strip() for p in result.stdout.strip().split('\n') if p.strip()]
        assert len(packages) >= 10, \
            f"Expected at least 10 manually installed packages, found {len(packages)}. " \
            "The system should have various packages marked as manually installed."

    def test_auto_packages_exist(self):
        """Verify there are auto-installed packages (dependencies) on the system."""
        result = subprocess.run(
            ["apt-mark", "showauto"],
            capture_output=True,
            text=True
        )
        packages = [p.strip() for p in result.stdout.strip().split('\n') if p.strip()]
        assert len(packages) >= 1, \
            "Expected at least some auto-installed packages (dependencies) on the system. " \
            "This is needed to verify the student filters them out correctly."

    def test_ubuntu_system(self):
        """Verify this is an Ubuntu system."""
        assert os.path.exists("/etc/os-release"), \
            "/etc/os-release does not exist - cannot verify Ubuntu system"

        with open("/etc/os-release", "r") as f:
            content = f.read().lower()

        assert "ubuntu" in content, \
            "This does not appear to be an Ubuntu system based on /etc/os-release"

    def test_dpkg_status_file_exists(self):
        """Verify dpkg status file exists (needed for package queries)."""
        assert os.path.exists("/var/lib/dpkg/status"), \
            "/var/lib/dpkg/status does not exist - dpkg database may be corrupted"

    def test_apt_extended_states_exists(self):
        """Verify apt extended states file exists (tracks manual/auto status)."""
        # This file may not exist on fresh systems, but should exist on systems
        # with auto-installed packages
        extended_states = "/var/lib/apt/extended_states"
        if os.path.exists(extended_states):
            assert os.access(extended_states, os.R_OK), \
                f"{extended_states} exists but is not readable"
        # If it doesn't exist, that's okay - apt-mark will still work
