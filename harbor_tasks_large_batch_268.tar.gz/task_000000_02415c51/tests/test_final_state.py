# test_final_state.py
"""
Tests to validate the final state of the system after the student has
listed manually installed packages to /home/user/manual_packages.txt.
"""

import os
import subprocess
import pytest


class TestFinalState:
    """Tests to verify the task was completed correctly."""

    def test_output_file_exists(self):
        """Verify /home/user/manual_packages.txt exists."""
        assert os.path.exists("/home/user/manual_packages.txt"), \
            "/home/user/manual_packages.txt does not exist - task not completed"

    def test_output_file_is_regular_file(self):
        """Verify the output is a regular file, not a directory or symlink."""
        filepath = "/home/user/manual_packages.txt"
        assert os.path.isfile(filepath), \
            f"{filepath} exists but is not a regular file"

    def test_output_file_is_readable(self):
        """Verify the output file is readable."""
        filepath = "/home/user/manual_packages.txt"
        assert os.access(filepath, os.R_OK), \
            f"{filepath} exists but is not readable"

    def test_output_file_not_empty(self):
        """Verify the output file is not empty."""
        filepath = "/home/user/manual_packages.txt"
        assert os.path.getsize(filepath) > 0, \
            f"{filepath} is empty - should contain package names"

    def test_output_file_ends_with_newline(self):
        """Verify the output file ends with a newline."""
        filepath = "/home/user/manual_packages.txt"
        with open(filepath, "rb") as f:
            content = f.read()
        assert content.endswith(b"\n"), \
            f"{filepath} does not end with a newline"

    def test_minimum_package_count(self):
        """Verify the file contains at least 10 packages (sanity check)."""
        filepath = "/home/user/manual_packages.txt"
        with open(filepath, "r") as f:
            lines = [line.strip() for line in f if line.strip()]
        assert len(lines) >= 10, \
            f"File contains only {len(lines)} packages, expected at least 10. " \
            "The file may be truncated or incomplete."

    def test_one_package_per_line(self):
        """Verify each line contains exactly one package name (no spaces/multiple entries)."""
        filepath = "/home/user/manual_packages.txt"
        with open(filepath, "r") as f:
            lines = [line.strip() for line in f if line.strip()]

        for i, line in enumerate(lines, 1):
            # Package names should not contain spaces
            assert " " not in line, \
                f"Line {i} contains spaces: '{line}'. Each line should have one package name."
            # Package names should not contain tabs
            assert "\t" not in line, \
                f"Line {i} contains tabs: '{line}'. Each line should have one package name."

    def test_no_version_numbers(self):
        """Verify package names don't include version numbers."""
        filepath = "/home/user/manual_packages.txt"
        with open(filepath, "r") as f:
            lines = [line.strip() for line in f if line.strip()]

        for line in lines:
            # Version numbers typically follow a colon or are after package name
            assert ":" not in line or line.endswith(":i386") or line.endswith(":amd64") or line.endswith(":arm64"), \
                f"Package '{line}' may contain a version number (unexpected colon)"
            # Check for common version patterns
            import re
            # This pattern catches things like "package=1.2.3" or "package 1.2.3"
            assert not re.search(r'[=\s]\d+\.', line), \
                f"Package '{line}' appears to contain a version number"

    def test_packages_are_sorted(self):
        """Verify packages are sorted alphabetically."""
        filepath = "/home/user/manual_packages.txt"
        with open(filepath, "r") as f:
            lines = [line.strip() for line in f if line.strip()]

        sorted_lines = sorted(lines)
        assert lines == sorted_lines, \
            "Packages are not sorted alphabetically. " \
            f"First mismatch: expected '{sorted_lines[0]}' but got '{lines[0]}' at position 0" \
            if lines and sorted_lines and lines[0] != sorted_lines[0] else \
            "Packages are not sorted alphabetically."

    def test_matches_apt_mark_showmanual(self):
        """Verify file contents match apt-mark showmanual output."""
        filepath = "/home/user/manual_packages.txt"

        # Get expected packages from apt-mark
        result = subprocess.run(
            ["apt-mark", "showmanual"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            f"apt-mark showmanual failed: {result.stderr}"

        expected_packages = sorted([p.strip() for p in result.stdout.strip().split('\n') if p.strip()])

        # Get actual packages from file
        with open(filepath, "r") as f:
            actual_packages = [line.strip() for line in f if line.strip()]

        # Compare as sets first to identify missing/extra packages
        expected_set = set(expected_packages)
        actual_set = set(actual_packages)

        missing = expected_set - actual_set
        extra = actual_set - expected_set

        error_msg = ""
        if missing:
            error_msg += f"Missing packages (in apt-mark showmanual but not in file): {sorted(missing)[:10]}"
            if len(missing) > 10:
                error_msg += f" ... and {len(missing) - 10} more"
        if extra:
            if error_msg:
                error_msg += "\n"
            error_msg += f"Extra packages (in file but not in apt-mark showmanual): {sorted(extra)[:10]}"
            if len(extra) > 10:
                error_msg += f" ... and {len(extra) - 10} more"

        assert expected_set == actual_set, \
            f"File contents don't match apt-mark showmanual output.\n{error_msg}"

    def test_no_auto_packages_included(self):
        """Verify no auto-installed packages are in the file."""
        filepath = "/home/user/manual_packages.txt"

        # Get auto packages from apt-mark
        result = subprocess.run(
            ["apt-mark", "showauto"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            f"apt-mark showauto failed: {result.stderr}"

        auto_packages = set(p.strip() for p in result.stdout.strip().split('\n') if p.strip())

        # Get actual packages from file
        with open(filepath, "r") as f:
            actual_packages = set(line.strip() for line in f if line.strip())

        # Check for intersection (should be empty)
        incorrectly_included = actual_packages & auto_packages

        assert not incorrectly_included, \
            f"File contains auto-installed packages that should not be included: " \
            f"{sorted(incorrectly_included)[:10]}" + \
            (f" ... and {len(incorrectly_included) - 10} more" if len(incorrectly_included) > 10 else "")

    def test_no_duplicate_packages(self):
        """Verify there are no duplicate package entries."""
        filepath = "/home/user/manual_packages.txt"
        with open(filepath, "r") as f:
            lines = [line.strip() for line in f if line.strip()]

        seen = set()
        duplicates = []
        for line in lines:
            if line in seen:
                duplicates.append(line)
            seen.add(line)

        assert not duplicates, \
            f"File contains duplicate entries: {duplicates[:10]}" + \
            (f" ... and {len(duplicates) - 10} more" if len(duplicates) > 10 else "")

    def test_valid_package_names(self):
        """Verify all entries look like valid Debian package names."""
        filepath = "/home/user/manual_packages.txt"
        with open(filepath, "r") as f:
            lines = [line.strip() for line in f if line.strip()]

        import re
        # Debian package names: lowercase, digits, +, -, . (must start with alphanumeric)
        # May have :arch suffix
        package_pattern = re.compile(r'^[a-z0-9][a-z0-9+.\-]*(:[a-z0-9]+)?$')

        invalid = []
        for line in lines:
            if not package_pattern.match(line):
                invalid.append(line)

        assert not invalid, \
            f"File contains invalid package names: {invalid[:10]}" + \
            (f" ... and {len(invalid) - 10} more" if len(invalid) > 10 else "")
