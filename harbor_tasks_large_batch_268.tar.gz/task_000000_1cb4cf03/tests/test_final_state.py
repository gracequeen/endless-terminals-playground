# test_final_state.py
"""
Tests to validate the final state after the student has fixed the changelog generator.
Verifies that the script works correctly and produces proper output.
"""

import os
import subprocess
import pytest
import re

REPO_PATH = "/home/user/backup-tools"
SCRIPT_PATH = os.path.join(REPO_PATH, "generate_changelog.sh")
LIB_DIR = os.path.join(REPO_PATH, "lib")
VERSION_UTILS_PATH = os.path.join(LIB_DIR, "version_utils.sh")
CHANGELOG_FORMAT_PATH = os.path.join(LIB_DIR, "changelog_format.sh")
CHANGELOG_PATH = os.path.join(REPO_PATH, "CHANGELOG.md")

EXPECTED_TAGS = ["v2.0.0", "v2.1.0", "v2.1.1", "v2.2.0", "v2.3.0", "v2.3.1"]


class TestScriptExecution:
    """Verify the script runs successfully and produces expected output."""

    def test_script_exits_zero(self):
        """Running generate_changelog.sh should exit with code 0."""
        result = subprocess.run(
            ["./generate_changelog.sh"],
            cwd=REPO_PATH,
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            f"Script exited with code {result.returncode}. stderr: {result.stderr}, stdout: {result.stdout}"

    def test_script_prints_success_message(self):
        """Script should print 'Changelog written to CHANGELOG.md'."""
        result = subprocess.run(
            ["./generate_changelog.sh"],
            cwd=REPO_PATH,
            capture_output=True,
            text=True
        )
        assert "Changelog written to CHANGELOG.md" in result.stdout, \
            f"Expected success message not found. stdout: {result.stdout}"

    def test_script_does_not_print_no_version_history(self):
        """Script should NOT print 'No version history found' anymore."""
        result = subprocess.run(
            ["./generate_changelog.sh"],
            cwd=REPO_PATH,
            capture_output=True,
            text=True
        )
        assert "No version history found" not in result.stdout, \
            f"Script still outputs 'No version history found' - bug not fixed. stdout: {result.stdout}"


class TestChangelogFileExists:
    """Verify CHANGELOG.md is created with proper content."""

    def test_changelog_file_exists(self):
        """CHANGELOG.md should exist after running the script."""
        # Run the script first to ensure file is generated
        subprocess.run(["./generate_changelog.sh"], cwd=REPO_PATH, capture_output=True)
        assert os.path.isfile(CHANGELOG_PATH), \
            f"CHANGELOG.md does not exist at {CHANGELOG_PATH}"

    def test_changelog_has_header(self):
        """CHANGELOG.md should have a '# Changelog' header."""
        subprocess.run(["./generate_changelog.sh"], cwd=REPO_PATH, capture_output=True)
        with open(CHANGELOG_PATH, 'r') as f:
            content = f.read()
        assert "# Changelog" in content, \
            "CHANGELOG.md should contain '# Changelog' header"

    def test_changelog_has_version_sections(self):
        """CHANGELOG.md should have section headers for all expected versions."""
        subprocess.run(["./generate_changelog.sh"], cwd=REPO_PATH, capture_output=True)
        with open(CHANGELOG_PATH, 'r') as f:
            content = f.read()

        for tag in EXPECTED_TAGS:
            # Look for version as a section header (## v2.3.1 format)
            assert tag in content, \
                f"CHANGELOG.md should contain version section for '{tag}'. Content:\n{content}"

    def test_changelog_versions_in_descending_order(self):
        """Version sections should appear in descending order (newest first)."""
        subprocess.run(["./generate_changelog.sh"], cwd=REPO_PATH, capture_output=True)
        with open(CHANGELOG_PATH, 'r') as f:
            content = f.read()

        # Find positions of each version tag in the file
        positions = {}
        for tag in EXPECTED_TAGS:
            pos = content.find(tag)
            if pos != -1:
                positions[tag] = pos

        # Check descending order: v2.3.1 should appear before v2.3.0, etc.
        sorted_by_version = sorted(EXPECTED_TAGS, key=lambda x: [int(n) for n in x[1:].split('.')], reverse=True)

        for i in range(len(sorted_by_version) - 1):
            current = sorted_by_version[i]
            next_tag = sorted_by_version[i + 1]
            if current in positions and next_tag in positions:
                assert positions[current] < positions[next_tag], \
                    f"Version {current} should appear before {next_tag} in CHANGELOG.md"

    def test_changelog_has_minimum_lines(self):
        """CHANGELOG.md should have at least 20 lines."""
        subprocess.run(["./generate_changelog.sh"], cwd=REPO_PATH, capture_output=True)
        with open(CHANGELOG_PATH, 'r') as f:
            lines = f.readlines()
        assert len(lines) >= 20, \
            f"CHANGELOG.md should have at least 20 lines, found {len(lines)}"

    def test_changelog_has_commit_list_items(self):
        """CHANGELOG.md should contain commit messages as list items."""
        subprocess.run(["./generate_changelog.sh"], cwd=REPO_PATH, capture_output=True)
        with open(CHANGELOG_PATH, 'r') as f:
            content = f.read()

        # List items start with '- '
        list_items = [line for line in content.split('\n') if line.strip().startswith('- ')]
        assert len(list_items) >= 6, \
            f"CHANGELOG.md should have at least 6 commit list items, found {len(list_items)}"


class TestGitTagsUnchanged:
    """Verify git tags were not renamed (invariant)."""

    def test_original_tags_still_exist(self):
        """All original v-prefixed tags should still exist."""
        result = subprocess.run(
            ["git", "tag"],
            cwd=REPO_PATH,
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, f"Failed to list git tags: {result.stderr}"
        tags = result.stdout.strip().split('\n')
        tags = [t.strip() for t in tags if t.strip()]

        for expected_tag in EXPECTED_TAGS:
            assert expected_tag in tags, \
                f"Original tag '{expected_tag}' is missing - tags should not be renamed. Found: {tags}"

    def test_no_release_prefixed_tags(self):
        """No 'release-' prefixed tags should exist (tags weren't migrated)."""
        result = subprocess.run(
            ["git", "tag"],
            cwd=REPO_PATH,
            capture_output=True,
            text=True
        )
        tags = result.stdout.strip().split('\n')
        release_tags = [t for t in tags if t.startswith('release-')]
        assert len(release_tags) == 0, \
            f"Found 'release-' prefixed tags which shouldn't exist: {release_tags}"


class TestScriptStructurePreserved:
    """Verify the overall structure of shell scripts is preserved (invariant)."""

    def test_generate_changelog_still_sources_libs(self):
        """generate_changelog.sh should still source the two lib files."""
        with open(SCRIPT_PATH, 'r') as f:
            content = f.read()
        assert "source" in content or "." in content, \
            "generate_changelog.sh should still use source/. to include libs"
        assert "version_utils.sh" in content, \
            "generate_changelog.sh should still reference version_utils.sh"
        assert "changelog_format.sh" in content, \
            "generate_changelog.sh should still reference changelog_format.sh"

    def test_version_utils_still_uses_version_pattern(self):
        """version_utils.sh should still use VERSION_PATTERN."""
        with open(VERSION_UTILS_PATH, 'r') as f:
            content = f.read()
        assert "VERSION_PATTERN" in content, \
            "version_utils.sh should still use VERSION_PATTERN variable"
        assert "get_version_tags" in content, \
            "version_utils.sh should still define get_version_tags function"

    def test_changelog_format_still_generates_markdown(self):
        """changelog_format.sh should still have generate_markdown function."""
        with open(CHANGELOG_FORMAT_PATH, 'r') as f:
            content = f.read()
        assert "generate_markdown" in content, \
            "changelog_format.sh should still define generate_markdown function"


class TestPatternFixedInScripts:
    """Verify the fix was made in the shell scripts to match v-prefixed tags."""

    def test_pattern_matches_v_prefix(self):
        """VERSION_PATTERN should now match v-prefixed tags."""
        # Check both files for the pattern fix
        with open(CHANGELOG_FORMAT_PATH, 'r') as f:
            changelog_format_content = f.read()
        with open(VERSION_UTILS_PATH, 'r') as f:
            version_utils_content = f.read()

        combined = changelog_format_content + version_utils_content

        # The pattern should match v-prefixed versions
        # Check for patterns like 'v[0-9]', '^v[0-9]', 'v\d', etc.
        v_pattern_found = bool(re.search(r'v\[?[0-9\\d]', combined))

        assert v_pattern_found, \
            "Neither changelog_format.sh nor version_utils.sh contains a pattern matching v-prefixed tags. " \
            "The fix should update VERSION_PATTERN to match tags like v2.3.1"


class TestAntiShortcut:
    """Verify the fix is legitimate and not a shortcut."""

    def test_changelog_regenerates_correctly(self):
        """Deleting CHANGELOG.md and re-running should recreate it with same structure."""
        # Delete existing CHANGELOG.md if present
        if os.path.exists(CHANGELOG_PATH):
            os.remove(CHANGELOG_PATH)

        # Run the script
        result = subprocess.run(
            ["./generate_changelog.sh"],
            cwd=REPO_PATH,
            capture_output=True,
            text=True
        )

        assert result.returncode == 0, \
            f"Script failed after deleting CHANGELOG.md. stderr: {result.stderr}"
        assert "Changelog written to CHANGELOG.md" in result.stdout, \
            "Script should print success message after regenerating"
        assert os.path.isfile(CHANGELOG_PATH), \
            "CHANGELOG.md was not recreated by the script"

        # Verify regenerated file has proper content
        with open(CHANGELOG_PATH, 'r') as f:
            content = f.read()

        assert "# Changelog" in content, \
            "Regenerated CHANGELOG.md missing header"

        for tag in EXPECTED_TAGS:
            assert tag in content, \
                f"Regenerated CHANGELOG.md missing version section for {tag}"

        lines = content.split('\n')
        assert len(lines) >= 20, \
            f"Regenerated CHANGELOG.md has only {len(lines)} lines, expected at least 20"

    def test_fix_not_hardcoded_output(self):
        """The script should actually use git to generate content, not hardcoded text."""
        # Get actual commits from git
        result = subprocess.run(
            ["git", "log", "--oneline", "-n", "30"],
            cwd=REPO_PATH,
            capture_output=True,
            text=True
        )
        commits = result.stdout.strip().split('\n')

        # Run the changelog script
        subprocess.run(["./generate_changelog.sh"], cwd=REPO_PATH, capture_output=True)

        with open(CHANGELOG_PATH, 'r') as f:
            changelog_content = f.read()

        # At least some commit messages should appear in the changelog
        matches = 0
        for commit in commits:
            # Extract the message part (after the hash)
            parts = commit.split(' ', 1)
            if len(parts) > 1:
                msg = parts[1]
                if msg in changelog_content:
                    matches += 1

        assert matches >= 3, \
            f"CHANGELOG.md should contain actual git commit messages. Only found {matches} matches."


class TestGitHistoryUnchanged:
    """Verify git history was not modified."""

    def test_git_log_has_commits(self):
        """Git history should still have commits."""
        result = subprocess.run(
            ["git", "log", "--oneline"],
            cwd=REPO_PATH,
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, f"Failed to get git log: {result.stderr}"
        commits = result.stdout.strip().split('\n')
        assert len(commits) >= 10, \
            f"Git history should have at least 10 commits, found {len(commits)}"

    def test_tags_still_annotated(self):
        """Tags should still be annotated."""
        for tag in EXPECTED_TAGS:
            result = subprocess.run(
                ["git", "cat-file", "-t", tag],
                cwd=REPO_PATH,
                capture_output=True,
                text=True
            )
            assert result.returncode == 0, f"Tag {tag} does not exist"
            tag_type = result.stdout.strip()
            assert tag_type == "tag", \
                f"Tag {tag} should still be annotated (type: {tag_type})"
