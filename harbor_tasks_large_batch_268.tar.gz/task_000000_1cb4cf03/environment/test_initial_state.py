# test_initial_state.py
"""
Tests to validate the initial state of the system before the student performs the task.
This verifies the broken changelog generator setup at /home/user/backup-tools.
"""

import os
import subprocess
import pytest

REPO_PATH = "/home/user/backup-tools"
SCRIPT_PATH = os.path.join(REPO_PATH, "generate_changelog.sh")
LIB_DIR = os.path.join(REPO_PATH, "lib")
VERSION_UTILS_PATH = os.path.join(LIB_DIR, "version_utils.sh")
CHANGELOG_FORMAT_PATH = os.path.join(LIB_DIR, "changelog_format.sh")


class TestRepositoryExists:
    """Verify the git repository exists and is properly initialized."""

    def test_backup_tools_directory_exists(self):
        assert os.path.isdir(REPO_PATH), f"Directory {REPO_PATH} does not exist"

    def test_is_git_repository(self):
        git_dir = os.path.join(REPO_PATH, ".git")
        assert os.path.isdir(git_dir), f"{REPO_PATH} is not a git repository (no .git directory)"

    def test_lib_directory_exists(self):
        assert os.path.isdir(LIB_DIR), f"Directory {LIB_DIR} does not exist"


class TestGitTags:
    """Verify the expected git tags exist with v-prefix format."""

    EXPECTED_TAGS = ["v2.0.0", "v2.1.0", "v2.1.1", "v2.2.0", "v2.3.0", "v2.3.1"]

    def test_git_tags_exist(self):
        result = subprocess.run(
            ["git", "tag"],
            cwd=REPO_PATH,
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, f"Failed to list git tags: {result.stderr}"
        tags = result.stdout.strip().split('\n')
        tags = [t.strip() for t in tags if t.strip()]

        for expected_tag in self.EXPECTED_TAGS:
            assert expected_tag in tags, f"Expected tag '{expected_tag}' not found. Found tags: {tags}"

    def test_tags_are_annotated(self):
        """Verify tags are annotated (not lightweight)."""
        for tag in self.EXPECTED_TAGS:
            result = subprocess.run(
                ["git", "cat-file", "-t", tag],
                cwd=REPO_PATH,
                capture_output=True,
                text=True
            )
            assert result.returncode == 0, f"Tag {tag} does not exist"
            # Annotated tags point to 'tag' objects, lightweight tags point to 'commit'
            tag_type = result.stdout.strip()
            assert tag_type == "tag", f"Tag {tag} is not annotated (type: {tag_type})"

    def test_tags_have_commits_between_them(self):
        """Verify there are commits between tags."""
        result = subprocess.run(
            ["git", "log", "--oneline"],
            cwd=REPO_PATH,
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, f"Failed to get git log: {result.stderr}"
        commits = result.stdout.strip().split('\n')
        # Should have multiple commits (at least 2-5 per tag interval * 5 intervals)
        assert len(commits) >= 10, f"Expected at least 10 commits, found {len(commits)}"


class TestScriptFiles:
    """Verify the shell script files exist with expected structure."""

    def test_generate_changelog_exists(self):
        assert os.path.isfile(SCRIPT_PATH), f"Script {SCRIPT_PATH} does not exist"

    def test_generate_changelog_is_executable(self):
        assert os.access(SCRIPT_PATH, os.X_OK), f"Script {SCRIPT_PATH} is not executable"

    def test_version_utils_exists(self):
        assert os.path.isfile(VERSION_UTILS_PATH), f"Script {VERSION_UTILS_PATH} does not exist"

    def test_changelog_format_exists(self):
        assert os.path.isfile(CHANGELOG_FORMAT_PATH), f"Script {CHANGELOG_FORMAT_PATH} does not exist"


class TestGenerateChangelogScript:
    """Verify the main script has expected structure."""

    def test_sources_version_utils(self):
        with open(SCRIPT_PATH, 'r') as f:
            content = f.read()
        assert "source" in content and "version_utils.sh" in content, \
            "generate_changelog.sh should source lib/version_utils.sh"

    def test_sources_changelog_format(self):
        with open(SCRIPT_PATH, 'r') as f:
            content = f.read()
        assert "source" in content and "changelog_format.sh" in content, \
            "generate_changelog.sh should source lib/changelog_format.sh"

    def test_calls_get_version_tags(self):
        with open(SCRIPT_PATH, 'r') as f:
            content = f.read()
        assert "get_version_tags" in content, \
            "generate_changelog.sh should call get_version_tags function"

    def test_calls_generate_markdown(self):
        with open(SCRIPT_PATH, 'r') as f:
            content = f.read()
        assert "generate_markdown" in content, \
            "generate_changelog.sh should call generate_markdown function"

    def test_outputs_to_changelog_md(self):
        with open(SCRIPT_PATH, 'r') as f:
            content = f.read()
        assert "CHANGELOG.md" in content, \
            "generate_changelog.sh should output to CHANGELOG.md"


class TestVersionUtilsScript:
    """Verify version_utils.sh has expected structure."""

    def test_defines_get_version_tags(self):
        with open(VERSION_UTILS_PATH, 'r') as f:
            content = f.read()
        assert "get_version_tags" in content, \
            "version_utils.sh should define get_version_tags function"

    def test_uses_version_pattern(self):
        with open(VERSION_UTILS_PATH, 'r') as f:
            content = f.read()
        assert "VERSION_PATTERN" in content, \
            "version_utils.sh should use VERSION_PATTERN variable"

    def test_uses_git_tag(self):
        with open(VERSION_UTILS_PATH, 'r') as f:
            content = f.read()
        assert "git tag" in content, \
            "version_utils.sh should use git tag command"


class TestChangelogFormatScript:
    """Verify changelog_format.sh has expected structure and the bug."""

    def test_defines_version_pattern(self):
        with open(CHANGELOG_FORMAT_PATH, 'r') as f:
            content = f.read()
        assert "VERSION_PATTERN" in content, \
            "changelog_format.sh should define VERSION_PATTERN"

    def test_defines_generate_markdown(self):
        with open(CHANGELOG_FORMAT_PATH, 'r') as f:
            content = f.read()
        assert "generate_markdown" in content, \
            "changelog_format.sh should define generate_markdown function"

    def test_version_pattern_uses_release_prefix(self):
        """Verify the bug exists - pattern expects 'release-' prefix instead of 'v'."""
        with open(CHANGELOG_FORMAT_PATH, 'r') as f:
            content = f.read()
        assert "release-" in content, \
            "changelog_format.sh should have the buggy 'release-' pattern"

    def test_version_pattern_does_not_match_v_prefix(self):
        """Verify the pattern doesn't match v-prefixed tags (the bug)."""
        with open(CHANGELOG_FORMAT_PATH, 'r') as f:
            content = f.read()
        # Check that the VERSION_PATTERN line contains release- and not v prefix
        for line in content.split('\n'):
            if 'VERSION_PATTERN=' in line:
                assert 'release-' in line, \
                    "VERSION_PATTERN should contain 'release-' (the bug)"
                # The pattern should NOT already be fixed to match v-prefix
                assert "'^v" not in line, \
                    "VERSION_PATTERN should not already be fixed to match v-prefix"
                break


class TestBrokenBehavior:
    """Verify the script is currently broken as described."""

    def test_script_outputs_no_version_history(self):
        """Running the script should output 'No version history found' due to the bug."""
        result = subprocess.run(
            ["./generate_changelog.sh"],
            cwd=REPO_PATH,
            capture_output=True,
            text=True
        )
        assert "No version history found" in result.stdout, \
            f"Expected 'No version history found' in output, got: {result.stdout}"

    def test_changelog_md_not_created_or_empty(self):
        """The script should not create a proper CHANGELOG.md due to the bug."""
        # First run the script
        subprocess.run(
            ["./generate_changelog.sh"],
            cwd=REPO_PATH,
            capture_output=True,
            text=True
        )
        changelog_path = os.path.join(REPO_PATH, "CHANGELOG.md")
        # Either file doesn't exist or it's empty/minimal
        if os.path.exists(changelog_path):
            with open(changelog_path, 'r') as f:
                content = f.read()
            # If file exists, it should NOT have the version sections
            assert "v2.3.1" not in content, \
                "CHANGELOG.md should not contain version sections yet (bug not fixed)"


class TestGitCommitMessages:
    """Verify commits have conventional commit messages."""

    def test_commits_have_conventional_format(self):
        """Check that commit messages follow conventional format."""
        result = subprocess.run(
            ["git", "log", "--oneline", "--all"],
            cwd=REPO_PATH,
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, f"Failed to get git log: {result.stderr}"

        commits = result.stdout.strip().split('\n')
        conventional_prefixes = ['fix:', 'feat:', 'docs:', 'chore:', 'refactor:', 'test:', 'style:']

        conventional_count = 0
        for commit in commits:
            for prefix in conventional_prefixes:
                if prefix in commit.lower():
                    conventional_count += 1
                    break

        # At least some commits should have conventional format
        assert conventional_count >= 5, \
            f"Expected at least 5 commits with conventional format, found {conventional_count}"


class TestToolsAvailable:
    """Verify required tools are available."""

    def test_git_available(self):
        result = subprocess.run(["which", "git"], capture_output=True, text=True)
        assert result.returncode == 0, "git is not available"

    def test_bash_available(self):
        result = subprocess.run(["which", "bash"], capture_output=True, text=True)
        assert result.returncode == 0, "bash is not available"

    def test_grep_available(self):
        result = subprocess.run(["which", "grep"], capture_output=True, text=True)
        assert result.returncode == 0, "grep is not available"


class TestDirectoryWritable:
    """Verify the repository is writable."""

    def test_repo_is_writable(self):
        assert os.access(REPO_PATH, os.W_OK), f"{REPO_PATH} is not writable"

    def test_lib_is_writable(self):
        assert os.access(LIB_DIR, os.W_OK), f"{LIB_DIR} is not writable"
