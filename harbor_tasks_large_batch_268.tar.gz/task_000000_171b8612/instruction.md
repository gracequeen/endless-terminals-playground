I need to grab all the unique source IPs from /home/user/logs/traffic.csv — it's the third column, has a header row. Just dump them sorted to /home/user/ips.txt, one per line.
