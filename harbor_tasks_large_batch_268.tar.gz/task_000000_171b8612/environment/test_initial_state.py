# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the task of extracting unique source IPs from traffic.csv.
"""

import os
import re
import pytest


class TestInitialState:
    """Validate the initial state before the task is performed."""

    def test_home_user_directory_exists(self):
        """Verify /home/user directory exists."""
        assert os.path.isdir("/home/user"), "/home/user directory does not exist"

    def test_home_user_is_writable(self):
        """Verify /home/user is writable."""
        assert os.access("/home/user", os.W_OK), "/home/user is not writable"

    def test_logs_directory_exists(self):
        """Verify /home/user/logs directory exists."""
        assert os.path.isdir("/home/user/logs"), "/home/user/logs directory does not exist"

    def test_logs_directory_is_readable(self):
        """Verify /home/user/logs is readable."""
        assert os.access("/home/user/logs", os.R_OK), "/home/user/logs is not readable"

    def test_traffic_csv_exists(self):
        """Verify /home/user/logs/traffic.csv exists."""
        assert os.path.isfile("/home/user/logs/traffic.csv"), \
            "/home/user/logs/traffic.csv does not exist"

    def test_traffic_csv_is_readable(self):
        """Verify /home/user/logs/traffic.csv is readable."""
        assert os.access("/home/user/logs/traffic.csv", os.R_OK), \
            "/home/user/logs/traffic.csv is not readable"

    def test_traffic_csv_has_500_lines(self):
        """Verify traffic.csv has exactly 500 lines (1 header + 499 data rows)."""
        with open("/home/user/logs/traffic.csv", "r") as f:
            line_count = sum(1 for _ in f)
        assert line_count == 500, \
            f"traffic.csv should have 500 lines, but has {line_count}"

    def test_traffic_csv_header_format(self):
        """Verify the header row matches expected format."""
        with open("/home/user/logs/traffic.csv", "r") as f:
            header = f.readline().strip()
        expected_header = "timestamp,dest_port,src_ip,bytes,protocol"
        assert header == expected_header, \
            f"Header should be '{expected_header}', but got '{header}'"

    def test_traffic_csv_third_column_is_src_ip(self):
        """Verify the third column in header is 'src_ip'."""
        with open("/home/user/logs/traffic.csv", "r") as f:
            header = f.readline().strip()
        columns = header.split(",")
        assert len(columns) >= 3, \
            f"Header should have at least 3 columns, but has {len(columns)}"
        assert columns[2] == "src_ip", \
            f"Third column should be 'src_ip', but got '{columns[2]}'"

    def test_traffic_csv_data_rows_have_valid_ips(self):
        """Verify data rows contain valid IPv4 addresses in the third column."""
        ip_pattern = re.compile(r"^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$")
        with open("/home/user/logs/traffic.csv", "r") as f:
            # Skip header
            next(f)
            for line_num, line in enumerate(f, start=2):
                columns = line.strip().split(",")
                assert len(columns) >= 3, \
                    f"Line {line_num} should have at least 3 columns"
                src_ip = columns[2]
                assert ip_pattern.match(src_ip), \
                    f"Line {line_num}: '{src_ip}' is not a valid IPv4 address format"

    def test_traffic_csv_has_47_unique_ips(self):
        """Verify there are exactly 47 unique source IPs in the data rows."""
        unique_ips = set()
        with open("/home/user/logs/traffic.csv", "r") as f:
            # Skip header
            next(f)
            for line in f:
                columns = line.strip().split(",")
                if len(columns) >= 3:
                    unique_ips.add(columns[2])
        assert len(unique_ips) == 47, \
            f"Should have 47 unique source IPs, but found {len(unique_ips)}"

    def test_ips_txt_does_not_exist(self):
        """Verify /home/user/ips.txt does not exist initially."""
        assert not os.path.exists("/home/user/ips.txt"), \
            "/home/user/ips.txt should not exist initially"

    def test_required_tools_available(self):
        """Verify standard coreutils tools are available."""
        import shutil
        tools = ["cut", "sort", "uniq", "awk", "sed", "grep", "tail", "head"]
        missing_tools = []
        for tool in tools:
            if shutil.which(tool) is None:
                missing_tools.append(tool)
        assert not missing_tools, \
            f"Required tools are missing: {', '.join(missing_tools)}"

    def test_python3_available(self):
        """Verify Python 3 is available."""
        import shutil
        python3_path = shutil.which("python3")
        assert python3_path is not None, "Python 3 is not available"
