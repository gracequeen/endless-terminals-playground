# test_final_state.py
"""
Tests to validate the final state of the OS/filesystem after the student
has completed the task of extracting unique source IPs from traffic.csv.
"""

import os
import re
import pytest


class TestFinalState:
    """Validate the final state after the task is performed."""

    def test_ips_txt_exists(self):
        """Verify /home/user/ips.txt exists."""
        assert os.path.isfile("/home/user/ips.txt"), \
            "/home/user/ips.txt does not exist - the output file was not created"

    def test_ips_txt_has_exactly_47_lines(self):
        """Verify /home/user/ips.txt has exactly 47 lines."""
        with open("/home/user/ips.txt", "r") as f:
            lines = f.readlines()
        # Count non-empty lines (but file should have exactly 47 lines with content)
        line_count = len(lines)
        assert line_count == 47, \
            f"/home/user/ips.txt should have exactly 47 lines, but has {line_count}"

    def test_ips_txt_no_header(self):
        """Verify /home/user/ips.txt does not contain the header 'src_ip'."""
        with open("/home/user/ips.txt", "r") as f:
            content = f.read()
        assert "src_ip" not in content, \
            "/home/user/ips.txt contains 'src_ip' header - header should be excluded"

    def test_ips_txt_all_lines_are_valid_ipv4(self):
        """Verify every line in /home/user/ips.txt is a valid IPv4 address format."""
        ip_pattern = re.compile(r"^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$")
        with open("/home/user/ips.txt", "r") as f:
            for line_num, line in enumerate(f, start=1):
                ip = line.strip()
                assert ip_pattern.match(ip), \
                    f"Line {line_num}: '{ip}' does not match IPv4 pattern ^[0-9]+\\.[0-9]+\\.[0-9]+\\.[0-9]+$"

    def test_ips_txt_no_trailing_commas_or_extra_whitespace(self):
        """Verify each line has no trailing commas or extra whitespace."""
        with open("/home/user/ips.txt", "r") as f:
            for line_num, line in enumerate(f, start=1):
                # Line should be just IP + newline
                stripped = line.rstrip('\n')
                assert ',' not in stripped, \
                    f"Line {line_num}: contains trailing comma"
                assert stripped == stripped.strip(), \
                    f"Line {line_num}: contains extra leading/trailing whitespace"

    def test_ips_txt_is_sorted_lexicographically(self):
        """Verify /home/user/ips.txt is sorted lexicographically."""
        with open("/home/user/ips.txt", "r") as f:
            lines = [line.strip() for line in f.readlines()]
        sorted_lines = sorted(lines)
        assert lines == sorted_lines, \
            "/home/user/ips.txt is not sorted lexicographically"

    def test_ips_txt_all_unique(self):
        """Verify all IPs in /home/user/ips.txt are unique."""
        with open("/home/user/ips.txt", "r") as f:
            lines = [line.strip() for line in f.readlines()]
        unique_lines = set(lines)
        assert len(lines) == len(unique_lines), \
            f"/home/user/ips.txt contains duplicate IPs - {len(lines)} lines but only {len(unique_lines)} unique"

    def test_ips_txt_ends_with_newline(self):
        """Verify /home/user/ips.txt ends with a newline."""
        with open("/home/user/ips.txt", "rb") as f:
            f.seek(-1, 2)  # Go to last byte
            last_byte = f.read(1)
        assert last_byte == b'\n', \
            "/home/user/ips.txt does not end with a newline"

    def test_ips_txt_matches_source_data(self):
        """Verify the IPs in ips.txt match the unique IPs from traffic.csv."""
        # Get unique IPs from source file
        source_ips = set()
        with open("/home/user/logs/traffic.csv", "r") as f:
            # Skip header
            next(f)
            for line in f:
                columns = line.strip().split(",")
                if len(columns) >= 3:
                    source_ips.add(columns[2])

        # Get IPs from output file
        with open("/home/user/ips.txt", "r") as f:
            output_ips = set(line.strip() for line in f.readlines())

        assert source_ips == output_ips, \
            f"IPs in ips.txt don't match unique IPs from traffic.csv. " \
            f"Missing: {source_ips - output_ips}, Extra: {output_ips - source_ips}"

    def test_traffic_csv_unchanged(self):
        """Verify /home/user/logs/traffic.csv is unchanged (still has 500 lines with correct header)."""
        assert os.path.isfile("/home/user/logs/traffic.csv"), \
            "/home/user/logs/traffic.csv no longer exists - source file should not be modified"

        with open("/home/user/logs/traffic.csv", "r") as f:
            lines = f.readlines()

        assert len(lines) == 500, \
            f"traffic.csv should still have 500 lines, but has {len(lines)} - source file should not be modified"

        expected_header = "timestamp,dest_port,src_ip,bytes,protocol"
        assert lines[0].strip() == expected_header, \
            f"traffic.csv header changed - source file should not be modified"
