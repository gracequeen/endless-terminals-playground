# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student performs the ETL pipeline fix task.
"""

import os
import subprocess
import json
import pytest

ETL_DIR = "/home/user/etl"
DATA_DIR = os.path.join(ETL_DIR, "data")


class TestDirectoryStructure:
    """Test that required directories exist."""

    def test_etl_directory_exists(self):
        assert os.path.isdir(ETL_DIR), f"ETL directory {ETL_DIR} does not exist"

    def test_data_directory_exists(self):
        assert os.path.isdir(DATA_DIR), f"Data directory {DATA_DIR} does not exist"


class TestRequiredFiles:
    """Test that all required files exist."""

    def test_run_pipeline_sh_exists(self):
        filepath = os.path.join(ETL_DIR, "run_pipeline.sh")
        assert os.path.isfile(filepath), f"Pipeline script {filepath} does not exist"

    def test_extract_py_exists(self):
        filepath = os.path.join(ETL_DIR, "extract.py")
        assert os.path.isfile(filepath), f"Extract script {filepath} does not exist"

    def test_transform_py_exists(self):
        filepath = os.path.join(ETL_DIR, "transform.py")
        assert os.path.isfile(filepath), f"Transform script {filepath} does not exist"

    def test_load_py_exists(self):
        filepath = os.path.join(ETL_DIR, "load.py")
        assert os.path.isfile(filepath), f"Load script {filepath} does not exist"

    def test_config_yaml_exists(self):
        filepath = os.path.join(ETL_DIR, "config.yaml")
        assert os.path.isfile(filepath), f"Config file {filepath} does not exist"

    def test_input_json_exists(self):
        filepath = os.path.join(DATA_DIR, "input.json")
        assert os.path.isfile(filepath), f"Input data file {filepath} does not exist"


class TestFilePermissions:
    """Test that files have appropriate permissions."""

    def test_run_pipeline_sh_is_executable(self):
        filepath = os.path.join(ETL_DIR, "run_pipeline.sh")
        assert os.access(filepath, os.X_OK), f"Pipeline script {filepath} is not executable"

    def test_etl_files_are_writable(self):
        files_to_check = [
            os.path.join(ETL_DIR, "config.yaml"),
            os.path.join(ETL_DIR, "transform.py"),
        ]
        for filepath in files_to_check:
            assert os.access(filepath, os.W_OK), f"File {filepath} is not writable"


class TestConfigYamlContent:
    """Test the initial state of config.yaml matches expected buggy configuration."""

    @pytest.fixture
    def config_content(self):
        filepath = os.path.join(ETL_DIR, "config.yaml")
        with open(filepath, 'r') as f:
            return f.read()

    def test_config_has_strict_mode(self, config_content):
        """Config should have 'strict' mode initially (the bug)."""
        assert "strict" in config_content, \
            "config.yaml should contain 'strict' mode initially (this is the bug to fix)"

    def test_config_has_quarantine_file_key(self, config_content):
        """Config should use 'quarantine_file' key initially (mismatched with transform.py)."""
        assert "quarantine_file" in config_content, \
            "config.yaml should contain 'quarantine_file' key initially (this is the key mismatch bug)"

    def test_config_has_error_handling_section(self, config_content):
        """Config should have error_handling section."""
        assert "error_handling" in config_content, \
            "config.yaml should contain 'error_handling' section"

    def test_config_has_pipeline_section(self, config_content):
        """Config should have pipeline section."""
        assert "pipeline" in config_content, \
            "config.yaml should contain 'pipeline' section"


class TestTransformPyContent:
    """Test that transform.py has the expected recovery logic structure."""

    @pytest.fixture
    def transform_content(self):
        filepath = os.path.join(ETL_DIR, "transform.py")
        with open(filepath, 'r') as f:
            return f.read()

    def test_transform_has_recovery_mode_check(self, transform_content):
        """Transform.py should check for 'recovery' mode."""
        assert "recovery" in transform_content, \
            "transform.py should contain recovery mode logic"

    def test_transform_has_quarantine_path_reference(self, transform_content):
        """Transform.py should reference 'quarantine_path' (not 'quarantine_file')."""
        assert "quarantine_path" in transform_content, \
            "transform.py should reference 'quarantine_path' key (this is the mismatch with config.yaml)"

    def test_transform_has_transform_error(self, transform_content):
        """Transform.py should have TransformError for strict mode."""
        assert "transform failed" in transform_content.lower() or "TransformError" in transform_content, \
            "transform.py should contain error handling that raises 'transform failed'"


class TestInputData:
    """Test the input data file structure."""

    @pytest.fixture
    def input_data(self):
        filepath = os.path.join(DATA_DIR, "input.json")
        with open(filepath, 'r') as f:
            return json.load(f)

    def test_input_json_has_records(self, input_data):
        """Input JSON should contain records."""
        if isinstance(input_data, list):
            record_count = len(input_data)
        elif isinstance(input_data, dict) and 'records' in input_data:
            record_count = len(input_data['records'])
        else:
            record_count = len(input_data) if isinstance(input_data, (list, dict)) else 0

        assert record_count == 47, \
            f"input.json should contain exactly 47 records, found {record_count}"

    def test_input_json_has_malformed_dates(self, input_data):
        """Input JSON should contain records with malformed dates (YYYY/MM/DD format)."""
        if isinstance(input_data, list):
            records = input_data
        elif isinstance(input_data, dict) and 'records' in input_data:
            records = input_data['records']
        else:
            records = list(input_data.values()) if isinstance(input_data, dict) else []

        # Count records with malformed date format (YYYY/MM/DD instead of YYYY-MM-DD)
        malformed_count = 0
        for record in records:
            if isinstance(record, dict):
                timestamp = record.get('timestamp', '')
                if isinstance(timestamp, str) and '/' in timestamp:
                    malformed_count += 1

        assert malformed_count == 3, \
            f"input.json should contain exactly 3 records with malformed dates (YYYY/MM/DD), found {malformed_count}"


class TestOutputFilesDoNotExist:
    """Test that output files do not exist initially."""

    def test_transformed_csv_does_not_exist(self):
        filepath = os.path.join(DATA_DIR, "transformed.csv")
        assert not os.path.exists(filepath), \
            f"Intermediate file {filepath} should not exist initially"

    def test_output_csv_does_not_exist(self):
        filepath = os.path.join(DATA_DIR, "output.csv")
        assert not os.path.exists(filepath), \
            f"Output file {filepath} should not exist initially"

    def test_quarantine_log_does_not_exist(self):
        filepath = os.path.join(ETL_DIR, "quarantine.log")
        assert not os.path.exists(filepath), \
            f"Quarantine log {filepath} should not exist initially"


class TestPythonEnvironment:
    """Test that required Python environment is available."""

    def test_python3_available(self):
        result = subprocess.run(["python3", "--version"], capture_output=True, text=True)
        assert result.returncode == 0, "Python 3 is not available"

    def test_pyyaml_installed(self):
        result = subprocess.run(
            ["python3", "-c", "import yaml; print(yaml.__version__)"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "PyYAML is not installed"


class TestPipelineCurrentlyFails:
    """Test that the pipeline fails in its current state (before fix)."""

    def test_pipeline_fails_on_transform(self):
        """Running the pipeline should fail at the transform step."""
        result = subprocess.run(
            ["./run_pipeline.sh"],
            cwd=ETL_DIR,
            capture_output=True,
            text=True,
            timeout=60
        )
        assert result.returncode != 0, \
            "Pipeline should fail in its current buggy state"

    def test_extracted_csv_created_after_run(self):
        """Extract step should succeed and create extracted.csv."""
        # Run the pipeline (it will fail at transform, but extract should work)
        subprocess.run(
            ["./run_pipeline.sh"],
            cwd=ETL_DIR,
            capture_output=True,
            text=True,
            timeout=60
        )
        filepath = os.path.join(DATA_DIR, "extracted.csv")
        assert os.path.isfile(filepath), \
            "Extract step should succeed and create data/extracted.csv"
