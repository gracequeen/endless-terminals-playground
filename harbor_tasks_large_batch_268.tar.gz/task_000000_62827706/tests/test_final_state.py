# test_final_state.py
"""
Tests to validate the final state of the OS/filesystem after the student has fixed the ETL pipeline.
"""

import os
import subprocess
import json
import pytest

ETL_DIR = "/home/user/etl"
DATA_DIR = os.path.join(ETL_DIR, "data")


class TestPipelineCompletion:
    """Test that the pipeline runs successfully end-to-end."""

    def test_pipeline_exits_zero(self):
        """Running ./run_pipeline.sh should exit with code 0."""
        result = subprocess.run(
            ["./run_pipeline.sh"],
            cwd=ETL_DIR,
            capture_output=True,
            text=True,
            timeout=120
        )
        assert result.returncode == 0, \
            f"Pipeline should exit with code 0, but got {result.returncode}. " \
            f"stdout: {result.stdout}\nstderr: {result.stderr}"


class TestOutputCsvFile:
    """Test that output.csv exists and has correct content."""

    def test_output_csv_exists(self):
        """output.csv should exist in data/ folder."""
        filepath = os.path.join(DATA_DIR, "output.csv")
        assert os.path.isfile(filepath), \
            f"Output file {filepath} does not exist. Pipeline did not complete successfully."

    def test_output_csv_has_correct_line_count(self):
        """output.csv should have exactly 45 lines (1 header + 44 data rows)."""
        filepath = os.path.join(DATA_DIR, "output.csv")
        assert os.path.isfile(filepath), f"Output file {filepath} does not exist"

        with open(filepath, 'r') as f:
            lines = f.readlines()

        # Count non-empty lines
        non_empty_lines = [line for line in lines if line.strip()]

        assert len(non_empty_lines) == 45, \
            f"output.csv should have exactly 45 lines (header + 44 good records), " \
            f"but has {len(non_empty_lines)} non-empty lines"

    def test_output_csv_line_count_via_grep(self):
        """Verify line count using grep -c (anti-shortcut guard)."""
        filepath = os.path.join(DATA_DIR, "output.csv")
        result = subprocess.run(
            ["grep", "-c", "^", filepath],
            capture_output=True,
            text=True
        )
        line_count = int(result.stdout.strip())
        assert line_count == 45, \
            f"grep -c '^' output.csv should return 45, but got {line_count}"

    def test_output_csv_has_header(self):
        """output.csv should have a header row."""
        filepath = os.path.join(DATA_DIR, "output.csv")
        with open(filepath, 'r') as f:
            header = f.readline().strip()

        # Header should contain expected field names
        assert header, "output.csv should have a non-empty header row"
        # Check for typical header fields
        header_lower = header.lower()
        assert "id" in header_lower or "timestamp" in header_lower or "value" in header_lower, \
            f"output.csv header should contain expected fields, got: {header}"


class TestQuarantineLogFile:
    """Test that quarantine.log exists and has correct content."""

    def test_quarantine_log_exists(self):
        """quarantine.log should exist in /home/user/etl/."""
        filepath = os.path.join(ETL_DIR, "quarantine.log")
        assert os.path.isfile(filepath), \
            f"Quarantine log {filepath} does not exist. Recovery mode may not be working."

    def test_quarantine_log_has_correct_line_count(self):
        """quarantine.log should have exactly 3 lines (one per bad record)."""
        filepath = os.path.join(ETL_DIR, "quarantine.log")
        assert os.path.isfile(filepath), f"Quarantine log {filepath} does not exist"

        with open(filepath, 'r') as f:
            lines = f.readlines()

        # Count non-empty lines
        non_empty_lines = [line for line in lines if line.strip()]

        assert len(non_empty_lines) == 3, \
            f"quarantine.log should have exactly 3 lines (one per bad record), " \
            f"but has {len(non_empty_lines)} non-empty lines"

    def test_quarantine_log_line_count_via_grep(self):
        """Verify line count using grep -c (anti-shortcut guard)."""
        filepath = os.path.join(ETL_DIR, "quarantine.log")
        result = subprocess.run(
            ["grep", "-c", "^", filepath],
            capture_output=True,
            text=True
        )
        line_count = int(result.stdout.strip())
        assert line_count == 3, \
            f"grep -c '^' quarantine.log should return 3, but got {line_count}"

    def test_quarantine_log_has_record_info(self):
        """quarantine.log entries should contain identifiable record information."""
        filepath = os.path.join(ETL_DIR, "quarantine.log")
        with open(filepath, 'r') as f:
            content = f.read()

        # Each line should have some content that identifies a record
        assert len(content.strip()) > 10, \
            "quarantine.log should contain meaningful record information"


class TestConfigYamlFixed:
    """Test that config.yaml has been properly fixed."""

    @pytest.fixture
    def config_content(self):
        filepath = os.path.join(ETL_DIR, "config.yaml")
        with open(filepath, 'r') as f:
            return f.read()

    def test_config_no_longer_has_strict_mode(self, config_content):
        """config.yaml should no longer contain 'strict' mode."""
        # Check that 'strict' is not present as a mode value
        result = subprocess.run(
            ["grep", "-E", "strict", os.path.join(ETL_DIR, "config.yaml")],
            capture_output=True,
            text=True
        )
        # grep returns 1 if no match found (which is what we want)
        assert result.returncode != 0 or "strict" not in result.stdout, \
            "config.yaml should not contain 'strict' mode after fix"

    def test_config_no_longer_has_quarantine_file_key(self, config_content):
        """config.yaml should no longer use 'quarantine_file' key (should be 'quarantine_path')."""
        result = subprocess.run(
            ["grep", "-E", "quarantine_file", os.path.join(ETL_DIR, "config.yaml")],
            capture_output=True,
            text=True
        )
        # grep returns 1 if no match found (which is what we want)
        assert result.returncode != 0 or "quarantine_file" not in result.stdout, \
            "config.yaml should not contain 'quarantine_file' key after fix (should be 'quarantine_path')"

    def test_config_has_recovery_mode(self, config_content):
        """config.yaml should have 'recovery' mode."""
        assert "recovery" in config_content, \
            "config.yaml should contain 'recovery' mode after fix"

    def test_config_has_quarantine_path_key(self, config_content):
        """config.yaml should use 'quarantine_path' key."""
        assert "quarantine_path" in config_content, \
            "config.yaml should contain 'quarantine_path' key after fix"

    def test_config_grep_no_buggy_values(self):
        """Anti-shortcut: grep for buggy values should return no matches."""
        result = subprocess.run(
            ["grep", "-E", "quarantine_file|strict", os.path.join(ETL_DIR, "config.yaml")],
            capture_output=True,
            text=True
        )
        # grep returns 1 if no match found
        assert result.returncode != 0, \
            f"config.yaml should not contain 'quarantine_file' or 'strict' after fix. " \
            f"Found: {result.stdout}"


class TestInvariantsPreserved:
    """Test that files that should not be modified remain unchanged."""

    def test_input_json_unchanged(self):
        """data/input.json should not be modified."""
        filepath = os.path.join(DATA_DIR, "input.json")
        assert os.path.isfile(filepath), f"Input file {filepath} should still exist"

        with open(filepath, 'r') as f:
            data = json.load(f)

        # Check it still has 47 records
        if isinstance(data, list):
            record_count = len(data)
        elif isinstance(data, dict) and 'records' in data:
            record_count = len(data['records'])
        else:
            record_count = len(data) if isinstance(data, (list, dict)) else 0

        assert record_count == 47, \
            f"input.json should still contain 47 records, found {record_count}"

    def test_input_json_still_has_bad_records(self):
        """data/input.json should still have 3 records with malformed dates."""
        filepath = os.path.join(DATA_DIR, "input.json")
        with open(filepath, 'r') as f:
            data = json.load(f)

        if isinstance(data, list):
            records = data
        elif isinstance(data, dict) and 'records' in data:
            records = data['records']
        else:
            records = list(data.values()) if isinstance(data, dict) else []

        # Count records with malformed date format (YYYY/MM/DD)
        malformed_count = 0
        for record in records:
            if isinstance(record, dict):
                timestamp = record.get('timestamp', '')
                if isinstance(timestamp, str) and '/' in timestamp:
                    malformed_count += 1

        assert malformed_count == 3, \
            f"input.json should still contain 3 malformed records, found {malformed_count}. " \
            "The bad records should be quarantined, not fixed in the source file."


class TestBadRecordsNotInOutput:
    """Test that bad records are quarantined, not passed through to output."""

    def test_output_does_not_contain_slash_dates(self):
        """output.csv should not contain any records with YYYY/MM/DD date format."""
        filepath = os.path.join(DATA_DIR, "output.csv")
        with open(filepath, 'r') as f:
            content = f.read()

        # Check for the malformed date pattern (YYYY/MM/DD)
        import re
        malformed_pattern = r'\d{4}/\d{2}/\d{2}'
        matches = re.findall(malformed_pattern, content)

        assert len(matches) == 0, \
            f"output.csv should not contain malformed dates (YYYY/MM/DD). " \
            f"Found {len(matches)} occurrences. Bad records should be quarantined, not passed through."


class TestAllPipelineStagesComplete:
    """Test that all pipeline stages completed successfully."""

    def test_extracted_csv_exists(self):
        """data/extracted.csv should exist (extract stage completed)."""
        filepath = os.path.join(DATA_DIR, "extracted.csv")
        assert os.path.isfile(filepath), \
            f"Extracted file {filepath} should exist after pipeline run"

    def test_transformed_csv_exists(self):
        """data/transformed.csv should exist (transform stage completed)."""
        filepath = os.path.join(DATA_DIR, "transformed.csv")
        assert os.path.isfile(filepath), \
            f"Transformed file {filepath} should exist after pipeline run"

    def test_output_csv_exists(self):
        """data/output.csv should exist (load stage completed)."""
        filepath = os.path.join(DATA_DIR, "output.csv")
        assert os.path.isfile(filepath), \
            f"Output file {filepath} should exist after pipeline run"


class TestPipelineIdempotent:
    """Test that running the pipeline again produces consistent results."""

    def test_pipeline_can_run_again(self):
        """Pipeline should be able to run successfully again."""
        # First, clean up intermediate files if they exist
        for filename in ["extracted.csv", "transformed.csv", "output.csv"]:
            filepath = os.path.join(DATA_DIR, filename)
            if os.path.exists(filepath):
                os.remove(filepath)

        quarantine_path = os.path.join(ETL_DIR, "quarantine.log")
        if os.path.exists(quarantine_path):
            os.remove(quarantine_path)

        # Run the pipeline
        result = subprocess.run(
            ["./run_pipeline.sh"],
            cwd=ETL_DIR,
            capture_output=True,
            text=True,
            timeout=120
        )

        assert result.returncode == 0, \
            f"Pipeline should run successfully again. Exit code: {result.returncode}"

        # Verify outputs exist
        assert os.path.isfile(os.path.join(DATA_DIR, "output.csv")), \
            "output.csv should be created on re-run"
        assert os.path.isfile(quarantine_path), \
            "quarantine.log should be created on re-run"
