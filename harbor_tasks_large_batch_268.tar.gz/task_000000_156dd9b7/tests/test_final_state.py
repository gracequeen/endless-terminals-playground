# test_final_state.py
"""
Tests to validate the final state after the student has fixed the setup.sh script
for nginx + Flask deployment with proper startup sequencing.
"""

import os
import subprocess
import time
import re
import signal
import pytest


# Constants
HOME = "/home/user"
INFRA_DIR = f"{HOME}/infra"
APP_DIR = f"{INFRA_DIR}/app"
SETUP_SCRIPT = f"{INFRA_DIR}/setup.sh"
APP_PY = f"{APP_DIR}/app.py"
NGINX_CONF = f"{INFRA_DIR}/nginx.conf"


def cleanup_processes():
    """Helper to clean up any running Flask or nginx processes."""
    # Kill Flask processes
    subprocess.run(['pkill', '-f', 'python.*app.py'], capture_output=True)
    # Kill nginx processes
    subprocess.run(['sudo', 'pkill', '-x', 'nginx'], capture_output=True)
    subprocess.run(['pkill', '-x', 'nginx'], capture_output=True)
    time.sleep(0.5)


@pytest.fixture(scope="module", autouse=True)
def setup_and_teardown():
    """Setup: clean environment, run setup.sh, then teardown after tests."""
    # Cleanup any existing processes first
    cleanup_processes()
    time.sleep(1)

    # Run the setup script
    result = subprocess.run(
        [SETUP_SCRIPT],
        cwd=INFRA_DIR,
        capture_output=True,
        text=True,
        timeout=30
    )

    # Store the result for tests to access
    setup_and_teardown.script_result = result

    # Give a moment for everything to stabilize
    time.sleep(1)

    yield

    # Teardown: cleanup processes
    cleanup_processes()


class TestSetupScriptExecution:
    """Test that setup.sh executes successfully."""

    def test_setup_script_exits_zero(self, setup_and_teardown):
        """Setup script should complete with exit code 0."""
        result = setup_and_teardown.script_result
        assert result.returncode == 0, \
            f"Setup script should exit with code 0, got {result.returncode}. " \
            f"Stderr: {result.stderr}"


class TestServicesRunning:
    """Test that both Flask and nginx are running after setup."""

    def test_flask_process_running(self):
        """Flask app.py process should be running."""
        result = subprocess.run(
            ['pgrep', '-f', 'python.*app.py'],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            "Flask app.py process should be running after setup.sh"

    def test_nginx_process_running(self):
        """Nginx process should be running."""
        result = subprocess.run(
            ['pgrep', '-x', 'nginx'],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            "Nginx process should be running after setup.sh"

    def test_port_5000_listening(self):
        """Port 5000 should be listening (Flask)."""
        result = subprocess.run(
            ['ss', '-tlnp'],
            capture_output=True,
            text=True
        )
        assert ':5000' in result.stdout, \
            "Port 5000 should be listening (Flask app)"

    def test_port_8080_listening(self):
        """Port 8080 should be listening (nginx)."""
        result = subprocess.run(
            ['ss', '-tlnp'],
            capture_output=True,
            text=True
        )
        assert ':8080' in result.stdout, \
            "Port 8080 should be listening (nginx)"


class TestEndToEndFunctionality:
    """Test that the full stack works end-to-end."""

    def test_curl_localhost_8080_returns_hello(self):
        """Curling localhost:8080 should return 'Hello from Flask!'."""
        # Try multiple times with short delays to handle any timing issues
        max_attempts = 5
        last_error = None

        for attempt in range(max_attempts):
            try:
                result = subprocess.run(
                    ['curl', '-s', '-m', '5', 'http://localhost:8080/'],
                    capture_output=True,
                    text=True,
                    timeout=10
                )

                if result.returncode == 0 and 'Hello from Flask!' in result.stdout:
                    return  # Success!

                last_error = f"Got response: '{result.stdout}', stderr: '{result.stderr}', returncode: {result.returncode}"
            except subprocess.TimeoutExpired:
                last_error = "Request timed out"

            if attempt < max_attempts - 1:
                time.sleep(1)

        pytest.fail(
            f"curl http://localhost:8080/ should return 'Hello from Flask!' within 5 seconds. "
            f"Last error: {last_error}"
        )

    def test_curl_localhost_8080_health_returns_ok(self):
        """Curling localhost:8080/health should return 'OK'."""
        result = subprocess.run(
            ['curl', '-s', '-m', '5', 'http://localhost:8080/health'],
            capture_output=True,
            text=True,
            timeout=10
        )

        assert result.returncode == 0, \
            f"curl to /health should succeed, got returncode {result.returncode}"
        assert 'OK' in result.stdout, \
            f"curl http://localhost:8080/health should return 'OK', got '{result.stdout}'"

    def test_no_502_error(self):
        """Should not get 502 Bad Gateway error."""
        result = subprocess.run(
            ['curl', '-s', '-m', '5', '-w', '%{http_code}', '-o', '/dev/null', 
             'http://localhost:8080/'],
            capture_output=True,
            text=True,
            timeout=10
        )

        http_code = result.stdout.strip()
        assert http_code != '502', \
            "Should not get 502 Bad Gateway - the race condition bug should be fixed"
        assert http_code == '200', \
            f"Should get HTTP 200, got {http_code}"

    def test_direct_flask_still_works(self):
        """Direct curl to Flask on port 5000 should still work."""
        result = subprocess.run(
            ['curl', '-s', '-m', '5', 'http://127.0.0.1:5000/'],
            capture_output=True,
            text=True,
            timeout=10
        )

        assert result.returncode == 0, \
            "Direct curl to Flask on port 5000 should succeed"
        assert 'Hello from Flask!' in result.stdout, \
            f"Direct Flask response should be 'Hello from Flask!', got '{result.stdout}'"


class TestAntiShortcutGuards:
    """Test that the solution doesn't use prohibited shortcuts."""

    def test_init_delay_not_zero_in_app_py(self):
        """INIT_DELAY must not be set to 0 in app.py."""
        with open(APP_PY, 'r') as f:
            content = f.read()

        # Check for patterns like INIT_DELAY = 0, '0', "0"
        result = subprocess.run(
            ['grep', '-E', r"INIT_DELAY.*=.*['\"]?0['\"]?", APP_PY],
            capture_output=True,
            text=True
        )

        # If grep finds a match, that's bad
        if result.returncode == 0:
            pytest.fail(
                "INIT_DELAY must not be set to 0 in app.py - "
                "the solution must handle the delay, not remove it"
            )

    def test_init_delay_not_exported_as_zero(self):
        """Setup script must not export INIT_DELAY=0."""
        with open(SETUP_SCRIPT, 'r') as f:
            content = f.read()

        # Check for INIT_DELAY=0 or export INIT_DELAY=0
        if re.search(r'INIT_DELAY\s*=\s*0', content):
            pytest.fail(
                "Setup script must not set INIT_DELAY=0 - "
                "the solution must handle the delay properly"
            )

    def test_proxy_connect_timeout_not_increased(self):
        """proxy_connect_timeout must not be increased above 10s."""
        with open(NGINX_CONF, 'r') as f:
            content = f.read()

        # Look for proxy_connect_timeout with values >= 10
        match = re.search(r'proxy_connect_timeout\s+(\d+)', content)
        if match:
            timeout_val = int(match.group(1))
            assert timeout_val < 10, \
                f"proxy_connect_timeout must not be increased above 10s, found {timeout_val}s"

    def test_proxy_read_timeout_not_increased_excessively(self):
        """proxy_read_timeout should remain reasonable."""
        with open(NGINX_CONF, 'r') as f:
            content = f.read()

        # Original is 5s, shouldn't be bumped excessively
        match = re.search(r'proxy_read_timeout\s+(\d+)', content)
        if match:
            timeout_val = int(match.group(1))
            assert timeout_val <= 10, \
                f"proxy_read_timeout should not be increased excessively, found {timeout_val}s"

    def test_flask_still_on_port_5000(self):
        """Flask must still run on port 5000."""
        with open(APP_PY, 'r') as f:
            content = f.read()

        assert 'port=5000' in content, \
            "Flask must still run on port 5000"

    def test_nginx_still_on_port_8080(self):
        """Nginx must still listen on port 8080."""
        with open(NGINX_CONF, 'r') as f:
            content = f.read()

        assert 'listen 8080' in content, \
            "Nginx must still listen on port 8080"

    def test_init_delay_value_preserved(self):
        """The 3-second INIT_DELAY default must be preserved in app.py."""
        with open(APP_PY, 'r') as f:
            content = f.read()

        # Check that the default is still 3.0
        assert "'3.0'" in content or '"3.0"' in content, \
            "INIT_DELAY default of 3.0 must be preserved in app.py"


class TestSolutionInSetupScript:
    """Test that the solution is implemented in setup.sh."""

    def test_setup_script_has_wait_logic(self):
        """Setup script should have some form of wait/ready-check logic."""
        with open(SETUP_SCRIPT, 'r') as f:
            content = f.read().lower()

        # Check for various forms of wait logic
        has_sleep = 'sleep' in content
        has_health_check = 'health' in content or 'curl' in content or 'wget' in content
        has_port_check = 'nc ' in content or 'netcat' in content or ':5000' in content
        has_loop = 'while' in content or 'until' in content or 'for ' in content
        has_wait_for_port = 'wait' in content or 'ready' in content

        # At minimum, there should be some form of synchronization
        has_any_wait_logic = (
            (has_sleep) or
            (has_health_check) or
            (has_port_check) or
            (has_loop and (has_health_check or has_port_check or has_sleep)) or
            (has_wait_for_port)
        )

        assert has_any_wait_logic, \
            "Setup script should have wait/health-check/port-check logic to handle Flask startup delay"


class TestFilesIntegrity:
    """Test that required files still exist and have correct structure."""

    def test_setup_script_exists(self):
        """Setup script should still exist."""
        assert os.path.isfile(SETUP_SCRIPT), \
            f"Setup script {SETUP_SCRIPT} should exist"

    def test_setup_script_executable(self):
        """Setup script should be executable."""
        assert os.access(SETUP_SCRIPT, os.X_OK), \
            f"Setup script {SETUP_SCRIPT} should be executable"

    def test_app_py_exists(self):
        """Flask app should still exist."""
        assert os.path.isfile(APP_PY), \
            f"Flask app {APP_PY} should exist"

    def test_nginx_conf_exists(self):
        """Nginx config should still exist."""
        assert os.path.isfile(NGINX_CONF), \
            f"Nginx config {NGINX_CONF} should exist"

    def test_setup_script_still_starts_flask(self):
        """Setup script should still start Flask."""
        with open(SETUP_SCRIPT, 'r') as f:
            content = f.read()

        assert 'python' in content and 'app.py' in content, \
            "Setup script should still start Flask app"

    def test_setup_script_still_starts_nginx(self):
        """Setup script should still start nginx."""
        with open(SETUP_SCRIPT, 'r') as f:
            content = f.read()

        assert 'nginx' in content, \
            "Setup script should still start nginx"
