# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the task of fixing the setup.sh script for nginx + Flask deployment.
"""

import os
import subprocess
import pytest


# Constants
HOME = "/home/user"
INFRA_DIR = f"{HOME}/infra"
APP_DIR = f"{INFRA_DIR}/app"
SETUP_SCRIPT = f"{INFRA_DIR}/setup.sh"
APP_PY = f"{APP_DIR}/app.py"
NGINX_CONF = f"{INFRA_DIR}/nginx.conf"


class TestDirectoryStructure:
    """Test that required directories exist."""

    def test_home_directory_exists(self):
        assert os.path.isdir(HOME), f"Home directory {HOME} does not exist"

    def test_infra_directory_exists(self):
        assert os.path.isdir(INFRA_DIR), f"Infrastructure directory {INFRA_DIR} does not exist"

    def test_app_directory_exists(self):
        assert os.path.isdir(APP_DIR), f"Application directory {APP_DIR} does not exist"


class TestSetupScript:
    """Test the setup.sh script exists and has correct properties."""

    def test_setup_script_exists(self):
        assert os.path.isfile(SETUP_SCRIPT), f"Setup script {SETUP_SCRIPT} does not exist"

    def test_setup_script_is_executable(self):
        assert os.access(SETUP_SCRIPT, os.X_OK), f"Setup script {SETUP_SCRIPT} is not executable"

    def test_setup_script_contains_flask_start(self):
        with open(SETUP_SCRIPT, 'r') as f:
            content = f.read()
        assert 'python app.py &' in content, "Setup script should start Flask app in background"

    def test_setup_script_contains_nginx_start(self):
        with open(SETUP_SCRIPT, 'r') as f:
            content = f.read()
        assert 'nginx' in content, "Setup script should start nginx"

    def test_setup_script_has_shebang(self):
        with open(SETUP_SCRIPT, 'r') as f:
            first_line = f.readline()
        assert first_line.startswith('#!/bin/bash'), "Setup script should have bash shebang"

    def test_setup_script_has_set_e(self):
        with open(SETUP_SCRIPT, 'r') as f:
            content = f.read()
        assert 'set -e' in content, "Setup script should have 'set -e' for error handling"


class TestFlaskApp:
    """Test the Flask application file exists and has correct content."""

    def test_app_py_exists(self):
        assert os.path.isfile(APP_PY), f"Flask app {APP_PY} does not exist"

    def test_app_py_has_init_delay(self):
        with open(APP_PY, 'r') as f:
            content = f.read()
        assert 'INIT_DELAY' in content, "Flask app should have INIT_DELAY variable"

    def test_app_py_has_time_sleep(self):
        with open(APP_PY, 'r') as f:
            content = f.read()
        assert 'time.sleep' in content, "Flask app should have time.sleep for initialization delay"

    def test_app_py_default_init_delay_is_3(self):
        with open(APP_PY, 'r') as f:
            content = f.read()
        # Check for default value of 3.0 or '3.0'
        assert "'3.0'" in content or '"3.0"' in content, \
            "Flask app should have default INIT_DELAY of 3.0 seconds"

    def test_app_py_runs_on_port_5000(self):
        with open(APP_PY, 'r') as f:
            content = f.read()
        assert 'port=5000' in content, "Flask app should run on port 5000"

    def test_app_py_has_index_route(self):
        with open(APP_PY, 'r') as f:
            content = f.read()
        assert "def index(" in content or "def index():" in content, \
            "Flask app should have index route"

    def test_app_py_has_health_route(self):
        with open(APP_PY, 'r') as f:
            content = f.read()
        assert "def health(" in content or "def health():" in content, \
            "Flask app should have health route"

    def test_app_py_returns_hello_from_flask(self):
        with open(APP_PY, 'r') as f:
            content = f.read()
        assert 'Hello from Flask!' in content, \
            "Flask app should return 'Hello from Flask!' from index route"


class TestNginxConfig:
    """Test the nginx configuration file exists and has correct content."""

    def test_nginx_conf_exists(self):
        assert os.path.isfile(NGINX_CONF), f"Nginx config {NGINX_CONF} does not exist"

    def test_nginx_conf_listens_on_8080(self):
        with open(NGINX_CONF, 'r') as f:
            content = f.read()
        assert 'listen 8080' in content, "Nginx should listen on port 8080"

    def test_nginx_conf_proxies_to_flask(self):
        with open(NGINX_CONF, 'r') as f:
            content = f.read()
        assert '127.0.0.1:5000' in content, "Nginx should proxy to Flask on 127.0.0.1:5000"

    def test_nginx_conf_has_upstream_flask(self):
        with open(NGINX_CONF, 'r') as f:
            content = f.read()
        assert 'upstream flask' in content, "Nginx config should have upstream flask block"

    def test_nginx_conf_has_proxy_connect_timeout(self):
        with open(NGINX_CONF, 'r') as f:
            content = f.read()
        assert 'proxy_connect_timeout 2s' in content, \
            "Nginx config should have proxy_connect_timeout 2s"

    def test_nginx_conf_has_proxy_read_timeout(self):
        with open(NGINX_CONF, 'r') as f:
            content = f.read()
        assert 'proxy_read_timeout 5s' in content, \
            "Nginx config should have proxy_read_timeout 5s"


class TestNoServicesRunning:
    """Test that no services are currently running on the required ports."""

    def test_port_5000_not_in_use(self):
        """Verify port 5000 is not currently in use."""
        result = subprocess.run(
            ['ss', '-tlnp'],
            capture_output=True,
            text=True
        )
        # Check if port 5000 appears in listening sockets
        assert ':5000' not in result.stdout, \
            "Port 5000 should not be in use initially (Flask should not be running)"

    def test_port_8080_not_in_use(self):
        """Verify port 8080 is not currently in use."""
        result = subprocess.run(
            ['ss', '-tlnp'],
            capture_output=True,
            text=True
        )
        # Check if port 8080 appears in listening sockets
        assert ':8080' not in result.stdout, \
            "Port 8080 should not be in use initially (nginx should not be running)"

    def test_no_flask_process_running(self):
        """Verify no Flask/Python app.py process is running."""
        result = subprocess.run(
            ['pgrep', '-f', 'python.*app.py'],
            capture_output=True,
            text=True
        )
        assert result.returncode != 0, \
            "No Flask app.py process should be running initially"

    def test_no_nginx_process_running(self):
        """Verify nginx is not running."""
        result = subprocess.run(
            ['pgrep', '-x', 'nginx'],
            capture_output=True,
            text=True
        )
        assert result.returncode != 0, \
            "Nginx should not be running initially"


class TestDependencies:
    """Test that required dependencies are installed."""

    def test_python3_available(self):
        """Verify Python 3 is available."""
        result = subprocess.run(
            ['python3', '--version'],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "Python 3 should be installed"
        assert 'Python 3' in result.stdout, "Python 3 should be available"

    def test_python_command_available(self):
        """Verify 'python' command is available (may be symlink to python3)."""
        result = subprocess.run(
            ['python', '--version'],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "'python' command should be available"

    def test_flask_installed(self):
        """Verify Flask is installed."""
        result = subprocess.run(
            ['python', '-c', 'import flask; print(flask.__version__)'],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "Flask should be installed"

    def test_nginx_installed(self):
        """Verify nginx is installed."""
        result = subprocess.run(
            ['which', 'nginx'],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "Nginx should be installed"

    def test_curl_installed(self):
        """Verify curl is installed (for testing)."""
        result = subprocess.run(
            ['which', 'curl'],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "Curl should be installed"


class TestInfraDirectoryWritable:
    """Test that the infra directory is writable."""

    def test_infra_directory_writable(self):
        """Verify /home/user/infra is writable."""
        assert os.access(INFRA_DIR, os.W_OK), \
            f"Directory {INFRA_DIR} should be writable"

    def test_app_directory_writable(self):
        """Verify /home/user/infra/app is writable."""
        assert os.access(APP_DIR, os.W_OK), \
            f"Directory {APP_DIR} should be writable"


class TestBugConditions:
    """Test that the bug conditions are present (the race condition setup)."""

    def test_setup_script_lacks_wait_logic(self):
        """Verify setup.sh does NOT have wait/health-check logic (the bug)."""
        with open(SETUP_SCRIPT, 'r') as f:
            content = f.read()

        # The buggy script should NOT have proper wait logic
        # It should just start Flask in background and immediately start nginx
        has_sleep_wait = 'sleep' in content.lower() and 'flask' in content.lower()
        has_health_check = 'health' in content.lower() or 'curl' in content.lower()
        has_port_check = 'nc ' in content or 'netcat' in content or 'wait-for' in content
        has_retry_logic = 'until' in content or 'while' in content

        # The initial buggy state should not have these fixes
        assert not (has_health_check and has_retry_logic), \
            "Setup script should NOT have health check with retry logic initially (this is the bug to fix)"

    def test_init_delay_not_zero(self):
        """Verify INIT_DELAY is not set to 0 in app.py."""
        with open(APP_PY, 'r') as f:
            content = f.read()

        # Check that INIT_DELAY default is not 0
        result = subprocess.run(
            ['grep', '-E', r"INIT_DELAY.*=.*['\"]?0['\"]?\)?$", APP_PY],
            capture_output=True,
            text=True
        )
        # grep returns 0 if match found, 1 if no match
        assert result.returncode != 0, \
            "INIT_DELAY should not be set to 0 in app.py"
