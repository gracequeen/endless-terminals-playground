# test_final_state.py
"""
Tests to validate the final state of the system after the student has fixed the bug.
This verifies that disk_usage.py now produces correct values in usage.json.
"""

import json
import os
import subprocess
import sys

import pytest

# Constants
HOME_DIR = "/home/user"
COLLECTOR_DIR = "/home/user/collector"
DISK_USAGE_SCRIPT = "/home/user/collector/disk_usage.py"
CONFIG_FILE = "/home/user/collector/config.yaml"
DATA_METRICS_DIR = "/data/metrics"
USAGE_JSON = "/data/metrics/usage.json"


class TestDirectoriesStillExist:
    """Test that required directories still exist after fix."""

    def test_collector_directory_exists(self):
        """Verify /home/user/collector directory exists."""
        assert os.path.isdir(COLLECTOR_DIR), f"Collector directory {COLLECTOR_DIR} does not exist"

    def test_data_metrics_directory_exists(self):
        """Verify /data/metrics directory exists."""
        assert os.path.isdir(DATA_METRICS_DIR), f"Data metrics directory {DATA_METRICS_DIR} does not exist"


class TestFilesStillExist:
    """Test that required files still exist after fix."""

    def test_disk_usage_script_exists(self):
        """Verify disk_usage.py script still exists."""
        assert os.path.isfile(DISK_USAGE_SCRIPT), f"Disk usage script {DISK_USAGE_SCRIPT} does not exist"

    def test_config_yaml_exists(self):
        """Verify config.yaml still exists."""
        assert os.path.isfile(CONFIG_FILE), f"Config file {CONFIG_FILE} does not exist"

    def test_usage_json_exists(self):
        """Verify usage.json exists."""
        assert os.path.isfile(USAGE_JSON), f"Usage JSON file {USAGE_JSON} does not exist"


class TestConfigYamlInvariants:
    """Test that config.yaml maintains required invariants."""

    def test_config_yaml_has_target_path_data_metrics(self):
        """Verify config.yaml still has target_path set to /data/metrics."""
        try:
            import yaml
            with open(CONFIG_FILE, 'r') as f:
                config = yaml.safe_load(f)
            target_path = config.get('target_path', '')
            assert target_path == '/data/metrics', (
                f"config.yaml target_path is '{target_path}', expected '/data/metrics'"
            )
        except ImportError:
            # Fallback to string check if PyYAML not available
            with open(CONFIG_FILE, 'r') as f:
                content = f.read()
            assert '/data/metrics' in content, (
                "config.yaml should contain target_path: /data/metrics"
            )

    def test_config_yaml_has_multiplier_field(self):
        """Verify config.yaml still has a multiplier field."""
        try:
            import yaml
            with open(CONFIG_FILE, 'r') as f:
                config = yaml.safe_load(f)
            assert 'multiplier' in config, (
                "config.yaml must still contain 'multiplier' field"
            )
        except ImportError:
            with open(CONFIG_FILE, 'r') as f:
                content = f.read()
            assert 'multiplier' in content, (
                "config.yaml must still contain 'multiplier' field"
            )


class TestScriptStillReadsConfig:
    """Test that the script still reads from config.yaml (not hardcoded)."""

    def test_script_references_config(self):
        """Verify disk_usage.py still reads configuration from config.yaml."""
        with open(DISK_USAGE_SCRIPT, 'r') as f:
            content = f.read()
        # Script should still reference config file
        config_refs = (
            'config.yaml' in content or
            'config' in content.lower() and 'yaml' in content.lower() or
            'open(' in content and 'config' in content.lower()
        )
        assert config_refs, (
            f"{DISK_USAGE_SCRIPT} should still read from config.yaml, not use hardcoded values"
        )

    def test_script_uses_multiplier_from_config(self):
        """Verify disk_usage.py still uses the multiplier from config."""
        with open(DISK_USAGE_SCRIPT, 'r') as f:
            content = f.read()
        # Script should reference multiplier from config
        assert 'multiplier' in content, (
            f"{DISK_USAGE_SCRIPT} should still use the multiplier field from config"
        )


class TestScriptExecutesSuccessfully:
    """Test that the script runs without errors."""

    def test_script_syntax_valid(self):
        """Verify disk_usage.py has valid Python syntax."""
        result = subprocess.run(
            ['python3', '-m', 'py_compile', DISK_USAGE_SCRIPT],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"disk_usage.py has syntax errors: {result.stderr}"
        )

    def test_script_runs_without_error(self):
        """Verify disk_usage.py executes without errors."""
        result = subprocess.run(
            ['python3', DISK_USAGE_SCRIPT],
            capture_output=True,
            text=True,
            cwd=COLLECTOR_DIR
        )
        assert result.returncode == 0, (
            f"disk_usage.py failed to execute: stdout={result.stdout}, stderr={result.stderr}"
        )


class TestUsageJsonStructure:
    """Test that usage.json has correct structure."""

    def test_usage_json_is_valid_json(self):
        """Verify usage.json contains valid JSON after running script."""
        # First run the script to regenerate the file
        subprocess.run(
            ['python3', DISK_USAGE_SCRIPT],
            capture_output=True,
            text=True,
            cwd=COLLECTOR_DIR
        )

        with open(USAGE_JSON, 'r') as f:
            content = f.read()
        try:
            data = json.loads(content)
        except json.JSONDecodeError as e:
            pytest.fail(f"usage.json is not valid JSON: {e}")
        assert isinstance(data, dict), "usage.json should contain a JSON object"

    def test_usage_json_has_path_key(self):
        """Verify usage.json has 'path' key."""
        # Run the script first
        subprocess.run(
            ['python3', DISK_USAGE_SCRIPT],
            capture_output=True,
            text=True,
            cwd=COLLECTOR_DIR
        )

        with open(USAGE_JSON, 'r') as f:
            data = json.load(f)
        assert 'path' in data, "usage.json does not contain 'path' key"

    def test_usage_json_has_used_gb_key(self):
        """Verify usage.json has 'used_gb' key."""
        # Run the script first
        subprocess.run(
            ['python3', DISK_USAGE_SCRIPT],
            capture_output=True,
            text=True,
            cwd=COLLECTOR_DIR
        )

        with open(USAGE_JSON, 'r') as f:
            data = json.load(f)
        assert 'used_gb' in data, "usage.json does not contain 'used_gb' key"


class TestUsageJsonCorrectValue:
    """Test that usage.json now shows correct disk usage values."""

    def test_used_gb_in_expected_range(self):
        """Verify used_gb is between 10 and 15 GB (reflecting actual ~12GB usage)."""
        # Run the script to regenerate usage.json with (hopefully) fixed values
        result = subprocess.run(
            ['python3', DISK_USAGE_SCRIPT],
            capture_output=True,
            text=True,
            cwd=COLLECTOR_DIR
        )
        assert result.returncode == 0, (
            f"Script failed to run: {result.stderr}"
        )

        with open(USAGE_JSON, 'r') as f:
            data = json.load(f)

        used_gb = data.get('used_gb')
        assert used_gb is not None, "usage.json missing 'used_gb' value"

        # Convert to float if it's a string
        if isinstance(used_gb, str):
            used_gb = float(used_gb)

        assert 10 <= used_gb <= 15, (
            f"usage.json used_gb is {used_gb}, expected between 10 and 15 GB "
            "(reflecting actual ~12GB disk usage of /data/metrics)"
        )

    def test_used_gb_not_absurdly_large(self):
        """Verify used_gb is not the buggy absurdly large value."""
        # Run the script
        subprocess.run(
            ['python3', DISK_USAGE_SCRIPT],
            capture_output=True,
            text=True,
            cwd=COLLECTOR_DIR
        )

        with open(USAGE_JSON, 'r') as f:
            data = json.load(f)

        used_gb = data.get('used_gb', 0)
        if isinstance(used_gb, str):
            used_gb = float(used_gb)

        # Should not be larger than the partition size (40GB)
        assert used_gb < 40, (
            f"usage.json used_gb is {used_gb}, which exceeds the 40GB partition size. "
            "The bug has not been fixed."
        )

    def test_path_is_data_metrics(self):
        """Verify the path in usage.json is /data/metrics."""
        # Run the script
        subprocess.run(
            ['python3', DISK_USAGE_SCRIPT],
            capture_output=True,
            text=True,
            cwd=COLLECTOR_DIR
        )

        with open(USAGE_JSON, 'r') as f:
            data = json.load(f)

        path = data.get('path', '')
        assert path == '/data/metrics', (
            f"usage.json path is '{path}', expected '/data/metrics'"
        )


class TestAntiShortcutGuards:
    """Tests to ensure the fix is proper and not a shortcut."""

    def test_running_script_regenerates_correct_value(self):
        """Verify running the script multiple times produces consistent correct values."""
        # Run the script twice
        for i in range(2):
            result = subprocess.run(
                ['python3', DISK_USAGE_SCRIPT],
                capture_output=True,
                text=True,
                cwd=COLLECTOR_DIR
            )
            assert result.returncode == 0, f"Script run {i+1} failed: {result.stderr}"

        with open(USAGE_JSON, 'r') as f:
            data = json.load(f)

        used_gb = data.get('used_gb', 0)
        if isinstance(used_gb, str):
            used_gb = float(used_gb)

        assert 10 <= used_gb <= 15, (
            f"After re-running script, used_gb is {used_gb}. "
            "Expected 10-15 GB. The fix must make the script produce correct values, "
            "not just manually edit usage.json."
        )

    def test_value_matches_actual_disk_usage(self):
        """Verify the reported value reasonably matches actual du output."""
        # Get actual disk usage
        du_result = subprocess.run(
            ['du', '-sb', DATA_METRICS_DIR],
            capture_output=True,
            text=True
        )
        assert du_result.returncode == 0, f"Failed to run du: {du_result.stderr}"

        actual_bytes = int(du_result.stdout.strip().split()[0])
        actual_gb = actual_bytes / (1024 ** 3)

        # Run the script
        subprocess.run(
            ['python3', DISK_USAGE_SCRIPT],
            capture_output=True,
            text=True,
            cwd=COLLECTOR_DIR
        )

        with open(USAGE_JSON, 'r') as f:
            data = json.load(f)

        reported_gb = data.get('used_gb', 0)
        if isinstance(reported_gb, str):
            reported_gb = float(reported_gb)

        # Allow some tolerance (within 2GB or 20% of actual)
        tolerance = max(2, actual_gb * 0.2)
        assert abs(reported_gb - actual_gb) < tolerance, (
            f"Reported used_gb ({reported_gb:.2f}) does not match actual disk usage "
            f"({actual_gb:.2f} GB). Difference should be less than {tolerance:.2f} GB."
        )

    def test_script_not_hardcoded_output(self):
        """Verify the script calculates values dynamically, not hardcoded."""
        with open(DISK_USAGE_SCRIPT, 'r') as f:
            content = f.read()

        # Should still use du command to get actual disk usage
        assert 'du' in content, (
            "Script should still use 'du' command to calculate disk usage, "
            "not hardcode values"
        )

        # Should still write to usage.json dynamically
        assert 'json' in content.lower(), (
            "Script should still use json module to write output"
        )
