# test_initial_state.py
"""
Tests to validate the initial state of the system before the student performs the action.
This verifies the buggy state where disk_usage.py produces incorrect values.
"""

import json
import os
import subprocess
import sys

import pytest

# Constants
HOME_DIR = "/home/user"
COLLECTOR_DIR = "/home/user/collector"
DISK_USAGE_SCRIPT = "/home/user/collector/disk_usage.py"
CONFIG_FILE = "/home/user/collector/config.yaml"
DATA_METRICS_DIR = "/data/metrics"
USAGE_JSON = "/data/metrics/usage.json"


class TestDirectoriesExist:
    """Test that required directories exist."""

    def test_home_user_exists(self):
        """Verify /home/user directory exists."""
        assert os.path.isdir(HOME_DIR), f"Home directory {HOME_DIR} does not exist"

    def test_collector_directory_exists(self):
        """Verify /home/user/collector directory exists."""
        assert os.path.isdir(COLLECTOR_DIR), f"Collector directory {COLLECTOR_DIR} does not exist"

    def test_data_metrics_directory_exists(self):
        """Verify /data/metrics directory exists."""
        assert os.path.isdir(DATA_METRICS_DIR), f"Data metrics directory {DATA_METRICS_DIR} does not exist"


class TestFilesExist:
    """Test that required files exist."""

    def test_disk_usage_script_exists(self):
        """Verify disk_usage.py script exists."""
        assert os.path.isfile(DISK_USAGE_SCRIPT), f"Disk usage script {DISK_USAGE_SCRIPT} does not exist"

    def test_config_yaml_exists(self):
        """Verify config.yaml exists."""
        assert os.path.isfile(CONFIG_FILE), f"Config file {CONFIG_FILE} does not exist"

    def test_usage_json_exists(self):
        """Verify usage.json exists."""
        assert os.path.isfile(USAGE_JSON), f"Usage JSON file {USAGE_JSON} does not exist"


class TestFilePermissions:
    """Test that files have appropriate permissions."""

    def test_collector_directory_writable(self):
        """Verify collector directory is writable."""
        assert os.access(COLLECTOR_DIR, os.W_OK), f"Collector directory {COLLECTOR_DIR} is not writable"

    def test_usage_json_writable(self):
        """Verify usage.json is writable."""
        assert os.access(USAGE_JSON, os.W_OK), f"Usage JSON file {USAGE_JSON} is not writable"

    def test_disk_usage_script_readable(self):
        """Verify disk_usage.py is readable."""
        assert os.access(DISK_USAGE_SCRIPT, os.R_OK), f"Disk usage script {DISK_USAGE_SCRIPT} is not readable"

    def test_config_yaml_readable(self):
        """Verify config.yaml is readable."""
        assert os.access(CONFIG_FILE, os.R_OK), f"Config file {CONFIG_FILE} is not readable"


class TestConfigYaml:
    """Test the configuration file content."""

    def test_config_yaml_has_target_path(self):
        """Verify config.yaml contains target_path set to /data/metrics."""
        with open(CONFIG_FILE, 'r') as f:
            content = f.read()
        assert 'target_path' in content, "config.yaml does not contain 'target_path'"
        assert '/data/metrics' in content, "config.yaml target_path is not set to /data/metrics"

    def test_config_yaml_has_multiplier(self):
        """Verify config.yaml contains a multiplier field."""
        with open(CONFIG_FILE, 'r') as f:
            content = f.read()
        assert 'multiplier' in content, "config.yaml does not contain 'multiplier'"

    def test_config_yaml_multiplier_is_large(self):
        """Verify config.yaml multiplier is set to a large value (the bug condition)."""
        try:
            import yaml
            with open(CONFIG_FILE, 'r') as f:
                config = yaml.safe_load(f)
            multiplier = config.get('multiplier', 0)
            # The bug is that multiplier is 1073741824 (bytes to GB conversion factor)
            # but the code multiplies instead of divides
            assert multiplier > 1000000, (
                f"config.yaml multiplier is {multiplier}, expected a large value like 1073741824 "
                "to reproduce the bug condition"
            )
        except ImportError:
            # If PyYAML not available, do a simple string check
            with open(CONFIG_FILE, 'r') as f:
                content = f.read()
            assert '1073741824' in content or 'multiplier' in content, (
                "config.yaml should contain multiplier value"
            )


class TestDiskUsageScript:
    """Test the disk_usage.py script content and structure."""

    def test_script_is_python(self):
        """Verify disk_usage.py is a Python script."""
        with open(DISK_USAGE_SCRIPT, 'r') as f:
            content = f.read()
        # Should contain Python-like syntax
        assert 'import' in content or 'def ' in content or 'open(' in content, (
            f"{DISK_USAGE_SCRIPT} does not appear to be a Python script"
        )

    def test_script_reads_config(self):
        """Verify disk_usage.py reads from config.yaml."""
        with open(DISK_USAGE_SCRIPT, 'r') as f:
            content = f.read()
        assert 'config' in content.lower() or 'yaml' in content.lower(), (
            f"{DISK_USAGE_SCRIPT} does not appear to read configuration"
        )

    def test_script_uses_du_command(self):
        """Verify disk_usage.py uses du command."""
        with open(DISK_USAGE_SCRIPT, 'r') as f:
            content = f.read()
        assert 'du' in content, (
            f"{DISK_USAGE_SCRIPT} does not appear to use 'du' command"
        )

    def test_script_writes_json(self):
        """Verify disk_usage.py writes JSON output."""
        with open(DISK_USAGE_SCRIPT, 'r') as f:
            content = f.read()
        assert 'json' in content.lower() or 'usage.json' in content, (
            f"{DISK_USAGE_SCRIPT} does not appear to write JSON output"
        )

    def test_script_has_multiplication_bug(self):
        """Verify disk_usage.py has the multiplication bug (multiplies instead of divides)."""
        with open(DISK_USAGE_SCRIPT, 'r') as f:
            content = f.read()
        # The bug is that it multiplies by the multiplier instead of dividing
        # Look for patterns like "* multiplier" or "*multiplier"
        has_multiply = ('* multiplier' in content or '*multiplier' in content or 
                       '* config' in content and 'multiplier' in content)
        # Should NOT have division by multiplier
        has_correct_divide = ('/ multiplier' in content or '/multiplier' in content or
                             '// multiplier' in content or '//multiplier' in content)

        assert has_multiply or not has_correct_divide, (
            f"{DISK_USAGE_SCRIPT} should have the multiplication bug "
            "(multiplies by multiplier instead of dividing)"
        )


class TestUsageJson:
    """Test the current state of usage.json."""

    def test_usage_json_is_valid_json(self):
        """Verify usage.json contains valid JSON."""
        with open(USAGE_JSON, 'r') as f:
            content = f.read()
        try:
            data = json.loads(content)
        except json.JSONDecodeError as e:
            pytest.fail(f"usage.json is not valid JSON: {e}")
        assert isinstance(data, dict), "usage.json should contain a JSON object"

    def test_usage_json_has_path_key(self):
        """Verify usage.json has 'path' key."""
        with open(USAGE_JSON, 'r') as f:
            data = json.load(f)
        assert 'path' in data, "usage.json does not contain 'path' key"

    def test_usage_json_has_used_gb_key(self):
        """Verify usage.json has 'used_gb' key."""
        with open(USAGE_JSON, 'r') as f:
            data = json.load(f)
        assert 'used_gb' in data, "usage.json does not contain 'used_gb' key"

    def test_usage_json_shows_incorrect_value(self):
        """Verify usage.json shows an absurdly large value (the bug symptom)."""
        with open(USAGE_JSON, 'r') as f:
            data = json.load(f)
        used_gb = data.get('used_gb', 0)
        # The bug causes the value to be way too large (task says 89GB shown but partition is 40GB)
        # The actual bug multiplies ~12GB by 1073741824, giving exabytes
        # But even showing 89GB when partition is 40GB is wrong
        assert used_gb > 40, (
            f"usage.json used_gb is {used_gb}, expected > 40 to show the bug condition "
            "(dashboard shows 89GB but partition is only 40GB total)"
        )


class TestActualDiskUsage:
    """Test the actual disk usage of /data/metrics."""

    def test_actual_usage_is_reasonable(self):
        """Verify actual disk usage of /data/metrics is around 12GB (not 89GB)."""
        result = subprocess.run(
            ['du', '-sb', DATA_METRICS_DIR],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, f"Failed to run du -sb {DATA_METRICS_DIR}: {result.stderr}"

        # Parse output: "12345678901\t/data/metrics"
        parts = result.stdout.strip().split()
        assert len(parts) >= 1, f"Unexpected du output format: {result.stdout}"

        bytes_used = int(parts[0])
        gb_used = bytes_used / (1024 ** 3)

        # Actual usage should be around 12GB (between 5GB and 20GB is reasonable)
        assert 5 < gb_used < 20, (
            f"Actual disk usage of {DATA_METRICS_DIR} is {gb_used:.2f}GB, "
            "expected around 12GB (between 5-20GB)"
        )


class TestPythonEnvironment:
    """Test that required Python environment is available."""

    def test_python3_available(self):
        """Verify Python 3 is available."""
        result = subprocess.run(
            ['python3', '--version'],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "Python 3 is not available"
        assert 'Python 3' in result.stdout or 'Python 3' in result.stderr, (
            "Python 3 version string not found"
        )

    def test_pyyaml_installed(self):
        """Verify PyYAML is installed."""
        result = subprocess.run(
            ['python3', '-c', 'import yaml; print(yaml.__version__)'],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"PyYAML is not installed or cannot be imported: {result.stderr}"
        )


class TestScriptExecutability:
    """Test that the script can be executed."""

    def test_script_syntax_valid(self):
        """Verify disk_usage.py has valid Python syntax."""
        result = subprocess.run(
            ['python3', '-m', 'py_compile', DISK_USAGE_SCRIPT],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"disk_usage.py has syntax errors: {result.stderr}"
        )
