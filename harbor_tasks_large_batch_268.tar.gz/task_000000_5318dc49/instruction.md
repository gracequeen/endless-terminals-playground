Dashboard for /data/metrics keeps showing 89GB used but df says the partition is only 40GB total. I've been staring at this for an hour — the collector script at /home/user/collector/disk_usage.py runs every minute via cron and writes to /data/metrics/usage.json, and that's what Grafana reads. The numbers were fine last week.

Honestly not sure if it's the collector lying, some stale cache, or if I broke something when I tweaked the config on Thursday. Just need usage.json reporting accurate numbers for /data/metrics so the dashboard isn't embarrassing me in standup.
