# test_initial_state.py
"""
Tests to validate the initial state of the system before the student performs the task.
This validates that the webapp exists with the broken setup.js file that needs to be fixed.
"""

import pytest
import os
import subprocess
import json


class TestWebappDirectoryStructure:
    """Test that the webapp directory and required files exist."""

    def test_webapp_directory_exists(self):
        """Verify /home/user/webapp directory exists."""
        assert os.path.isdir("/home/user/webapp"), \
            "Directory /home/user/webapp does not exist"

    def test_package_json_exists(self):
        """Verify package.json exists in webapp."""
        path = "/home/user/webapp/package.json"
        assert os.path.isfile(path), \
            f"File {path} does not exist"

    def test_jest_config_exists(self):
        """Verify jest.config.js exists in webapp."""
        path = "/home/user/webapp/jest.config.js"
        assert os.path.isfile(path), \
            f"File {path} does not exist"

    def test_node_modules_exists(self):
        """Verify node_modules directory exists."""
        path = "/home/user/webapp/node_modules"
        assert os.path.isdir(path), \
            f"Directory {path} does not exist - npm install may not have been run"

    def test_jest_installed(self):
        """Verify jest is installed in node_modules."""
        path = "/home/user/webapp/node_modules/jest"
        assert os.path.isdir(path), \
            f"Jest not found at {path} - jest dependency not installed"

    def test_test_directory_exists(self):
        """Verify test directory exists."""
        path = "/home/user/webapp/test"
        assert os.path.isdir(path), \
            f"Directory {path} does not exist"


class TestTestFiles:
    """Test that all required test files exist."""

    def test_setup_js_exists(self):
        """Verify setup.js exists in test directory."""
        path = "/home/user/webapp/test/setup.js"
        assert os.path.isfile(path), \
            f"File {path} does not exist"

    def test_helpers_js_exists(self):
        """Verify helpers.js exists in test directory."""
        path = "/home/user/webapp/test/helpers.js"
        assert os.path.isfile(path), \
            f"File {path} does not exist"

    def test_api_test_js_exists(self):
        """Verify api.test.js exists in test directory."""
        path = "/home/user/webapp/test/api.test.js"
        assert os.path.isfile(path), \
            f"File {path} does not exist"

    def test_utils_test_js_exists(self):
        """Verify utils.test.js exists in test directory."""
        path = "/home/user/webapp/test/utils.test.js"
        assert os.path.isfile(path), \
            f"File {path} does not exist"


class TestPackageJsonContent:
    """Test that package.json has the expected configuration."""

    def test_package_json_valid_json(self):
        """Verify package.json is valid JSON."""
        path = "/home/user/webapp/package.json"
        with open(path, 'r') as f:
            try:
                data = json.load(f)
            except json.JSONDecodeError as e:
                pytest.fail(f"package.json is not valid JSON: {e}")

    def test_package_json_has_jest_script(self):
        """Verify package.json has test script configured for jest."""
        path = "/home/user/webapp/package.json"
        with open(path, 'r') as f:
            data = json.load(f)

        assert "scripts" in data, "package.json missing 'scripts' section"
        assert "test" in data["scripts"], "package.json missing 'test' script"
        assert "jest" in data["scripts"]["test"], \
            "package.json test script does not use jest"

    def test_package_json_has_jest_devdep(self):
        """Verify package.json has jest in devDependencies."""
        path = "/home/user/webapp/package.json"
        with open(path, 'r') as f:
            data = json.load(f)

        assert "devDependencies" in data, "package.json missing 'devDependencies'"
        assert "jest" in data["devDependencies"], \
            "package.json missing jest in devDependencies"


class TestJestConfig:
    """Test that jest.config.js has the expected configuration."""

    def test_jest_config_references_setup_js(self):
        """Verify jest.config.js references setup.js in setupFilesAfterEnv."""
        path = "/home/user/webapp/jest.config.js"
        with open(path, 'r') as f:
            content = f.read()

        assert "setupFilesAfterEnv" in content, \
            "jest.config.js missing setupFilesAfterEnv configuration"
        assert "setup.js" in content, \
            "jest.config.js does not reference setup.js"


class TestSetupJsHasSyntaxError:
    """Test that setup.js has the expected syntax error (the bug to fix)."""

    def test_setup_js_has_syntax_error(self):
        """Verify setup.js has a syntax error (unclosed bracket)."""
        path = "/home/user/webapp/test/setup.js"
        with open(path, 'r') as f:
            content = f.read()

        # Check that the file has the unclosed object pattern
        # It should have an opening brace for testConfig but missing closing
        assert "global.testConfig" in content, \
            "setup.js does not contain expected global.testConfig"

        # Count braces - there should be more opening than closing
        open_braces = content.count('{')
        close_braces = content.count('}')

        assert open_braces > close_braces, \
            f"setup.js does not have unclosed braces (found {open_braces} '{{' and {close_braces} '}}'). " \
            "The file should have a syntax error with missing closing brace."


class TestNpmTestFails:
    """Test that npm test currently fails (the problem to solve)."""

    def test_npm_test_fails(self):
        """Verify that npm test currently fails due to setup.js syntax error."""
        result = subprocess.run(
            ["npm", "test"],
            cwd="/home/user/webapp",
            capture_output=True,
            text=True
        )

        assert result.returncode != 0, \
            "npm test should fail initially due to setup.js syntax error, but it succeeded"

    def test_npm_test_error_mentions_setup_or_syntax(self):
        """Verify the npm test error is related to setup.js or syntax."""
        result = subprocess.run(
            ["npm", "test"],
            cwd="/home/user/webapp",
            capture_output=True,
            text=True
        )

        combined_output = result.stdout + result.stderr

        # The error should mention setup.js or indicate a syntax/parse error
        has_setup_mention = "setup.js" in combined_output or "setup" in combined_output.lower()
        has_syntax_error = any(term in combined_output.lower() for term in 
                              ["syntax", "unexpected token", "parse", "failed to parse"])

        assert has_setup_mention or has_syntax_error, \
            f"npm test error should mention setup.js or syntax error. Output: {combined_output[:500]}"


class TestNodeEnvironment:
    """Test that Node.js environment is properly set up."""

    def test_node_installed(self):
        """Verify Node.js is installed."""
        result = subprocess.run(
            ["node", "--version"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "Node.js is not installed or not in PATH"

    def test_node_version_20(self):
        """Verify Node.js version is 20.x."""
        result = subprocess.run(
            ["node", "--version"],
            capture_output=True,
            text=True
        )
        version = result.stdout.strip()
        assert version.startswith("v20"), \
            f"Expected Node.js v20.x but found {version}"

    def test_npm_installed(self):
        """Verify npm is installed."""
        result = subprocess.run(
            ["npm", "--version"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "npm is not installed or not in PATH"

    def test_npm_version_10(self):
        """Verify npm version is 10.x."""
        result = subprocess.run(
            ["npm", "--version"],
            capture_output=True,
            text=True
        )
        version = result.stdout.strip()
        assert version.startswith("10"), \
            f"Expected npm 10.x but found {version}"


class TestDirectoryWritable:
    """Test that the webapp directory is writable."""

    def test_webapp_writable(self):
        """Verify /home/user/webapp is writable."""
        path = "/home/user/webapp"
        assert os.access(path, os.W_OK), \
            f"Directory {path} is not writable"

    def test_test_directory_writable(self):
        """Verify /home/user/webapp/test is writable."""
        path = "/home/user/webapp/test"
        assert os.access(path, os.W_OK), \
            f"Directory {path} is not writable"

    def test_setup_js_writable(self):
        """Verify setup.js is writable."""
        path = "/home/user/webapp/test/setup.js"
        assert os.access(path, os.W_OK), \
            f"File {path} is not writable"
