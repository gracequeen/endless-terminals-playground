# test_final_state.py
"""
Tests to validate the final state of the system after the student has fixed the webapp test suite.
The setup.js syntax error should be fixed and all 47 tests should pass.
"""

import pytest
import os
import subprocess
import json
import re


class TestWebappDirectoryStructure:
    """Test that the webapp directory and required files still exist."""

    def test_webapp_directory_exists(self):
        """Verify /home/user/webapp directory exists."""
        assert os.path.isdir("/home/user/webapp"), \
            "Directory /home/user/webapp does not exist"

    def test_package_json_exists(self):
        """Verify package.json exists in webapp."""
        path = "/home/user/webapp/package.json"
        assert os.path.isfile(path), \
            f"File {path} does not exist"

    def test_jest_config_exists(self):
        """Verify jest.config.js exists in webapp."""
        path = "/home/user/webapp/jest.config.js"
        assert os.path.isfile(path), \
            f"File {path} does not exist"

    def test_node_modules_exists(self):
        """Verify node_modules directory exists."""
        path = "/home/user/webapp/node_modules"
        assert os.path.isdir(path), \
            f"Directory {path} does not exist"

    def test_test_directory_exists(self):
        """Verify test directory exists."""
        path = "/home/user/webapp/test"
        assert os.path.isdir(path), \
            f"Directory {path} does not exist"


class TestTestFilesExist:
    """Test that all required test files still exist."""

    def test_setup_js_exists(self):
        """Verify setup.js exists in test directory."""
        path = "/home/user/webapp/test/setup.js"
        assert os.path.isfile(path), \
            f"File {path} does not exist - setup.js should be fixed, not deleted"

    def test_helpers_js_exists(self):
        """Verify helpers.js exists in test directory."""
        path = "/home/user/webapp/test/helpers.js"
        assert os.path.isfile(path), \
            f"File {path} does not exist"

    def test_api_test_js_exists(self):
        """Verify api.test.js exists in test directory."""
        path = "/home/user/webapp/test/api.test.js"
        assert os.path.isfile(path), \
            f"File {path} does not exist"

    def test_utils_test_js_exists(self):
        """Verify utils.test.js exists in test directory."""
        path = "/home/user/webapp/test/utils.test.js"
        assert os.path.isfile(path), \
            f"File {path} does not exist"


class TestSetupJsSyntaxValid:
    """Test that setup.js is now syntactically valid JavaScript."""

    def test_setup_js_is_valid_javascript(self):
        """Verify setup.js can be parsed by Node.js without syntax errors."""
        path = "/home/user/webapp/test/setup.js"

        # Use Node.js to check syntax
        result = subprocess.run(
            ["node", "--check", path],
            capture_output=True,
            text=True
        )

        assert result.returncode == 0, \
            f"setup.js has syntax errors: {result.stderr}"

    def test_setup_js_has_balanced_braces(self):
        """Verify setup.js has balanced braces."""
        path = "/home/user/webapp/test/setup.js"
        with open(path, 'r') as f:
            content = f.read()

        open_braces = content.count('{')
        close_braces = content.count('}')

        assert open_braces == close_braces, \
            f"setup.js has unbalanced braces: {open_braces} '{{' vs {close_braces} '}}'"

    def test_setup_js_still_has_test_config(self):
        """Verify setup.js still contains the testConfig setup."""
        path = "/home/user/webapp/test/setup.js"
        with open(path, 'r') as f:
            content = f.read()

        assert "global.testConfig" in content or "testConfig" in content, \
            "setup.js should still contain testConfig configuration"


class TestJestConfigUnchanged:
    """Test that jest.config.js still references setup.js (anti-shortcut guard)."""

    def test_jest_config_still_references_setup_js(self):
        """Verify jest.config.js still has setupFilesAfterEnv with setup.js."""
        path = "/home/user/webapp/jest.config.js"
        with open(path, 'r') as f:
            content = f.read()

        assert "setupFilesAfterEnv" in content, \
            "jest.config.js must still have setupFilesAfterEnv configured"
        assert "setup.js" in content, \
            "jest.config.js must still reference setup.js in setupFilesAfterEnv"

    def test_grep_setup_files_after_env(self):
        """Verify grep confirms setup.js is still in jest.config.js setupFilesAfterEnv."""
        result = subprocess.run(
            ["grep", "-c", "setupFilesAfterEnv.*setup.js", "/home/user/webapp/jest.config.js"],
            capture_output=True,
            text=True
        )

        # grep -c returns the count; should be at least 1
        count = result.stdout.strip()
        assert count == "1" or (result.returncode == 0 and int(count) >= 1), \
            "jest.config.js must have setupFilesAfterEnv referencing setup.js"


class TestPackageJsonUnchanged:
    """Test that package.json devDependencies are unchanged."""

    def test_package_json_valid(self):
        """Verify package.json is still valid JSON."""
        path = "/home/user/webapp/package.json"
        with open(path, 'r') as f:
            try:
                data = json.load(f)
            except json.JSONDecodeError as e:
                pytest.fail(f"package.json is not valid JSON: {e}")

    def test_package_json_has_jest_devdep(self):
        """Verify package.json still has jest in devDependencies."""
        path = "/home/user/webapp/package.json"
        with open(path, 'r') as f:
            data = json.load(f)

        assert "devDependencies" in data, \
            "package.json must still have devDependencies"
        assert "jest" in data["devDependencies"], \
            "package.json must still have jest in devDependencies"

    def test_package_json_test_script_unchanged(self):
        """Verify package.json test script still uses jest."""
        path = "/home/user/webapp/package.json"
        with open(path, 'r') as f:
            data = json.load(f)

        assert "scripts" in data, "package.json must have scripts"
        assert "test" in data["scripts"], "package.json must have test script"
        assert "jest" in data["scripts"]["test"], \
            "package.json test script must use jest"


class TestNpmTestPasses:
    """Test that npm test now passes with all 47 tests."""

    def test_npm_test_exits_zero(self):
        """Verify npm test exits with code 0."""
        result = subprocess.run(
            ["npm", "test"],
            cwd="/home/user/webapp",
            capture_output=True,
            text=True,
            timeout=120
        )

        assert result.returncode == 0, \
            f"npm test should exit 0 but exited {result.returncode}.\n" \
            f"stdout: {result.stdout[-1000:] if len(result.stdout) > 1000 else result.stdout}\n" \
            f"stderr: {result.stderr[-1000:] if len(result.stderr) > 1000 else result.stderr}"

    def test_all_47_tests_pass(self):
        """Verify all 47 tests pass."""
        result = subprocess.run(
            ["npm", "test"],
            cwd="/home/user/webapp",
            capture_output=True,
            text=True,
            timeout=120
        )

        combined_output = result.stdout + result.stderr

        # Look for patterns indicating 47 tests passed
        # Jest output formats: "47 passed", "Tests: 47 passed", "Tests:       47 passed"
        patterns = [
            r'47\s+passed',
            r'Tests:\s*47\s+passed',
            r'Tests:.*47\s+passed',
            r'47\s*passed',
        ]

        found_47_passed = any(re.search(pattern, combined_output, re.IGNORECASE) 
                             for pattern in patterns)

        # Also check for the specific test counts (23 + 24 = 47)
        if not found_47_passed:
            # Try to find any "passed" count
            passed_match = re.search(r'(\d+)\s+passed', combined_output, re.IGNORECASE)
            if passed_match:
                passed_count = int(passed_match.group(1))
                assert passed_count == 47, \
                    f"Expected 47 tests to pass but found {passed_count} passed.\n" \
                    f"Output: {combined_output[-1500:]}"
            else:
                pytest.fail(
                    f"Could not find test pass count in output. Expected 47 tests to pass.\n"
                    f"Output: {combined_output[-1500:]}"
                )

    def test_grep_47_passed(self):
        """Verify grep can find 47 passed in npm test output."""
        result = subprocess.run(
            ["npm", "test"],
            cwd="/home/user/webapp",
            capture_output=True,
            text=True,
            timeout=120
        )

        combined_output = result.stdout + result.stderr

        # Use grep-like check for "47 passed" or "Tests:.*47"
        has_47_passed = bool(re.search(r'47\s*passed', combined_output, re.IGNORECASE))
        has_tests_47 = bool(re.search(r'Tests:.*47', combined_output))

        assert has_47_passed or has_tests_47, \
            f"npm test output must show 47 tests passed.\nOutput: {combined_output[-1500:]}"


class TestNoTestsDeleted:
    """Test that test files still contain all their tests (anti-shortcut guard)."""

    def test_api_test_has_tests(self):
        """Verify api.test.js still has test definitions."""
        path = "/home/user/webapp/test/api.test.js"
        with open(path, 'r') as f:
            content = f.read()

        # Count test definitions (it() or test() calls)
        test_count = len(re.findall(r'\b(it|test)\s*\(', content))

        assert test_count >= 20, \
            f"api.test.js should have at least 20 tests but found {test_count}. " \
            "Tests should not be deleted to make the suite pass."

    def test_utils_test_has_tests(self):
        """Verify utils.test.js still has test definitions."""
        path = "/home/user/webapp/test/utils.test.js"
        with open(path, 'r') as f:
            content = f.read()

        # Count test definitions (it() or test() calls)
        test_count = len(re.findall(r'\b(it|test)\s*\(', content))

        assert test_count >= 20, \
            f"utils.test.js should have at least 20 tests but found {test_count}. " \
            "Tests should not be deleted to make the suite pass."


class TestNoFailedTests:
    """Test that there are no failed tests in the output."""

    def test_no_failures_in_output(self):
        """Verify npm test output shows no failures."""
        result = subprocess.run(
            ["npm", "test"],
            cwd="/home/user/webapp",
            capture_output=True,
            text=True,
            timeout=120
        )

        combined_output = result.stdout + result.stderr

        # Check for failure indicators
        failed_match = re.search(r'(\d+)\s+failed', combined_output, re.IGNORECASE)

        if failed_match:
            failed_count = int(failed_match.group(1))
            assert failed_count == 0, \
                f"Expected 0 failed tests but found {failed_count} failed.\n" \
                f"Output: {combined_output[-1500:]}"
