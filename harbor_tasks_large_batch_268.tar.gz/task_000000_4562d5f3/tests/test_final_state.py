# test_final_state.py
"""
Tests to validate the final state after the student has fixed the merge_reports.py script.
The script should now correctly merge quarterly JSON files into merged.csv with accurate totals.
"""

import csv
import json
import os
import subprocess
import pytest


HOME_DIR = "/home/user"
CAPACITY_DIR = os.path.join(HOME_DIR, "capacity")
DATA_DIR = os.path.join(CAPACITY_DIR, "data")
MERGE_SCRIPT = os.path.join(CAPACITY_DIR, "merge_reports.py")
MERGED_CSV = os.path.join(CAPACITY_DIR, "merged.csv")

QUARTERLY_FILES = ["q1_2024.json", "q2_2024.json", "q3_2024.json", "q4_2024.json"]

EXPECTED_MONTHS = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
]


def get_source_totals():
    """Calculate the expected totals directly from source JSON files."""
    total_cpu_hours = 0
    total_mem_gb = 0
    total_storage_tb = 0

    for filename in QUARTERLY_FILES:
        filepath = os.path.join(DATA_DIR, filename)
        with open(filepath, 'r') as f:
            data = json.load(f)

        for month_data in data["months"]:
            resources = month_data["resources"]
            total_cpu_hours += resources["cpu_hours"]
            total_mem_gb += resources["mem_gb"]
            total_storage_tb += resources["storage_tb"]

    return total_cpu_hours, total_mem_gb, total_storage_tb


def get_merged_csv_totals():
    """Calculate totals from the merged.csv file."""
    total_cpu_hours = 0
    total_mem_gb = 0
    total_storage_tb = 0

    with open(MERGED_CSV, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            total_cpu_hours += float(row["cpu_hours"])
            total_mem_gb += float(row["mem_gb"])
            total_storage_tb += float(row["storage_tb"])

    return total_cpu_hours, total_mem_gb, total_storage_tb


def get_merged_csv_rows():
    """Read all rows from merged.csv."""
    with open(MERGED_CSV, 'r') as f:
        reader = csv.DictReader(f)
        return list(reader)


class TestScriptExecution:
    """Test that the fixed script runs correctly."""

    def test_script_exists(self):
        assert os.path.isfile(MERGE_SCRIPT), (
            f"Script {MERGE_SCRIPT} does not exist."
        )

    def test_script_runs_successfully(self):
        """Verify the script executes with exit code 0."""
        result = subprocess.run(
            ["python3", MERGE_SCRIPT],
            capture_output=True,
            text=True,
            cwd=CAPACITY_DIR
        )
        assert result.returncode == 0, (
            f"Script {MERGE_SCRIPT} failed to run with exit code 0. "
            f"Return code: {result.returncode}, "
            f"Stderr: {result.stderr}, "
            f"Stdout: {result.stdout}"
        )

    def test_merged_csv_is_produced(self):
        """Verify the script produces merged.csv."""
        # Run the script first
        subprocess.run(
            ["python3", MERGE_SCRIPT],
            capture_output=True,
            cwd=CAPACITY_DIR
        )

        assert os.path.isfile(MERGED_CSV), (
            f"Script did not produce {MERGED_CSV}."
        )


class TestScriptIntegrity:
    """Test that the script maintains required function names."""

    def test_script_contains_normalize_units_function(self):
        with open(MERGE_SCRIPT, 'r') as f:
            content = f.read()
        assert "normalize_units" in content, (
            f"Script {MERGE_SCRIPT} must still contain 'normalize_units' function. "
            "The fix should modify the existing code, not replace it entirely."
        )

    def test_script_contains_merge_quarterly_data_function(self):
        with open(MERGE_SCRIPT, 'r') as f:
            content = f.read()
        assert "merge_quarterly_data" in content, (
            f"Script {MERGE_SCRIPT} must still contain 'merge_quarterly_data' function. "
            "The fix should modify the existing code, not replace it entirely."
        )


class TestSourceFilesUnchanged:
    """Test that source JSON files remain unchanged."""

    @pytest.mark.parametrize("filename", QUARTERLY_FILES)
    def test_source_file_exists(self, filename):
        filepath = os.path.join(DATA_DIR, filename)
        assert os.path.isfile(filepath), (
            f"Source file {filepath} must still exist."
        )

    @pytest.mark.parametrize("filename", QUARTERLY_FILES)
    def test_source_file_is_valid_json(self, filename):
        filepath = os.path.join(DATA_DIR, filename)
        with open(filepath, 'r') as f:
            try:
                data = json.load(f)
            except json.JSONDecodeError as e:
                pytest.fail(f"Source file {filepath} is no longer valid JSON: {e}")

    @pytest.mark.parametrize("filename", QUARTERLY_FILES)
    def test_source_file_has_required_structure(self, filename):
        filepath = os.path.join(DATA_DIR, filename)
        with open(filepath, 'r') as f:
            data = json.load(f)

        assert "quarter" in data, f"Source file {filepath} missing 'quarter' key"
        assert "year" in data, f"Source file {filepath} missing 'year' key"
        assert "months" in data, f"Source file {filepath} missing 'months' key"
        assert len(data["months"]) == 3, (
            f"Source file {filepath} should have 3 months"
        )


class TestMergedCSVStructure:
    """Test the structure of the merged.csv file."""

    def test_merged_csv_has_correct_columns(self):
        """Verify merged.csv has the expected column headers in correct order."""
        # Run script first
        subprocess.run(
            ["python3", MERGE_SCRIPT],
            capture_output=True,
            cwd=CAPACITY_DIR
        )

        with open(MERGED_CSV, 'r') as f:
            header = f.readline().strip()

        expected_columns = ["month", "cpu_hours", "mem_gb", "storage_tb"]
        actual_columns = [col.strip() for col in header.split(",")]

        assert actual_columns == expected_columns, (
            f"merged.csv should have columns {expected_columns} in that order, "
            f"but has {actual_columns}"
        )

    def test_merged_csv_has_exactly_twelve_data_rows(self):
        """Verify merged.csv has exactly 12 data rows (plus header)."""
        subprocess.run(
            ["python3", MERGE_SCRIPT],
            capture_output=True,
            cwd=CAPACITY_DIR
        )

        rows = get_merged_csv_rows()

        assert len(rows) == 12, (
            f"merged.csv should have exactly 12 data rows (one per month), "
            f"but has {len(rows)} rows"
        )

    def test_each_month_appears_exactly_once(self):
        """Verify each month appears exactly once in merged.csv."""
        subprocess.run(
            ["python3", MERGE_SCRIPT],
            capture_output=True,
            cwd=CAPACITY_DIR
        )

        rows = get_merged_csv_rows()
        months_in_csv = [row["month"] for row in rows]

        # Check no duplicates
        assert len(months_in_csv) == len(set(months_in_csv)), (
            f"Duplicate months found in merged.csv: {months_in_csv}"
        )

        # Check all expected months are present
        missing_months = set(EXPECTED_MONTHS) - set(months_in_csv)
        extra_months = set(months_in_csv) - set(EXPECTED_MONTHS)

        assert not missing_months, (
            f"Missing months in merged.csv: {missing_months}"
        )
        assert not extra_months, (
            f"Unexpected months in merged.csv: {extra_months}"
        )


class TestMergedCSVTotals:
    """Test that the merged.csv totals match the source JSON totals."""

    def test_cpu_hours_total_matches_source(self):
        """Verify sum of cpu_hours in merged.csv matches sum from source JSONs."""
        subprocess.run(
            ["python3", MERGE_SCRIPT],
            capture_output=True,
            cwd=CAPACITY_DIR
        )

        expected_cpu, _, _ = get_source_totals()
        actual_cpu, _, _ = get_merged_csv_totals()

        assert abs(actual_cpu - expected_cpu) < 1, (
            f"cpu_hours total mismatch. "
            f"Expected (from source JSONs): {expected_cpu}, "
            f"Actual (from merged.csv): {actual_cpu}, "
            f"Difference: {abs(actual_cpu - expected_cpu)}. "
            "The merged.csv should reflect the real totals from source data."
        )

    def test_mem_gb_total_matches_source(self):
        """Verify sum of mem_gb in merged.csv matches sum from source JSONs."""
        subprocess.run(
            ["python3", MERGE_SCRIPT],
            capture_output=True,
            cwd=CAPACITY_DIR
        )

        _, expected_mem, _ = get_source_totals()
        _, actual_mem, _ = get_merged_csv_totals()

        assert abs(actual_mem - expected_mem) < 0.01, (
            f"mem_gb total mismatch. "
            f"Expected (from source JSONs): {expected_mem}, "
            f"Actual (from merged.csv): {actual_mem}, "
            f"Difference: {abs(actual_mem - expected_mem)}. "
            "The merged.csv should reflect the real totals from source data."
        )

    def test_storage_tb_total_matches_source(self):
        """Verify sum of storage_tb in merged.csv matches sum from source JSONs."""
        subprocess.run(
            ["python3", MERGE_SCRIPT],
            capture_output=True,
            cwd=CAPACITY_DIR
        )

        _, _, expected_storage = get_source_totals()
        _, _, actual_storage = get_merged_csv_totals()

        assert abs(actual_storage - expected_storage) < 0.01, (
            f"storage_tb total mismatch. "
            f"Expected (from source JSONs): {expected_storage}, "
            f"Actual (from merged.csv): {actual_storage}, "
            f"Difference: {abs(actual_storage - expected_storage)}. "
            "The merged.csv should reflect the real totals from source data."
        )


class TestIndividualMonthValues:
    """Test that individual month values are reasonable and match source data."""

    def test_all_values_are_positive(self):
        """Verify all numeric values in merged.csv are positive."""
        subprocess.run(
            ["python3", MERGE_SCRIPT],
            capture_output=True,
            cwd=CAPACITY_DIR
        )

        rows = get_merged_csv_rows()

        for row in rows:
            month = row["month"]
            cpu = float(row["cpu_hours"])
            mem = float(row["mem_gb"])
            storage = float(row["storage_tb"])

            assert cpu > 0, f"cpu_hours for {month} should be positive, got {cpu}"
            assert mem > 0, f"mem_gb for {month} should be positive, got {mem}"
            assert storage > 0, f"storage_tb for {month} should be positive, got {storage}"

    def test_values_are_in_realistic_ranges(self):
        """Verify values are in realistic ranges (not divided down by bug)."""
        subprocess.run(
            ["python3", MERGE_SCRIPT],
            capture_output=True,
            cwd=CAPACITY_DIR
        )

        rows = get_merged_csv_rows()

        for row in rows:
            month = row["month"]
            cpu = float(row["cpu_hours"])
            mem = float(row["mem_gb"])
            storage = float(row["storage_tb"])

            # Based on task description: cpu_hours 10000-50000, mem_gb 500-2000, storage_tb 50-200
            assert 10000 <= cpu <= 50000, (
                f"cpu_hours for {month} = {cpu} is outside expected range [10000, 50000]. "
                "This suggests the buggy unit conversion may still be active."
            )
            assert 500 <= mem <= 2000, (
                f"mem_gb for {month} = {mem} is outside expected range [500, 2000]. "
                "This suggests the buggy unit conversion may still be active."
            )
            assert 50 <= storage <= 200, (
                f"storage_tb for {month} = {storage} is outside expected range [50, 200]."
            )


class TestPerMonthAccuracy:
    """Test that each month's values match the source data exactly."""

    def test_each_month_matches_source(self):
        """Verify each month's values in merged.csv match the corresponding source JSON."""
        subprocess.run(
            ["python3", MERGE_SCRIPT],
            capture_output=True,
            cwd=CAPACITY_DIR
        )

        # Build expected values from source
        expected_by_month = {}
        for filename in QUARTERLY_FILES:
            filepath = os.path.join(DATA_DIR, filename)
            with open(filepath, 'r') as f:
                data = json.load(f)

            for month_data in data["months"]:
                month_name = month_data["month"]
                resources = month_data["resources"]
                expected_by_month[month_name] = {
                    "cpu_hours": resources["cpu_hours"],
                    "mem_gb": resources["mem_gb"],
                    "storage_tb": resources["storage_tb"]
                }

        # Check merged.csv against expected
        rows = get_merged_csv_rows()

        for row in rows:
            month = row["month"]
            assert month in expected_by_month, f"Unexpected month in merged.csv: {month}"

            expected = expected_by_month[month]
            actual_cpu = float(row["cpu_hours"])
            actual_mem = float(row["mem_gb"])
            actual_storage = float(row["storage_tb"])

            assert abs(actual_cpu - expected["cpu_hours"]) < 1, (
                f"cpu_hours mismatch for {month}. "
                f"Expected: {expected['cpu_hours']}, Actual: {actual_cpu}"
            )
            assert abs(actual_mem - expected["mem_gb"]) < 0.01, (
                f"mem_gb mismatch for {month}. "
                f"Expected: {expected['mem_gb']}, Actual: {actual_mem}"
            )
            assert abs(actual_storage - expected["storage_tb"]) < 0.01, (
                f"storage_tb mismatch for {month}. "
                f"Expected: {expected['storage_tb']}, Actual: {actual_storage}"
            )


class TestNoHardcodedValues:
    """Test that the fix doesn't just hardcode expected values."""

    def test_totals_match_dynamic_source_calculation(self):
        """
        Verify that merged.csv totals match dynamically calculated source totals.
        This guards against hardcoding values in the script.
        """
        subprocess.run(
            ["python3", MERGE_SCRIPT],
            capture_output=True,
            cwd=CAPACITY_DIR
        )

        # Calculate expected from source (this is dynamic, based on actual file contents)
        expected_cpu, expected_mem, expected_storage = get_source_totals()
        actual_cpu, actual_mem, actual_storage = get_merged_csv_totals()

        # All three must match
        all_match = (
            abs(actual_cpu - expected_cpu) < 1 and
            abs(actual_mem - expected_mem) < 0.01 and
            abs(actual_storage - expected_storage) < 0.01
        )

        assert all_match, (
            f"Totals don't match source data. This could indicate hardcoded values. "
            f"Expected: cpu={expected_cpu}, mem={expected_mem}, storage={expected_storage}. "
            f"Actual: cpu={actual_cpu}, mem={actual_mem}, storage={actual_storage}."
        )
