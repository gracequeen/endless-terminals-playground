# test_initial_state.py
"""
Tests to validate the initial state of the filesystem before the student
performs the task of fixing the merge_reports.py script.
"""

import json
import os
import subprocess
import pytest


HOME_DIR = "/home/user"
CAPACITY_DIR = os.path.join(HOME_DIR, "capacity")
DATA_DIR = os.path.join(CAPACITY_DIR, "data")
MERGE_SCRIPT = os.path.join(CAPACITY_DIR, "merge_reports.py")

QUARTERLY_FILES = ["q1_2024.json", "q2_2024.json", "q3_2024.json", "q4_2024.json"]

EXPECTED_MONTHS_PER_QUARTER = {
    "Q1": ["January", "February", "March"],
    "Q2": ["April", "May", "June"],
    "Q3": ["July", "August", "September"],
    "Q4": ["October", "November", "December"],
}


class TestDirectoryStructure:
    """Test that required directories exist."""

    def test_capacity_directory_exists(self):
        assert os.path.isdir(CAPACITY_DIR), (
            f"Directory {CAPACITY_DIR} does not exist. "
            "The capacity directory must be present."
        )

    def test_data_directory_exists(self):
        assert os.path.isdir(DATA_DIR), (
            f"Directory {DATA_DIR} does not exist. "
            "The data directory containing quarterly JSON files must be present."
        )

    def test_capacity_directory_is_writable(self):
        assert os.access(CAPACITY_DIR, os.W_OK), (
            f"Directory {CAPACITY_DIR} is not writable. "
            "The capacity directory must be writable to produce merged.csv."
        )


class TestMergeScript:
    """Test that the merge_reports.py script exists and has expected structure."""

    def test_merge_script_exists(self):
        assert os.path.isfile(MERGE_SCRIPT), (
            f"Script {MERGE_SCRIPT} does not exist. "
            "The merge_reports.py script must be present."
        )

    def test_merge_script_is_readable(self):
        assert os.access(MERGE_SCRIPT, os.R_OK), (
            f"Script {MERGE_SCRIPT} is not readable."
        )

    def test_merge_script_contains_normalize_units_function(self):
        with open(MERGE_SCRIPT, 'r') as f:
            content = f.read()
        assert "normalize_units" in content, (
            f"Script {MERGE_SCRIPT} does not contain 'normalize_units' function. "
            "The script should have this function as part of the buggy implementation."
        )

    def test_merge_script_contains_merge_quarterly_data_function(self):
        with open(MERGE_SCRIPT, 'r') as f:
            content = f.read()
        assert "merge_quarterly_data" in content, (
            f"Script {MERGE_SCRIPT} does not contain 'merge_quarterly_data' function. "
            "The script should have this function as part of the implementation."
        )

    def test_merge_script_is_valid_python(self):
        """Verify the script has valid Python syntax."""
        result = subprocess.run(
            ["python3", "-m", "py_compile", MERGE_SCRIPT],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"Script {MERGE_SCRIPT} has syntax errors: {result.stderr}"
        )


class TestQuarterlyJSONFiles:
    """Test that all quarterly JSON files exist and have correct structure."""

    def test_all_quarterly_files_exist(self):
        for filename in QUARTERLY_FILES:
            filepath = os.path.join(DATA_DIR, filename)
            assert os.path.isfile(filepath), (
                f"Quarterly file {filepath} does not exist. "
                f"All four quarterly JSON files must be present: {QUARTERLY_FILES}"
            )

    @pytest.mark.parametrize("filename", QUARTERLY_FILES)
    def test_quarterly_file_is_valid_json(self, filename):
        filepath = os.path.join(DATA_DIR, filename)
        with open(filepath, 'r') as f:
            try:
                data = json.load(f)
            except json.JSONDecodeError as e:
                pytest.fail(f"File {filepath} is not valid JSON: {e}")

    @pytest.mark.parametrize("filename", QUARTERLY_FILES)
    def test_quarterly_file_has_required_keys(self, filename):
        filepath = os.path.join(DATA_DIR, filename)
        with open(filepath, 'r') as f:
            data = json.load(f)

        assert "quarter" in data, (
            f"File {filepath} missing 'quarter' key"
        )
        assert "year" in data, (
            f"File {filepath} missing 'year' key"
        )
        assert "months" in data, (
            f"File {filepath} missing 'months' key"
        )

    @pytest.mark.parametrize("filename", QUARTERLY_FILES)
    def test_quarterly_file_has_three_months(self, filename):
        filepath = os.path.join(DATA_DIR, filename)
        with open(filepath, 'r') as f:
            data = json.load(f)

        assert len(data["months"]) == 3, (
            f"File {filepath} should have exactly 3 months, "
            f"but has {len(data['months'])}"
        )

    @pytest.mark.parametrize("filename", QUARTERLY_FILES)
    def test_quarterly_file_months_have_correct_structure(self, filename):
        filepath = os.path.join(DATA_DIR, filename)
        with open(filepath, 'r') as f:
            data = json.load(f)

        for i, month_data in enumerate(data["months"]):
            assert "month" in month_data, (
                f"File {filepath}, month entry {i} missing 'month' key"
            )
            assert "resources" in month_data, (
                f"File {filepath}, month entry {i} missing 'resources' key"
            )

            resources = month_data["resources"]
            assert "cpu_hours" in resources, (
                f"File {filepath}, month {month_data.get('month', i)} "
                "missing 'cpu_hours' in resources"
            )
            assert "mem_gb" in resources, (
                f"File {filepath}, month {month_data.get('month', i)} "
                "missing 'mem_gb' in resources"
            )
            assert "storage_tb" in resources, (
                f"File {filepath}, month {month_data.get('month', i)} "
                "missing 'storage_tb' in resources"
            )

    @pytest.mark.parametrize("filename", QUARTERLY_FILES)
    def test_quarterly_file_has_realistic_values(self, filename):
        """Verify capacity numbers are in realistic ranges."""
        filepath = os.path.join(DATA_DIR, filename)
        with open(filepath, 'r') as f:
            data = json.load(f)

        for month_data in data["months"]:
            month_name = month_data["month"]
            resources = month_data["resources"]

            cpu_hours = resources["cpu_hours"]
            assert 10000 <= cpu_hours <= 50000, (
                f"File {filepath}, month {month_name}: "
                f"cpu_hours={cpu_hours} outside expected range [10000, 50000]"
            )

            mem_gb = resources["mem_gb"]
            assert 500 <= mem_gb <= 2000, (
                f"File {filepath}, month {month_name}: "
                f"mem_gb={mem_gb} outside expected range [500, 2000]"
            )

            storage_tb = resources["storage_tb"]
            assert 50 <= storage_tb <= 200, (
                f"File {filepath}, month {month_name}: "
                f"storage_tb={storage_tb} outside expected range [50, 200]"
            )

    @pytest.mark.parametrize("filename", QUARTERLY_FILES)
    def test_quarterly_file_does_not_have_units_key(self, filename):
        """
        Verify that quarterly files do NOT have a 'units' key.
        This is part of the bug - the script incorrectly assumes legacy format
        when 'units' key is missing.
        """
        filepath = os.path.join(DATA_DIR, filename)
        with open(filepath, 'r') as f:
            data = json.load(f)

        assert "units" not in data, (
            f"File {filepath} has a 'units' key, but according to the bug description, "
            "the quarterly files should NOT have this key (which triggers the buggy "
            "unit conversion)."
        )

    def test_all_twelve_months_covered(self):
        """Verify that across all quarterly files, all 12 months are represented."""
        all_months = set()

        for filename in QUARTERLY_FILES:
            filepath = os.path.join(DATA_DIR, filename)
            with open(filepath, 'r') as f:
                data = json.load(f)

            for month_data in data["months"]:
                all_months.add(month_data["month"])

        expected_months = {
            "January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"
        }

        assert all_months == expected_months, (
            f"Expected all 12 months to be covered across quarterly files. "
            f"Missing: {expected_months - all_months}, "
            f"Extra: {all_months - expected_months}"
        )


class TestScriptExecution:
    """Test that the merge script runs and produces output (even if buggy)."""

    def test_script_runs_without_error(self):
        """Verify the script executes without crashing."""
        result = subprocess.run(
            ["python3", MERGE_SCRIPT],
            capture_output=True,
            text=True,
            cwd=CAPACITY_DIR
        )
        assert result.returncode == 0, (
            f"Script {MERGE_SCRIPT} failed to run. "
            f"Return code: {result.returncode}, "
            f"Stderr: {result.stderr}"
        )

    def test_script_produces_merged_csv(self):
        """Verify the script produces the merged.csv file."""
        merged_csv = os.path.join(CAPACITY_DIR, "merged.csv")

        # Remove if exists from previous run
        if os.path.exists(merged_csv):
            os.remove(merged_csv)

        subprocess.run(
            ["python3", MERGE_SCRIPT],
            capture_output=True,
            cwd=CAPACITY_DIR
        )

        assert os.path.isfile(merged_csv), (
            f"Script did not produce {merged_csv}. "
            "The merge script should create merged.csv when run."
        )

    def test_merged_csv_has_twelve_data_rows(self):
        """Verify merged.csv has 12 data rows (one per month)."""
        merged_csv = os.path.join(CAPACITY_DIR, "merged.csv")

        # Run script to generate fresh output
        subprocess.run(
            ["python3", MERGE_SCRIPT],
            capture_output=True,
            cwd=CAPACITY_DIR
        )

        with open(merged_csv, 'r') as f:
            lines = f.readlines()

        # Should have header + 12 data rows = 13 lines
        # Account for possible trailing newline
        non_empty_lines = [l for l in lines if l.strip()]

        assert len(non_empty_lines) == 13, (
            f"merged.csv should have 13 lines (1 header + 12 data rows), "
            f"but has {len(non_empty_lines)} non-empty lines"
        )

    def test_merged_csv_has_correct_columns(self):
        """Verify merged.csv has the expected column headers."""
        merged_csv = os.path.join(CAPACITY_DIR, "merged.csv")

        subprocess.run(
            ["python3", MERGE_SCRIPT],
            capture_output=True,
            cwd=CAPACITY_DIR
        )

        with open(merged_csv, 'r') as f:
            header = f.readline().strip()

        expected_columns = ["month", "cpu_hours", "mem_gb", "storage_tb"]
        actual_columns = [col.strip() for col in header.split(",")]

        assert actual_columns == expected_columns, (
            f"merged.csv should have columns {expected_columns}, "
            f"but has {actual_columns}"
        )


class TestPythonEnvironment:
    """Test that required Python packages are available."""

    def test_python3_available(self):
        result = subprocess.run(
            ["python3", "--version"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "Python 3 is not available"

    def test_pandas_installed(self):
        result = subprocess.run(
            ["python3", "-c", "import pandas"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "pandas is not installed. The merge script requires pandas."
        )
