# test_initial_state.py
"""
Tests to validate the initial state of the filesystem before the student
performs the ETL directory reorganization task.
"""

import os
import pytest

BASE_DIR = "/home/user/etl/incoming"

# Expected CSV files with date prefixes
EXPECTED_CSV_FILES = [
    "20240115_sales.csv",
    "20240115_inventory.csv",
    "20240115_returns.csv",
    "20240203_sales.csv",
    "20240203_inventory.csv",
    "20240203_returns.csv",
    "20240218_sales.csv",
    "20240218_inventory.csv",
    "20240301_sales.csv",
    "20240301_inventory.csv",
    "20240301_returns.csv",
    "20240301_shipments.csv",
]

# Expected non-CSV files that should be ignored
EXPECTED_NON_CSV_FILES = [
    "README.txt",
    ".DS_Store",
    "processing.log",
]

# Date prefixes that will become subdirectories (should NOT exist initially)
DATE_PREFIXES = ["20240115", "20240203", "20240218", "20240301"]


class TestBaseDirectoryExists:
    """Tests for the base incoming directory."""

    def test_incoming_directory_exists(self):
        """The /home/user/etl/incoming directory must exist."""
        assert os.path.exists(BASE_DIR), (
            f"Directory {BASE_DIR} does not exist. "
            "Please create the incoming directory structure."
        )

    def test_incoming_directory_is_directory(self):
        """The incoming path must be a directory, not a file."""
        assert os.path.isdir(BASE_DIR), (
            f"{BASE_DIR} exists but is not a directory."
        )

    def test_incoming_directory_is_writable(self):
        """The incoming directory must be writable."""
        assert os.access(BASE_DIR, os.W_OK), (
            f"Directory {BASE_DIR} is not writable. "
            "Please ensure proper permissions."
        )


class TestCSVFilesExist:
    """Tests for the expected CSV files in the incoming directory."""

    @pytest.mark.parametrize("csv_file", EXPECTED_CSV_FILES)
    def test_csv_file_exists(self, csv_file):
        """Each expected CSV file must exist in the incoming directory."""
        file_path = os.path.join(BASE_DIR, csv_file)
        assert os.path.exists(file_path), (
            f"CSV file {csv_file} does not exist in {BASE_DIR}. "
            f"Expected file at: {file_path}"
        )

    @pytest.mark.parametrize("csv_file", EXPECTED_CSV_FILES)
    def test_csv_file_is_regular_file(self, csv_file):
        """Each CSV must be a regular file, not a directory or symlink."""
        file_path = os.path.join(BASE_DIR, csv_file)
        if os.path.exists(file_path):
            assert os.path.isfile(file_path), (
                f"{csv_file} exists but is not a regular file."
            )

    @pytest.mark.parametrize("csv_file", EXPECTED_CSV_FILES)
    def test_csv_file_has_content(self, csv_file):
        """Each CSV file must have at least one line of content."""
        file_path = os.path.join(BASE_DIR, csv_file)
        if os.path.exists(file_path):
            with open(file_path, 'r') as f:
                content = f.read()
            assert len(content.strip()) > 0, (
                f"CSV file {csv_file} is empty. "
                "Each CSV should contain at least one line."
            )

    def test_correct_number_of_csv_files(self):
        """There should be exactly 12 CSV files in the incoming directory."""
        if os.path.isdir(BASE_DIR):
            csv_files = [f for f in os.listdir(BASE_DIR) 
                        if f.endswith('.csv') and os.path.isfile(os.path.join(BASE_DIR, f))]
            assert len(csv_files) == 12, (
                f"Expected 12 CSV files in {BASE_DIR}, found {len(csv_files)}: {csv_files}"
            )


class TestNonCSVFilesExist:
    """Tests for the non-CSV files that should be present and ignored."""

    @pytest.mark.parametrize("non_csv_file", EXPECTED_NON_CSV_FILES)
    def test_non_csv_file_exists(self, non_csv_file):
        """Each expected non-CSV file must exist in the incoming directory."""
        file_path = os.path.join(BASE_DIR, non_csv_file)
        assert os.path.exists(file_path), (
            f"Non-CSV file {non_csv_file} does not exist in {BASE_DIR}. "
            f"Expected file at: {file_path}"
        )

    @pytest.mark.parametrize("non_csv_file", EXPECTED_NON_CSV_FILES)
    def test_non_csv_file_is_regular_file(self, non_csv_file):
        """Each non-CSV file must be a regular file."""
        file_path = os.path.join(BASE_DIR, non_csv_file)
        if os.path.exists(file_path):
            assert os.path.isfile(file_path), (
                f"{non_csv_file} exists but is not a regular file."
            )


class TestNoSubdirectoriesExist:
    """Tests to ensure no date subdirectories exist initially."""

    @pytest.mark.parametrize("date_prefix", DATE_PREFIXES)
    def test_date_subdirectory_does_not_exist(self, date_prefix):
        """Date subdirectories should NOT exist before the task is performed."""
        subdir_path = os.path.join(BASE_DIR, date_prefix)
        assert not os.path.exists(subdir_path), (
            f"Subdirectory {subdir_path} already exists. "
            "The initial state should have no date subdirectories - "
            "all CSV files should be flat in the incoming directory."
        )

    def test_no_subdirectories_at_all(self):
        """There should be no subdirectories in the incoming directory initially."""
        if os.path.isdir(BASE_DIR):
            subdirs = [d for d in os.listdir(BASE_DIR) 
                      if os.path.isdir(os.path.join(BASE_DIR, d))]
            assert len(subdirs) == 0, (
                f"Found unexpected subdirectories in {BASE_DIR}: {subdirs}. "
                "The initial state should have all files flat in the incoming directory."
            )


class TestFileNamingConvention:
    """Tests to verify CSV files follow the expected naming convention."""

    @pytest.mark.parametrize("csv_file", EXPECTED_CSV_FILES)
    def test_csv_has_date_prefix(self, csv_file):
        """Each CSV file should have a valid date prefix (YYYYMMDD_)."""
        # Extract the prefix before the first underscore
        parts = csv_file.split('_')
        assert len(parts) >= 2, (
            f"CSV file {csv_file} does not follow the expected naming pattern "
            "(YYYYMMDD_name.csv)"
        )
        date_prefix = parts[0]
        assert len(date_prefix) == 8 and date_prefix.isdigit(), (
            f"CSV file {csv_file} has invalid date prefix '{date_prefix}'. "
            "Expected 8-digit date (YYYYMMDD)."
        )
