I need to reorganize the raw data drops in /home/user/etl/incoming — right now everything's flat, hundreds of csvs dumped together. Need them sorted into subdirectories by their date prefix. Files are named like `20240115_sales.csv`, `20240115_inventory.csv`, `20240203_sales.csv`, etc. So `20240115_sales.csv` should end up in `/home/user/etl/incoming/20240115/20240115_sales.csv`.

Just the csvs, ignore any other junk in there.
