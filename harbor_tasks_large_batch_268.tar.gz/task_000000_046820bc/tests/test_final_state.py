# test_final_state.py
"""
Tests to validate the final state of the filesystem after the student
has completed the ETL directory reorganization task.
"""

import os
import pytest

BASE_DIR = "/home/user/etl/incoming"

# Date subdirectories that should exist after reorganization
DATE_SUBDIRS = ["20240115", "20240203", "20240218", "20240301"]

# Expected CSV files in each subdirectory
EXPECTED_FILES_BY_DATE = {
    "20240115": [
        "20240115_sales.csv",
        "20240115_inventory.csv",
        "20240115_returns.csv",
    ],
    "20240203": [
        "20240203_sales.csv",
        "20240203_inventory.csv",
        "20240203_returns.csv",
    ],
    "20240218": [
        "20240218_sales.csv",
        "20240218_inventory.csv",
    ],
    "20240301": [
        "20240301_sales.csv",
        "20240301_inventory.csv",
        "20240301_returns.csv",
        "20240301_shipments.csv",
    ],
}

# Non-CSV files that should remain at the top level
NON_CSV_FILES = [
    "README.txt",
    ".DS_Store",
    "processing.log",
]

# All CSV files (for counting)
ALL_CSV_FILES = [
    "20240115_sales.csv",
    "20240115_inventory.csv",
    "20240115_returns.csv",
    "20240203_sales.csv",
    "20240203_inventory.csv",
    "20240203_returns.csv",
    "20240218_sales.csv",
    "20240218_inventory.csv",
    "20240301_sales.csv",
    "20240301_inventory.csv",
    "20240301_returns.csv",
    "20240301_shipments.csv",
]


class TestDateSubdirectoriesExist:
    """Tests for the existence of date subdirectories."""

    @pytest.mark.parametrize("date_subdir", DATE_SUBDIRS)
    def test_date_subdirectory_exists(self, date_subdir):
        """Each date subdirectory must exist after reorganization."""
        subdir_path = os.path.join(BASE_DIR, date_subdir)
        assert os.path.exists(subdir_path), (
            f"Date subdirectory {subdir_path} does not exist. "
            f"CSV files with prefix {date_subdir}_ should be moved into this directory."
        )

    @pytest.mark.parametrize("date_subdir", DATE_SUBDIRS)
    def test_date_subdirectory_is_directory(self, date_subdir):
        """Each date path must be a directory, not a file."""
        subdir_path = os.path.join(BASE_DIR, date_subdir)
        if os.path.exists(subdir_path):
            assert os.path.isdir(subdir_path), (
                f"{subdir_path} exists but is not a directory."
            )

    def test_exactly_four_date_subdirectories(self):
        """There should be exactly 4 date subdirectories."""
        if os.path.isdir(BASE_DIR):
            subdirs = [d for d in os.listdir(BASE_DIR)
                      if os.path.isdir(os.path.join(BASE_DIR, d))]
            assert len(subdirs) == 4, (
                f"Expected exactly 4 date subdirectories, found {len(subdirs)}: {subdirs}"
            )


class TestCSVFilesMovedToSubdirectories:
    """Tests for CSV files being in their correct subdirectories."""

    @pytest.mark.parametrize("date_subdir", DATE_SUBDIRS)
    def test_csv_files_in_date_subdirectory(self, date_subdir):
        """Each date subdirectory must contain its expected CSV files."""
        subdir_path = os.path.join(BASE_DIR, date_subdir)
        expected_files = EXPECTED_FILES_BY_DATE[date_subdir]

        for csv_file in expected_files:
            file_path = os.path.join(subdir_path, csv_file)
            assert os.path.exists(file_path), (
                f"CSV file {csv_file} not found in {subdir_path}. "
                f"Expected path: {file_path}"
            )
            assert os.path.isfile(file_path), (
                f"{file_path} exists but is not a regular file."
            )

    @pytest.mark.parametrize("date_subdir", DATE_SUBDIRS)
    def test_csv_files_have_content(self, date_subdir):
        """Each moved CSV file should still have content (not empty)."""
        subdir_path = os.path.join(BASE_DIR, date_subdir)
        expected_files = EXPECTED_FILES_BY_DATE[date_subdir]

        for csv_file in expected_files:
            file_path = os.path.join(subdir_path, csv_file)
            if os.path.exists(file_path):
                with open(file_path, 'r') as f:
                    content = f.read()
                assert len(content.strip()) > 0, (
                    f"CSV file {file_path} is empty. "
                    "File contents should be preserved after moving."
                )

    @pytest.mark.parametrize("date_subdir", DATE_SUBDIRS)
    def test_correct_file_count_in_subdirectory(self, date_subdir):
        """Each subdirectory should have the correct number of CSV files."""
        subdir_path = os.path.join(BASE_DIR, date_subdir)
        expected_count = len(EXPECTED_FILES_BY_DATE[date_subdir])

        if os.path.isdir(subdir_path):
            actual_files = [f for f in os.listdir(subdir_path)
                          if f.endswith('.csv') and os.path.isfile(os.path.join(subdir_path, f))]
            assert len(actual_files) == expected_count, (
                f"Expected {expected_count} CSV files in {subdir_path}, "
                f"found {len(actual_files)}: {actual_files}"
            )


class TestNoCSVsAtTopLevel:
    """Tests to ensure no CSV files remain at the top level."""

    def test_no_csv_files_at_top_level(self):
        """No CSV files should remain in the top-level incoming directory."""
        if os.path.isdir(BASE_DIR):
            top_level_csvs = [f for f in os.listdir(BASE_DIR)
                            if f.endswith('.csv') and os.path.isfile(os.path.join(BASE_DIR, f))]
            assert len(top_level_csvs) == 0, (
                f"Found {len(top_level_csvs)} CSV files still at top level in {BASE_DIR}: "
                f"{top_level_csvs}. All CSV files should be moved to date subdirectories."
            )

    @pytest.mark.parametrize("csv_file", ALL_CSV_FILES)
    def test_specific_csv_not_at_top_level(self, csv_file):
        """Each specific CSV file should NOT be at the top level."""
        file_path = os.path.join(BASE_DIR, csv_file)
        assert not os.path.exists(file_path), (
            f"CSV file {csv_file} still exists at top level ({file_path}). "
            f"It should have been moved to {BASE_DIR}/{csv_file.split('_')[0]}/{csv_file}"
        )


class TestNonCSVFilesUntouched:
    """Tests to ensure non-CSV files remain at the top level untouched."""

    @pytest.mark.parametrize("non_csv_file", NON_CSV_FILES)
    def test_non_csv_file_still_exists_at_top_level(self, non_csv_file):
        """Non-CSV files should remain at the top level."""
        file_path = os.path.join(BASE_DIR, non_csv_file)
        assert os.path.exists(file_path), (
            f"Non-CSV file {non_csv_file} is missing from {BASE_DIR}. "
            f"These files should remain untouched at the top level."
        )

    @pytest.mark.parametrize("non_csv_file", NON_CSV_FILES)
    def test_non_csv_file_is_regular_file(self, non_csv_file):
        """Non-CSV files should still be regular files."""
        file_path = os.path.join(BASE_DIR, non_csv_file)
        if os.path.exists(file_path):
            assert os.path.isfile(file_path), (
                f"{non_csv_file} at {file_path} is not a regular file."
            )


class TestAntiShortcutGuards:
    """Anti-shortcut tests to ensure proper task completion."""

    def test_total_csv_count_in_subdirs(self):
        """All 12 CSV files should be found in subdirectories."""
        csv_count = 0
        for date_subdir in DATE_SUBDIRS:
            subdir_path = os.path.join(BASE_DIR, date_subdir)
            if os.path.isdir(subdir_path):
                for f in os.listdir(subdir_path):
                    if f.endswith('.csv') and os.path.isfile(os.path.join(subdir_path, f)):
                        csv_count += 1

        assert csv_count == 12, (
            f"Expected 12 CSV files total in subdirectories, found {csv_count}. "
            "All CSV files should be moved to their respective date subdirectories."
        )

    def test_no_files_deleted(self):
        """Verify no files were deleted - total file count should be correct."""
        total_files = 0

        # Count files at top level (should be 3 non-CSV files)
        if os.path.isdir(BASE_DIR):
            for item in os.listdir(BASE_DIR):
                item_path = os.path.join(BASE_DIR, item)
                if os.path.isfile(item_path):
                    total_files += 1
                elif os.path.isdir(item_path):
                    # Count files in subdirectories
                    for subitem in os.listdir(item_path):
                        if os.path.isfile(os.path.join(item_path, subitem)):
                            total_files += 1

        # 12 CSV files + 3 non-CSV files = 15 total
        assert total_files == 15, (
            f"Expected 15 total files (12 CSVs + 3 non-CSVs), found {total_files}. "
            "No files should be deleted during reorganization."
        )

    def test_files_moved_not_copied(self):
        """
        Verify files were moved (not copied) by checking they don't exist
        in both locations.
        """
        for csv_file in ALL_CSV_FILES:
            top_level_path = os.path.join(BASE_DIR, csv_file)
            date_prefix = csv_file.split('_')[0]
            subdir_path = os.path.join(BASE_DIR, date_prefix, csv_file)

            # File should exist in subdir but NOT at top level
            if os.path.exists(subdir_path):
                assert not os.path.exists(top_level_path), (
                    f"File {csv_file} exists in both {BASE_DIR} and {BASE_DIR}/{date_prefix}/. "
                    "Files should be moved, not copied."
                )
