# test_final_state.py
"""
Tests to validate the final state of the OS/filesystem after the student
has fixed the pip install resolver issue.
"""

import os
import subprocess
import re
import time
import pytest


PROJECT_DIR = "/home/user/myservice"
REQUIREMENTS_FILE = "/home/user/myservice/requirements.txt"
CONSTRAINTS_FILE = "/home/user/myservice/constraints.txt"
VENV_DIR = "/home/user/myservice/.venv"
VENV_PIP = "/home/user/myservice/.venv/bin/pip"
VENV_PYTHON = "/home/user/myservice/.venv/bin/python"


def get_installed_version(package_name):
    """Get the installed version of a package in the venv."""
    result = subprocess.run(
        [VENV_PIP, "show", package_name],
        capture_output=True,
        text=True
    )
    if result.returncode != 0:
        return None
    for line in result.stdout.splitlines():
        if line.startswith("Version:"):
            return line.split(":", 1)[1].strip()
    return None


def parse_version(version_str):
    """Parse a version string into a tuple of integers for comparison."""
    if version_str is None:
        return None
    # Handle versions like "1.25.0", "14.0.1", etc.
    match = re.match(r'^(\d+)\.(\d+)(?:\.(\d+))?', version_str)
    if match:
        major = int(match.group(1))
        minor = int(match.group(2))
        patch = int(match.group(3)) if match.group(3) else 0
        return (major, minor, patch)
    return None


class TestPipConstraintEnvironmentUnchanged:
    """Test that PIP_CONSTRAINT environment variable is still set correctly."""

    def test_pip_constraint_env_var_is_set(self):
        pip_constraint = os.environ.get("PIP_CONSTRAINT")
        assert pip_constraint is not None, \
            "PIP_CONSTRAINT environment variable must remain set (CI pipeline requirement)"

    def test_pip_constraint_points_to_constraints_file(self):
        pip_constraint = os.environ.get("PIP_CONSTRAINT")
        assert pip_constraint == CONSTRAINTS_FILE, \
            f"PIP_CONSTRAINT must remain {CONSTRAINTS_FILE}, but is {pip_constraint}"


class TestConstraintsFileUnchanged:
    """Test that constraints.txt content is unchanged."""

    def test_constraints_file_exists(self):
        assert os.path.isfile(CONSTRAINTS_FILE), \
            f"Constraints file {CONSTRAINTS_FILE} must still exist"

    def test_constraints_contains_numpy_constraint(self):
        with open(CONSTRAINTS_FILE, 'r') as f:
            content = f.read()
        assert "numpy>=1.25.0" in content, \
            "constraints.txt must still contain numpy>=1.25.0 (security team constraint)"

    def test_constraints_contains_pyarrow_constraint(self):
        with open(CONSTRAINTS_FILE, 'r') as f:
            content = f.read()
        assert "pyarrow>=14.0.0" in content, \
            "constraints.txt must still contain pyarrow>=14.0.0 (security team constraint)"


class TestRequirementsFileStillHasPins:
    """Test that requirements.txt still exists and contains version pins."""

    def test_requirements_file_exists(self):
        assert os.path.isfile(REQUIREMENTS_FILE), \
            f"Requirements file {REQUIREMENTS_FILE} must still exist"

    def test_requirements_has_at_least_5_pinned_dependencies(self):
        with open(REQUIREMENTS_FILE, 'r') as f:
            content = f.read()

        # Count lines that match package==version pattern
        pin_pattern = re.compile(r'^[a-zA-Z0-9_-]+==\d+\.\d+', re.MULTILINE)
        pins = pin_pattern.findall(content)

        assert len(pins) >= 5, \
            f"requirements.txt must contain at least 5 pinned dependencies (package==version format), found {len(pins)}"

    def test_requirements_contains_version_pins(self):
        """Verify requirements.txt still uses version pinning, not unpinned package names."""
        with open(REQUIREMENTS_FILE, 'r') as f:
            content = f.read()

        # Check that there are == version pins
        assert "==" in content, \
            "requirements.txt must still contain version pins (== syntax) for reproducibility"


class TestAllPackagesInstalled:
    """Test that all required packages are installed in the venv."""

    def test_pandas_is_installed(self):
        version = get_installed_version("pandas")
        assert version is not None, \
            "pandas must be installed in the venv"

    def test_numpy_is_installed(self):
        version = get_installed_version("numpy")
        assert version is not None, \
            "numpy must be installed in the venv"

    def test_scipy_is_installed(self):
        version = get_installed_version("scipy")
        assert version is not None, \
            "scipy must be installed in the venv"

    def test_scikit_learn_is_installed(self):
        version = get_installed_version("scikit-learn")
        assert version is not None, \
            "scikit-learn must be installed in the venv"

    def test_requests_is_installed(self):
        version = get_installed_version("requests")
        assert version is not None, \
            "requests must be installed in the venv"

    def test_boto3_is_installed(self):
        version = get_installed_version("boto3")
        assert version is not None, \
            "boto3 must be installed in the venv"

    def test_pyarrow_is_installed(self):
        version = get_installed_version("pyarrow")
        assert version is not None, \
            "pyarrow must be installed in the venv"


class TestSecurityConstraintsSatisfied:
    """Test that installed versions satisfy the security constraints."""

    def test_numpy_version_satisfies_constraint(self):
        """numpy must be >= 1.25.0 as required by security constraints."""
        version = get_installed_version("numpy")
        assert version is not None, "numpy must be installed"

        parsed = parse_version(version)
        assert parsed is not None, f"Could not parse numpy version: {version}"

        # Must be >= 1.25.0
        min_version = (1, 25, 0)
        assert parsed >= min_version, \
            f"numpy version must be >= 1.25.0 (security constraint), but got {version}"

    def test_numpy_version_below_2(self):
        """numpy must be < 2.0.0 as required by security constraints."""
        version = get_installed_version("numpy")
        assert version is not None, "numpy must be installed"

        parsed = parse_version(version)
        assert parsed is not None, f"Could not parse numpy version: {version}"

        # Must be < 2.0.0
        max_version = (2, 0, 0)
        assert parsed < max_version, \
            f"numpy version must be < 2.0.0 (security constraint), but got {version}"

    def test_pyarrow_version_satisfies_constraint(self):
        """pyarrow must be >= 14.0.0 as required by security constraints."""
        version = get_installed_version("pyarrow")
        assert version is not None, "pyarrow must be installed"

        parsed = parse_version(version)
        assert parsed is not None, f"Could not parse pyarrow version: {version}"

        # Must be >= 14.0.0
        min_version = (14, 0, 0)
        assert parsed >= min_version, \
            f"pyarrow version must be >= 14.0.0 (security constraint), but got {version}"


class TestPipInstallWorksCleanly:
    """Test that pip install -r requirements.txt works cleanly and quickly."""

    def test_pip_install_succeeds(self):
        """Running pip install -r requirements.txt should succeed with exit code 0."""
        # Run pip install with the constraint file active
        env = os.environ.copy()
        env["PIP_CONSTRAINT"] = CONSTRAINTS_FILE

        result = subprocess.run(
            [VENV_PIP, "install", "-r", REQUIREMENTS_FILE],
            capture_output=True,
            text=True,
            cwd=PROJECT_DIR,
            env=env,
            timeout=120  # Allow up to 2 minutes for the test
        )

        assert result.returncode == 0, \
            f"pip install -r requirements.txt failed with exit code {result.returncode}.\n" \
            f"stdout: {result.stdout}\nstderr: {result.stderr}"

    def test_pip_install_completes_quickly(self):
        """Running pip install -r requirements.txt should complete in under 60 seconds."""
        env = os.environ.copy()
        env["PIP_CONSTRAINT"] = CONSTRAINTS_FILE

        start_time = time.time()
        result = subprocess.run(
            [VENV_PIP, "install", "-r", REQUIREMENTS_FILE],
            capture_output=True,
            text=True,
            cwd=PROJECT_DIR,
            env=env,
            timeout=120
        )
        elapsed_time = time.time() - start_time

        assert result.returncode == 0, \
            f"pip install failed: {result.stderr}"

        # Since packages are already installed, this should be very fast
        # But we check the 60 second requirement
        assert elapsed_time < 60, \
            f"pip install -r requirements.txt took {elapsed_time:.1f} seconds, " \
            f"should complete in under 60 seconds"


class TestPackagesImportable:
    """Test that installed packages can be imported."""

    def test_can_import_pandas(self):
        result = subprocess.run(
            [VENV_PYTHON, "-c", "import pandas; print(pandas.__version__)"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            f"Failed to import pandas: {result.stderr}"

    def test_can_import_numpy(self):
        result = subprocess.run(
            [VENV_PYTHON, "-c", "import numpy; print(numpy.__version__)"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            f"Failed to import numpy: {result.stderr}"

    def test_can_import_scipy(self):
        result = subprocess.run(
            [VENV_PYTHON, "-c", "import scipy; print(scipy.__version__)"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            f"Failed to import scipy: {result.stderr}"

    def test_can_import_sklearn(self):
        result = subprocess.run(
            [VENV_PYTHON, "-c", "import sklearn; print(sklearn.__version__)"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            f"Failed to import sklearn: {result.stderr}"

    def test_can_import_requests(self):
        result = subprocess.run(
            [VENV_PYTHON, "-c", "import requests; print(requests.__version__)"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            f"Failed to import requests: {result.stderr}"

    def test_can_import_boto3(self):
        result = subprocess.run(
            [VENV_PYTHON, "-c", "import boto3; print(boto3.__version__)"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            f"Failed to import boto3: {result.stderr}"

    def test_can_import_pyarrow(self):
        result = subprocess.run(
            [VENV_PYTHON, "-c", "import pyarrow; print(pyarrow.__version__)"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            f"Failed to import pyarrow: {result.stderr}"
