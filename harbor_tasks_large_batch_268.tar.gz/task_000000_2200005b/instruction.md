CI just started failing on one of our Python services — the `pip install -r requirements.txt` step in /home/user/myservice hangs for like 10 minutes and then errors out with some resolver backtracking garbage. Thing is, nobody touched requirements.txt in weeks, and it was installing fine yesterday. I diffed against the last green build's lockfile and they're identical.

Weird part: if I comment out `pandas` it installs instantly. But pandas has been in there forever at the same pin. Local installs work fine on my mac. Something about the CI environment specifically is choking on it now.

Need it installing cleanly again — under 60 seconds ideally, no resolver drama. Don't want to just nuke the version pins, we need reproducibility.
