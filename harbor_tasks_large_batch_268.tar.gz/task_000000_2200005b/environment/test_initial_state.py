# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the task of fixing the pip install resolver issue.
"""

import os
import subprocess
import pytest


HOME_DIR = "/home/user"
PROJECT_DIR = "/home/user/myservice"
REQUIREMENTS_FILE = "/home/user/myservice/requirements.txt"
CONSTRAINTS_FILE = "/home/user/myservice/constraints.txt"
VENV_DIR = "/home/user/myservice/.venv"


class TestProjectDirectoryExists:
    """Test that the project directory structure exists."""

    def test_home_directory_exists(self):
        assert os.path.isdir(HOME_DIR), f"Home directory {HOME_DIR} does not exist"

    def test_project_directory_exists(self):
        assert os.path.isdir(PROJECT_DIR), f"Project directory {PROJECT_DIR} does not exist"

    def test_project_directory_is_writable(self):
        assert os.access(PROJECT_DIR, os.W_OK), f"Project directory {PROJECT_DIR} is not writable"


class TestRequirementsFile:
    """Test that requirements.txt exists with expected content."""

    def test_requirements_file_exists(self):
        assert os.path.isfile(REQUIREMENTS_FILE), f"Requirements file {REQUIREMENTS_FILE} does not exist"

    def test_requirements_file_is_readable(self):
        assert os.access(REQUIREMENTS_FILE, os.R_OK), f"Requirements file {REQUIREMENTS_FILE} is not readable"

    def test_requirements_contains_numpy_pin(self):
        with open(REQUIREMENTS_FILE, 'r') as f:
            content = f.read()
        assert "numpy==1.24.3" in content, "requirements.txt should contain numpy==1.24.3"

    def test_requirements_contains_pandas_pin(self):
        with open(REQUIREMENTS_FILE, 'r') as f:
            content = f.read()
        assert "pandas==2.0.2" in content, "requirements.txt should contain pandas==2.0.2"

    def test_requirements_contains_scipy_pin(self):
        with open(REQUIREMENTS_FILE, 'r') as f:
            content = f.read()
        assert "scipy==1.10.1" in content, "requirements.txt should contain scipy==1.10.1"

    def test_requirements_contains_scikit_learn_pin(self):
        with open(REQUIREMENTS_FILE, 'r') as f:
            content = f.read()
        assert "scikit-learn==1.2.2" in content, "requirements.txt should contain scikit-learn==1.2.2"

    def test_requirements_contains_requests_pin(self):
        with open(REQUIREMENTS_FILE, 'r') as f:
            content = f.read()
        assert "requests==2.31.0" in content, "requirements.txt should contain requests==2.31.0"

    def test_requirements_contains_boto3_pin(self):
        with open(REQUIREMENTS_FILE, 'r') as f:
            content = f.read()
        assert "boto3==1.28.0" in content, "requirements.txt should contain boto3==1.28.0"

    def test_requirements_contains_pyarrow_pin(self):
        with open(REQUIREMENTS_FILE, 'r') as f:
            content = f.read()
        assert "pyarrow==12.0.0" in content, "requirements.txt should contain pyarrow==12.0.0"


class TestConstraintsFile:
    """Test that constraints.txt exists with expected content."""

    def test_constraints_file_exists(self):
        assert os.path.isfile(CONSTRAINTS_FILE), f"Constraints file {CONSTRAINTS_FILE} does not exist"

    def test_constraints_file_is_readable(self):
        assert os.access(CONSTRAINTS_FILE, os.R_OK), f"Constraints file {CONSTRAINTS_FILE} is not readable"

    def test_constraints_contains_numpy_constraint(self):
        with open(CONSTRAINTS_FILE, 'r') as f:
            content = f.read()
        assert "numpy>=1.25.0,<2.0.0" in content, "constraints.txt should contain numpy>=1.25.0,<2.0.0"

    def test_constraints_contains_pyarrow_constraint(self):
        with open(CONSTRAINTS_FILE, 'r') as f:
            content = f.read()
        assert "pyarrow>=14.0.0" in content, "constraints.txt should contain pyarrow>=14.0.0"

    def test_constraints_contains_security_comment(self):
        with open(CONSTRAINTS_FILE, 'r') as f:
            content = f.read()
        assert "CI security constraints" in content, "constraints.txt should contain CI security constraints comment"


class TestPipConstraintEnvironment:
    """Test that PIP_CONSTRAINT environment variable is set correctly."""

    def test_pip_constraint_env_var_is_set(self):
        pip_constraint = os.environ.get("PIP_CONSTRAINT")
        assert pip_constraint is not None, "PIP_CONSTRAINT environment variable is not set"

    def test_pip_constraint_points_to_constraints_file(self):
        pip_constraint = os.environ.get("PIP_CONSTRAINT")
        assert pip_constraint == CONSTRAINTS_FILE, \
            f"PIP_CONSTRAINT should be {CONSTRAINTS_FILE}, but is {pip_constraint}"


class TestVirtualEnvironment:
    """Test that the virtual environment exists."""

    def test_venv_directory_exists(self):
        assert os.path.isdir(VENV_DIR), f"Virtual environment directory {VENV_DIR} does not exist"

    def test_venv_bin_directory_exists(self):
        venv_bin = os.path.join(VENV_DIR, "bin")
        assert os.path.isdir(venv_bin), f"Virtual environment bin directory {venv_bin} does not exist"

    def test_venv_python_exists(self):
        venv_python = os.path.join(VENV_DIR, "bin", "python")
        assert os.path.isfile(venv_python), f"Virtual environment python {venv_python} does not exist"

    def test_venv_pip_exists(self):
        venv_pip = os.path.join(VENV_DIR, "bin", "pip")
        assert os.path.isfile(venv_pip), f"Virtual environment pip {venv_pip} does not exist"

    def test_venv_activate_exists(self):
        venv_activate = os.path.join(VENV_DIR, "bin", "activate")
        assert os.path.isfile(venv_activate), f"Virtual environment activate script {venv_activate} does not exist"


class TestPythonEnvironment:
    """Test that Python 3.10 and pip are available."""

    def test_python3_is_available(self):
        result = subprocess.run(["python3", "--version"], capture_output=True, text=True)
        assert result.returncode == 0, "python3 is not available"

    def test_python_version_is_3_10(self):
        result = subprocess.run(["python3", "--version"], capture_output=True, text=True)
        assert "3.10" in result.stdout or "3.10" in result.stderr, \
            f"Python version should be 3.10, got: {result.stdout}{result.stderr}"

    def test_pip_is_available(self):
        result = subprocess.run(["pip3", "--version"], capture_output=True, text=True)
        assert result.returncode == 0, "pip3 is not available"

    def test_pip_version_is_23_x(self):
        result = subprocess.run(["pip3", "--version"], capture_output=True, text=True)
        output = result.stdout + result.stderr
        # Check for pip 23.x
        assert "pip 23" in output or "pip 24" in output, \
            f"pip version should be 23.x or higher, got: {output}"


class TestVenvIsEmpty:
    """Test that the venv site-packages is essentially empty (no project packages installed)."""

    def test_pandas_not_installed_in_venv(self):
        venv_pip = os.path.join(VENV_DIR, "bin", "pip")
        result = subprocess.run([venv_pip, "show", "pandas"], capture_output=True, text=True)
        assert result.returncode != 0, "pandas should not be installed in venv yet"

    def test_numpy_not_installed_in_venv(self):
        venv_pip = os.path.join(VENV_DIR, "bin", "pip")
        result = subprocess.run([venv_pip, "show", "numpy"], capture_output=True, text=True)
        assert result.returncode != 0, "numpy should not be installed in venv yet"

    def test_scipy_not_installed_in_venv(self):
        venv_pip = os.path.join(VENV_DIR, "bin", "pip")
        result = subprocess.run([venv_pip, "show", "scipy"], capture_output=True, text=True)
        assert result.returncode != 0, "scipy should not be installed in venv yet"


class TestConflictExists:
    """Verify that the conflict between requirements.txt and constraints.txt exists."""

    def test_numpy_versions_conflict(self):
        """Verify numpy==1.24.3 in requirements conflicts with numpy>=1.25.0 in constraints."""
        with open(REQUIREMENTS_FILE, 'r') as f:
            req_content = f.read()
        with open(CONSTRAINTS_FILE, 'r') as f:
            const_content = f.read()

        # requirements pins 1.24.3
        assert "numpy==1.24.3" in req_content, "requirements.txt should pin numpy==1.24.3"
        # constraints requires >=1.25.0
        assert "numpy>=1.25.0" in const_content, "constraints.txt should require numpy>=1.25.0"
        # These are incompatible - 1.24.3 < 1.25.0

    def test_pyarrow_versions_conflict(self):
        """Verify pyarrow==12.0.0 in requirements conflicts with pyarrow>=14.0.0 in constraints."""
        with open(REQUIREMENTS_FILE, 'r') as f:
            req_content = f.read()
        with open(CONSTRAINTS_FILE, 'r') as f:
            const_content = f.read()

        # requirements pins 12.0.0
        assert "pyarrow==12.0.0" in req_content, "requirements.txt should pin pyarrow==12.0.0"
        # constraints requires >=14.0.0
        assert "pyarrow>=14.0.0" in const_content, "constraints.txt should require pyarrow>=14.0.0"
        # These are incompatible - 12.0.0 < 14.0.0
