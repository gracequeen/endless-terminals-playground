# test_final_state.py
"""
Tests to validate the final state of the system after the student has completed the task.
This verifies the reposync daemon is running correctly and will stay up.
"""

import os
import subprocess
import pytest
import time
import re

REPOSYNC_DIR = "/home/user/reposync"
SYNC_DAEMON = os.path.join(REPOSYNC_DIR, "sync_daemon.py")
RUN_SYNC_SH = os.path.join(REPOSYNC_DIR, "run_sync.sh")
CHECK_HEALTH_SH = os.path.join(REPOSYNC_DIR, "check_health.sh")
SYNC_PID = os.path.join(REPOSYNC_DIR, "sync.pid")
SYNC_LOCK = os.path.join(REPOSYNC_DIR, "sync.lock")
SYNC_LOG = os.path.join(REPOSYNC_DIR, "sync.log")
LAST_SYNC_TXT = os.path.join(REPOSYNC_DIR, "last_sync.txt")


class TestHealthCheckPasses:
    """Test that the health check passes."""

    def test_health_check_passes(self):
        """The check_health.sh script should return 0 (healthy state)."""
        result = subprocess.run(
            [CHECK_HEALTH_SH],
            capture_output=True,
            text=True,
            cwd=REPOSYNC_DIR
        )
        assert result.returncode == 0, (
            f"Health check should PASS after fix, but it returned {result.returncode}. "
            f"stdout: {result.stdout}, stderr: {result.stderr}"
        )


class TestSyncDaemonRunning:
    """Test that the sync daemon is running correctly."""

    def test_exactly_one_sync_daemon_process(self):
        """There should be exactly one running sync_daemon.py process."""
        result = subprocess.run(
            ["pgrep", "-f", "sync_daemon.py"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "sync_daemon.py should be running, but no process found"
        )
        pids = result.stdout.strip().split('\n')
        pids = [p for p in pids if p]  # Filter empty strings
        assert len(pids) == 1, (
            f"Expected exactly one sync_daemon.py process, but found {len(pids)}: {pids}"
        )

    def test_sync_pid_file_matches_running_process(self):
        """The PID in sync.pid must match the running sync_daemon.py process."""
        assert os.path.isfile(SYNC_PID), f"File {SYNC_PID} does not exist"

        with open(SYNC_PID, 'r') as f:
            pid_from_file = f.read().strip()

        assert pid_from_file.isdigit(), f"sync.pid should contain a numeric PID, got: {pid_from_file}"
        pid_from_file = int(pid_from_file)

        # Get the actual running sync_daemon.py PID
        result = subprocess.run(
            ["pgrep", "-f", "sync_daemon.py"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "sync_daemon.py should be running"

        running_pids = [int(p) for p in result.stdout.strip().split('\n') if p]
        assert pid_from_file in running_pids, (
            f"PID in sync.pid ({pid_from_file}) does not match running process(es): {running_pids}"
        )

    def test_running_process_is_python3(self):
        """The running sync_daemon.py process should be a python3 process."""
        with open(SYNC_PID, 'r') as f:
            pid = f.read().strip()

        # Check the process command
        result = subprocess.run(
            ["ps", "-p", pid, "-o", "comm="],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, f"Process {pid} is not running"

        comm = result.stdout.strip().lower()
        assert "python" in comm, (
            f"Process {pid} should be a python process, but comm is: {comm}"
        )


class TestLastSyncRecent:
    """Test that last_sync.txt is recently modified."""

    def test_last_sync_is_recent(self):
        """last_sync.txt should be modified within the last 120 seconds."""
        assert os.path.isfile(LAST_SYNC_TXT), f"File {LAST_SYNC_TXT} does not exist"

        mtime = os.path.getmtime(LAST_SYNC_TXT)
        current_time = time.time()
        age = current_time - mtime

        assert age <= 120, (
            f"last_sync.txt should be recent (<=120 seconds old), but it's {age:.1f} seconds old. "
            "The daemon may not be running or syncing properly."
        )


class TestFileDescriptorLimit:
    """Test that the daemon has adequate file descriptor limits."""

    def test_daemon_fd_limit_adequate(self):
        """The running daemon's file descriptor soft limit must be >= 32."""
        assert os.path.isfile(SYNC_PID), f"File {SYNC_PID} does not exist"

        with open(SYNC_PID, 'r') as f:
            pid = f.read().strip()

        limits_path = f"/proc/{pid}/limits"
        assert os.path.isfile(limits_path), f"Cannot read limits for PID {pid}"

        with open(limits_path, 'r') as f:
            limits_content = f.read()

        # Parse the "Max open files" line
        # Format: "Max open files            1024                 1048576              files"
        for line in limits_content.split('\n'):
            if "open files" in line.lower():
                parts = line.split()
                # Find numeric values - soft limit comes after "files" description
                # The format is: "Max open files" <soft> <hard> "files"
                numbers = [p for p in parts if p.isdigit()]
                if numbers:
                    soft_limit = int(numbers[0])
                    assert soft_limit >= 32, (
                        f"Daemon's soft file descriptor limit is {soft_limit}, but must be >= 32. "
                        f"The ulimit bug in run_sync.sh may not be fixed."
                    )
                    return

        pytest.fail(f"Could not find 'open files' limit in /proc/{pid}/limits")


class TestSyncLogPreserved:
    """Test that sync.log still exists with historical entries."""

    def test_sync_log_exists(self):
        """The sync.log file must still exist."""
        assert os.path.isfile(SYNC_LOG), f"File {SYNC_LOG} does not exist - it should be preserved"

    def test_sync_log_has_historical_content(self):
        """The sync.log should still contain historical entries."""
        with open(SYNC_LOG, 'r') as f:
            content = f.read()

        assert len(content) > 0, "sync.log should not be empty"

        # Check for historical error that was present
        # The log should contain either the old error or evidence of past runs
        has_history = (
            "Too many open files" in content or
            "ERROR" in content or
            "Sync cycle complete" in content or
            "Sync daemon started" in content
        )
        assert has_history, (
            "sync.log should contain historical entries from before the fix. "
            "The log file should not have been deleted/cleared."
        )


class TestSyncDaemonSourceUnmodified:
    """Test that sync_daemon.py was not modified (invariant)."""

    def test_sync_daemon_still_uses_fcntl(self):
        """sync_daemon.py should still use fcntl for locking (not modified)."""
        with open(SYNC_DAEMON, 'r') as f:
            content = f.read()
        assert "fcntl" in content, (
            "sync_daemon.py should still use fcntl - the daemon source should not be modified"
        )

    def test_sync_daemon_still_writes_pid(self):
        """sync_daemon.py should still handle PID file (not modified)."""
        with open(SYNC_DAEMON, 'r') as f:
            content = f.read()
        assert "sync.pid" in content or ".pid" in content, (
            "sync_daemon.py should still handle PID file - the daemon source should not be modified"
        )


class TestWrapperScriptExists:
    """Test that run_sync.sh still exists (ops expects to use it)."""

    def test_run_sync_sh_exists(self):
        """The run_sync.sh wrapper script must still exist."""
        assert os.path.isfile(RUN_SYNC_SH), (
            f"File {RUN_SYNC_SH} does not exist - ops expects to use this wrapper script"
        )

    def test_run_sync_sh_is_executable(self):
        """The run_sync.sh script must be executable."""
        assert os.access(RUN_SYNC_SH, os.X_OK), (
            f"File {RUN_SYNC_SH} is not executable"
        )


class TestDaemonStability:
    """Test that the daemon stays up through multiple cycles."""

    def test_daemon_survives_90_seconds(self):
        """
        The daemon must stay running for 90+ seconds (multiple sync cycles).
        This proves it's not just starting and crashing due to fd limits.
        """
        # Get initial PID
        assert os.path.isfile(SYNC_PID), f"File {SYNC_PID} does not exist"
        with open(SYNC_PID, 'r') as f:
            initial_pid = f.read().strip()

        # Verify process is running
        result = subprocess.run(
            ["ps", "-p", initial_pid, "-o", "pid="],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, f"Process {initial_pid} is not running at start of stability test"

        # Wait 90 seconds
        time.sleep(90)

        # Check process is still running with same PID
        result = subprocess.run(
            ["ps", "-p", initial_pid, "-o", "pid="],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"Process {initial_pid} died during 90-second stability test. "
            "The daemon is not staying up - likely still hitting file descriptor limits."
        )

        # Verify PID file still has same PID
        with open(SYNC_PID, 'r') as f:
            current_pid = f.read().strip()
        assert current_pid == initial_pid, (
            f"PID changed from {initial_pid} to {current_pid} during stability test. "
            "The daemon restarted, which means it crashed."
        )

        # Run health check again after waiting
        result = subprocess.run(
            [CHECK_HEALTH_SH],
            capture_output=True,
            text=True,
            cwd=REPOSYNC_DIR
        )
        assert result.returncode == 0, (
            f"Health check failed after 90-second wait. "
            f"stdout: {result.stdout}, stderr: {result.stderr}"
        )

    def test_last_sync_updated_during_wait(self):
        """Verify that last_sync.txt was updated during the stability test."""
        # After the 90-second wait in the previous test, last_sync should be very recent
        mtime = os.path.getmtime(LAST_SYNC_TXT)
        current_time = time.time()
        age = current_time - mtime

        # Should have been updated within the last 60 seconds at most
        # (daemon syncs every 30 seconds per the accelerated test config)
        assert age <= 60, (
            f"last_sync.txt is {age:.1f} seconds old after stability test. "
            "The daemon should have updated it during the 90-second wait period."
        )
