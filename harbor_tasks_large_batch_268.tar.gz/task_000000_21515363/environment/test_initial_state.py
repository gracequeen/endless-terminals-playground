# test_initial_state.py
"""
Tests to validate the initial state of the system before the student performs the task.
This verifies the broken reposync daemon scenario is properly set up.
"""

import os
import subprocess
import pytest
import time
import stat

REPOSYNC_DIR = "/home/user/reposync"
SYNC_DAEMON = os.path.join(REPOSYNC_DIR, "sync_daemon.py")
RUN_SYNC_SH = os.path.join(REPOSYNC_DIR, "run_sync.sh")
CHECK_HEALTH_SH = os.path.join(REPOSYNC_DIR, "check_health.sh")
SYNC_PID = os.path.join(REPOSYNC_DIR, "sync.pid")
SYNC_LOCK = os.path.join(REPOSYNC_DIR, "sync.lock")
SYNC_LOG = os.path.join(REPOSYNC_DIR, "sync.log")
LAST_SYNC_TXT = os.path.join(REPOSYNC_DIR, "last_sync.txt")


class TestDirectoryStructure:
    """Test that the reposync directory and required files exist."""

    def test_reposync_directory_exists(self):
        """The /home/user/reposync directory must exist."""
        assert os.path.isdir(REPOSYNC_DIR), f"Directory {REPOSYNC_DIR} does not exist"

    def test_sync_daemon_py_exists(self):
        """The sync_daemon.py script must exist."""
        assert os.path.isfile(SYNC_DAEMON), f"File {SYNC_DAEMON} does not exist"

    def test_run_sync_sh_exists(self):
        """The run_sync.sh wrapper script must exist."""
        assert os.path.isfile(RUN_SYNC_SH), f"File {RUN_SYNC_SH} does not exist"

    def test_check_health_sh_exists(self):
        """The check_health.sh script must exist."""
        assert os.path.isfile(CHECK_HEALTH_SH), f"File {CHECK_HEALTH_SH} does not exist"

    def test_sync_pid_exists(self):
        """The sync.pid file must exist (with stale PID)."""
        assert os.path.isfile(SYNC_PID), f"File {SYNC_PID} does not exist"

    def test_sync_lock_exists(self):
        """The sync.lock file must exist."""
        assert os.path.isfile(SYNC_LOCK), f"File {SYNC_LOCK} does not exist"

    def test_sync_log_exists(self):
        """The sync.log file must exist."""
        assert os.path.isfile(SYNC_LOG), f"File {SYNC_LOG} does not exist"

    def test_last_sync_txt_exists(self):
        """The last_sync.txt file must exist."""
        assert os.path.isfile(LAST_SYNC_TXT), f"File {LAST_SYNC_TXT} does not exist"


class TestFilePermissions:
    """Test that files are writable by the agent."""

    def test_reposync_dir_writable(self):
        """The reposync directory must be writable."""
        assert os.access(REPOSYNC_DIR, os.W_OK), f"Directory {REPOSYNC_DIR} is not writable"

    def test_run_sync_sh_writable(self):
        """The run_sync.sh script must be writable (for fixing)."""
        assert os.access(RUN_SYNC_SH, os.W_OK), f"File {RUN_SYNC_SH} is not writable"

    def test_sync_pid_writable(self):
        """The sync.pid file must be writable."""
        assert os.access(SYNC_PID, os.W_OK), f"File {SYNC_PID} is not writable"

    def test_sync_lock_writable(self):
        """The sync.lock file must be writable."""
        assert os.access(SYNC_LOCK, os.W_OK), f"File {SYNC_LOCK} is not writable"

    def test_scripts_are_executable(self):
        """The shell scripts must be executable."""
        assert os.access(RUN_SYNC_SH, os.X_OK), f"File {RUN_SYNC_SH} is not executable"
        assert os.access(CHECK_HEALTH_SH, os.X_OK), f"File {CHECK_HEALTH_SH} is not executable"


class TestStalePidState:
    """Test that the PID file contains a stale (non-existent) PID."""

    def test_sync_pid_contains_number(self):
        """The sync.pid file must contain a PID number."""
        with open(SYNC_PID, 'r') as f:
            content = f.read().strip()
        assert content.isdigit(), f"sync.pid should contain a numeric PID, got: {content}"

    def test_pid_process_not_running(self):
        """The PID in sync.pid must NOT correspond to a running process."""
        with open(SYNC_PID, 'r') as f:
            pid = int(f.read().strip())

        # Check if process exists
        try:
            os.kill(pid, 0)
            # If we get here, process exists - this is wrong for initial state
            pytest.fail(f"Process {pid} from sync.pid should NOT be running, but it exists")
        except ProcessLookupError:
            # This is expected - process doesn't exist
            pass
        except PermissionError:
            # Process exists but we can't signal it - also wrong
            pytest.fail(f"Process {pid} from sync.pid appears to exist (permission denied)")


class TestSyncDaemonNotRunning:
    """Test that no sync_daemon.py process is currently running."""

    def test_no_sync_daemon_process(self):
        """There should be no running sync_daemon.py process."""
        result = subprocess.run(
            ["pgrep", "-f", "sync_daemon.py"],
            capture_output=True,
            text=True
        )
        # pgrep returns 0 if processes found, 1 if none found
        assert result.returncode != 0, (
            f"sync_daemon.py should NOT be running, but found process(es): {result.stdout.strip()}"
        )


class TestHealthCheckFails:
    """Test that the health check currently fails."""

    def test_health_check_fails(self):
        """The check_health.sh script should return non-zero (unhealthy state)."""
        result = subprocess.run(
            [CHECK_HEALTH_SH],
            capture_output=True,
            text=True,
            cwd=REPOSYNC_DIR
        )
        assert result.returncode != 0, (
            f"Health check should FAIL in initial state, but it returned 0. "
            f"stdout: {result.stdout}, stderr: {result.stderr}"
        )


class TestSyncLogContent:
    """Test that sync.log contains expected historical entries."""

    def test_sync_log_has_content(self):
        """The sync.log file should have historical log entries."""
        with open(SYNC_LOG, 'r') as f:
            content = f.read()
        assert len(content) > 0, "sync.log should not be empty"

    def test_sync_log_shows_error(self):
        """The sync.log should contain the 'Too many open files' error."""
        with open(SYNC_LOG, 'r') as f:
            content = f.read()
        assert "Too many open files" in content or "ERROR" in content, (
            "sync.log should contain error indicating the daemon crashed due to file descriptor issues"
        )

    def test_sync_log_shows_daemon_started(self):
        """The sync.log should show the daemon was started previously."""
        with open(SYNC_LOG, 'r') as f:
            content = f.read()
        assert "started" in content.lower() or "Sync daemon" in content, (
            "sync.log should contain entries showing the daemon was running"
        )


class TestRunSyncShContent:
    """Test that run_sync.sh has the problematic ulimit setting."""

    def test_run_sync_has_ulimit(self):
        """The run_sync.sh should contain the problematic ulimit setting."""
        with open(RUN_SYNC_SH, 'r') as f:
            content = f.read()
        # Check for ulimit with a low value
        assert "ulimit" in content, (
            "run_sync.sh should contain a ulimit command (this is the bug to fix)"
        )


class TestRequiredTools:
    """Test that required system tools are available."""

    def test_python3_available(self):
        """Python 3 must be available."""
        result = subprocess.run(
            ["python3", "--version"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "python3 is not available"

    def test_fuser_available(self):
        """fuser command must be available."""
        result = subprocess.run(
            ["which", "fuser"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "fuser is not installed"

    def test_lsof_available(self):
        """lsof command must be available."""
        result = subprocess.run(
            ["which", "lsof"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "lsof is not installed"

    def test_ps_available(self):
        """ps command must be available."""
        result = subprocess.run(
            ["which", "ps"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "ps is not available"

    def test_kill_available(self):
        """kill command must be available."""
        result = subprocess.run(
            ["which", "kill"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "kill is not available"


class TestSyncDaemonScript:
    """Test that sync_daemon.py is a valid Python script."""

    def test_sync_daemon_is_python(self):
        """sync_daemon.py should be a valid Python file."""
        with open(SYNC_DAEMON, 'r') as f:
            content = f.read()
        # Basic check that it looks like Python
        assert "import" in content or "def " in content or "class " in content, (
            "sync_daemon.py doesn't appear to be a Python script"
        )

    def test_sync_daemon_uses_fcntl(self):
        """sync_daemon.py should use fcntl for locking."""
        with open(SYNC_DAEMON, 'r') as f:
            content = f.read()
        assert "fcntl" in content, (
            "sync_daemon.py should use fcntl for file locking"
        )

    def test_sync_daemon_writes_pid(self):
        """sync_daemon.py should write to sync.pid."""
        with open(SYNC_DAEMON, 'r') as f:
            content = f.read()
        assert "sync.pid" in content or "pid" in content.lower(), (
            "sync_daemon.py should handle PID file"
        )


class TestLastSyncStale:
    """Test that last_sync.txt is stale (not recently modified)."""

    def test_last_sync_is_stale(self):
        """last_sync.txt should be stale (modified more than 120 seconds ago)."""
        mtime = os.path.getmtime(LAST_SYNC_TXT)
        current_time = time.time()
        age = current_time - mtime

        assert age > 120, (
            f"last_sync.txt should be stale (>120 seconds old), but it's only {age:.1f} seconds old. "
            "This suggests the daemon might still be running or was recently active."
        )
