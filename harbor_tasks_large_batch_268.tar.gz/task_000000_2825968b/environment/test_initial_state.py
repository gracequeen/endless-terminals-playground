# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the task of fixing the security scan workflow.
"""

import os
import stat
import subprocess
import json
import pytest


SCANNER_DIR = "/home/user/scanner"
SCRIPT_PATH = "/home/user/scanner/run_scan.sh"
CONFIG_PATH = "/home/user/scanner/targets.yaml"
VULNSCAN_PATH = "/home/user/scanner/bin/vulnscan"
RESULTS_DIR = "/home/user/scanner/results"


class TestDirectoryStructure:
    """Test that the required directory structure exists."""

    def test_scanner_directory_exists(self):
        """The scanner directory must exist."""
        assert os.path.isdir(SCANNER_DIR), \
            f"Scanner directory {SCANNER_DIR} does not exist"

    def test_scanner_bin_directory_exists(self):
        """The bin directory for vulnscan must exist."""
        bin_dir = os.path.join(SCANNER_DIR, "bin")
        assert os.path.isdir(bin_dir), \
            f"Binary directory {bin_dir} does not exist"

    def test_results_directory_exists(self):
        """The results directory must exist."""
        assert os.path.isdir(RESULTS_DIR), \
            f"Results directory {RESULTS_DIR} does not exist"

    def test_results_directory_is_writable(self):
        """The results directory must be writable."""
        assert os.access(RESULTS_DIR, os.W_OK), \
            f"Results directory {RESULTS_DIR} is not writable"

    def test_results_directory_is_empty(self):
        """The results directory should be empty initially."""
        contents = os.listdir(RESULTS_DIR)
        assert len(contents) == 0, \
            f"Results directory {RESULTS_DIR} should be empty but contains: {contents}"


class TestRunScanScript:
    """Test the run_scan.sh script exists and has expected properties."""

    def test_script_exists(self):
        """The run_scan.sh script must exist."""
        assert os.path.isfile(SCRIPT_PATH), \
            f"Script {SCRIPT_PATH} does not exist"

    def test_script_is_executable(self):
        """The run_scan.sh script must be executable."""
        assert os.access(SCRIPT_PATH, os.X_OK), \
            f"Script {SCRIPT_PATH} is not executable"

    def test_script_is_bash_script(self):
        """The script should be a bash script."""
        with open(SCRIPT_PATH, 'r') as f:
            first_line = f.readline()
        assert first_line.strip().startswith('#!') and 'bash' in first_line, \
            f"Script {SCRIPT_PATH} does not appear to be a bash script. First line: {first_line}"

    def test_script_has_set_e(self):
        """The script should have 'set -e' for error handling."""
        with open(SCRIPT_PATH, 'r') as f:
            content = f.read()
        assert 'set -e' in content, \
            f"Script {SCRIPT_PATH} should contain 'set -e'"

    def test_script_references_config(self):
        """The script should reference the targets.yaml config."""
        with open(SCRIPT_PATH, 'r') as f:
            content = f.read()
        assert 'targets.yaml' in content or 'CONFIG' in content, \
            f"Script {SCRIPT_PATH} should reference the config file"

    def test_script_has_stderr_redirect(self):
        """The script should have stderr redirect to /dev/null on python line."""
        with open(SCRIPT_PATH, 'r') as f:
            content = f.read()
        assert '2>/dev/null' in content, \
            f"Script {SCRIPT_PATH} should contain stderr redirect '2>/dev/null'"

    def test_script_has_buggy_targets_key(self):
        """The script should have the bug - referencing 'targets' instead of 'endpoints'."""
        with open(SCRIPT_PATH, 'r') as f:
            content = f.read()
        # The bug is that it uses data['targets'] when it should be data['endpoints']
        assert "data['targets']" in content or 'data["targets"]' in content, \
            f"Script {SCRIPT_PATH} should contain the buggy reference to data['targets']"

    def test_script_calls_vulnscan(self):
        """The script should call the vulnscan binary."""
        with open(SCRIPT_PATH, 'r') as f:
            content = f.read()
        assert 'vulnscan' in content, \
            f"Script {SCRIPT_PATH} should reference vulnscan"


class TestTargetsYaml:
    """Test the targets.yaml configuration file."""

    def test_config_exists(self):
        """The targets.yaml config must exist."""
        assert os.path.isfile(CONFIG_PATH), \
            f"Config file {CONFIG_PATH} does not exist"

    def test_config_is_valid_yaml(self):
        """The config file must be valid YAML."""
        try:
            import yaml
            with open(CONFIG_PATH, 'r') as f:
                data = yaml.safe_load(f)
            assert data is not None, "YAML file is empty or invalid"
        except ImportError:
            pytest.skip("PyYAML not installed, skipping YAML validation")
        except yaml.YAMLError as e:
            pytest.fail(f"Config file {CONFIG_PATH} is not valid YAML: {e}")

    def test_config_has_endpoints_key(self):
        """The config should have 'endpoints' key (not 'targets')."""
        try:
            import yaml
            with open(CONFIG_PATH, 'r') as f:
                data = yaml.safe_load(f)
            assert 'endpoints' in data, \
                f"Config file {CONFIG_PATH} should have 'endpoints' key"
        except ImportError:
            # Fallback to checking raw content
            with open(CONFIG_PATH, 'r') as f:
                content = f.read()
            assert 'endpoints:' in content, \
                f"Config file {CONFIG_PATH} should have 'endpoints' key"

    def test_config_does_not_have_targets_key(self):
        """The config should NOT have 'targets' key at root level."""
        try:
            import yaml
            with open(CONFIG_PATH, 'r') as f:
                data = yaml.safe_load(f)
            assert 'targets' not in data, \
                f"Config file {CONFIG_PATH} should NOT have 'targets' key (it should be 'endpoints')"
        except ImportError:
            pytest.skip("PyYAML not installed")

    def test_config_has_three_endpoints(self):
        """The config should have exactly 3 endpoints."""
        try:
            import yaml
            with open(CONFIG_PATH, 'r') as f:
                data = yaml.safe_load(f)
            endpoints = data.get('endpoints', [])
            assert len(endpoints) == 3, \
                f"Config should have 3 endpoints, found {len(endpoints)}"
        except ImportError:
            pytest.skip("PyYAML not installed")

    def test_config_endpoints_have_required_fields(self):
        """Each endpoint should have host, port, and checks fields."""
        try:
            import yaml
            with open(CONFIG_PATH, 'r') as f:
                data = yaml.safe_load(f)
            endpoints = data.get('endpoints', [])
            for i, endpoint in enumerate(endpoints):
                assert 'host' in endpoint, f"Endpoint {i} missing 'host' field"
                assert 'port' in endpoint, f"Endpoint {i} missing 'port' field"
                assert 'checks' in endpoint, f"Endpoint {i} missing 'checks' field"
        except ImportError:
            pytest.skip("PyYAML not installed")


class TestVulnscanBinary:
    """Test the vulnscan binary."""

    def test_vulnscan_exists(self):
        """The vulnscan binary must exist."""
        assert os.path.isfile(VULNSCAN_PATH), \
            f"Vulnscan binary {VULNSCAN_PATH} does not exist"

    def test_vulnscan_is_executable(self):
        """The vulnscan binary must be executable."""
        assert os.access(VULNSCAN_PATH, os.X_OK), \
            f"Vulnscan binary {VULNSCAN_PATH} is not executable"

    def test_vulnscan_produces_json_output(self):
        """The vulnscan binary should produce JSON output when called."""
        result = subprocess.run(
            [VULNSCAN_PATH, "--host", "127.0.0.1", "--port", "80", "--checks", "xss"],
            capture_output=True,
            text=True,
            timeout=10
        )
        # It should produce some output
        assert result.stdout.strip(), \
            f"Vulnscan should produce output but got nothing"
        # Output should be valid JSON
        try:
            output = json.loads(result.stdout)
            assert isinstance(output, dict), "Vulnscan output should be a JSON object"
        except json.JSONDecodeError as e:
            pytest.fail(f"Vulnscan output is not valid JSON: {e}")


class TestPythonEnvironment:
    """Test that Python environment is properly set up."""

    def test_python3_available(self):
        """Python 3 must be available."""
        result = subprocess.run(
            ["python3", "--version"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "python3 is not available"

    def test_pyyaml_installed(self):
        """PyYAML must be installed."""
        result = subprocess.run(
            ["python3", "-c", "import yaml; print(yaml.__version__)"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            f"PyYAML is not installed: {result.stderr}"


class TestScriptBehavior:
    """Test that the script exhibits the buggy behavior described."""

    def test_script_fails_silently(self):
        """Running the script should fail silently (no output, no error message)."""
        result = subprocess.run(
            ["bash", SCRIPT_PATH],
            capture_output=True,
            text=True,
            cwd=SCANNER_DIR,
            timeout=30
        )
        # With set -e and stderr redirected, script should exit non-zero silently
        # or exit quickly without producing output file
        # Check that no results file was created
        results_files = [f for f in os.listdir(RESULTS_DIR) if f.startswith('scan_') and f.endswith('.json')]
        assert len(results_files) == 0, \
            f"Script should not produce output file in buggy state, but found: {results_files}"

    def test_python_parsing_fails_with_wrong_key(self):
        """Demonstrate the bug: parsing with 'targets' key fails."""
        result = subprocess.run(
            ["python3", "-c", 
             f"import yaml; data=yaml.safe_load(open('{CONFIG_PATH}')); print(data['targets'])"],
            capture_output=True,
            text=True
        )
        assert result.returncode != 0, \
            "Python parsing with 'targets' key should fail (KeyError)"
        assert 'KeyError' in result.stderr or 'targets' in result.stderr, \
            f"Expected KeyError for 'targets' key, got: {result.stderr}"

    def test_python_parsing_succeeds_with_endpoints_key(self):
        """The correct key 'endpoints' should work."""
        result = subprocess.run(
            ["python3", "-c", 
             f"import yaml; data=yaml.safe_load(open('{CONFIG_PATH}')); print(data['endpoints'])"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            f"Python parsing with 'endpoints' key should succeed: {result.stderr}"
