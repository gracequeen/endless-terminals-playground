# test_final_state.py
"""
Tests to validate the final state of the OS/filesystem after the student
has fixed the security scan workflow.
"""

import os
import subprocess
import json
import glob
import pytest


SCANNER_DIR = "/home/user/scanner"
SCRIPT_PATH = "/home/user/scanner/run_scan.sh"
CONFIG_PATH = "/home/user/scanner/targets.yaml"
VULNSCAN_PATH = "/home/user/scanner/bin/vulnscan"
RESULTS_DIR = "/home/user/scanner/results"


class TestScriptExecutesSuccessfully:
    """Test that the run_scan.sh script now executes successfully."""

    def test_script_exits_zero(self):
        """Running the script should exit with code 0."""
        # Clean up any existing results first to ensure fresh run
        existing_results = glob.glob(os.path.join(RESULTS_DIR, "scan_*.json"))
        for f in existing_results:
            os.remove(f)

        result = subprocess.run(
            ["bash", SCRIPT_PATH],
            capture_output=True,
            text=True,
            cwd=SCANNER_DIR,
            timeout=60
        )
        assert result.returncode == 0, \
            f"Script should exit with code 0, but got {result.returncode}. " \
            f"stdout: {result.stdout}, stderr: {result.stderr}"


class TestResultsFileGenerated:
    """Test that the results file is properly generated."""

    @pytest.fixture(autouse=True)
    def run_script_once(self):
        """Ensure the script has been run before testing results."""
        # Check if results already exist, if not run the script
        existing_results = glob.glob(os.path.join(RESULTS_DIR, "scan_*.json"))
        if not existing_results:
            subprocess.run(
                ["bash", SCRIPT_PATH],
                capture_output=True,
                text=True,
                cwd=SCANNER_DIR,
                timeout=60
            )

    def test_results_file_exists(self):
        """A file matching scan_*.json should exist in results directory."""
        results_files = glob.glob(os.path.join(RESULTS_DIR, "scan_*.json"))
        assert len(results_files) >= 1, \
            f"Expected at least one scan_*.json file in {RESULTS_DIR}, " \
            f"but found: {os.listdir(RESULTS_DIR)}"

    def test_results_file_is_valid_json(self):
        """The results file should contain valid JSON."""
        results_files = glob.glob(os.path.join(RESULTS_DIR, "scan_*.json"))
        assert len(results_files) >= 1, \
            f"No results file found in {RESULTS_DIR}"

        results_file = results_files[0]
        with open(results_file, 'r') as f:
            content = f.read()

        try:
            data = json.loads(content)
        except json.JSONDecodeError as e:
            pytest.fail(f"Results file {results_file} is not valid JSON: {e}. Content: {content[:500]}")

    def test_results_contains_array_with_at_least_three_objects(self):
        """The results should be an array with at least 3 objects (one per endpoint)."""
        results_files = glob.glob(os.path.join(RESULTS_DIR, "scan_*.json"))
        assert len(results_files) >= 1, \
            f"No results file found in {RESULTS_DIR}"

        results_file = results_files[0]
        with open(results_file, 'r') as f:
            data = json.load(f)

        assert isinstance(data, list), \
            f"Results should be a JSON array, but got {type(data).__name__}"
        assert len(data) >= 3, \
            f"Results should contain at least 3 objects (one per endpoint), but found {len(data)}"

    def test_each_result_has_required_keys(self):
        """Each object in the results array should have host, port, and findings keys."""
        results_files = glob.glob(os.path.join(RESULTS_DIR, "scan_*.json"))
        assert len(results_files) >= 1, \
            f"No results file found in {RESULTS_DIR}"

        results_file = results_files[0]
        with open(results_file, 'r') as f:
            data = json.load(f)

        for i, obj in enumerate(data):
            assert isinstance(obj, dict), \
                f"Result item {i} should be a JSON object, but got {type(obj).__name__}"
            assert 'host' in obj, \
                f"Result item {i} missing 'host' key. Keys found: {list(obj.keys())}"
            assert 'port' in obj, \
                f"Result item {i} missing 'port' key. Keys found: {list(obj.keys())}"
            assert 'findings' in obj, \
                f"Result item {i} missing 'findings' key. Keys found: {list(obj.keys())}"


class TestResultsContainAllTargets:
    """Test that results contain all three hosts from targets.yaml."""

    def test_results_contain_all_expected_hosts(self):
        """Results should contain entries for all three hosts from targets.yaml."""
        results_files = glob.glob(os.path.join(RESULTS_DIR, "scan_*.json"))
        assert len(results_files) >= 1, \
            f"No results file found in {RESULTS_DIR}"

        results_file = results_files[0]
        with open(results_file, 'r') as f:
            data = json.load(f)

        # Expected hosts from targets.yaml
        expected_hosts = {"192.168.1.10", "192.168.1.11", "192.168.1.12"}

        found_hosts = set()
        for obj in data:
            if 'host' in obj:
                found_hosts.add(str(obj['host']))

        missing_hosts = expected_hosts - found_hosts
        assert not missing_hosts, \
            f"Results missing hosts: {missing_hosts}. Found hosts: {found_hosts}"

    def test_results_contain_expected_ports(self):
        """Results should contain the expected port numbers from targets.yaml."""
        results_files = glob.glob(os.path.join(RESULTS_DIR, "scan_*.json"))
        assert len(results_files) >= 1, \
            f"No results file found in {RESULTS_DIR}"

        results_file = results_files[0]
        with open(results_file, 'r') as f:
            data = json.load(f)

        # Expected host:port combinations from targets.yaml
        expected_combinations = {
            ("192.168.1.10", 8080),
            ("192.168.1.11", 443),
            ("192.168.1.12", 8443),
        }

        found_combinations = set()
        for obj in data:
            if 'host' in obj and 'port' in obj:
                found_combinations.add((str(obj['host']), int(obj['port'])))

        missing = expected_combinations - found_combinations
        assert not missing, \
            f"Results missing host:port combinations: {missing}. Found: {found_combinations}"


class TestInvariantsPreserved:
    """Test that invariants are preserved - targets.yaml structure unchanged."""

    def test_targets_yaml_still_uses_endpoints_key(self):
        """targets.yaml should still use 'endpoints' key."""
        try:
            import yaml
            with open(CONFIG_PATH, 'r') as f:
                data = yaml.safe_load(f)
            assert 'endpoints' in data, \
                f"targets.yaml should still have 'endpoints' key"
        except ImportError:
            # Fallback to checking raw content
            with open(CONFIG_PATH, 'r') as f:
                content = f.read()
            assert 'endpoints:' in content, \
                f"targets.yaml should still have 'endpoints' key"

    def test_targets_yaml_has_three_hosts(self):
        """targets.yaml should still have the same three hosts."""
        try:
            import yaml
            with open(CONFIG_PATH, 'r') as f:
                data = yaml.safe_load(f)
            endpoints = data.get('endpoints', [])
            hosts = [ep.get('host') for ep in endpoints if 'host' in ep]
            expected_hosts = ["192.168.1.10", "192.168.1.11", "192.168.1.12"]
            for host in expected_hosts:
                assert host in hosts, \
                    f"targets.yaml should still contain host {host}"
        except ImportError:
            with open(CONFIG_PATH, 'r') as f:
                content = f.read()
            assert '192.168.1.10' in content
            assert '192.168.1.11' in content
            assert '192.168.1.12' in content

    def test_vulnscan_binary_unchanged(self):
        """vulnscan binary should still exist and be executable."""
        assert os.path.isfile(VULNSCAN_PATH), \
            f"vulnscan binary {VULNSCAN_PATH} should still exist"
        assert os.access(VULNSCAN_PATH, os.X_OK), \
            f"vulnscan binary {VULNSCAN_PATH} should still be executable"


class TestAntiShortcutGuards:
    """Test that the fix is legitimate and not a shortcut."""

    def test_script_still_exists_and_is_bash(self):
        """The script should still exist and be a bash script."""
        assert os.path.isfile(SCRIPT_PATH), \
            f"Script {SCRIPT_PATH} should still exist"
        with open(SCRIPT_PATH, 'r') as f:
            first_line = f.readline()
        assert 'bash' in first_line or 'sh' in first_line, \
            f"Script should still be a shell script"

    def test_script_still_calls_vulnscan(self):
        """The script should still call vulnscan (not hardcode results)."""
        with open(SCRIPT_PATH, 'r') as f:
            content = f.read()
        assert 'vulnscan' in content, \
            f"Script should still reference vulnscan binary"

    def test_script_still_reads_config(self):
        """The script should still read from the config file."""
        with open(SCRIPT_PATH, 'r') as f:
            content = f.read()
        assert 'targets.yaml' in content or 'CONFIG' in content, \
            f"Script should still reference the config file"

    def test_fresh_run_produces_results(self):
        """A fresh run of the script should produce results."""
        # Clean up existing results
        existing_results = glob.glob(os.path.join(RESULTS_DIR, "scan_*.json"))
        for f in existing_results:
            os.remove(f)

        # Verify results directory is empty
        assert len(os.listdir(RESULTS_DIR)) == 0, \
            "Results directory should be empty before fresh run"

        # Run the script
        result = subprocess.run(
            ["bash", SCRIPT_PATH],
            capture_output=True,
            text=True,
            cwd=SCANNER_DIR,
            timeout=60
        )

        assert result.returncode == 0, \
            f"Fresh run should exit 0, got {result.returncode}. stderr: {result.stderr}"

        # Check results were created
        new_results = glob.glob(os.path.join(RESULTS_DIR, "scan_*.json"))
        assert len(new_results) >= 1, \
            f"Fresh run should produce results file, but none found in {RESULTS_DIR}"

        # Verify the new results are valid
        with open(new_results[0], 'r') as f:
            data = json.load(f)
        assert isinstance(data, list) and len(data) >= 3, \
            f"Fresh run results should contain at least 3 entries"
