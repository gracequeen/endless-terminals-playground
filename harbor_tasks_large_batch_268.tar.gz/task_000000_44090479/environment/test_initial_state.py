# test_initial_state.py
"""
Tests to validate the initial state before the student installs the CGI module.
"""

import os
import subprocess
import pytest


class TestPerlEnvironment:
    """Test that Perl is properly installed and configured."""

    def test_perl_is_installed(self):
        """Verify Perl interpreter is available."""
        result = subprocess.run(
            ["which", "perl"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "Perl interpreter is not installed or not in PATH"

    def test_perl_version_534_or_higher(self):
        """Verify Perl version is 5.34+ (CGI removed from core in 5.22)."""
        result = subprocess.run(
            ["perl", "-v"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "Failed to get Perl version"

        # Extract version number
        version_result = subprocess.run(
            ["perl", "-e", "print $^V"],
            capture_output=True,
            text=True
        )
        version_str = version_result.stdout.strip()
        # Version string is like "v5.34.0"
        assert version_str.startswith("v5."), f"Unexpected Perl version format: {version_str}"

        # Parse version - remove 'v' prefix and split
        version_parts = version_str[1:].split(".")
        major = int(version_parts[0])
        minor = int(version_parts[1])

        assert major == 5 and minor >= 22, (
            f"Perl version {version_str} should be 5.22+ where CGI was removed from core"
        )


class TestCpanmAvailable:
    """Test that cpanminus is available for module installation."""

    def test_cpanm_exists(self):
        """Verify cpanm is available at /usr/bin/cpanm."""
        assert os.path.exists("/usr/bin/cpanm"), (
            "cpanminus (cpanm) is not installed at /usr/bin/cpanm"
        )

    def test_cpanm_is_executable(self):
        """Verify cpanm is executable."""
        assert os.access("/usr/bin/cpanm", os.X_OK), (
            "/usr/bin/cpanm exists but is not executable"
        )


class TestLegacyDirectory:
    """Test the legacy directory structure."""

    def test_legacy_directory_exists(self):
        """Verify /home/user/legacy/ directory exists."""
        assert os.path.isdir("/home/user/legacy"), (
            "Directory /home/user/legacy/ does not exist"
        )

    def test_legacy_directory_is_writable(self):
        """Verify /home/user/legacy/ is writable."""
        assert os.access("/home/user/legacy", os.W_OK), (
            "Directory /home/user/legacy/ is not writable"
        )


class TestReportScript:
    """Test the report.pl script exists and has correct content."""

    def test_report_script_exists(self):
        """Verify /home/user/legacy/report.pl exists."""
        assert os.path.isfile("/home/user/legacy/report.pl"), (
            "Script /home/user/legacy/report.pl does not exist"
        )

    def test_report_script_is_readable(self):
        """Verify report.pl is readable."""
        assert os.access("/home/user/legacy/report.pl", os.R_OK), (
            "Script /home/user/legacy/report.pl is not readable"
        )

    def test_report_script_uses_cgi_module(self):
        """Verify the script begins with 'use CGI qw(:standard);'."""
        with open("/home/user/legacy/report.pl", "r") as f:
            content = f.read()

        # Check for the CGI use statement
        assert "use CGI qw(:standard);" in content, (
            "Script does not contain 'use CGI qw(:standard);' - "
            "this is required for the task"
        )

    def test_report_script_uses_cgi_functions(self):
        """Verify the script uses CGI functions."""
        with open("/home/user/legacy/report.pl", "r") as f:
            content = f.read()

        # Check for common CGI functions mentioned in the task
        cgi_functions = ["header", "start_html", "end_html"]
        found_functions = [func for func in cgi_functions if func in content]

        assert len(found_functions) > 0, (
            f"Script should use CGI functions like {cgi_functions}, but none were found"
        )

    def test_report_script_is_valid_perl(self):
        """Verify the script is valid Perl syntax (ignoring missing modules)."""
        # Use perl -c with a fake CGI module to check syntax
        result = subprocess.run(
            ["perl", "-c", "-e", "BEGIN { $INC{'CGI.pm'} = 1; } do '/home/user/legacy/report.pl'"],
            capture_output=True,
            text=True,
            cwd="/home/user/legacy"
        )
        # This is a basic check - the script should at least be parseable Perl
        # Note: This may not catch all syntax errors due to the fake module


class TestCGIModuleNotInstalled:
    """Test that CGI module is NOT currently installed (initial state)."""

    def test_cgi_module_not_available(self):
        """Verify CGI.pm is not currently installed."""
        result = subprocess.run(
            ["perl", "-e", "use CGI; print 'ok'"],
            capture_output=True,
            text=True
        )
        assert result.returncode != 0, (
            "CGI module is already installed - it should NOT be installed in the initial state"
        )
        assert "Can't locate CGI.pm" in result.stderr, (
            f"Expected 'Can't locate CGI.pm' error, but got: {result.stderr}"
        )

    def test_script_fails_without_cgi(self):
        """Verify running the script fails with 'Can't locate CGI.pm in @INC'."""
        result = subprocess.run(
            ["perl", "/home/user/legacy/report.pl"],
            capture_output=True,
            text=True
        )
        assert result.returncode != 0, (
            "Script should fail without CGI module installed"
        )
        assert "Can't locate CGI.pm in @INC" in result.stderr, (
            f"Expected error 'Can't locate CGI.pm in @INC', but got: {result.stderr}"
        )


class TestUserPermissions:
    """Test that user has necessary permissions."""

    def test_home_directory_exists(self):
        """Verify /home/user exists."""
        assert os.path.isdir("/home/user"), (
            "Home directory /home/user does not exist"
        )

    def test_home_directory_is_writable(self):
        """Verify user can write to home directory (for local::lib installs)."""
        assert os.access("/home/user", os.W_OK), (
            "Home directory /home/user is not writable"
        )
