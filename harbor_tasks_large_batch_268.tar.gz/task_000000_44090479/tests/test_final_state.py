# test_final_state.py
"""
Tests to validate the final state after the student has installed the CGI module.
The script /home/user/legacy/report.pl should now run successfully.
"""

import os
import subprocess
import hashlib
import pytest


class TestScriptUnmodified:
    """Verify the script was not modified (invariant)."""

    def test_script_still_exists(self):
        """Verify /home/user/legacy/report.pl still exists."""
        assert os.path.isfile("/home/user/legacy/report.pl"), (
            "Script /home/user/legacy/report.pl no longer exists - it should not be deleted"
        )

    def test_script_still_uses_cgi(self):
        """Verify the script still contains the original CGI use statement."""
        with open("/home/user/legacy/report.pl", "r") as f:
            content = f.read()

        assert "use CGI qw(:standard);" in content, (
            "Script was modified - it should still contain 'use CGI qw(:standard);' "
            "The task requires installing the module, not modifying the script."
        )

    def test_script_still_uses_cgi_functions(self):
        """Verify the script still uses CGI functions (wasn't gutted)."""
        with open("/home/user/legacy/report.pl", "r") as f:
            content = f.read()

        # At least some CGI functions should still be present
        cgi_functions = ["header", "start_html", "end_html", "param"]
        found_functions = [func for func in cgi_functions if func in content]

        assert len(found_functions) >= 2, (
            f"Script appears to have been modified - expected CGI functions like {cgi_functions}, "
            f"but only found: {found_functions}. The task requires installing the module, "
            "not modifying the script."
        )


class TestCGIModuleInstalled:
    """Verify the CGI module is now installed and loadable."""

    def test_cgi_module_can_be_loaded(self):
        """Verify CGI.pm can now be loaded by Perl."""
        result = subprocess.run(
            ["perl", "-e", "use CGI; print 'CGI loaded successfully'"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"CGI module still cannot be loaded. Error: {result.stderr}\n"
            "The CGI module needs to be installed (e.g., via cpanm CGI)"
        )
        assert "CGI loaded successfully" in result.stdout, (
            "CGI module load test did not produce expected output"
        )

    def test_cgi_standard_exports_work(self):
        """Verify CGI :standard exports are available."""
        result = subprocess.run(
            ["perl", "-e", "use CGI qw(:standard); print header()"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"CGI :standard exports not working. Error: {result.stderr}\n"
            "Make sure the full CGI module is installed with its standard functions."
        )
        assert "Content-Type" in result.stdout or "content-type" in result.stdout.lower(), (
            "CGI header() function did not produce expected Content-Type header"
        )


class TestScriptRuns:
    """Verify the report.pl script now runs successfully."""

    def test_script_exits_zero(self):
        """Verify perl /home/user/legacy/report.pl exits with code 0."""
        result = subprocess.run(
            ["perl", "/home/user/legacy/report.pl"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"Script /home/user/legacy/report.pl failed with exit code {result.returncode}.\n"
            f"STDERR: {result.stderr}\n"
            f"STDOUT: {result.stdout}\n"
            "The script should run successfully after installing the CGI module."
        )

    def test_script_produces_content_type_header(self):
        """Verify script output contains Content-Type header (CGI header)."""
        result = subprocess.run(
            ["perl", "/home/user/legacy/report.pl"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"Script failed to run: {result.stderr}"
        )

        output = result.stdout
        assert output.strip(), (
            "Script produced empty output. It should generate HTML content."
        )

        # Check for Content-Type header (case-insensitive)
        assert "content-type" in output.lower(), (
            f"Script output does not contain 'Content-Type' header.\n"
            f"Output was:\n{output}\n"
            "The CGI header() function should produce this header."
        )

    def test_script_produces_html_content_type(self):
        """Verify the Content-Type is text/html."""
        result = subprocess.run(
            ["perl", "/home/user/legacy/report.pl"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, f"Script failed: {result.stderr}"

        output = result.stdout.lower()
        assert "text/html" in output, (
            f"Script output should contain 'text/html' Content-Type.\n"
            f"Output was:\n{result.stdout}"
        )

    def test_script_produces_monthly_report(self):
        """Verify script output contains 'Monthly Report'."""
        result = subprocess.run(
            ["perl", "/home/user/legacy/report.pl"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, f"Script failed: {result.stderr}"

        output = result.stdout
        assert "Monthly Report" in output, (
            f"Script output does not contain 'Monthly Report'.\n"
            f"Output was:\n{output}\n"
            "The script should generate an HTML page with 'Monthly Report' heading."
        )

    def test_script_produces_html_structure(self):
        """Verify script output has basic HTML structure."""
        result = subprocess.run(
            ["perl", "/home/user/legacy/report.pl"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, f"Script failed: {result.stderr}"

        output = result.stdout.lower()

        # Check for basic HTML tags that start_html and end_html would produce
        assert "<html" in output or "<!doctype" in output, (
            f"Script output does not appear to contain HTML.\n"
            f"Output was:\n{result.stdout}"
        )
        assert "</html>" in output, (
            f"Script output does not contain closing </html> tag.\n"
            f"Output was:\n{result.stdout}"
        )


class TestPerlEnvironmentUnchanged:
    """Verify Perl interpreter itself wasn't changed (invariant)."""

    def test_perl_still_works(self):
        """Verify Perl interpreter still functions."""
        result = subprocess.run(
            ["perl", "-e", "print 'Hello'"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "Perl interpreter is broken"
        assert "Hello" in result.stdout, "Perl interpreter not producing expected output"

    def test_perl_version_unchanged(self):
        """Verify Perl version is still 5.x (wasn't downgraded to get bundled CGI)."""
        result = subprocess.run(
            ["perl", "-e", "print $^V"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "Failed to get Perl version"
        version_str = result.stdout.strip()
        assert version_str.startswith("v5."), (
            f"Perl version should still be 5.x, got: {version_str}"
        )

        # Ensure it's still a modern Perl (5.22+)
        version_parts = version_str[1:].split(".")
        major = int(version_parts[0])
        minor = int(version_parts[1])
        assert major == 5 and minor >= 22, (
            f"Perl version {version_str} appears to have been downgraded. "
            "The solution should install the CGI module, not change Perl version."
        )


class TestNoShortcuts:
    """Anti-shortcut guards to ensure proper solution."""

    def test_script_not_replaced_with_stub(self):
        """Verify the script wasn't replaced with a minimal stub."""
        with open("/home/user/legacy/report.pl", "r") as f:
            content = f.read()

        # A real script should have reasonable length
        assert len(content) > 50, (
            "Script appears to have been replaced with a stub. "
            "The original script should be preserved."
        )

        # Should have multiple lines
        lines = [l for l in content.split('\n') if l.strip()]
        assert len(lines) >= 5, (
            "Script appears to have been replaced with a minimal version. "
            "The original script should be preserved."
        )

    def test_output_is_not_empty(self):
        """Verify script produces actual output, not just exits 0."""
        result = subprocess.run(
            ["perl", "/home/user/legacy/report.pl"],
            capture_output=True,
            text=True
        )

        output = result.stdout.strip()
        assert len(output) > 100, (
            f"Script output is suspiciously short ({len(output)} chars). "
            f"It should produce a full HTML page.\nOutput: {output}"
        )

    def test_cgi_module_is_real(self):
        """Verify CGI module is the real module, not a stub."""
        result = subprocess.run(
            ["perl", "-e", "use CGI; print $CGI::VERSION"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, f"Failed to get CGI version: {result.stderr}"

        version = result.stdout.strip()
        assert version, "CGI module has no version - might be a stub"

        # CGI versions are typically like "4.51" or similar
        # Just verify it's a reasonable version number
        assert any(c.isdigit() for c in version), (
            f"CGI::VERSION '{version}' doesn't look like a real version number"
        )
