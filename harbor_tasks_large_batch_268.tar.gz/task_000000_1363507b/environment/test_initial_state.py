# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the rsync debugging task.
"""

import os
import subprocess
import pytest
from pathlib import Path


HOME = Path("/home/user")
SOURCE_DIR = HOME / "data" / "source"
DEST_DIR = HOME / "data" / "dest"
SCRIPTS_DIR = HOME / "scripts"
LOGS_DIR = HOME / "logs"
SYNC_SCRIPT = SCRIPTS_DIR / "sync.sh"
RSYNC_FILTER = SCRIPTS_DIR / "rsync-filter"
SYNC_LOG = LOGS_DIR / "sync.log"


class TestDirectoryStructure:
    """Test that required directories exist."""

    def test_home_directory_exists(self):
        assert HOME.is_dir(), f"Home directory {HOME} does not exist"

    def test_source_directory_exists(self):
        assert SOURCE_DIR.is_dir(), f"Source directory {SOURCE_DIR} does not exist"

    def test_dest_directory_exists(self):
        assert DEST_DIR.is_dir(), f"Destination directory {DEST_DIR} does not exist"

    def test_scripts_directory_exists(self):
        assert SCRIPTS_DIR.is_dir(), f"Scripts directory {SCRIPTS_DIR} does not exist"

    def test_logs_directory_exists(self):
        assert LOGS_DIR.is_dir(), f"Logs directory {LOGS_DIR} does not exist"


class TestSourceFiles:
    """Test that all 12 source files exist."""

    def test_report_csv_files_exist(self):
        """Check that report_2024_01.csv through report_2024_06.csv exist."""
        for i in range(1, 7):
            filename = f"report_2024_{i:02d}.csv"
            filepath = SOURCE_DIR / filename
            assert filepath.is_file(), f"Source file {filepath} does not exist"

    def test_summary_txt_exists(self):
        filepath = SOURCE_DIR / "summary.txt"
        assert filepath.is_file(), f"Source file {filepath} does not exist"

    def test_notes_md_exists(self):
        filepath = SOURCE_DIR / "notes.md"
        assert filepath.is_file(), f"Source file {filepath} does not exist"

    def test_config_json_exists(self):
        filepath = SOURCE_DIR / "config.json"
        assert filepath.is_file(), f"Source file {filepath} does not exist"

    def test_data_xml_exists(self):
        filepath = SOURCE_DIR / "data.xml"
        assert filepath.is_file(), f"Source file {filepath} does not exist"

    def test_archive_tar_gz_exists(self):
        filepath = SOURCE_DIR / "archive.tar.gz"
        assert filepath.is_file(), f"Source file {filepath} does not exist"

    def test_readme_txt_exists(self):
        filepath = SOURCE_DIR / "readme.txt"
        assert filepath.is_file(), f"Source file {filepath} does not exist"

    def test_source_has_exactly_12_files(self):
        files = list(SOURCE_DIR.iterdir())
        assert len(files) == 12, f"Source should have 12 files, found {len(files)}: {[f.name for f in files]}"

    def test_source_summary_content(self):
        """Verify source summary.txt contains the FINAL VERSION text."""
        filepath = SOURCE_DIR / "summary.txt"
        content = filepath.read_text()
        assert "Q1 2024 Summary - FINAL VERSION" in content, \
            f"Source summary.txt should contain 'Q1 2024 Summary - FINAL VERSION', got: {content}"


class TestDestFiles:
    """Test that dest has the expected partial state."""

    def test_dest_report_2024_01_exists(self):
        filepath = DEST_DIR / "report_2024_01.csv"
        assert filepath.is_file(), f"Dest file {filepath} should exist (partial copy state)"

    def test_dest_report_2024_02_exists(self):
        filepath = DEST_DIR / "report_2024_02.csv"
        assert filepath.is_file(), f"Dest file {filepath} should exist (partial copy state)"

    def test_dest_summary_txt_exists(self):
        filepath = DEST_DIR / "summary.txt"
        assert filepath.is_file(), f"Dest file {filepath} should exist (with future timestamp trap)"

    def test_dest_config_json_exists(self):
        filepath = DEST_DIR / "config.json"
        assert filepath.is_file(), f"Dest file {filepath} should exist"

    def test_dest_summary_has_draft_content(self):
        """Verify dest summary.txt contains DRAFT (the trap)."""
        filepath = DEST_DIR / "summary.txt"
        content = filepath.read_text()
        assert "DRAFT" in content, \
            f"Dest summary.txt should contain 'DRAFT' (the trap), got: {content}"

    def test_dest_summary_has_future_timestamp(self):
        """Verify dest summary.txt has a timestamp newer than source (the trap)."""
        source_summary = SOURCE_DIR / "summary.txt"
        dest_summary = DEST_DIR / "summary.txt"

        source_mtime = source_summary.stat().st_mtime
        dest_mtime = dest_summary.stat().st_mtime

        assert dest_mtime > source_mtime, \
            f"Dest summary.txt should have newer timestamp than source (trap). " \
            f"Source mtime: {source_mtime}, Dest mtime: {dest_mtime}"


class TestSyncScript:
    """Test that the sync script exists and has expected content."""

    def test_sync_script_exists(self):
        assert SYNC_SCRIPT.is_file(), f"Sync script {SYNC_SCRIPT} does not exist"

    def test_sync_script_is_executable(self):
        assert os.access(SYNC_SCRIPT, os.X_OK), f"Sync script {SYNC_SCRIPT} is not executable"

    def test_sync_script_contains_rsync(self):
        content = SYNC_SCRIPT.read_text()
        assert "rsync" in content, f"Sync script should contain 'rsync' command"

    def test_sync_script_contains_update_flag(self):
        """Verify the --update flag is present (part of the problem)."""
        content = SYNC_SCRIPT.read_text()
        assert "--update" in content, \
            f"Sync script should contain '--update' flag (this is part of the problem)"

    def test_sync_script_references_filter(self):
        """Verify the script references the rsync-filter file."""
        content = SYNC_SCRIPT.read_text()
        assert "rsync-filter" in content, \
            f"Sync script should reference rsync-filter file"

    def test_sync_script_logs_to_correct_file(self):
        content = SYNC_SCRIPT.read_text()
        assert "/home/user/logs/sync.log" in content, \
            f"Sync script should log to /home/user/logs/sync.log"

    def test_sync_script_has_shebang(self):
        content = SYNC_SCRIPT.read_text()
        assert content.startswith("#!/bin/bash"), \
            f"Sync script should start with #!/bin/bash shebang"


class TestRsyncFilter:
    """Test that the rsync filter file exists and has expected content."""

    def test_rsync_filter_exists(self):
        assert RSYNC_FILTER.is_file(), f"Rsync filter file {RSYNC_FILTER} does not exist"

    def test_rsync_filter_excludes_md(self):
        """Verify filter excludes .md files (part of the problem)."""
        content = RSYNC_FILTER.read_text()
        assert "*.md" in content, \
            f"Rsync filter should exclude *.md files (part of the problem)"

    def test_rsync_filter_excludes_tar_gz(self):
        """Verify filter excludes .tar.gz files (part of the problem)."""
        content = RSYNC_FILTER.read_text()
        assert "*.tar.gz" in content, \
            f"Rsync filter should exclude *.tar.gz files (part of the problem)"


class TestSyncLog:
    """Test that the sync log exists and shows previous runs."""

    def test_sync_log_exists(self):
        assert SYNC_LOG.is_file(), f"Sync log {SYNC_LOG} does not exist"

    def test_sync_log_has_content(self):
        content = SYNC_LOG.read_text()
        assert len(content) > 0, f"Sync log should have content from previous runs"

    def test_sync_log_shows_previous_runs(self):
        """Verify the log shows evidence of previous sync attempts."""
        content = SYNC_LOG.read_text()
        assert "Sync started" in content or "Sync completed" in content, \
            f"Sync log should show evidence of previous sync runs"


class TestRequiredTools:
    """Test that required tools are available."""

    def test_rsync_available(self):
        result = subprocess.run(["which", "rsync"], capture_output=True)
        assert result.returncode == 0, "rsync command must be available"

    def test_bash_available(self):
        result = subprocess.run(["which", "bash"], capture_output=True)
        assert result.returncode == 0, "bash must be available"

    def test_touch_available(self):
        result = subprocess.run(["which", "touch"], capture_output=True)
        assert result.returncode == 0, "touch command must be available"

    def test_stat_available(self):
        result = subprocess.run(["which", "stat"], capture_output=True)
        assert result.returncode == 0, "stat command must be available"

    def test_diff_available(self):
        result = subprocess.run(["which", "diff"], capture_output=True)
        assert result.returncode == 0, "diff command must be available"


class TestPathsWritable:
    """Test that required paths are writable."""

    def test_scripts_dir_writable(self):
        assert os.access(SCRIPTS_DIR, os.W_OK), f"{SCRIPTS_DIR} must be writable"

    def test_dest_dir_writable(self):
        assert os.access(DEST_DIR, os.W_OK), f"{DEST_DIR} must be writable"

    def test_logs_dir_writable(self):
        assert os.access(LOGS_DIR, os.W_OK), f"{LOGS_DIR} must be writable"
