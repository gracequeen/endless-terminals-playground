# test_final_state.py
"""
Tests to validate the final state of the OS/filesystem after the student
has completed the rsync debugging task.

The fix should ensure that running /home/user/scripts/sync.sh reliably
copies all 12 files from source to dest without random skips.
"""

import os
import subprocess
import pytest
from pathlib import Path


HOME = Path("/home/user")
SOURCE_DIR = HOME / "data" / "source"
DEST_DIR = HOME / "data" / "dest"
SCRIPTS_DIR = HOME / "scripts"
LOGS_DIR = HOME / "logs"
SYNC_SCRIPT = SCRIPTS_DIR / "sync.sh"
RSYNC_FILTER = SCRIPTS_DIR / "rsync-filter"
SYNC_LOG = LOGS_DIR / "sync.log"


# List of all expected source files
EXPECTED_FILES = [
    "report_2024_01.csv",
    "report_2024_02.csv",
    "report_2024_03.csv",
    "report_2024_04.csv",
    "report_2024_05.csv",
    "report_2024_06.csv",
    "summary.txt",
    "notes.md",
    "config.json",
    "data.xml",
    "archive.tar.gz",
    "readme.txt",
]


class TestSyncScriptIntegrity:
    """Test that the sync script still exists and uses rsync."""

    def test_sync_script_exists(self):
        assert SYNC_SCRIPT.is_file(), \
            f"Sync script {SYNC_SCRIPT} must still exist (cannot delete/replace the wrapper)"

    def test_sync_script_is_executable(self):
        assert os.access(SYNC_SCRIPT, os.X_OK), \
            f"Sync script {SYNC_SCRIPT} must be executable"

    def test_sync_script_uses_rsync(self):
        """The script must still use rsync, not cp or other workarounds."""
        result = subprocess.run(
            ["grep", "-q", "rsync", str(SYNC_SCRIPT)],
            capture_output=True
        )
        assert result.returncode == 0, \
            f"Sync script must still use rsync command (cannot replace with cp or manual operations)"

    def test_sync_script_has_shebang(self):
        content = SYNC_SCRIPT.read_text()
        assert content.strip().startswith("#!"), \
            f"Sync script should have a shebang line"

    def test_sync_script_logs_to_sync_log(self):
        """Logging to /home/user/logs/sync.log should still work."""
        content = SYNC_SCRIPT.read_text()
        assert "sync.log" in content or "/home/user/logs" in content, \
            f"Sync script should still log to sync.log"


class TestSourceFilesUnchanged:
    """Test that source files remain unchanged."""

    def test_source_directory_exists(self):
        assert SOURCE_DIR.is_dir(), f"Source directory {SOURCE_DIR} must exist"

    def test_source_has_all_files(self):
        for filename in EXPECTED_FILES:
            filepath = SOURCE_DIR / filename
            assert filepath.is_file(), \
                f"Source file {filepath} must still exist (source should be unchanged)"

    def test_source_summary_content_unchanged(self):
        """Source summary.txt should still have FINAL VERSION content."""
        filepath = SOURCE_DIR / "summary.txt"
        content = filepath.read_text()
        assert "Q1 2024 Summary - FINAL VERSION" in content, \
            f"Source summary.txt content should be unchanged, expected 'FINAL VERSION'"


class TestSyncScriptExecution:
    """
    Reset dest to initial broken state and run sync.sh to verify the fix works.
    This is the anti-shortcut guard - the fix must be in script/filter, not manual copy.
    """

    @pytest.fixture(autouse=True)
    def reset_and_run_sync(self):
        """Reset dest to broken state and run sync.sh before each test in this class."""
        # Clear dest directory
        for f in DEST_DIR.iterdir():
            f.unlink()

        # Recreate partial broken state
        # Copy report_2024_01.csv and report_2024_02.csv with older timestamps
        subprocess.run([
            "cp", str(SOURCE_DIR / "report_2024_01.csv"), str(DEST_DIR / "report_2024_01.csv")
        ], check=True)
        subprocess.run([
            "cp", str(SOURCE_DIR / "report_2024_02.csv"), str(DEST_DIR / "report_2024_02.csv")
        ], check=True)
        # Touch them to be older
        subprocess.run([
            "touch", "-d", "2024-01-01", str(DEST_DIR / "report_2024_01.csv")
        ], check=True)
        subprocess.run([
            "touch", "-d", "2024-01-01", str(DEST_DIR / "report_2024_02.csv")
        ], check=True)

        # Create summary.txt with DRAFT content and future timestamp (the trap)
        dest_summary = DEST_DIR / "summary.txt"
        dest_summary.write_text("Q1 2024 Summary - DRAFT\n")
        # Set timestamp to tomorrow
        subprocess.run([
            "touch", "-d", "tomorrow", str(dest_summary)
        ], check=True)

        # Copy config.json with same timestamp
        subprocess.run([
            "cp", "-p", str(SOURCE_DIR / "config.json"), str(DEST_DIR / "config.json")
        ], check=True)

        # Now run the sync script
        result = subprocess.run(
            ["/bin/bash", str(SYNC_SCRIPT)],
            capture_output=True,
            text=True,
            timeout=60
        )

        # Store result for potential debugging
        self.sync_result = result

        yield

    def test_sync_script_runs_successfully(self):
        """The sync script should complete without error."""
        # rsync may return 0 even with some skips, but script should not crash
        assert self.sync_result.returncode == 0 or "error" not in self.sync_result.stderr.lower(), \
            f"Sync script should run without critical errors. " \
            f"Return code: {self.sync_result.returncode}, stderr: {self.sync_result.stderr}"

    def test_all_csv_files_synced(self):
        """All 6 report CSV files should be in dest."""
        for i in range(1, 7):
            filename = f"report_2024_{i:02d}.csv"
            filepath = DEST_DIR / filename
            assert filepath.is_file(), \
                f"After sync, {filepath} should exist in dest"

    def test_summary_txt_synced_with_correct_content(self):
        """
        summary.txt in dest should now have FINAL VERSION content,
        not the DRAFT content (the --update flag trap should be fixed).
        """
        filepath = DEST_DIR / "summary.txt"
        assert filepath.is_file(), f"summary.txt should exist in dest"
        content = filepath.read_text()
        assert "FINAL VERSION" in content, \
            f"Dest summary.txt should contain 'FINAL VERSION' after sync. " \
            f"Got: {content!r}. The --update flag issue may not be fixed."
        assert "DRAFT" not in content, \
            f"Dest summary.txt should NOT contain 'DRAFT' after sync. " \
            f"Got: {content!r}. The --update flag issue may not be fixed."

    def test_notes_md_synced(self):
        """notes.md should be in dest (filter exclusion should be fixed)."""
        filepath = DEST_DIR / "notes.md"
        assert filepath.is_file(), \
            f"notes.md should exist in dest after sync. " \
            f"The rsync filter exclusion for *.md may not be fixed."

    def test_archive_tar_gz_synced(self):
        """archive.tar.gz should be in dest (filter exclusion should be fixed)."""
        filepath = DEST_DIR / "archive.tar.gz"
        assert filepath.is_file(), \
            f"archive.tar.gz should exist in dest after sync. " \
            f"The rsync filter exclusion for *.tar.gz may not be fixed."

    def test_config_json_synced(self):
        """config.json should be in dest."""
        filepath = DEST_DIR / "config.json"
        assert filepath.is_file(), f"config.json should exist in dest"

    def test_data_xml_synced(self):
        """data.xml should be in dest."""
        filepath = DEST_DIR / "data.xml"
        assert filepath.is_file(), f"data.xml should exist in dest"

    def test_readme_txt_synced(self):
        """readme.txt should be in dest."""
        filepath = DEST_DIR / "readme.txt"
        assert filepath.is_file(), f"readme.txt should exist in dest"

    def test_diff_source_dest_succeeds(self):
        """diff -r source dest should exit 0 (directories match)."""
        result = subprocess.run(
            ["diff", "-r", str(SOURCE_DIR), str(DEST_DIR)],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            f"diff -r source dest should exit 0 (all files should match). " \
            f"Differences found:\n{result.stdout}"

    def test_dest_has_all_12_files(self):
        """Dest should have exactly 12 files matching source."""
        dest_files = set(f.name for f in DEST_DIR.iterdir() if f.is_file())
        expected_set = set(EXPECTED_FILES)

        missing = expected_set - dest_files
        extra = dest_files - expected_set

        assert missing == set(), \
            f"Dest is missing files: {missing}"
        assert extra == set(), \
            f"Dest has unexpected extra files: {extra}"
        assert len(dest_files) == 12, \
            f"Dest should have exactly 12 files, found {len(dest_files)}"


class TestLoggingStillWorks:
    """Test that logging functionality is preserved."""

    def test_sync_log_exists(self):
        assert SYNC_LOG.is_file(), f"Sync log {SYNC_LOG} should exist"

    def test_sync_log_updated_after_run(self):
        """Run sync and verify log is updated."""
        # Get initial log size/content
        initial_size = SYNC_LOG.stat().st_size if SYNC_LOG.exists() else 0

        # Run sync
        subprocess.run(["/bin/bash", str(SYNC_SCRIPT)], capture_output=True, timeout=60)

        # Check log was updated
        new_size = SYNC_LOG.stat().st_size
        assert new_size > initial_size, \
            f"Sync log should be updated after running sync.sh. " \
            f"Initial size: {initial_size}, new size: {new_size}"

    def test_sync_log_contains_sync_markers(self):
        """Log should contain sync started/completed markers."""
        content = SYNC_LOG.read_text()
        has_markers = "Sync started" in content or "Sync completed" in content or "===" in content
        assert has_markers, \
            f"Sync log should contain sync run markers"


class TestFileContentMatches:
    """Test that file contents in dest match source after sync."""

    @pytest.fixture(autouse=True)
    def run_sync_first(self):
        """Ensure sync has been run."""
        subprocess.run(["/bin/bash", str(SYNC_SCRIPT)], capture_output=True, timeout=60)
        yield

    def test_csv_content_matches(self):
        """Spot check that CSV content matches."""
        for filename in ["report_2024_01.csv", "report_2024_06.csv"]:
            source_content = (SOURCE_DIR / filename).read_bytes()
            dest_content = (DEST_DIR / filename).read_bytes()
            assert source_content == dest_content, \
                f"{filename} content should match between source and dest"

    def test_notes_md_content_matches(self):
        """notes.md content should match."""
        source_content = (SOURCE_DIR / "notes.md").read_bytes()
        dest_content = (DEST_DIR / "notes.md").read_bytes()
        assert source_content == dest_content, \
            f"notes.md content should match between source and dest"

    def test_archive_content_matches(self):
        """archive.tar.gz content should match."""
        source_content = (SOURCE_DIR / "archive.tar.gz").read_bytes()
        dest_content = (DEST_DIR / "archive.tar.gz").read_bytes()
        assert source_content == dest_content, \
            f"archive.tar.gz content should match between source and dest"
