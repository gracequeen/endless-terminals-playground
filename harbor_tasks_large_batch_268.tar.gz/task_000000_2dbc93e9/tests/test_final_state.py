# test_final_state.py
"""
Tests to validate the final state after the student fixes the supervisor.sh script.
This verifies that SIGTERM to the supervisor properly terminates all worker processes.
"""

import os
import subprocess
import time
import signal
import pytest


class TestDirectoryStructure:
    """Test that required directories still exist."""

    def test_workers_directory_exists(self):
        """The /home/user/workers/ directory must exist."""
        path = "/home/user/workers"
        assert os.path.isdir(path), f"Directory {path} does not exist"

    def test_logs_directory_exists(self):
        """The /home/user/workers/logs/ directory must exist."""
        path = "/home/user/workers/logs"
        assert os.path.isdir(path), f"Directory {path} does not exist"


class TestSupervisorScript:
    """Test the supervisor.sh script still exists and has required properties."""

    def test_supervisor_script_exists(self):
        """supervisor.sh must exist."""
        path = "/home/user/workers/supervisor.sh"
        assert os.path.isfile(path), f"File {path} does not exist"

    def test_supervisor_script_is_executable(self):
        """supervisor.sh must be executable."""
        path = "/home/user/workers/supervisor.sh"
        assert os.access(path, os.X_OK), f"File {path} is not executable"

    def test_supervisor_script_is_bash(self):
        """supervisor.sh must be a bash script."""
        path = "/home/user/workers/supervisor.sh"
        with open(path, 'r') as f:
            first_line = f.readline().strip()
        assert first_line == "#!/bin/bash", f"supervisor.sh shebang is '{first_line}', expected '#!/bin/bash'"

    def test_supervisor_starts_all_three_workers(self):
        """supervisor.sh must still start all three workers."""
        path = "/home/user/workers/supervisor.sh"
        with open(path, 'r') as f:
            content = f.read()
        assert "worker_a" in content, "supervisor.sh does not reference worker_a"
        assert "worker_b" in content, "supervisor.sh does not reference worker_b"
        assert "worker_c" in content, "supervisor.sh does not reference worker_c"

    def test_supervisor_still_logs_worker_b(self):
        """supervisor.sh must still log worker_b output to file."""
        path = "/home/user/workers/supervisor.sh"
        with open(path, 'r') as f:
            content = f.read()
        assert "worker_b.log" in content or "worker_b" in content, \
            "supervisor.sh does not reference worker_b logging"

    def test_supervisor_still_logs_worker_c(self):
        """supervisor.sh must still log worker_c output to file."""
        path = "/home/user/workers/supervisor.sh"
        with open(path, 'r') as f:
            content = f.read()
        assert "worker_c.log" in content or "worker_c" in content, \
            "supervisor.sh does not reference worker_c logging"


class TestWorkerBinary:
    """Test the worker binary is unchanged."""

    def test_worker_binary_exists(self):
        """worker binary must exist."""
        path = "/home/user/workers/worker"
        assert os.path.isfile(path), f"File {path} does not exist"

    def test_worker_binary_is_executable(self):
        """worker binary must be executable."""
        path = "/home/user/workers/worker"
        assert os.access(path, os.X_OK), f"File {path} is not executable"


class TestCleanShutdown:
    """Test that SIGTERM to supervisor cleanly shuts down all workers."""

    @pytest.fixture(autouse=True)
    def cleanup_workers(self):
        """Ensure no stray workers before and after each test."""
        # Kill any existing workers before test
        subprocess.run(["pkill", "-9", "-f", "worker worker_"], 
                      capture_output=True, timeout=5)
        subprocess.run(["pkill", "-9", "-f", "supervisor.sh"],
                      capture_output=True, timeout=5)
        time.sleep(0.5)

        yield

        # Kill any remaining workers after test
        subprocess.run(["pkill", "-9", "-f", "worker worker_"],
                      capture_output=True, timeout=5)
        subprocess.run(["pkill", "-9", "-f", "supervisor.sh"],
                      capture_output=True, timeout=5)
        time.sleep(0.5)

    def test_no_workers_before_start(self):
        """Verify no workers are running before we start."""
        result = subprocess.run(
            ["pgrep", "-f", "worker worker_"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 1, \
            f"Worker processes already running before test: {result.stdout}"

    def test_supervisor_starts_workers(self):
        """Test that supervisor actually starts all three workers."""
        # Start supervisor in background
        proc = subprocess.Popen(
            ["/home/user/workers/supervisor.sh"],
            cwd="/home/user/workers",
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            start_new_session=True
        )

        try:
            # Wait for workers to start
            time.sleep(2)

            # Check that workers are running
            result = subprocess.run(
                ["pgrep", "-f", "worker worker_"],
                capture_output=True,
                text=True
            )

            assert result.returncode == 0, \
                "Supervisor did not start any worker processes"

            pids = result.stdout.strip().split('\n')
            assert len(pids) >= 3, \
                f"Expected at least 3 worker processes, found {len(pids)}: {pids}"

        finally:
            # Clean up
            os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
            proc.wait()

    def test_sigterm_kills_all_workers(self):
        """
        Main test: SIGTERM to supervisor must terminate ALL workers within 5 seconds.
        This is the core requirement from the task.
        """
        # Start supervisor in background
        proc = subprocess.Popen(
            ["/home/user/workers/supervisor.sh"],
            cwd="/home/user/workers",
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            start_new_session=False  # Keep in same session for signal handling
        )
        supervisor_pid = proc.pid

        # Wait for workers to start
        time.sleep(2)

        # Verify workers are running
        result = subprocess.run(
            ["pgrep", "-f", "worker worker_"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            "Workers did not start - cannot test shutdown"

        worker_count_before = len(result.stdout.strip().split('\n'))
        assert worker_count_before >= 3, \
            f"Expected at least 3 workers running, found {worker_count_before}"

        # Send SIGTERM to supervisor
        os.kill(supervisor_pid, signal.SIGTERM)

        # Wait for cleanup (up to 5 seconds as per task requirement)
        time.sleep(3)

        # Check that NO workers are running
        result = subprocess.run(
            ["pgrep", "-f", "worker worker_"],
            capture_output=True,
            text=True
        )

        assert result.returncode == 1, \
            f"Workers still running after SIGTERM to supervisor! " \
            f"Found PIDs: {result.stdout.strip()}. " \
            f"The supervisor must terminate ALL worker processes on SIGTERM."

        # Also verify supervisor itself is gone
        try:
            os.kill(supervisor_pid, 0)
            # If we get here, process still exists
            pytest.fail(f"Supervisor process {supervisor_pid} still running after SIGTERM")
        except ProcessLookupError:
            pass  # Expected - process is gone
        except PermissionError:
            pass  # Process exists but we can't signal it (shouldn't happen)

    def test_no_orphan_workers_after_sigterm(self):
        """
        Specifically test that worker_b and worker_c don't become orphans.
        """
        # Start supervisor
        proc = subprocess.Popen(
            ["/home/user/workers/supervisor.sh"],
            cwd="/home/user/workers",
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
        supervisor_pid = proc.pid

        time.sleep(2)

        # Get worker PIDs before SIGTERM
        result = subprocess.run(
            ["pgrep", "-af", "worker worker_"],
            capture_output=True,
            text=True
        )
        workers_before = result.stdout.strip()

        # Send SIGTERM
        os.kill(supervisor_pid, signal.SIGTERM)

        # Wait for cleanup
        time.sleep(3)

        # Check specifically for worker_b and worker_c
        result_b = subprocess.run(
            ["pgrep", "-f", "worker worker_b"],
            capture_output=True,
            text=True
        )
        result_c = subprocess.run(
            ["pgrep", "-f", "worker worker_c"],
            capture_output=True,
            text=True
        )

        assert result_b.returncode == 1, \
            f"worker_b is still running (orphaned)! PID: {result_b.stdout.strip()}"
        assert result_c.returncode == 1, \
            f"worker_c is still running (orphaned)! PID: {result_c.stdout.strip()}"

    def test_worker_a_also_terminates(self):
        """Verify worker_a still terminates correctly (regression test)."""
        proc = subprocess.Popen(
            ["/home/user/workers/supervisor.sh"],
            cwd="/home/user/workers",
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
        supervisor_pid = proc.pid

        time.sleep(2)

        # Verify worker_a is running
        result = subprocess.run(
            ["pgrep", "-f", "worker worker_a"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "worker_a did not start"

        # Send SIGTERM
        os.kill(supervisor_pid, signal.SIGTERM)
        time.sleep(3)

        # Check worker_a is gone
        result = subprocess.run(
            ["pgrep", "-f", "worker worker_a"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 1, \
            f"worker_a still running after SIGTERM! PID: {result.stdout.strip()}"


class TestLoggingPreserved:
    """Test that logging functionality is preserved for worker_b and worker_c."""

    @pytest.fixture(autouse=True)
    def cleanup_workers(self):
        """Ensure no stray workers and clean log files."""
        subprocess.run(["pkill", "-9", "-f", "worker worker_"],
                      capture_output=True, timeout=5)
        subprocess.run(["pkill", "-9", "-f", "supervisor.sh"],
                      capture_output=True, timeout=5)
        time.sleep(0.5)

        # Clean up old log files
        for logfile in ["/home/user/workers/logs/worker_b.log",
                       "/home/user/workers/logs/worker_c.log"]:
            if os.path.exists(logfile):
                os.remove(logfile)

        yield

        subprocess.run(["pkill", "-9", "-f", "worker worker_"],
                      capture_output=True, timeout=5)
        subprocess.run(["pkill", "-9", "-f", "supervisor.sh"],
                      capture_output=True, timeout=5)

    def test_worker_b_creates_log_file(self):
        """worker_b must still create/write to its log file."""
        proc = subprocess.Popen(
            ["/home/user/workers/supervisor.sh"],
            cwd="/home/user/workers",
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )

        try:
            # Wait for workers to start and produce output
            time.sleep(3)

            log_path = "/home/user/workers/logs/worker_b.log"
            assert os.path.exists(log_path), \
                f"worker_b.log was not created - logging for worker_b is broken"

            # Check that something was written
            size = os.path.getsize(log_path)
            assert size > 0, \
                f"worker_b.log is empty - logging for worker_b is not working"

        finally:
            os.kill(proc.pid, signal.SIGTERM)
            time.sleep(2)
            try:
                proc.kill()
            except:
                pass

    def test_worker_c_creates_log_file(self):
        """worker_c must still create/write to its log file."""
        proc = subprocess.Popen(
            ["/home/user/workers/supervisor.sh"],
            cwd="/home/user/workers",
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )

        try:
            # Wait for workers to start and produce output
            time.sleep(3)

            log_path = "/home/user/workers/logs/worker_c.log"
            assert os.path.exists(log_path), \
                f"worker_c.log was not created - logging for worker_c is broken"

            # Check that something was written
            size = os.path.getsize(log_path)
            assert size > 0, \
                f"worker_c.log is empty - logging for worker_c is not working"

        finally:
            os.kill(proc.pid, signal.SIGTERM)
            time.sleep(2)
            try:
                proc.kill()
            except:
                pass


class TestNoBlankKillWorkaround:
    """Ensure the fix doesn't use a blanket pkill as a workaround."""

    def test_cleanup_is_scoped(self):
        """
        The cleanup should not use 'pkill -f worker' which would kill
        workers from other potential supervisors.
        """
        path = "/home/user/workers/supervisor.sh"
        with open(path, 'r') as f:
            content = f.read()

        # Check for blanket pkill patterns that would be too broad
        import re

        # These patterns would kill ALL workers, not just this supervisor's
        bad_patterns = [
            r'pkill\s+(-\d+\s+)?-f\s+["\']?worker["\']?\s*$',
            r'pkill\s+(-\d+\s+)?worker\s*$',
            r'killall\s+worker',
        ]

        for pattern in bad_patterns:
            match = re.search(pattern, content, re.MULTILINE)
            if match:
                # This is a weak check - we allow it if there's more specificity
                # But flag obvious blanket kills
                line = match.group(0)
                if 'worker_' not in line and '$' not in line:
                    pytest.fail(
                        f"Found blanket kill pattern '{line}' - cleanup must be "
                        f"scoped to this supervisor's children, not all workers"
                    )
