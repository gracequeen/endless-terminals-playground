# test_initial_state.py
"""
Tests to validate the initial state before the student fixes the supervisor.sh script.
This verifies the buggy state exists as described in the task.
"""

import os
import stat
import subprocess
import pytest


class TestDirectoryStructure:
    """Test that required directories exist."""

    def test_workers_directory_exists(self):
        """The /home/user/workers/ directory must exist."""
        path = "/home/user/workers"
        assert os.path.isdir(path), f"Directory {path} does not exist"

    def test_logs_directory_exists(self):
        """The /home/user/workers/logs/ directory must exist."""
        path = "/home/user/workers/logs"
        assert os.path.isdir(path), f"Directory {path} does not exist"

    def test_logs_directory_is_writable(self):
        """The logs directory must be writable."""
        path = "/home/user/workers/logs"
        assert os.access(path, os.W_OK), f"Directory {path} is not writable"


class TestSupervisorScript:
    """Test the supervisor.sh script exists and has correct properties."""

    def test_supervisor_script_exists(self):
        """supervisor.sh must exist."""
        path = "/home/user/workers/supervisor.sh"
        assert os.path.isfile(path), f"File {path} does not exist"

    def test_supervisor_script_is_executable(self):
        """supervisor.sh must be executable."""
        path = "/home/user/workers/supervisor.sh"
        assert os.access(path, os.X_OK), f"File {path} is not executable"

    def test_supervisor_script_is_writable(self):
        """supervisor.sh must be writable (so student can fix it)."""
        path = "/home/user/workers/supervisor.sh"
        assert os.access(path, os.W_OK), f"File {path} is not writable"

    def test_supervisor_script_is_bash(self):
        """supervisor.sh must be a bash script."""
        path = "/home/user/workers/supervisor.sh"
        with open(path, 'r') as f:
            first_line = f.readline().strip()
        assert first_line == "#!/bin/bash", f"supervisor.sh shebang is '{first_line}', expected '#!/bin/bash'"

    def test_supervisor_has_cleanup_function(self):
        """supervisor.sh must have a cleanup function."""
        path = "/home/user/workers/supervisor.sh"
        with open(path, 'r') as f:
            content = f.read()
        assert "cleanup()" in content or "cleanup ()" in content, \
            "supervisor.sh does not contain a cleanup function"

    def test_supervisor_traps_sigterm(self):
        """supervisor.sh must trap SIGTERM."""
        path = "/home/user/workers/supervisor.sh"
        with open(path, 'r') as f:
            content = f.read()
        assert "trap" in content and "SIGTERM" in content, \
            "supervisor.sh does not trap SIGTERM"

    def test_supervisor_starts_worker_a(self):
        """supervisor.sh must start worker_a."""
        path = "/home/user/workers/supervisor.sh"
        with open(path, 'r') as f:
            content = f.read()
        assert "worker_a" in content, "supervisor.sh does not reference worker_a"

    def test_supervisor_starts_worker_b(self):
        """supervisor.sh must start worker_b."""
        path = "/home/user/workers/supervisor.sh"
        with open(path, 'r') as f:
            content = f.read()
        assert "worker_b" in content, "supervisor.sh does not reference worker_b"

    def test_supervisor_starts_worker_c(self):
        """supervisor.sh must start worker_c."""
        path = "/home/user/workers/supervisor.sh"
        with open(path, 'r') as f:
            content = f.read()
        assert "worker_c" in content, "supervisor.sh does not reference worker_c"

    def test_supervisor_uses_tee_for_worker_b(self):
        """supervisor.sh must use tee for worker_b logging (the buggy pattern)."""
        path = "/home/user/workers/supervisor.sh"
        with open(path, 'r') as f:
            content = f.read()
        assert "tee" in content and "worker_b.log" in content, \
            "supervisor.sh does not use tee for worker_b logging"

    def test_supervisor_uses_tee_for_worker_c(self):
        """supervisor.sh must use tee for worker_c logging (the buggy pattern)."""
        path = "/home/user/workers/supervisor.sh"
        with open(path, 'r') as f:
            content = f.read()
        assert "tee" in content and "worker_c.log" in content, \
            "supervisor.sh does not use tee for worker_c logging"

    def test_supervisor_has_subshell_pattern(self):
        """supervisor.sh must have the buggy subshell pattern with pipes."""
        path = "/home/user/workers/supervisor.sh"
        with open(path, 'r') as f:
            content = f.read()
        # Check for the subshell pattern: (./worker ... | tee ...) &
        assert "(./worker" in content or "( ./worker" in content, \
            "supervisor.sh does not have the subshell pattern that causes the bug"


class TestWorkerBinary:
    """Test the worker binary exists and has correct properties."""

    def test_worker_binary_exists(self):
        """worker binary must exist."""
        path = "/home/user/workers/worker"
        assert os.path.isfile(path), f"File {path} does not exist"

    def test_worker_binary_is_executable(self):
        """worker binary must be executable."""
        path = "/home/user/workers/worker"
        assert os.access(path, os.X_OK), f"File {path} is not executable"

    def test_worker_binary_is_not_writable(self):
        """worker binary must be read-only (not writable by user)."""
        path = "/home/user/workers/worker"
        # Check if the file is writable by the current user
        file_stat = os.stat(path)
        mode = file_stat.st_mode
        # The binary should not be writable
        assert not os.access(path, os.W_OK), \
            f"File {path} should be read-only but is writable"

    def test_worker_binary_is_elf_or_executable(self):
        """worker binary must be a valid executable."""
        path = "/home/user/workers/worker"
        result = subprocess.run(["file", path], capture_output=True, text=True)
        output = result.stdout.lower()
        assert "executable" in output or "elf" in output or "script" in output, \
            f"File {path} does not appear to be an executable: {result.stdout}"


class TestRequiredTools:
    """Test that required tools are available."""

    def test_bash_available(self):
        """bash must be available."""
        result = subprocess.run(["which", "bash"], capture_output=True)
        assert result.returncode == 0, "bash is not available"

    def test_tee_available(self):
        """tee must be available (coreutils)."""
        result = subprocess.run(["which", "tee"], capture_output=True)
        assert result.returncode == 0, "tee is not available"

    def test_pgrep_available(self):
        """pgrep must be available (procps)."""
        result = subprocess.run(["which", "pgrep"], capture_output=True)
        assert result.returncode == 0, "pgrep is not available"

    def test_pkill_available(self):
        """pkill must be available (procps)."""
        result = subprocess.run(["which", "pkill"], capture_output=True)
        assert result.returncode == 0, "pkill is not available"

    def test_ps_available(self):
        """ps must be available (procps)."""
        result = subprocess.run(["which", "ps"], capture_output=True)
        assert result.returncode == 0, "ps is not available"

    def test_kill_available(self):
        """kill must be available."""
        result = subprocess.run(["which", "kill"], capture_output=True)
        assert result.returncode == 0, "kill is not available"


class TestNoPreExistingWorkers:
    """Test that no worker processes are running before we start."""

    def test_no_worker_processes_running(self):
        """No worker processes should be running initially."""
        result = subprocess.run(
            ["pgrep", "-f", "worker worker_"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 1, \
            f"Worker processes are already running (should not be): {result.stdout}"

    def test_no_supervisor_running(self):
        """No supervisor.sh should be running initially."""
        result = subprocess.run(
            ["pgrep", "-f", "supervisor.sh"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 1, \
            f"supervisor.sh is already running (should not be): {result.stdout}"


class TestBuggyBehaviorPattern:
    """Verify the script contains the buggy pattern described in the task."""

    def test_cleanup_sends_sigint_to_process_group(self):
        """The cleanup function should send SIGINT to process group (the bug)."""
        path = "/home/user/workers/supervisor.sh"
        with open(path, 'r') as f:
            content = f.read()
        # The buggy pattern: kill -SIGINT -$$
        assert "kill -SIGINT -$$" in content or "kill -INT -$$" in content or \
               "kill -2 -$$" in content, \
            "supervisor.sh cleanup does not use 'kill -SIGINT -$$' pattern"

    def test_worker_b_uses_subshell_with_pipe(self):
        """worker_b must be launched in a subshell with pipe (causing the bug)."""
        path = "/home/user/workers/supervisor.sh"
        with open(path, 'r') as f:
            content = f.read()
        # Look for pattern like: (./worker worker_b ... | tee ...) &
        import re
        pattern = r'\(\s*\./worker\s+worker_b.*\|.*tee.*\)\s*&'
        assert re.search(pattern, content), \
            "worker_b is not launched with the buggy subshell+pipe pattern"

    def test_worker_c_uses_subshell_with_pipe(self):
        """worker_c must be launched in a subshell with pipe (causing the bug)."""
        path = "/home/user/workers/supervisor.sh"
        with open(path, 'r') as f:
            content = f.read()
        # Look for pattern like: (./worker worker_c ... | tee ...) &
        import re
        pattern = r'\(\s*\./worker\s+worker_c.*\|.*tee.*\)\s*&'
        assert re.search(pattern, content), \
            "worker_c is not launched with the buggy subshell+pipe pattern"

    def test_worker_a_is_direct_child(self):
        """worker_a must be launched as a direct child (works correctly)."""
        path = "/home/user/workers/supervisor.sh"
        with open(path, 'r') as f:
            content = f.read()
        # worker_a should be launched directly: ./worker worker_a &
        # NOT in a subshell
        import re
        # Should match: ./worker worker_a &
        # Should NOT match: (./worker worker_a ...) &
        lines = content.split('\n')
        found_direct_launch = False
        for line in lines:
            line = line.strip()
            if './worker worker_a' in line and '&' in line:
                # Check it's not in a subshell
                if not line.startswith('('):
                    found_direct_launch = True
                    break
        assert found_direct_launch, \
            "worker_a is not launched as a direct child (should be: ./worker worker_a &)"
