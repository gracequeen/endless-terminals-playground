# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the task of fixing the broken patch file.
"""

import os
import subprocess
import pytest


# Base directory for the task
BASE_DIR = "/home/user/infra/edge-case"


class TestDirectoryStructure:
    """Test that required directories exist and are accessible."""

    def test_infra_directory_exists(self):
        """The /home/user/infra directory must exist."""
        assert os.path.isdir("/home/user/infra"), \
            "Directory /home/user/infra does not exist"

    def test_edge_case_directory_exists(self):
        """The /home/user/infra/edge-case directory must exist."""
        assert os.path.isdir(BASE_DIR), \
            f"Directory {BASE_DIR} does not exist"

    def test_edge_case_directory_is_writable(self):
        """The edge-case directory must be writable."""
        assert os.access(BASE_DIR, os.W_OK), \
            f"Directory {BASE_DIR} is not writable"


class TestRequiredFiles:
    """Test that all required input files exist."""

    def test_deployed_conf_exists(self):
        """The deployed.conf file must exist."""
        filepath = os.path.join(BASE_DIR, "deployed.conf")
        assert os.path.isfile(filepath), \
            f"File {filepath} does not exist"

    def test_target_conf_exists(self):
        """The target.conf file must exist."""
        filepath = os.path.join(BASE_DIR, "target.conf")
        assert os.path.isfile(filepath), \
            f"File {filepath} does not exist"

    def test_update_patch_exists(self):
        """The update.patch file (the broken patch) must exist."""
        filepath = os.path.join(BASE_DIR, "update.patch")
        assert os.path.isfile(filepath), \
            f"File {filepath} does not exist"


class TestDeployedConfContent:
    """Test that deployed.conf has the expected content."""

    @pytest.fixture
    def deployed_content(self):
        filepath = os.path.join(BASE_DIR, "deployed.conf")
        with open(filepath, 'r') as f:
            return f.read()

    def test_deployed_conf_has_header(self, deployed_content):
        """deployed.conf should have the config header."""
        assert "# Edge router config v2.1" in deployed_content, \
            "deployed.conf missing expected header comment"

    def test_deployed_conf_has_upstream_timeout_30(self, deployed_content):
        """deployed.conf should have upstream_timeout=30."""
        assert "upstream_timeout=30" in deployed_content, \
            "deployed.conf should have upstream_timeout=30"

    def test_deployed_conf_has_retry_count_3(self, deployed_content):
        """deployed.conf should have retry_count=3."""
        assert "retry_count=3" in deployed_content, \
            "deployed.conf should have retry_count=3"

    def test_deployed_conf_has_failover_enabled(self, deployed_content):
        """deployed.conf should have failover_enabled=true."""
        assert "failover_enabled=true" in deployed_content, \
            "deployed.conf should have failover_enabled=true"

    def test_deployed_conf_has_original_failover_targets(self, deployed_content):
        """deployed.conf should have the original failover_targets (without 10.0.0.3)."""
        assert "failover_targets=10.0.0.1,10.0.0.2" in deployed_content, \
            "deployed.conf should have failover_targets=10.0.0.1,10.0.0.2"
        # Should NOT have the third target yet
        assert "10.0.0.3" not in deployed_content, \
            "deployed.conf should NOT contain 10.0.0.3 (that's the target state)"

    def test_deployed_conf_has_log_level_info(self, deployed_content):
        """deployed.conf should have log_level=INFO."""
        assert "log_level=INFO" in deployed_content, \
            "deployed.conf should have log_level=INFO"

    def test_deployed_conf_has_rate_limit_1000(self, deployed_content):
        """deployed.conf should have rate_limit=1000."""
        assert "rate_limit=1000" in deployed_content, \
            "deployed.conf should have rate_limit=1000"

    def test_deployed_conf_does_not_have_burst_allowed(self, deployed_content):
        """deployed.conf should NOT have burst_allowed (that's in target)."""
        assert "burst_allowed" not in deployed_content, \
            "deployed.conf should NOT contain burst_allowed"


class TestTargetConfContent:
    """Test that target.conf has the expected content."""

    @pytest.fixture
    def target_content(self):
        filepath = os.path.join(BASE_DIR, "target.conf")
        with open(filepath, 'r') as f:
            return f.read()

    def test_target_conf_has_header(self, target_content):
        """target.conf should have the config header."""
        assert "# Edge router config v2.1" in target_content, \
            "target.conf missing expected header comment"

    def test_target_conf_has_upstream_timeout_45(self, target_content):
        """target.conf should have upstream_timeout=45."""
        assert "upstream_timeout=45" in target_content, \
            "target.conf should have upstream_timeout=45"

    def test_target_conf_has_retry_count_5(self, target_content):
        """target.conf should have retry_count=5."""
        assert "retry_count=5" in target_content, \
            "target.conf should have retry_count=5"

    def test_target_conf_has_updated_failover_targets(self, target_content):
        """target.conf should have failover_targets with 10.0.0.3."""
        assert "failover_targets=10.0.0.1,10.0.0.2,10.0.0.3" in target_content, \
            "target.conf should have failover_targets including 10.0.0.3"

    def test_target_conf_has_log_level_debug(self, target_content):
        """target.conf should have log_level=DEBUG."""
        assert "log_level=DEBUG" in target_content, \
            "target.conf should have log_level=DEBUG"

    def test_target_conf_has_rate_limit_2000(self, target_content):
        """target.conf should have rate_limit=2000."""
        assert "rate_limit=2000" in target_content, \
            "target.conf should have rate_limit=2000"

    def test_target_conf_has_burst_allowed(self, target_content):
        """target.conf should have burst_allowed=true."""
        assert "burst_allowed=true" in target_content, \
            "target.conf should have burst_allowed=true"


class TestUpdatePatchContent:
    """Test that update.patch exists and is a unified diff (the broken one)."""

    @pytest.fixture
    def patch_content(self):
        filepath = os.path.join(BASE_DIR, "update.patch")
        with open(filepath, 'r') as f:
            return f.read()

    def test_update_patch_is_unified_diff(self, patch_content):
        """update.patch should be a unified diff format."""
        assert patch_content.startswith("---"), \
            "update.patch should start with --- (unified diff format)"
        assert "+++" in patch_content, \
            "update.patch should contain +++ line (unified diff format)"
        assert "@@" in patch_content, \
            "update.patch should contain @@ hunk headers"

    def test_update_patch_has_some_changes(self, patch_content):
        """update.patch should contain actual changes (+ and - lines)."""
        lines = patch_content.split('\n')
        change_lines = [l for l in lines if l.startswith('+') or l.startswith('-')]
        # Filter out the --- and +++ header lines
        change_lines = [l for l in change_lines if not l.startswith('---') and not l.startswith('+++')]
        assert len(change_lines) > 0, \
            "update.patch should contain actual change lines"


class TestRequiredTools:
    """Test that required tools are available."""

    def test_patch_command_available(self):
        """The patch command must be available."""
        result = subprocess.run(['which', 'patch'], capture_output=True)
        assert result.returncode == 0, \
            "The 'patch' command is not available in PATH"

    def test_diff_command_available(self):
        """The diff command must be available."""
        result = subprocess.run(['which', 'diff'], capture_output=True)
        assert result.returncode == 0, \
            "The 'diff' command is not available in PATH"

    def test_python3_available(self):
        """Python 3 must be available."""
        result = subprocess.run(['python3', '--version'], capture_output=True)
        assert result.returncode == 0, \
            "Python 3 is not available"


class TestBrokenPatchBehavior:
    """Test that the update.patch is indeed broken (doesn't produce target.conf)."""

    def test_update_patch_does_not_produce_target(self, tmp_path):
        """
        Applying update.patch to deployed.conf should NOT produce target.conf.
        This confirms the patch is broken as described in the task.
        """
        deployed_path = os.path.join(BASE_DIR, "deployed.conf")
        target_path = os.path.join(BASE_DIR, "target.conf")
        patch_path = os.path.join(BASE_DIR, "update.patch")

        # Copy deployed.conf to temp location
        test_file = tmp_path / "test.conf"
        with open(deployed_path, 'r') as f:
            test_file.write_text(f.read())

        # Apply the broken patch
        result = subprocess.run(
            ['patch', str(test_file), patch_path],
            capture_output=True,
            cwd=str(tmp_path)
        )

        # The patch claims success (exit 0) - this is part of the bug
        # We don't assert on this as it might vary

        # But the result should NOT match target.conf
        diff_result = subprocess.run(
            ['diff', '-q', str(test_file), target_path],
            capture_output=True
        )

        # diff returns non-zero if files differ
        assert diff_result.returncode != 0, \
            "update.patch should be broken and NOT produce target.conf, but it did! " \
            "The initial state may be incorrect."


class TestFixedPatchDoesNotExistYet:
    """Verify that fixed.patch does not exist yet (student needs to create it)."""

    def test_fixed_patch_does_not_exist(self):
        """fixed.patch should NOT exist yet - the student needs to create it."""
        filepath = os.path.join(BASE_DIR, "fixed.patch")
        assert not os.path.exists(filepath), \
            f"File {filepath} already exists but should not - student needs to create it"
