# test_final_state.py
"""
Tests to validate the final state after the student has created a working
fixed.patch file that correctly transforms deployed.conf into target.conf.
"""

import os
import subprocess
import tempfile
import pytest


# Base directory for the task
BASE_DIR = "/home/user/infra/edge-case"


class TestFixedPatchExists:
    """Test that the fixed.patch file exists and is valid."""

    def test_fixed_patch_file_exists(self):
        """The fixed.patch file must exist."""
        filepath = os.path.join(BASE_DIR, "fixed.patch")
        assert os.path.isfile(filepath), \
            f"File {filepath} does not exist - student must create fixed.patch"

    def test_fixed_patch_is_not_empty(self):
        """The fixed.patch file must not be empty."""
        filepath = os.path.join(BASE_DIR, "fixed.patch")
        assert os.path.getsize(filepath) > 0, \
            f"File {filepath} is empty - it should contain a valid unified diff"


class TestFixedPatchFormat:
    """Test that fixed.patch is a valid unified diff format."""

    @pytest.fixture
    def patch_content(self):
        filepath = os.path.join(BASE_DIR, "fixed.patch")
        with open(filepath, 'r') as f:
            return f.read()

    def test_fixed_patch_has_unified_diff_header(self, patch_content):
        """fixed.patch should start with --- line (unified diff format)."""
        lines = patch_content.strip().split('\n')
        # Find the first non-empty line
        first_meaningful_line = None
        for line in lines:
            if line.strip():
                first_meaningful_line = line
                break
        assert first_meaningful_line is not None, \
            "fixed.patch appears to be empty or only whitespace"
        assert first_meaningful_line.startswith("---"), \
            f"fixed.patch should start with '---' (unified diff format), got: {first_meaningful_line[:50]}"

    def test_fixed_patch_has_plus_header(self, patch_content):
        """fixed.patch should contain +++ line (unified diff format)."""
        assert "+++" in patch_content, \
            "fixed.patch should contain '+++ ' line (unified diff format)"

    def test_fixed_patch_has_hunk_headers(self, patch_content):
        """fixed.patch should contain @@ hunk headers."""
        assert "@@" in patch_content, \
            "fixed.patch should contain @@ hunk headers"

    def test_fixed_patch_contains_actual_changes(self, patch_content):
        """fixed.patch must contain actual change lines (not just headers)."""
        lines = patch_content.split('\n')
        # Count lines starting with + or - but not --- or +++
        change_lines = []
        for line in lines:
            if line.startswith('+') and not line.startswith('+++'):
                change_lines.append(line)
            elif line.startswith('-') and not line.startswith('---'):
                change_lines.append(line)

        assert len(change_lines) > 0, \
            "fixed.patch must contain actual change lines (lines starting with + or -)"


class TestOriginalFilesUnchanged:
    """Test that the original files remain unchanged."""

    def test_deployed_conf_unchanged(self):
        """deployed.conf should remain unchanged (source for patching)."""
        filepath = os.path.join(BASE_DIR, "deployed.conf")
        with open(filepath, 'r') as f:
            content = f.read()

        # Check key original values are still there
        assert "upstream_timeout=30" in content, \
            "deployed.conf was modified - it should have upstream_timeout=30"
        assert "retry_count=3" in content, \
            "deployed.conf was modified - it should have retry_count=3"
        assert "log_level=INFO" in content, \
            "deployed.conf was modified - it should have log_level=INFO"
        assert "rate_limit=1000" in content, \
            "deployed.conf was modified - it should have rate_limit=1000"
        assert "burst_allowed" not in content, \
            "deployed.conf was modified - it should NOT have burst_allowed"
        # Check failover_targets doesn't have 10.0.0.3
        assert "failover_targets=10.0.0.1,10.0.0.2" in content, \
            "deployed.conf was modified - failover_targets should be original"

    def test_target_conf_unchanged(self):
        """target.conf should remain unchanged (reference file)."""
        filepath = os.path.join(BASE_DIR, "target.conf")
        with open(filepath, 'r') as f:
            content = f.read()

        # Check key target values are still there
        assert "upstream_timeout=45" in content, \
            "target.conf was modified - it should have upstream_timeout=45"
        assert "retry_count=5" in content, \
            "target.conf was modified - it should have retry_count=5"
        assert "log_level=DEBUG" in content, \
            "target.conf was modified - it should have log_level=DEBUG"
        assert "rate_limit=2000" in content, \
            "target.conf was modified - it should have rate_limit=2000"
        assert "burst_allowed=true" in content, \
            "target.conf was modified - it should have burst_allowed=true"
        assert "failover_targets=10.0.0.1,10.0.0.2,10.0.0.3" in content, \
            "target.conf was modified - failover_targets should include 10.0.0.3"


class TestFixedPatchAppliesCorrectly:
    """Test that fixed.patch actually works as required."""

    def test_patch_applies_without_errors(self):
        """Applying fixed.patch to deployed.conf should succeed."""
        deployed_path = os.path.join(BASE_DIR, "deployed.conf")
        patch_path = os.path.join(BASE_DIR, "fixed.patch")

        with tempfile.TemporaryDirectory() as tmp_dir:
            # Copy deployed.conf to temp location
            test_file = os.path.join(tmp_dir, "test.conf")
            with open(deployed_path, 'r') as f:
                deployed_content = f.read()
            with open(test_file, 'w') as f:
                f.write(deployed_content)

            # Apply the fixed patch
            result = subprocess.run(
                ['patch', test_file, patch_path],
                capture_output=True,
                text=True
            )

            assert result.returncode == 0, \
                f"patch command failed with exit code {result.returncode}.\n" \
                f"stdout: {result.stdout}\nstderr: {result.stderr}"

    def test_patched_file_matches_target_exactly(self):
        """
        The main test: applying fixed.patch to deployed.conf must produce
        a file byte-identical to target.conf.
        """
        deployed_path = os.path.join(BASE_DIR, "deployed.conf")
        target_path = os.path.join(BASE_DIR, "target.conf")
        patch_path = os.path.join(BASE_DIR, "fixed.patch")

        with tempfile.TemporaryDirectory() as tmp_dir:
            # Copy deployed.conf to temp location
            test_file = os.path.join(tmp_dir, "test.conf")
            with open(deployed_path, 'r') as f:
                deployed_content = f.read()
            with open(test_file, 'w') as f:
                f.write(deployed_content)

            # Apply the fixed patch
            patch_result = subprocess.run(
                ['patch', test_file, patch_path],
                capture_output=True,
                text=True
            )

            assert patch_result.returncode == 0, \
                f"patch command failed: {patch_result.stderr}"

            # Compare with target.conf using diff
            diff_result = subprocess.run(
                ['diff', '-q', test_file, target_path],
                capture_output=True,
                text=True
            )

            if diff_result.returncode != 0:
                # Get detailed diff for error message
                detailed_diff = subprocess.run(
                    ['diff', '-u', test_file, target_path],
                    capture_output=True,
                    text=True
                )
                pytest.fail(
                    f"Patched file does not match target.conf!\n"
                    f"Differences:\n{detailed_diff.stdout}"
                )

    def test_no_reject_files_created(self):
        """Applying the patch should not create any .rej files."""
        deployed_path = os.path.join(BASE_DIR, "deployed.conf")
        patch_path = os.path.join(BASE_DIR, "fixed.patch")

        with tempfile.TemporaryDirectory() as tmp_dir:
            # Copy deployed.conf to temp location
            test_file = os.path.join(tmp_dir, "test.conf")
            with open(deployed_path, 'r') as f:
                deployed_content = f.read()
            with open(test_file, 'w') as f:
                f.write(deployed_content)

            # Apply the fixed patch
            subprocess.run(
                ['patch', test_file, patch_path],
                capture_output=True,
                cwd=tmp_dir
            )

            # Check for .rej files
            rej_files = [f for f in os.listdir(tmp_dir) if f.endswith('.rej')]
            assert len(rej_files) == 0, \
                f"Patch created reject files: {rej_files}"


class TestPatchContainsAllRequiredChanges:
    """Test that the patch contains all the necessary changes."""

    @pytest.fixture
    def patch_content(self):
        filepath = os.path.join(BASE_DIR, "fixed.patch")
        with open(filepath, 'r') as f:
            return f.read()

    def test_patch_changes_upstream_timeout(self, patch_content):
        """Patch should change upstream_timeout from 30 to 45."""
        assert "-upstream_timeout=30" in patch_content or \
               ("upstream_timeout=30" in patch_content and "upstream_timeout=45" in patch_content), \
            "Patch should include change for upstream_timeout"
        assert "+upstream_timeout=45" in patch_content, \
            "Patch should add upstream_timeout=45"

    def test_patch_changes_retry_count(self, patch_content):
        """Patch should change retry_count from 3 to 5."""
        assert "-retry_count=3" in patch_content or \
               ("retry_count=3" in patch_content and "retry_count=5" in patch_content), \
            "Patch should include change for retry_count"
        assert "+retry_count=5" in patch_content, \
            "Patch should add retry_count=5"

    def test_patch_changes_failover_targets(self, patch_content):
        """Patch should add 10.0.0.3 to failover_targets."""
        assert "10.0.0.3" in patch_content, \
            "Patch should include the new failover target 10.0.0.3"

    def test_patch_changes_log_level(self, patch_content):
        """Patch should change log_level from INFO to DEBUG."""
        assert "DEBUG" in patch_content, \
            "Patch should include log_level=DEBUG"

    def test_patch_changes_rate_limit(self, patch_content):
        """Patch should change rate_limit from 1000 to 2000."""
        assert "+rate_limit=2000" in patch_content, \
            "Patch should add rate_limit=2000"

    def test_patch_adds_burst_allowed(self, patch_content):
        """Patch should add burst_allowed=true."""
        assert "+burst_allowed=true" in patch_content, \
            "Patch should add burst_allowed=true"


class TestGraderVerification:
    """
    Exact verification as described in the task's anti-shortcut guards.
    This mirrors what the grader will do.
    """

    def test_grader_verification_command(self):
        """
        Run the exact grader verification:
        cp deployed.conf /tmp/test.conf && 
        patch /tmp/test.conf fixed.patch && 
        diff /tmp/test.conf target.conf
        Must exit 0 with no output.
        """
        deployed_path = os.path.join(BASE_DIR, "deployed.conf")
        target_path = os.path.join(BASE_DIR, "target.conf")
        patch_path = os.path.join(BASE_DIR, "fixed.patch")

        with tempfile.NamedTemporaryFile(mode='w', suffix='.conf', delete=False) as tmp:
            tmp_path = tmp.name
            # Copy deployed.conf content
            with open(deployed_path, 'r') as f:
                tmp.write(f.read())

        try:
            # Apply patch
            patch_result = subprocess.run(
                ['patch', tmp_path, patch_path],
                capture_output=True,
                text=True
            )

            assert patch_result.returncode == 0, \
                f"Patch failed with code {patch_result.returncode}: {patch_result.stderr}"

            # Compare with diff
            diff_result = subprocess.run(
                ['diff', tmp_path, target_path],
                capture_output=True,
                text=True
            )

            assert diff_result.returncode == 0, \
                f"diff returned non-zero. Files differ:\n{diff_result.stdout}"
            assert diff_result.stdout == "", \
                f"diff produced output (files differ):\n{diff_result.stdout}"

        finally:
            # Cleanup
            if os.path.exists(tmp_path):
                os.unlink(tmp_path)
            # Also clean up potential .orig file
            orig_path = tmp_path + ".orig"
            if os.path.exists(orig_path):
                os.unlink(orig_path)

    def test_patch_has_actual_changes_grep_check(self):
        """
        Verify: grep -c '^[-+]' fixed.patch shows the patch contains actual changes.
        """
        patch_path = os.path.join(BASE_DIR, "fixed.patch")

        result = subprocess.run(
            ['grep', '-c', '^[-+]', patch_path],
            capture_output=True,
            text=True
        )

        # grep -c returns 0 if matches found, 1 if no matches
        assert result.returncode == 0, \
            "grep found no lines starting with - or + in fixed.patch"

        count = int(result.stdout.strip())
        # Should have at least several change lines (the patch has many changes)
        # Minimum: 2 for --- and +++ headers, plus actual changes
        assert count > 2, \
            f"fixed.patch only has {count} lines starting with [-+], expected more actual changes"
