# test_initial_state.py
"""
Tests to validate the initial state before the student converts the Python 2 script to Python 3.
"""

import os
import subprocess
import pytest


class TestInitialState:
    """Validate the initial state of the system before the task is performed."""

    SCRIPT_PATH = "/home/user/diag/collect.py"
    DIAG_DIR = "/home/user/diag"

    def test_diag_directory_exists(self):
        """Verify /home/user/diag/ directory exists."""
        assert os.path.isdir(self.DIAG_DIR), (
            f"Directory {self.DIAG_DIR} does not exist. "
            "The diag directory must be present for the task."
        )

    def test_diag_directory_is_writable(self):
        """Verify /home/user/diag/ directory is writable."""
        assert os.access(self.DIAG_DIR, os.W_OK), (
            f"Directory {self.DIAG_DIR} is not writable. "
            "The student needs write access to modify the script."
        )

    def test_script_exists(self):
        """Verify /home/user/diag/collect.py exists."""
        assert os.path.isfile(self.SCRIPT_PATH), (
            f"Script {self.SCRIPT_PATH} does not exist. "
            "The Python 2 script must be present for conversion."
        )

    def test_script_contains_python2_print_statements(self):
        """Verify the script contains Python 2 style print statements (without parentheses)."""
        with open(self.SCRIPT_PATH, 'r') as f:
            content = f.read()

        # Check for Python 2 style print statements (print followed by space and string/variable)
        # These are the specific print statements that should be in the file
        expected_prints = [
            'print "=== System Diagnostics ==="',
            'print "Hostname:"',
            'print "Python:"',
            'print "User:"',
            'print "CWD:"',
            'print "=== End Diagnostics ==="'
        ]

        found_py2_prints = 0
        for expected in expected_prints:
            if expected in content:
                found_py2_prints += 1

        assert found_py2_prints >= 5, (
            f"Script does not contain expected Python 2 print statements. "
            f"Found {found_py2_prints} of 6 expected. "
            "The script should have Python 2 syntax for the student to convert."
        )

    def test_script_contains_required_imports(self):
        """Verify the script imports os and sys modules."""
        with open(self.SCRIPT_PATH, 'r') as f:
            content = f.read()

        assert 'import os' in content, (
            "Script does not contain 'import os'. "
            "The original script must import the os module."
        )
        assert 'import sys' in content, (
            "Script does not contain 'import sys'. "
            "The original script must import the sys module."
        )

    def test_script_contains_diagnostic_calls(self):
        """Verify the script contains the required os/sys function calls."""
        with open(self.SCRIPT_PATH, 'r') as f:
            content = f.read()

        required_calls = [
            ('os.uname()', 'os.uname'),
            ('sys.version', 'sys.version'),
            ('os.environ.get', 'os.environ.get'),
            ('os.getcwd()', 'os.getcwd'),
        ]

        for call_name, pattern in required_calls:
            assert pattern in content, (
                f"Script does not contain '{call_name}'. "
                f"The original script must use {call_name} for diagnostics."
            )

    def test_python3_available(self):
        """Verify python3 is available on the system."""
        result = subprocess.run(
            ['which', 'python3'],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "python3 is not available on the system. "
            "Python 3 must be installed for the student to run the converted script."
        )

    def test_python2_not_available(self):
        """Verify python and python2 binaries are not available."""
        # Check for 'python' binary
        result_python = subprocess.run(
            ['which', 'python'],
            capture_output=True,
            text=True
        )
        # Check for 'python2' binary
        result_python2 = subprocess.run(
            ['which', 'python2'],
            capture_output=True,
            text=True
        )

        # At least one should not exist, or if python exists it should be python3
        if result_python.returncode == 0:
            # If python exists, verify it's actually python3
            version_result = subprocess.run(
                ['python', '--version'],
                capture_output=True,
                text=True
            )
            version_output = version_result.stdout + version_result.stderr
            assert 'Python 3' in version_output, (
                "A 'python' binary exists but is not Python 3. "
                "The task requires only Python 3 to be available."
            )

        assert result_python2.returncode != 0, (
            "python2 binary is available on the system. "
            "The task requires that only Python 3 is available."
        )

    def test_script_fails_with_python3(self):
        """Verify that running the script with python3 fails due to syntax errors."""
        result = subprocess.run(
            ['python3', self.SCRIPT_PATH],
            capture_output=True,
            text=True
        )

        assert result.returncode != 0, (
            "Script runs successfully with python3. "
            "The initial script should fail with SyntaxError due to Python 2 print statements."
        )

        # Check that it's a syntax error related to print
        error_output = result.stderr
        assert 'SyntaxError' in error_output or 'syntax' in error_output.lower(), (
            f"Script failed but not with SyntaxError. Error: {error_output}. "
            "The script should fail specifically due to Python 2 print syntax."
        )

    def test_script_has_shebang(self):
        """Verify the script has a shebang line."""
        with open(self.SCRIPT_PATH, 'r') as f:
            first_line = f.readline().strip()

        assert first_line.startswith('#!'), (
            "Script does not have a shebang line. "
            "The original script should have #!/usr/bin/env python."
        )
        assert 'python' in first_line, (
            f"Shebang line '{first_line}' does not reference python. "
            "The original script should have a python shebang."
        )
