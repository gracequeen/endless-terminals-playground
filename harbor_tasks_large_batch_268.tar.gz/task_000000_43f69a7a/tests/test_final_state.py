# test_final_state.py
"""
Tests to validate the final state after the student converts the Python 2 script to Python 3.
"""

import os
import subprocess
import re
import pytest


class TestFinalState:
    """Validate the final state of the system after the task is performed."""

    SCRIPT_PATH = "/home/user/diag/collect.py"
    DIAG_DIR = "/home/user/diag"

    def test_script_still_exists_at_original_location(self):
        """Verify /home/user/diag/collect.py still exists (not moved or renamed)."""
        assert os.path.isfile(self.SCRIPT_PATH), (
            f"Script {self.SCRIPT_PATH} does not exist. "
            "The script must remain at its original location, not moved or renamed."
        )

    def test_script_runs_successfully_with_python3(self):
        """Verify that python3 /home/user/diag/collect.py exits with code 0."""
        result = subprocess.run(
            ['python3', self.SCRIPT_PATH],
            capture_output=True,
            text=True
        )

        assert result.returncode == 0, (
            f"Script failed to run with python3. Exit code: {result.returncode}. "
            f"Stderr: {result.stderr}. "
            "The script must run successfully under Python 3."
        )

    def test_output_contains_system_diagnostics_header(self):
        """Verify output contains '=== System Diagnostics ===' header."""
        result = subprocess.run(
            ['python3', self.SCRIPT_PATH],
            capture_output=True,
            text=True
        )

        assert "=== System Diagnostics ===" in result.stdout, (
            f"Output does not contain '=== System Diagnostics ===' header. "
            f"Actual output: {result.stdout}"
        )

    def test_output_contains_hostname_line(self):
        """Verify output contains 'Hostname:' line."""
        result = subprocess.run(
            ['python3', self.SCRIPT_PATH],
            capture_output=True,
            text=True
        )

        assert "Hostname:" in result.stdout, (
            f"Output does not contain 'Hostname:' line. "
            f"Actual output: {result.stdout}"
        )

    def test_output_contains_python_line(self):
        """Verify output contains 'Python:' line."""
        result = subprocess.run(
            ['python3', self.SCRIPT_PATH],
            capture_output=True,
            text=True
        )

        assert "Python:" in result.stdout, (
            f"Output does not contain 'Python:' line. "
            f"Actual output: {result.stdout}"
        )

    def test_output_contains_user_line(self):
        """Verify output contains 'User:' line."""
        result = subprocess.run(
            ['python3', self.SCRIPT_PATH],
            capture_output=True,
            text=True
        )

        assert "User:" in result.stdout, (
            f"Output does not contain 'User:' line. "
            f"Actual output: {result.stdout}"
        )

    def test_output_contains_cwd_line(self):
        """Verify output contains 'CWD:' line."""
        result = subprocess.run(
            ['python3', self.SCRIPT_PATH],
            capture_output=True,
            text=True
        )

        assert "CWD:" in result.stdout, (
            f"Output does not contain 'CWD:' line. "
            f"Actual output: {result.stdout}"
        )

    def test_output_contains_end_diagnostics_footer(self):
        """Verify output contains '=== End Diagnostics ===' footer."""
        result = subprocess.run(
            ['python3', self.SCRIPT_PATH],
            capture_output=True,
            text=True
        )

        assert "=== End Diagnostics ===" in result.stdout, (
            f"Output does not contain '=== End Diagnostics ===' footer. "
            f"Actual output: {result.stdout}"
        )

    def test_output_lines_in_correct_order(self):
        """Verify all diagnostic lines appear in the correct order."""
        result = subprocess.run(
            ['python3', self.SCRIPT_PATH],
            capture_output=True,
            text=True
        )

        output = result.stdout
        expected_order = [
            "=== System Diagnostics ===",
            "Hostname:",
            "Python:",
            "User:",
            "CWD:",
            "=== End Diagnostics ==="
        ]

        positions = []
        for item in expected_order:
            pos = output.find(item)
            assert pos != -1, (
                f"'{item}' not found in output. Actual output: {output}"
            )
            positions.append(pos)

        # Verify they appear in order
        for i in range(len(positions) - 1):
            assert positions[i] < positions[i + 1], (
                f"Output lines are not in correct order. "
                f"'{expected_order[i]}' should appear before '{expected_order[i + 1]}'. "
                f"Actual output: {output}"
            )

    def test_script_uses_os_uname_for_hostname(self):
        """Verify script still uses os.uname()[1] for hostname."""
        with open(self.SCRIPT_PATH, 'r') as f:
            content = f.read()

        assert 'os.uname' in content, (
            "Script does not use os.uname() for hostname. "
            "The script must still use os.uname()[1] to get the hostname, "
            "not a hardcoded value or different method."
        )

    def test_script_uses_sys_version(self):
        """Verify script still uses sys.version for Python version."""
        with open(self.SCRIPT_PATH, 'r') as f:
            content = f.read()

        assert 'sys.version' in content, (
            "Script does not use sys.version for Python version. "
            "The script must still use sys.version, not a hardcoded value."
        )

    def test_script_uses_os_environ_get(self):
        """Verify script still uses os.environ.get for user."""
        with open(self.SCRIPT_PATH, 'r') as f:
            content = f.read()

        assert 'os.environ.get' in content or 'os.environ[' in content, (
            "Script does not use os.environ.get() or os.environ[] for user. "
            "The script must still use os.environ to get the USER, not a hardcoded value."
        )

    def test_script_uses_os_getcwd(self):
        """Verify script still uses os.getcwd() for working directory."""
        with open(self.SCRIPT_PATH, 'r') as f:
            content = f.read()

        assert 'os.getcwd' in content, (
            "Script does not use os.getcwd() for working directory. "
            "The script must still use os.getcwd(), not a hardcoded value."
        )

    def test_anti_shortcut_grep_check(self):
        """
        Anti-shortcut: Verify script contains at least 4 lines with os/sys function calls.
        This ensures the script wasn't replaced with a stub that just echoes hardcoded output.
        """
        result = subprocess.run(
            ['grep', '-E', r'os\.uname|sys\.version|os\.environ|os\.getcwd', self.SCRIPT_PATH],
            capture_output=True,
            text=True
        )

        matching_lines = [line for line in result.stdout.strip().split('\n') if line]
        assert len(matching_lines) >= 4, (
            f"Script does not contain at least 4 lines with os/sys function calls. "
            f"Found {len(matching_lines)} lines. "
            "The script must actually call os.uname, sys.version, os.environ, and os.getcwd, "
            "not just echo hardcoded values."
        )

    def test_output_shows_actual_hostname(self):
        """Verify the hostname in output matches the actual system hostname."""
        result = subprocess.run(
            ['python3', self.SCRIPT_PATH],
            capture_output=True,
            text=True
        )

        # Get actual hostname
        hostname_result = subprocess.run(
            ['hostname'],
            capture_output=True,
            text=True
        )
        actual_hostname = hostname_result.stdout.strip()

        assert actual_hostname in result.stdout, (
            f"Output does not contain actual hostname '{actual_hostname}'. "
            f"Actual output: {result.stdout}. "
            "The script must dynamically get the hostname using os.uname()."
        )

    def test_output_shows_python3_version(self):
        """Verify the Python version in output indicates Python 3."""
        result = subprocess.run(
            ['python3', self.SCRIPT_PATH],
            capture_output=True,
            text=True
        )

        # The output should show Python 3.x version
        assert '3.' in result.stdout, (
            f"Output does not show Python 3 version. "
            f"Actual output: {result.stdout}. "
            "The script must be running under Python 3 and showing sys.version."
        )

    def test_script_imports_os_and_sys(self):
        """Verify the script still imports os and sys modules."""
        with open(self.SCRIPT_PATH, 'r') as f:
            content = f.read()

        assert 'import os' in content, (
            "Script does not import os module. "
            "The script must import os to use os.uname, os.environ, os.getcwd."
        )
        assert 'import sys' in content, (
            "Script does not import sys module. "
            "The script must import sys to use sys.version."
        )
