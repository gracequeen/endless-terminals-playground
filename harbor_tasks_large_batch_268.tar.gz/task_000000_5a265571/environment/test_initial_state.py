# test_initial_state.py
"""
Tests to validate the initial state before the student generates an SSH keypair.
"""

import os
import stat
import subprocess
import pytest


class TestInitialState:
    """Validate the operating system state before the SSH keypair generation task."""

    def test_ssh_directory_exists(self):
        """Verify /home/user/.ssh directory exists."""
        ssh_dir = "/home/user/.ssh"
        assert os.path.exists(ssh_dir), f"Directory {ssh_dir} does not exist"

    def test_ssh_directory_is_directory(self):
        """Verify /home/user/.ssh is a directory, not a file."""
        ssh_dir = "/home/user/.ssh"
        assert os.path.isdir(ssh_dir), f"{ssh_dir} exists but is not a directory"

    def test_ssh_directory_permissions(self):
        """Verify /home/user/.ssh has mode 700."""
        ssh_dir = "/home/user/.ssh"
        mode = os.stat(ssh_dir).st_mode
        # Extract only the permission bits
        perm_bits = stat.S_IMODE(mode)
        assert perm_bits == 0o700, (
            f"{ssh_dir} has permissions {oct(perm_bits)}, expected 0o700 (700)"
        )

    def test_ssh_directory_owned_by_user(self):
        """Verify /home/user/.ssh is owned by user."""
        ssh_dir = "/home/user/.ssh"
        import pwd

        stat_info = os.stat(ssh_dir)
        owner_uid = stat_info.st_uid

        try:
            owner_name = pwd.getpwuid(owner_uid).pw_name
        except KeyError:
            owner_name = str(owner_uid)

        assert owner_name == "user", (
            f"{ssh_dir} is owned by '{owner_name}', expected 'user'"
        )

    def test_ssh_directory_is_empty(self):
        """Verify /home/user/.ssh directory is empty."""
        ssh_dir = "/home/user/.ssh"
        contents = os.listdir(ssh_dir)
        assert len(contents) == 0, (
            f"{ssh_dir} is not empty. Contains: {contents}"
        )

    def test_ssh_keygen_available(self):
        """Verify ssh-keygen command is available (openssh-client installed)."""
        result = subprocess.run(
            ["which", "ssh-keygen"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "ssh-keygen is not available. openssh-client may not be installed."
        )

    def test_ssh_keygen_executable(self):
        """Verify ssh-keygen can be executed."""
        result = subprocess.run(
            ["ssh-keygen", "-h"],
            capture_output=True,
            text=True
        )
        # ssh-keygen -h returns 1 but outputs help text
        # We just need to verify it runs without a "command not found" error
        assert "usage:" in result.stdout.lower() or "usage:" in result.stderr.lower() or result.returncode in [0, 1], (
            "ssh-keygen is not executable or not functioning properly"
        )

    def test_home_user_exists(self):
        """Verify /home/user directory exists."""
        home_dir = "/home/user"
        assert os.path.exists(home_dir), f"Directory {home_dir} does not exist"
        assert os.path.isdir(home_dir), f"{home_dir} exists but is not a directory"

    def test_home_user_writable(self):
        """Verify /home/user is writable."""
        home_dir = "/home/user"
        assert os.access(home_dir, os.W_OK), (
            f"{home_dir} is not writable"
        )

    def test_ci_runner_private_key_does_not_exist(self):
        """Verify the target private key file does not already exist."""
        private_key = "/home/user/.ssh/ci_runner"
        assert not os.path.exists(private_key), (
            f"{private_key} already exists - initial state should not have this file"
        )

    def test_ci_runner_public_key_does_not_exist(self):
        """Verify the target public key file does not already exist."""
        public_key = "/home/user/.ssh/ci_runner.pub"
        assert not os.path.exists(public_key), (
            f"{public_key} already exists - initial state should not have this file"
        )
