# test_final_state.py
"""
Tests to validate the final state after the student has generated an SSH keypair.
"""

import os
import stat
import subprocess
import pytest


class TestFinalState:
    """Validate the operating system state after the SSH keypair generation task."""

    def test_ssh_directory_still_exists(self):
        """Verify /home/user/.ssh directory still exists."""
        ssh_dir = "/home/user/.ssh"
        assert os.path.exists(ssh_dir), f"Directory {ssh_dir} does not exist"
        assert os.path.isdir(ssh_dir), f"{ssh_dir} exists but is not a directory"

    def test_ssh_directory_permissions_unchanged(self):
        """Verify /home/user/.ssh still has mode 700."""
        ssh_dir = "/home/user/.ssh"
        mode = os.stat(ssh_dir).st_mode
        perm_bits = stat.S_IMODE(mode)
        assert perm_bits == 0o700, (
            f"{ssh_dir} has permissions {oct(perm_bits)}, expected 0o700 (700)"
        )

    def test_private_key_exists(self):
        """Verify the private key file exists."""
        private_key = "/home/user/.ssh/ci_runner"
        assert os.path.exists(private_key), (
            f"Private key {private_key} does not exist"
        )
        assert os.path.isfile(private_key), (
            f"{private_key} exists but is not a regular file"
        )

    def test_public_key_exists(self):
        """Verify the public key file exists."""
        public_key = "/home/user/.ssh/ci_runner.pub"
        assert os.path.exists(public_key), (
            f"Public key {public_key} does not exist"
        )
        assert os.path.isfile(public_key), (
            f"{public_key} exists but is not a regular file"
        )

    def test_private_key_is_valid_openssh_format(self):
        """Verify the private key starts with the correct OpenSSH header."""
        private_key = "/home/user/.ssh/ci_runner"
        with open(private_key, "r") as f:
            content = f.read()

        assert content.startswith("-----BEGIN OPENSSH PRIVATE KEY-----"), (
            f"Private key does not start with '-----BEGIN OPENSSH PRIVATE KEY-----'. "
            f"Got: {content[:50]}..."
        )
        assert "-----END OPENSSH PRIVATE KEY-----" in content, (
            "Private key does not contain '-----END OPENSSH PRIVATE KEY-----'"
        )

    def test_public_key_is_ed25519(self):
        """Verify the public key is an ed25519 key."""
        public_key = "/home/user/.ssh/ci_runner.pub"
        with open(public_key, "r") as f:
            content = f.read().strip()

        assert content.startswith("ssh-ed25519 "), (
            f"Public key does not start with 'ssh-ed25519 '. "
            f"Got: {content[:30]}..."
        )

    def test_private_key_permissions(self):
        """Verify private key has permissions 600 or stricter."""
        private_key = "/home/user/.ssh/ci_runner"
        mode = os.stat(private_key).st_mode
        perm_bits = stat.S_IMODE(mode)

        # Check that group and other have no permissions
        group_perms = (perm_bits >> 3) & 0o7
        other_perms = perm_bits & 0o7

        assert group_perms == 0, (
            f"Private key {private_key} has group permissions {oct(group_perms)}, "
            f"expected none (full mode: {oct(perm_bits)})"
        )
        assert other_perms == 0, (
            f"Private key {private_key} has other permissions {oct(other_perms)}, "
            f"expected none (full mode: {oct(perm_bits)})"
        )

    def test_private_key_no_passphrase(self):
        """Verify private key has no passphrase by extracting public key without prompt."""
        private_key = "/home/user/.ssh/ci_runner"

        # ssh-keygen -y -f <private_key> should succeed without prompting if no passphrase
        result = subprocess.run(
            ["ssh-keygen", "-y", "-f", private_key],
            capture_output=True,
            text=True,
            timeout=5
        )

        assert result.returncode == 0, (
            f"Failed to extract public key from private key (may have passphrase). "
            f"Return code: {result.returncode}, stderr: {result.stderr}"
        )
        assert result.stdout.strip().startswith("ssh-ed25519 "), (
            f"Extracted public key is not ed25519. Got: {result.stdout[:50]}..."
        )

    def test_keypair_matches(self):
        """Verify the private and public keys are a matching pair."""
        private_key = "/home/user/.ssh/ci_runner"
        public_key = "/home/user/.ssh/ci_runner.pub"

        # Extract public key from private key
        result = subprocess.run(
            ["ssh-keygen", "-y", "-f", private_key],
            capture_output=True,
            text=True,
            timeout=5
        )
        assert result.returncode == 0, (
            f"Failed to extract public key from private key. stderr: {result.stderr}"
        )

        extracted_pubkey = result.stdout.strip()

        # Read the stored public key
        with open(public_key, "r") as f:
            stored_pubkey = f.read().strip()

        # The stored public key may have a comment at the end, so we compare
        # just the key type and key data (first two space-separated fields)
        extracted_parts = extracted_pubkey.split()[:2]
        stored_parts = stored_pubkey.split()[:2]

        assert extracted_parts == stored_parts, (
            f"Public key does not match private key.\n"
            f"Extracted from private: {' '.join(extracted_parts)}\n"
            f"Stored in .pub file: {' '.join(stored_parts)}"
        )

    def test_only_expected_files_in_ssh_dir(self):
        """Verify only ci_runner and ci_runner.pub exist in .ssh directory."""
        ssh_dir = "/home/user/.ssh"
        contents = set(os.listdir(ssh_dir))
        expected = {"ci_runner", "ci_runner.pub"}

        assert contents == expected, (
            f"Unexpected files in {ssh_dir}. "
            f"Expected: {expected}, Found: {contents}"
        )

    def test_private_key_is_ed25519_type(self):
        """Verify the private key is specifically an ed25519 key by checking key fingerprint."""
        private_key = "/home/user/.ssh/ci_runner"

        # Get the fingerprint which includes the key type
        result = subprocess.run(
            ["ssh-keygen", "-l", "-f", private_key],
            capture_output=True,
            text=True,
            timeout=5
        )

        assert result.returncode == 0, (
            f"Failed to get key fingerprint. stderr: {result.stderr}"
        )

        # Output format: "256 SHA256:... comment (ED25519)"
        output = result.stdout.strip()
        assert "(ED25519)" in output.upper(), (
            f"Private key is not an ED25519 key. Fingerprint output: {output}"
        )
