# test_initial_state.py
"""
Tests to validate the initial state before the student performs the port scanner optimization task.
"""

import os
import subprocess
import pytest


class TestScannerScriptExists:
    """Test that the scanner script exists and is properly set up."""

    def test_scanner_directory_exists(self):
        """Verify /home/user/scanner/ directory exists."""
        scanner_dir = "/home/user/scanner"
        assert os.path.isdir(scanner_dir), f"Directory {scanner_dir} does not exist"

    def test_scan_script_exists(self):
        """Verify /home/user/scanner/scan.py exists."""
        script_path = "/home/user/scanner/scan.py"
        assert os.path.isfile(script_path), f"Script {script_path} does not exist"

    def test_scan_script_readable(self):
        """Verify scan.py is readable."""
        script_path = "/home/user/scanner/scan.py"
        assert os.access(script_path, os.R_OK), f"Script {script_path} is not readable"

    def test_scan_script_executable_with_python3(self):
        """Verify scan.py can be executed with python3 (syntax check)."""
        script_path = "/home/user/scanner/scan.py"
        result = subprocess.run(
            ["python3", "-m", "py_compile", script_path],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, f"Script {script_path} has syntax errors: {result.stderr}"


class TestTargetsFile:
    """Test that the targets file exists and has correct content."""

    def test_targets_file_exists(self):
        """Verify /home/user/scanner/targets.txt exists."""
        targets_path = "/home/user/scanner/targets.txt"
        assert os.path.isfile(targets_path), f"Targets file {targets_path} does not exist"

    def test_targets_file_readable(self):
        """Verify targets.txt is readable."""
        targets_path = "/home/user/scanner/targets.txt"
        assert os.access(targets_path, os.R_OK), f"Targets file {targets_path} is not readable"

    def test_targets_file_has_10_hosts(self):
        """Verify targets.txt contains 10 hosts."""
        targets_path = "/home/user/scanner/targets.txt"
        with open(targets_path, 'r') as f:
            lines = [line.strip() for line in f if line.strip()]
        assert len(lines) == 10, f"Expected 10 hosts in targets.txt, found {len(lines)}"

    def test_targets_are_localhost_addresses(self):
        """Verify all targets are 127.0.0.x addresses."""
        targets_path = "/home/user/scanner/targets.txt"
        with open(targets_path, 'r') as f:
            lines = [line.strip() for line in f if line.strip()]

        for line in lines:
            assert line.startswith("127.0.0."), \
                f"Expected 127.0.0.x address, found: {line}"


class TestScriptContent:
    """Test that the script has the expected initial implementation."""

    def test_script_uses_socket(self):
        """Verify script uses socket module for connections."""
        script_path = "/home/user/scanner/scan.py"
        with open(script_path, 'r') as f:
            content = f.read()

        assert 'socket' in content, "Script does not appear to use socket module"

    def test_script_uses_connect(self):
        """Verify script uses connect or connect_ex for port checking."""
        script_path = "/home/user/scanner/scan.py"
        with open(script_path, 'r') as f:
            content = f.read()

        assert 'connect' in content, "Script does not appear to use connect/connect_ex"

    def test_script_checks_ports_1_to_500(self):
        """Verify script is configured to check ports 1-500."""
        script_path = "/home/user/scanner/scan.py"
        with open(script_path, 'r') as f:
            content = f.read()

        # Check for port range indicators
        assert '500' in content or '501' in content, \
            "Script does not appear to check up to port 500"

    def test_script_has_timeout(self):
        """Verify script has a timeout configured (should be 0.5s)."""
        script_path = "/home/user/scanner/scan.py"
        with open(script_path, 'r') as f:
            content = f.read()

        assert 'timeout' in content.lower() or 'settimeout' in content.lower(), \
            "Script does not appear to have timeout configuration"


class TestDirectoryWritable:
    """Test that the scanner directory is writable."""

    def test_scanner_directory_writable(self):
        """Verify /home/user/scanner/ is writable."""
        scanner_dir = "/home/user/scanner"
        assert os.access(scanner_dir, os.W_OK), f"Directory {scanner_dir} is not writable"


class TestPythonEnvironment:
    """Test that Python 3.11+ is available with required modules."""

    def test_python3_available(self):
        """Verify python3 is available."""
        result = subprocess.run(
            ["which", "python3"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "python3 is not available in PATH"

    def test_python_version_311_or_higher(self):
        """Verify Python version is 3.11 or higher."""
        result = subprocess.run(
            ["python3", "-c", "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "Failed to get Python version"
        version = result.stdout.strip()
        major, minor = map(int, version.split('.'))
        assert (major, minor) >= (3, 11), f"Python version {version} is less than 3.11"

    def test_concurrent_futures_available(self):
        """Verify concurrent.futures module is available."""
        result = subprocess.run(
            ["python3", "-c", "import concurrent.futures"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "concurrent.futures module is not available"

    def test_threading_available(self):
        """Verify threading module is available."""
        result = subprocess.run(
            ["python3", "-c", "import threading"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "threading module is not available"

    def test_multiprocessing_available(self):
        """Verify multiprocessing module is available."""
        result = subprocess.run(
            ["python3", "-c", "import multiprocessing"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "multiprocessing module is not available"


class TestInitialScriptIsSequential:
    """Test that the initial script implementation is sequential (slow)."""

    def test_script_does_not_use_concurrent_futures(self):
        """Verify initial script does not use concurrent.futures (is sequential)."""
        script_path = "/home/user/scanner/scan.py"
        with open(script_path, 'r') as f:
            content = f.read()

        assert 'concurrent.futures' not in content, \
            "Initial script already uses concurrent.futures - should be sequential"

    def test_script_does_not_use_threadpoolexecutor(self):
        """Verify initial script does not use ThreadPoolExecutor."""
        script_path = "/home/user/scanner/scan.py"
        with open(script_path, 'r') as f:
            content = f.read()

        assert 'ThreadPoolExecutor' not in content, \
            "Initial script already uses ThreadPoolExecutor - should be sequential"

    def test_script_does_not_use_processpoolexecutor(self):
        """Verify initial script does not use ProcessPoolExecutor."""
        script_path = "/home/user/scanner/scan.py"
        with open(script_path, 'r') as f:
            content = f.read()

        assert 'ProcessPoolExecutor' not in content, \
            "Initial script already uses ProcessPoolExecutor - should be sequential"

    def test_script_has_for_loops(self):
        """Verify script uses for loops (sequential iteration pattern)."""
        script_path = "/home/user/scanner/scan.py"
        with open(script_path, 'r') as f:
            content = f.read()

        assert 'for ' in content, \
            "Script does not appear to use for loops for iteration"
