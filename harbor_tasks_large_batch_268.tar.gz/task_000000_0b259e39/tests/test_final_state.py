# test_final_state.py
"""
Tests to validate the final state after the student has completed the port scanner optimization task.
"""

import os
import subprocess
import re
import pytest


class TestScriptStillExists:
    """Test that the scanner script still exists and is valid."""

    def test_scan_script_exists(self):
        """Verify /home/user/scanner/scan.py still exists."""
        script_path = "/home/user/scanner/scan.py"
        assert os.path.isfile(script_path), f"Script {script_path} does not exist"

    def test_scan_script_valid_python(self):
        """Verify scan.py is valid Python syntax."""
        script_path = "/home/user/scanner/scan.py"
        result = subprocess.run(
            ["python3", "-m", "py_compile", script_path],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, f"Script {script_path} has syntax errors: {result.stderr}"


class TestTargetsFileUnchanged:
    """Test that targets.txt is unchanged."""

    def test_targets_file_exists(self):
        """Verify /home/user/scanner/targets.txt still exists."""
        targets_path = "/home/user/scanner/targets.txt"
        assert os.path.isfile(targets_path), f"Targets file {targets_path} does not exist"

    def test_targets_file_has_10_hosts(self):
        """Verify targets.txt still contains 10 hosts."""
        targets_path = "/home/user/scanner/targets.txt"
        with open(targets_path, 'r') as f:
            lines = [line.strip() for line in f if line.strip()]
        assert len(lines) == 10, f"Expected 10 hosts in targets.txt, found {len(lines)}. File should not be modified."

    def test_targets_are_localhost_addresses(self):
        """Verify all targets are still 127.0.0.x addresses."""
        targets_path = "/home/user/scanner/targets.txt"
        with open(targets_path, 'r') as f:
            lines = [line.strip() for line in f if line.strip()]

        for line in lines:
            assert line.startswith("127.0.0."), \
                f"Expected 127.0.0.x address, found: {line}. Targets file should not be modified."


class TestScriptStillUsesSocketConnections:
    """Test that the script still performs actual socket connections."""

    def test_script_uses_socket_or_connect(self):
        """Verify script still uses socket/connect for port checking."""
        script_path = "/home/user/scanner/scan.py"
        with open(script_path, 'r') as f:
            content = f.read()

        # Must still use socket connections
        result = subprocess.run(
            ["grep", "-E", "connect|socket", script_path],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            "Script must still use socket connections (connect/socket not found in script)"


class TestPortRangeUnchanged:
    """Test that the script still checks ports 1-500."""

    def test_script_still_checks_port_500(self):
        """Verify script is still configured to check up to port 500."""
        script_path = "/home/user/scanner/scan.py"
        with open(script_path, 'r') as f:
            content = f.read()

        # Should still reference port 500 or 501 (for range end)
        assert '500' in content or '501' in content, \
            "Script does not appear to check up to port 500 anymore. Port range should not be reduced."


class TestTimeoutNotCheated:
    """Test that the solution doesn't cheat by reducing timeout to near-zero."""

    def test_timeout_not_reduced_to_cheat(self):
        """Verify timeout wasn't reduced to bypass the slowness (must be >= 0.5s)."""
        script_path = "/home/user/scanner/scan.py"

        # Check for timeout values less than 0.5 (cheating)
        result = subprocess.run(
            ["grep", "-E", r"timeout\s*=\s*0\.[0-4]|timeout\s*=\s*0\b|settimeout\s*\(\s*0\.[0-4]|settimeout\s*\(\s*0\b"],
            capture_output=True,
            text=True,
            cwd="/home/user/scanner"
        )

        # Also check the file content directly for more patterns
        with open(script_path, 'r') as f:
            content = f.read().lower()

        # Look for suspicious low timeout values
        low_timeout_patterns = [
            r'timeout\s*=\s*0\.0[0-4]',
            r'timeout\s*=\s*0\.[0-4]\d*[^0-9]',
            r'settimeout\s*\(\s*0\.0[0-4]',
            r'settimeout\s*\(\s*0\.[0-4]\d*\)',
            r'timeout\s*=\s*0[^.]',
            r'settimeout\s*\(\s*0[^.]',
        ]

        for pattern in low_timeout_patterns:
            match = re.search(pattern, content)
            if match:
                # Allow 0.5 specifically
                matched_text = match.group(0)
                if '0.5' not in matched_text:
                    pytest.fail(f"Timeout appears to be reduced below 0.5s (found: {matched_text}). "
                               "Parallelism should be the fix, not reducing timeout.")


class TestScriptCompletesQuickly:
    """Test that the optimized script completes within 60 seconds."""

    def test_script_completes_within_60_seconds(self):
        """Verify the script completes within 60 seconds using timeout command."""
        script_path = "/home/user/scanner/scan.py"

        result = subprocess.run(
            ["timeout", "60", "python3", script_path],
            capture_output=True,
            text=True,
            cwd="/home/user/scanner"
        )

        # Exit code 124 means timeout killed it
        assert result.returncode != 124, \
            "Script did not complete within 60 seconds. It needs to be parallelized."

        # Exit code 0 means success
        assert result.returncode == 0, \
            f"Script exited with error code {result.returncode}. stderr: {result.stderr}"


class TestOutputFormatPreserved:
    """Test that the output format is still correct."""

    def test_output_format_for_open_ports(self):
        """Verify script would output in correct format for open ports.

        Since no services are running, we check the script contains the right format string.
        """
        script_path = "/home/user/scanner/scan.py"
        with open(script_path, 'r') as f:
            content = f.read()

        # Should still have the OPEN output format
        assert 'OPEN' in content, \
            "Script should still output 'OPEN: {host}:{port}' format for open ports"

    def test_no_unexpected_output_when_all_closed(self):
        """Verify script produces no OPEN lines when all ports are closed."""
        script_path = "/home/user/scanner/scan.py"

        result = subprocess.run(
            ["timeout", "60", "python3", script_path],
            capture_output=True,
            text=True,
            cwd="/home/user/scanner"
        )

        # Skip if script didn't complete
        if result.returncode == 124:
            pytest.skip("Script timed out, can't check output")

        # Since no services are running, there should be no OPEN lines
        stdout_lines = [line for line in result.stdout.strip().split('\n') if line.strip()]
        open_lines = [line for line in stdout_lines if 'OPEN' in line.upper()]

        # All ports should be closed, so no OPEN lines expected
        # (This validates the script actually ran and checked ports)
        # We allow some open lines in case system has something running,
        # but mainly we're checking the format is preserved
        for line in open_lines:
            # If there are any OPEN lines, they should be in correct format
            assert re.match(r'OPEN:\s*\d+\.\d+\.\d+\.\d+:\d+', line) or \
                   re.match(r'OPEN:\s*127\.0\.0\.\d+:\d+', line), \
                f"Output format incorrect. Expected 'OPEN: host:port', got: {line}"


class TestParallelizationImplemented:
    """Test that some form of parallelization was implemented."""

    def test_uses_parallelization_mechanism(self):
        """Verify script uses some parallelization (threads, processes, or async)."""
        script_path = "/home/user/scanner/scan.py"
        with open(script_path, 'r') as f:
            content = f.read()

        parallelization_indicators = [
            'concurrent.futures',
            'ThreadPoolExecutor',
            'ProcessPoolExecutor',
            'threading.Thread',
            'multiprocessing.Pool',
            'multiprocessing.Process',
            'asyncio',
            'Thread(',
            'Pool(',
            '.map(',
            '.submit(',
            'async def',
            'await ',
        ]

        found_parallelization = any(indicator in content for indicator in parallelization_indicators)

        assert found_parallelization, \
            "Script does not appear to use any parallelization mechanism. " \
            "Expected one of: concurrent.futures, threading, multiprocessing, or asyncio"
