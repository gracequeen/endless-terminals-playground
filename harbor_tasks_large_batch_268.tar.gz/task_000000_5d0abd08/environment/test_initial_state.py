# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the version bump and changelog update task.
"""

import os
import stat
import pytest


class TestDirectoryExists:
    """Test that the required directory exists and is writable."""

    def test_libutil_directory_exists(self):
        """Verify /home/user/libutil directory exists."""
        path = "/home/user/libutil"
        assert os.path.exists(path), f"Directory {path} does not exist"
        assert os.path.isdir(path), f"{path} exists but is not a directory"

    def test_libutil_directory_is_writable(self):
        """Verify /home/user/libutil directory is writable."""
        path = "/home/user/libutil"
        assert os.access(path, os.W_OK), f"Directory {path} is not writable"


class TestVersionFile:
    """Test the VERSION file initial state."""

    def test_version_file_exists(self):
        """Verify /home/user/libutil/VERSION file exists."""
        path = "/home/user/libutil/VERSION"
        assert os.path.exists(path), f"File {path} does not exist"
        assert os.path.isfile(path), f"{path} exists but is not a regular file"

    def test_version_file_contains_correct_version(self):
        """Verify VERSION file contains exactly '2.3.1' (no trailing newline)."""
        path = "/home/user/libutil/VERSION"
        with open(path, 'r') as f:
            content = f.read()
        assert content == "2.3.1", (
            f"VERSION file should contain exactly '2.3.1' but contains: {repr(content)}"
        )

    def test_version_file_is_writable(self):
        """Verify VERSION file is writable."""
        path = "/home/user/libutil/VERSION"
        assert os.access(path, os.W_OK), f"File {path} is not writable"


class TestChangelogFile:
    """Test the CHANGELOG.md file initial state."""

    def test_changelog_file_exists(self):
        """Verify /home/user/libutil/CHANGELOG.md file exists."""
        path = "/home/user/libutil/CHANGELOG.md"
        assert os.path.exists(path), f"File {path} does not exist"
        assert os.path.isfile(path), f"{path} exists but is not a regular file"

    def test_changelog_file_is_writable(self):
        """Verify CHANGELOG.md file is writable."""
        path = "/home/user/libutil/CHANGELOG.md"
        assert os.access(path, os.W_OK), f"File {path} is not writable"

    def test_changelog_has_header(self):
        """Verify CHANGELOG.md starts with '# Changelog' header."""
        path = "/home/user/libutil/CHANGELOG.md"
        with open(path, 'r') as f:
            content = f.read()
        lines = content.split('\n')
        assert len(lines) > 0, "CHANGELOG.md is empty"
        assert lines[0] == "# Changelog", (
            f"CHANGELOG.md should start with '# Changelog' but first line is: {repr(lines[0])}"
        )

    def test_changelog_has_231_entry(self):
        """Verify CHANGELOG.md contains the 2.3.1 entry."""
        path = "/home/user/libutil/CHANGELOG.md"
        with open(path, 'r') as f:
            content = f.read()
        expected_entry = "## 2.3.1 - Fixed memory leak in parser"
        assert expected_entry in content, (
            f"CHANGELOG.md should contain '{expected_entry}' but it doesn't. "
            f"Content: {repr(content)}"
        )

    def test_changelog_has_230_entry(self):
        """Verify CHANGELOG.md contains the 2.3.0 entry."""
        path = "/home/user/libutil/CHANGELOG.md"
        with open(path, 'r') as f:
            content = f.read()
        expected_entry = "## 2.3.0 - Initial stable release"
        assert expected_entry in content, (
            f"CHANGELOG.md should contain '{expected_entry}' but it doesn't. "
            f"Content: {repr(content)}"
        )

    def test_changelog_correct_structure(self):
        """Verify CHANGELOG.md has the expected structure."""
        path = "/home/user/libutil/CHANGELOG.md"
        with open(path, 'r') as f:
            content = f.read()

        expected_content = """# Changelog

## 2.3.1 - Fixed memory leak in parser
## 2.3.0 - Initial stable release"""

        assert content == expected_content, (
            f"CHANGELOG.md content doesn't match expected structure.\n"
            f"Expected:\n{repr(expected_content)}\n"
            f"Got:\n{repr(content)}"
        )

    def test_changelog_does_not_have_240_entry(self):
        """Verify CHANGELOG.md does NOT yet contain a 2.4.0 entry (initial state)."""
        path = "/home/user/libutil/CHANGELOG.md"
        with open(path, 'r') as f:
            content = f.read()
        assert "2.4.0" not in content, (
            "CHANGELOG.md should NOT contain '2.4.0' in initial state - "
            "this is what the student needs to add"
        )


class TestVersionFileDoesNotHaveNewVersion:
    """Verify the VERSION file doesn't already have the target version."""

    def test_version_is_not_already_240(self):
        """Verify VERSION file does NOT contain 2.4.0 (initial state check)."""
        path = "/home/user/libutil/VERSION"
        with open(path, 'r') as f:
            content = f.read()
        assert "2.4.0" not in content, (
            "VERSION file should NOT contain '2.4.0' in initial state - "
            "this is what the student needs to change it to"
        )
