# test_final_state.py
"""
Tests to validate the final state of the OS/filesystem after the student
has completed the version bump and changelog update task.
"""

import os
import subprocess
import pytest


class TestVersionFile:
    """Test the VERSION file final state."""

    def test_version_file_exists(self):
        """Verify /home/user/libutil/VERSION file still exists."""
        path = "/home/user/libutil/VERSION"
        assert os.path.exists(path), f"File {path} does not exist"
        assert os.path.isfile(path), f"{path} exists but is not a regular file"

    def test_version_file_contains_240(self):
        """Verify VERSION file contains '2.4.0' (with or without trailing newline)."""
        path = "/home/user/libutil/VERSION"
        with open(path, 'r') as f:
            content = f.read()
        # Strip whitespace to allow for trailing newline
        stripped = content.strip()
        assert stripped == "2.4.0", (
            f"VERSION file should contain '2.4.0' but contains: {repr(content)}"
        )

    def test_version_file_grep_240(self):
        """Anti-shortcut: grep -F '2.4.0' must match in VERSION file."""
        result = subprocess.run(
            ["grep", "-F", "2.4.0", "/home/user/libutil/VERSION"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "grep -F '2.4.0' /home/user/libutil/VERSION did not match. "
            "VERSION file must contain '2.4.0'"
        )


class TestChangelogFile:
    """Test the CHANGELOG.md file final state."""

    def test_changelog_file_exists(self):
        """Verify /home/user/libutil/CHANGELOG.md file still exists."""
        path = "/home/user/libutil/CHANGELOG.md"
        assert os.path.exists(path), f"File {path} does not exist"
        assert os.path.isfile(path), f"{path} exists but is not a regular file"

    def test_changelog_has_header(self):
        """Verify CHANGELOG.md still starts with '# Changelog' header."""
        path = "/home/user/libutil/CHANGELOG.md"
        with open(path, 'r') as f:
            content = f.read()
        lines = content.split('\n')
        assert len(lines) > 0, "CHANGELOG.md is empty"
        assert lines[0] == "# Changelog", (
            f"CHANGELOG.md should start with '# Changelog' but first line is: {repr(lines[0])}"
        )

    def test_changelog_has_240_entry(self):
        """Verify CHANGELOG.md contains the new 2.4.0 entry."""
        path = "/home/user/libutil/CHANGELOG.md"
        with open(path, 'r') as f:
            content = f.read()
        expected_entry = "## 2.4.0 - Added batch processing support"
        assert expected_entry in content, (
            f"CHANGELOG.md should contain '{expected_entry}' but it doesn't. "
            f"Content:\n{content}"
        )

    def test_changelog_has_231_entry(self):
        """Anti-shortcut: Verify CHANGELOG.md still contains the 2.3.1 entry."""
        path = "/home/user/libutil/CHANGELOG.md"
        with open(path, 'r') as f:
            content = f.read()
        expected_entry = "## 2.3.1 - Fixed memory leak in parser"
        assert expected_entry in content, (
            f"CHANGELOG.md should still contain '{expected_entry}' but it doesn't. "
            f"Old entries must be preserved. Content:\n{content}"
        )

    def test_changelog_has_230_entry(self):
        """Verify CHANGELOG.md still contains the 2.3.0 entry."""
        path = "/home/user/libutil/CHANGELOG.md"
        with open(path, 'r') as f:
            content = f.read()
        expected_entry = "## 2.3.0 - Initial stable release"
        assert expected_entry in content, (
            f"CHANGELOG.md should still contain '{expected_entry}' but it doesn't. "
            f"Old entries must be preserved. Content:\n{content}"
        )

    def test_changelog_grep_240(self):
        """Anti-shortcut: grep -F for 2.4.0 entry must match."""
        result = subprocess.run(
            ["grep", "-F", "## 2.4.0 - Added batch processing support", "/home/user/libutil/CHANGELOG.md"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "grep -F '## 2.4.0 - Added batch processing support' /home/user/libutil/CHANGELOG.md "
            "did not match. The new changelog entry must be present."
        )

    def test_changelog_grep_231(self):
        """Anti-shortcut: grep -F for 2.3.1 entry must match."""
        result = subprocess.run(
            ["grep", "-F", "## 2.3.1", "/home/user/libutil/CHANGELOG.md"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "grep -F '## 2.3.1' /home/user/libutil/CHANGELOG.md did not match. "
            "The old 2.3.1 entry must not be deleted."
        )

    def test_changelog_entry_order(self):
        """Verify the new 2.4.0 entry appears before the 2.3.1 entry."""
        path = "/home/user/libutil/CHANGELOG.md"
        with open(path, 'r') as f:
            content = f.read()

        pos_240 = content.find("## 2.4.0")
        pos_231 = content.find("## 2.3.1")
        pos_230 = content.find("## 2.3.0")

        assert pos_240 != -1, "2.4.0 entry not found in CHANGELOG.md"
        assert pos_231 != -1, "2.3.1 entry not found in CHANGELOG.md"
        assert pos_230 != -1, "2.3.0 entry not found in CHANGELOG.md"

        assert pos_240 < pos_231, (
            f"2.4.0 entry (at position {pos_240}) should appear before "
            f"2.3.1 entry (at position {pos_231}) in CHANGELOG.md"
        )
        assert pos_231 < pos_230, (
            f"2.3.1 entry (at position {pos_231}) should appear before "
            f"2.3.0 entry (at position {pos_230}) in CHANGELOG.md"
        )

    def test_changelog_240_after_header(self):
        """Verify the 2.4.0 entry appears after the header (line 3 area)."""
        path = "/home/user/libutil/CHANGELOG.md"
        with open(path, 'r') as f:
            lines = f.readlines()

        # Find the line with the 2.4.0 entry
        found_240_line = None
        for i, line in enumerate(lines):
            if "## 2.4.0 - Added batch processing support" in line:
                found_240_line = i
                break

        assert found_240_line is not None, "2.4.0 entry not found in CHANGELOG.md"

        # The header is on line 0, blank line on line 1, so 2.4.0 should be on line 2 (index 2)
        # But we'll be flexible - it should be after the header and before 2.3.1
        assert found_240_line > 0, (
            "2.4.0 entry should not be on the first line (that's the header)"
        )

        # Find 2.3.1 line
        found_231_line = None
        for i, line in enumerate(lines):
            if "## 2.3.1" in line:
                found_231_line = i
                break

        assert found_231_line is not None, "2.3.1 entry not found"
        assert found_240_line < found_231_line, (
            f"2.4.0 entry (line {found_240_line + 1}) should appear before "
            f"2.3.1 entry (line {found_231_line + 1})"
        )


class TestNoExtraFilesCreated:
    """Test that no unexpected files were created in the directory."""

    def test_only_expected_files_exist(self):
        """Verify only VERSION and CHANGELOG.md exist in /home/user/libutil."""
        path = "/home/user/libutil"
        expected_files = {"VERSION", "CHANGELOG.md"}

        actual_files = set(os.listdir(path))

        # Check that no unexpected files were created
        unexpected = actual_files - expected_files
        assert len(unexpected) == 0, (
            f"Unexpected files found in {path}: {unexpected}. "
            f"Only VERSION and CHANGELOG.md should exist."
        )

        # Check that expected files still exist
        missing = expected_files - actual_files
        assert len(missing) == 0, (
            f"Expected files missing from {path}: {missing}"
        )
