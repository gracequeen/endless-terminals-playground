# test_initial_state.py
"""
Tests to validate the initial state of the filesystem before the student
performs the chmod operation to lock down /home/user/docs/drafts.
"""

import os
import stat
import subprocess
import pytest


class TestInitialState:
    """Validate the initial state before the chmod operation."""

    DRAFTS_DIR = "/home/user/docs/drafts"
    INTERNAL_DIR = "/home/user/docs/drafts/internal"

    EXPECTED_FILES = [
        "/home/user/docs/drafts/q3-release.md",
        "/home/user/docs/drafts/internal/roadmap.md",
        "/home/user/docs/drafts/internal/pricing.txt",
    ]

    EXPECTED_DIRS = [
        "/home/user/docs/drafts",
        "/home/user/docs/drafts/internal",
    ]

    def test_drafts_directory_exists(self):
        """Verify /home/user/docs/drafts directory exists."""
        assert os.path.exists(self.DRAFTS_DIR), \
            f"Directory {self.DRAFTS_DIR} does not exist"
        assert os.path.isdir(self.DRAFTS_DIR), \
            f"{self.DRAFTS_DIR} exists but is not a directory"

    def test_internal_subdirectory_exists(self):
        """Verify /home/user/docs/drafts/internal subdirectory exists."""
        assert os.path.exists(self.INTERNAL_DIR), \
            f"Directory {self.INTERNAL_DIR} does not exist"
        assert os.path.isdir(self.INTERNAL_DIR), \
            f"{self.INTERNAL_DIR} exists but is not a directory"

    @pytest.mark.parametrize("filepath", EXPECTED_FILES)
    def test_expected_files_exist(self, filepath):
        """Verify all expected files exist."""
        assert os.path.exists(filepath), \
            f"File {filepath} does not exist"
        assert os.path.isfile(filepath), \
            f"{filepath} exists but is not a regular file"

    def test_drafts_directory_ownership(self):
        """Verify /home/user/docs/drafts is owned by user:user."""
        stat_info = os.stat(self.DRAFTS_DIR)
        # Get username and group name
        import pwd
        import grp
        owner = pwd.getpwuid(stat_info.st_uid).pw_name
        group = grp.getgrgid(stat_info.st_gid).gr_name

        assert owner == "user", \
            f"{self.DRAFTS_DIR} is owned by '{owner}', expected 'user'"
        assert group == "user", \
            f"{self.DRAFTS_DIR} has group '{group}', expected 'user'"

    @pytest.mark.parametrize("filepath", EXPECTED_FILES)
    def test_file_ownership(self, filepath):
        """Verify all files are owned by user:user."""
        import pwd
        import grp
        stat_info = os.stat(filepath)
        owner = pwd.getpwuid(stat_info.st_uid).pw_name
        group = grp.getgrgid(stat_info.st_gid).gr_name

        assert owner == "user", \
            f"{filepath} is owned by '{owner}', expected 'user'"
        assert group == "user", \
            f"{filepath} has group '{group}', expected 'user'"

    @pytest.mark.parametrize("dirpath", EXPECTED_DIRS)
    def test_directories_have_755_permissions(self, dirpath):
        """Verify directories have 755 permissions (world-readable)."""
        stat_info = os.stat(dirpath)
        mode = stat.S_IMODE(stat_info.st_mode)
        octal_mode = oct(mode)[-3:]

        assert octal_mode == "755", \
            f"Directory {dirpath} has permissions {octal_mode}, expected 755 (world-readable)"

    @pytest.mark.parametrize("filepath", EXPECTED_FILES)
    def test_files_have_644_permissions(self, filepath):
        """Verify files have 644 permissions (world-readable)."""
        stat_info = os.stat(filepath)
        mode = stat.S_IMODE(stat_info.st_mode)
        octal_mode = oct(mode)[-3:]

        assert octal_mode == "644", \
            f"File {filepath} has permissions {octal_mode}, expected 644 (world-readable)"

    def test_drafts_directory_is_writable_by_agent(self):
        """Verify /home/user/docs/drafts is writable by the current user."""
        assert os.access(self.DRAFTS_DIR, os.W_OK), \
            f"Directory {self.DRAFTS_DIR} is not writable by the current user"

    @pytest.mark.parametrize("filepath", EXPECTED_FILES)
    def test_files_are_writable_by_agent(self, filepath):
        """Verify all files are writable by the current user."""
        assert os.access(filepath, os.W_OK), \
            f"File {filepath} is not writable by the current user"

    def test_parent_docs_directory_exists(self):
        """Verify parent /home/user/docs directory exists."""
        parent_dir = "/home/user/docs"
        assert os.path.exists(parent_dir), \
            f"Parent directory {parent_dir} does not exist"
        assert os.path.isdir(parent_dir), \
            f"{parent_dir} exists but is not a directory"

    def test_files_are_world_readable(self):
        """Verify files are currently world-readable (the problem to be fixed)."""
        for filepath in self.EXPECTED_FILES:
            stat_info = os.stat(filepath)
            mode = stat.S_IMODE(stat_info.st_mode)
            # Check if others have read permission (o+r)
            has_other_read = bool(mode & stat.S_IROTH)
            assert has_other_read, \
                f"File {filepath} is not world-readable - initial state may be incorrect"

    def test_directories_are_world_readable(self):
        """Verify directories are currently world-readable (the problem to be fixed)."""
        for dirpath in self.EXPECTED_DIRS:
            stat_info = os.stat(dirpath)
            mode = stat.S_IMODE(stat_info.st_mode)
            # Check if others have read and execute permission (o+rx)
            has_other_read = bool(mode & stat.S_IROTH)
            has_other_exec = bool(mode & stat.S_IXOTH)
            assert has_other_read and has_other_exec, \
                f"Directory {dirpath} is not world-readable/executable - initial state may be incorrect"

    def test_stat_command_available(self):
        """Verify stat command is available for verification."""
        result = subprocess.run(
            ["which", "stat"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            "stat command is not available on this system"

    def test_find_command_available(self):
        """Verify find command is available for verification."""
        result = subprocess.run(
            ["which", "find"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            "find command is not available on this system"

    def test_chmod_command_available(self):
        """Verify chmod command is available for the task."""
        result = subprocess.run(
            ["which", "chmod"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            "chmod command is not available on this system"
