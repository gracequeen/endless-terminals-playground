# test_final_state.py
"""
Tests to validate the final state of the filesystem after the student
has performed the chmod operation to lock down /home/user/docs/drafts.
"""

import os
import stat
import subprocess
import pytest


class TestFinalState:
    """Validate the final state after the chmod operation."""

    DRAFTS_DIR = "/home/user/docs/drafts"
    INTERNAL_DIR = "/home/user/docs/drafts/internal"
    PARENT_DIR = "/home/user/docs"

    EXPECTED_FILES = [
        "/home/user/docs/drafts/q3-release.md",
        "/home/user/docs/drafts/internal/roadmap.md",
        "/home/user/docs/drafts/internal/pricing.txt",
    ]

    EXPECTED_DIRS = [
        "/home/user/docs/drafts",
        "/home/user/docs/drafts/internal",
    ]

    def test_drafts_directory_still_exists(self):
        """Verify /home/user/docs/drafts directory still exists."""
        assert os.path.exists(self.DRAFTS_DIR), \
            f"Directory {self.DRAFTS_DIR} no longer exists - it should not have been deleted"
        assert os.path.isdir(self.DRAFTS_DIR), \
            f"{self.DRAFTS_DIR} is not a directory"

    def test_internal_subdirectory_still_exists(self):
        """Verify /home/user/docs/drafts/internal subdirectory still exists."""
        assert os.path.exists(self.INTERNAL_DIR), \
            f"Directory {self.INTERNAL_DIR} no longer exists - it should not have been deleted"
        assert os.path.isdir(self.INTERNAL_DIR), \
            f"{self.INTERNAL_DIR} is not a directory"

    @pytest.mark.parametrize("filepath", EXPECTED_FILES)
    def test_expected_files_still_exist(self, filepath):
        """Verify all expected files still exist."""
        assert os.path.exists(filepath), \
            f"File {filepath} no longer exists - it should not have been deleted"
        assert os.path.isfile(filepath), \
            f"{filepath} is not a regular file"

    def test_drafts_directory_has_700_permissions(self):
        """Verify /home/user/docs/drafts has 700 permissions (rwx------)."""
        stat_info = os.stat(self.DRAFTS_DIR)
        mode = stat.S_IMODE(stat_info.st_mode)
        octal_mode = oct(mode)[-3:]

        assert octal_mode == "700", \
            f"Directory {self.DRAFTS_DIR} has permissions {octal_mode}, expected 700 (owner-only access)"

    @pytest.mark.parametrize("dirpath", EXPECTED_DIRS)
    def test_all_directories_have_700_permissions(self, dirpath):
        """Verify all directories under drafts have 700 permissions."""
        stat_info = os.stat(dirpath)
        mode = stat.S_IMODE(stat_info.st_mode)
        octal_mode = oct(mode)[-3:]

        assert octal_mode == "700", \
            f"Directory {dirpath} has permissions {octal_mode}, expected 700 (owner-only access)"

    @pytest.mark.parametrize("filepath", EXPECTED_FILES)
    def test_all_files_have_600_permissions(self, filepath):
        """Verify all files under drafts have 600 permissions."""
        stat_info = os.stat(filepath)
        mode = stat.S_IMODE(stat_info.st_mode)
        octal_mode = oct(mode)[-3:]

        assert octal_mode == "600", \
            f"File {filepath} has permissions {octal_mode}, expected 600 (owner-only read/write)"

    def test_roadmap_file_has_600_permissions_anti_shortcut(self):
        """
        Anti-shortcut guard: Specifically check that the nested file
        /home/user/docs/drafts/internal/roadmap.md has 600 permissions.
        This ensures the chmod was applied recursively.
        """
        filepath = "/home/user/docs/drafts/internal/roadmap.md"
        stat_info = os.stat(filepath)
        mode = stat.S_IMODE(stat_info.st_mode)
        octal_mode = oct(mode)[-3:]

        assert octal_mode == "600", \
            f"Nested file {filepath} has permissions {octal_mode}, expected 600. " \
            "This suggests chmod was not applied recursively."

    def test_drafts_directory_ownership_unchanged(self):
        """Verify /home/user/docs/drafts is still owned by user:user."""
        import pwd
        import grp
        stat_info = os.stat(self.DRAFTS_DIR)
        owner = pwd.getpwuid(stat_info.st_uid).pw_name
        group = grp.getgrgid(stat_info.st_gid).gr_name

        assert owner == "user", \
            f"{self.DRAFTS_DIR} is owned by '{owner}', expected 'user' (ownership should not change)"
        assert group == "user", \
            f"{self.DRAFTS_DIR} has group '{group}', expected 'user' (ownership should not change)"

    @pytest.mark.parametrize("filepath", EXPECTED_FILES)
    def test_file_ownership_unchanged(self, filepath):
        """Verify all files are still owned by user:user."""
        import pwd
        import grp
        stat_info = os.stat(filepath)
        owner = pwd.getpwuid(stat_info.st_uid).pw_name
        group = grp.getgrgid(stat_info.st_gid).gr_name

        assert owner == "user", \
            f"{filepath} is owned by '{owner}', expected 'user' (ownership should not change)"
        assert group == "user", \
            f"{filepath} has group '{group}', expected 'user' (ownership should not change)"

    @pytest.mark.parametrize("dirpath", EXPECTED_DIRS)
    def test_directory_ownership_unchanged(self, dirpath):
        """Verify all directories are still owned by user:user."""
        import pwd
        import grp
        stat_info = os.stat(dirpath)
        owner = pwd.getpwuid(stat_info.st_uid).pw_name
        group = grp.getgrgid(stat_info.st_gid).gr_name

        assert owner == "user", \
            f"{dirpath} is owned by '{owner}', expected 'user' (ownership should not change)"
        assert group == "user", \
            f"{dirpath} has group '{group}', expected 'user' (ownership should not change)"

    def test_no_world_readable_files(self):
        """Verify no files under drafts are world-readable."""
        for filepath in self.EXPECTED_FILES:
            stat_info = os.stat(filepath)
            mode = stat.S_IMODE(stat_info.st_mode)
            has_other_read = bool(mode & stat.S_IROTH)
            assert not has_other_read, \
                f"File {filepath} is still world-readable - permissions not properly locked down"

    def test_no_world_readable_directories(self):
        """Verify no directories under drafts are world-readable."""
        for dirpath in self.EXPECTED_DIRS:
            stat_info = os.stat(dirpath)
            mode = stat.S_IMODE(stat_info.st_mode)
            has_other_read = bool(mode & stat.S_IROTH)
            has_other_exec = bool(mode & stat.S_IXOTH)
            assert not has_other_read, \
                f"Directory {dirpath} is still world-readable - permissions not properly locked down"
            assert not has_other_exec, \
                f"Directory {dirpath} is still world-executable - permissions not properly locked down"

    def test_no_group_readable_files(self):
        """Verify no files under drafts are group-readable."""
        for filepath in self.EXPECTED_FILES:
            stat_info = os.stat(filepath)
            mode = stat.S_IMODE(stat_info.st_mode)
            has_group_read = bool(mode & stat.S_IRGRP)
            assert not has_group_read, \
                f"File {filepath} is still group-readable - permissions not properly locked down"

    def test_no_group_readable_directories(self):
        """Verify no directories under drafts are group-readable."""
        for dirpath in self.EXPECTED_DIRS:
            stat_info = os.stat(dirpath)
            mode = stat.S_IMODE(stat_info.st_mode)
            has_group_read = bool(mode & stat.S_IRGRP)
            has_group_exec = bool(mode & stat.S_IXGRP)
            assert not has_group_read, \
                f"Directory {dirpath} is still group-readable - permissions not properly locked down"
            assert not has_group_exec, \
                f"Directory {dirpath} is still group-executable - permissions not properly locked down"

    def test_stat_command_verification_directories(self):
        """Verify permissions using stat command for directories."""
        result = subprocess.run(
            ["find", self.DRAFTS_DIR, "-type", "d", "-exec", "stat", "-c", "%a", "{}", ";"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            f"Failed to run stat command on directories: {result.stderr}"

        permissions = result.stdout.strip().split('\n')
        for perm in permissions:
            assert perm == "700", \
                f"Found directory with permissions {perm}, expected all directories to have 700"

    def test_stat_command_verification_files(self):
        """Verify permissions using stat command for files."""
        result = subprocess.run(
            ["find", self.DRAFTS_DIR, "-type", "f", "-exec", "stat", "-c", "%a", "{}", ";"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            f"Failed to run stat command on files: {result.stderr}"

        permissions = result.stdout.strip().split('\n')
        for perm in permissions:
            assert perm == "600", \
                f"Found file with permissions {perm}, expected all files to have 600"

    def test_parent_directory_permissions_unchanged(self):
        """
        Verify parent /home/user/docs directory permissions were not changed.
        This is an invariant - only the drafts folder and its contents should be modified.
        """
        # We just check that it's not 700 (which would indicate accidental modification)
        # and that it still exists and is accessible
        assert os.path.exists(self.PARENT_DIR), \
            f"Parent directory {self.PARENT_DIR} no longer exists"
        assert os.path.isdir(self.PARENT_DIR), \
            f"{self.PARENT_DIR} is not a directory"

        stat_info = os.stat(self.PARENT_DIR)
        mode = stat.S_IMODE(stat_info.st_mode)
        octal_mode = oct(mode)[-3:]

        # Parent should NOT have been changed to 700
        # It should remain at its original permissions (likely 755 or similar)
        assert octal_mode != "700" or self.PARENT_DIR == self.DRAFTS_DIR, \
            f"Parent directory {self.PARENT_DIR} appears to have been modified to 700 - " \
            "only /home/user/docs/drafts and its contents should be changed"
