Experiment tracker at /home/user/mlops/track.py is supposed to log solver runs to /home/user/mlops/runs.db — solver name, params, objective value, that kind of thing. It was working last week but now every run just inserts NULL for the objective. The solver itself is fine, I ran it manually and it prints the result to stdout like normal. Something in the pipeline between solver output and db insert is eating the value.

    There's a wrapper script, a parser module, and the tracker itself — not sure which one's broken. Just need the objective values actually landing in the database again.
