# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the debugging task for the MLOps experiment tracker.
"""

import os
import subprocess
import sqlite3
import pytest
import stat


MLOPS_DIR = "/home/user/mlops"
TRACK_PY = os.path.join(MLOPS_DIR, "track.py")
WRAPPER_SH = os.path.join(MLOPS_DIR, "wrapper.sh")
PARSER_PY = os.path.join(MLOPS_DIR, "parser.py")
SOLVER = os.path.join(MLOPS_DIR, "solver")
RUNS_DB = os.path.join(MLOPS_DIR, "runs.db")
CONFIG_YAML = os.path.join(MLOPS_DIR, "config.yaml")


class TestDirectoryStructure:
    """Test that the mlops directory and required files exist."""

    def test_mlops_directory_exists(self):
        assert os.path.isdir(MLOPS_DIR), f"Directory {MLOPS_DIR} does not exist"

    def test_track_py_exists(self):
        assert os.path.isfile(TRACK_PY), f"File {TRACK_PY} does not exist"

    def test_wrapper_sh_exists(self):
        assert os.path.isfile(WRAPPER_SH), f"File {WRAPPER_SH} does not exist"

    def test_parser_py_exists(self):
        assert os.path.isfile(PARSER_PY), f"File {PARSER_PY} does not exist"

    def test_solver_exists(self):
        assert os.path.isfile(SOLVER), f"File {SOLVER} does not exist"

    def test_runs_db_exists(self):
        assert os.path.isfile(RUNS_DB), f"File {RUNS_DB} does not exist"

    def test_config_yaml_exists(self):
        assert os.path.isfile(CONFIG_YAML), f"File {CONFIG_YAML} does not exist"


class TestFilePermissions:
    """Test that files have appropriate permissions."""

    def test_solver_is_executable(self):
        assert os.access(SOLVER, os.X_OK), f"Solver {SOLVER} is not executable"

    def test_wrapper_sh_is_executable(self):
        assert os.access(WRAPPER_SH, os.X_OK), f"Wrapper {WRAPPER_SH} is not executable"

    def test_files_are_writable(self):
        for filepath in [TRACK_PY, WRAPPER_SH, PARSER_PY, CONFIG_YAML, RUNS_DB]:
            assert os.access(filepath, os.W_OK), f"File {filepath} is not writable"


class TestSolverBehavior:
    """Test that the solver binary works correctly."""

    def test_solver_runs_successfully(self):
        result = subprocess.run([SOLVER], capture_output=True, text=True)
        assert result.returncode == 0, f"Solver failed with return code {result.returncode}"

    def test_solver_outputs_expected_format(self):
        result = subprocess.run([SOLVER], capture_output=True, text=True)
        output = result.stdout

        assert "GLOP Solver" in output, "Solver output missing 'GLOP Solver' header"
        assert "Status: OPTIMAL" in output, "Solver output missing 'Status: OPTIMAL'"
        assert "Objective: 42.5" in output, "Solver output missing 'Objective: 42.5'"
        assert "Iterations:" in output, "Solver output missing 'Iterations:' line"

    def test_solver_uses_standard_format(self):
        """Verify solver outputs in standard format (Objective: <value>), not verbose format."""
        result = subprocess.run([SOLVER], capture_output=True, text=True)
        output = result.stdout

        # Standard format uses "Objective: <value>"
        assert "Objective:" in output, "Solver should output in standard format with 'Objective:'"
        # Verbose format would use "OBJ_VALUE="
        assert "OBJ_VALUE=" not in output, "Solver should NOT output in verbose format"


class TestDatabaseState:
    """Test the SQLite database structure and initial data."""

    def test_database_is_valid_sqlite(self):
        try:
            conn = sqlite3.connect(RUNS_DB)
            cursor = conn.cursor()
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
            conn.close()
        except sqlite3.Error as e:
            pytest.fail(f"Database {RUNS_DB} is not a valid SQLite database: {e}")

    def test_runs_table_exists(self):
        conn = sqlite3.connect(RUNS_DB)
        cursor = conn.cursor()
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='runs'")
        result = cursor.fetchone()
        conn.close()
        assert result is not None, "Table 'runs' does not exist in database"

    def test_runs_table_has_correct_schema(self):
        conn = sqlite3.connect(RUNS_DB)
        cursor = conn.cursor()
        cursor.execute("PRAGMA table_info(runs)")
        columns = {row[1]: row[2] for row in cursor.fetchall()}
        conn.close()

        expected_columns = {
            'id': 'INTEGER',
            'solver': 'TEXT',
            'params': 'TEXT',
            'objective': 'REAL',
            'timestamp': 'TEXT'
        }

        for col_name, col_type in expected_columns.items():
            assert col_name in columns, f"Column '{col_name}' missing from runs table"
            assert columns[col_name].upper() == col_type.upper(), \
                f"Column '{col_name}' has type '{columns[col_name]}', expected '{col_type}'"

    def test_runs_table_has_five_rows(self):
        conn = sqlite3.connect(RUNS_DB)
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM runs")
        count = cursor.fetchone()[0]
        conn.close()
        assert count == 5, f"Expected 5 rows in runs table, found {count}"

    def test_all_existing_rows_have_null_objective(self):
        """Verify the bug state: all existing rows have NULL objectives."""
        conn = sqlite3.connect(RUNS_DB)
        cursor = conn.cursor()
        cursor.execute("SELECT id, objective FROM runs")
        rows = cursor.fetchall()
        conn.close()

        for row_id, objective in rows:
            assert objective is None, \
                f"Row {row_id} has objective={objective}, expected NULL (this is the bug state)"


class TestConfigState:
    """Test the configuration file state (the source of the bug)."""

    def test_config_yaml_is_readable(self):
        with open(CONFIG_YAML, 'r') as f:
            content = f.read()
        assert len(content) > 0, "config.yaml is empty"

    def test_config_has_output_format_verbose(self):
        """Verify the bug: config has output_format set to verbose."""
        with open(CONFIG_YAML, 'r') as f:
            content = f.read()

        # The bug is that output_format is set to "verbose" when solver outputs "standard"
        assert "verbose" in content.lower(), \
            "config.yaml should have output_format set to 'verbose' (this is the bug)"

    def test_config_has_solver_path(self):
        with open(CONFIG_YAML, 'r') as f:
            content = f.read()
        assert "solver" in content.lower(), "config.yaml should reference the solver"


class TestParserModule:
    """Test that parser.py exists and has the expected structure."""

    def test_parser_is_valid_python(self):
        result = subprocess.run(
            ["python3", "-m", "py_compile", PARSER_PY],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, f"parser.py has syntax errors: {result.stderr}"

    def test_parser_has_parsing_logic(self):
        with open(PARSER_PY, 'r') as f:
            content = f.read()

        # Parser should have both standard and verbose mode handling
        assert "standard" in content.lower() or "Objective:" in content, \
            "parser.py should have standard format parsing"
        assert "verbose" in content.lower() or "OBJ_VALUE" in content, \
            "parser.py should have verbose format parsing"


class TestTrackPy:
    """Test that track.py exists and is valid Python."""

    def test_track_is_valid_python(self):
        result = subprocess.run(
            ["python3", "-m", "py_compile", TRACK_PY],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, f"track.py has syntax errors: {result.stderr}"


class TestWrapperScript:
    """Test that wrapper.sh is a valid shell script."""

    def test_wrapper_is_shell_script(self):
        with open(WRAPPER_SH, 'r') as f:
            first_line = f.readline()
        assert first_line.startswith("#!") and ("sh" in first_line or "bash" in first_line), \
            "wrapper.sh should be a shell script with proper shebang"


class TestBugReproduction:
    """Test that the bug can be reproduced - running track.py inserts NULL."""

    def test_current_tracker_inserts_null(self):
        """Verify the bug: running track.py currently inserts NULL for objective."""
        # Get current row count
        conn = sqlite3.connect(RUNS_DB)
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM runs")
        initial_count = cursor.fetchone()[0]
        conn.close()

        # Run the tracker
        result = subprocess.run(
            ["python3", TRACK_PY],
            capture_output=True,
            text=True,
            cwd=MLOPS_DIR
        )

        # Check if a new row was inserted
        conn = sqlite3.connect(RUNS_DB)
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM runs")
        new_count = cursor.fetchone()[0]

        if new_count > initial_count:
            # A row was inserted, check if objective is NULL
            cursor.execute("SELECT objective FROM runs ORDER BY id DESC LIMIT 1")
            objective = cursor.fetchone()[0]
            conn.close()

            # Clean up: remove the test row to restore initial state
            conn = sqlite3.connect(RUNS_DB)
            cursor = conn.cursor()
            cursor.execute("DELETE FROM runs WHERE id = (SELECT MAX(id) FROM runs)")
            conn.commit()
            conn.close()

            assert objective is None, \
                f"Bug not reproduced: expected NULL objective, got {objective}"
        else:
            conn.close()
            # If no row was inserted, that's also a valid bug state
            # (the script might fail before insertion)
            pass


class TestPythonEnvironment:
    """Test that required Python packages are available."""

    def test_python3_available(self):
        result = subprocess.run(["python3", "--version"], capture_output=True, text=True)
        assert result.returncode == 0, "Python 3 is not available"

    def test_sqlite3_module_available(self):
        result = subprocess.run(
            ["python3", "-c", "import sqlite3"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "sqlite3 module is not available"

    def test_yaml_module_available(self):
        result = subprocess.run(
            ["python3", "-c", "import yaml"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "PyYAML module is not available"
