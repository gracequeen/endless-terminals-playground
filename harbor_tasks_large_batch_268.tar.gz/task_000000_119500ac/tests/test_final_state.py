# test_final_state.py
"""
Tests to validate the final state of the OS/filesystem after the student
has fixed the MLOps experiment tracker bug.
"""

import os
import subprocess
import sqlite3
import pytest
import hashlib


MLOPS_DIR = "/home/user/mlops"
TRACK_PY = os.path.join(MLOPS_DIR, "track.py")
WRAPPER_SH = os.path.join(MLOPS_DIR, "wrapper.sh")
PARSER_PY = os.path.join(MLOPS_DIR, "parser.py")
SOLVER = os.path.join(MLOPS_DIR, "solver")
RUNS_DB = os.path.join(MLOPS_DIR, "runs.db")
CONFIG_YAML = os.path.join(MLOPS_DIR, "config.yaml")


class TestDirectoryStructure:
    """Test that the mlops directory and required files still exist."""

    def test_mlops_directory_exists(self):
        assert os.path.isdir(MLOPS_DIR), f"Directory {MLOPS_DIR} does not exist"

    def test_track_py_exists(self):
        assert os.path.isfile(TRACK_PY), f"File {TRACK_PY} does not exist"

    def test_wrapper_sh_exists(self):
        assert os.path.isfile(WRAPPER_SH), f"File {WRAPPER_SH} does not exist"

    def test_parser_py_exists(self):
        assert os.path.isfile(PARSER_PY), f"File {PARSER_PY} does not exist"

    def test_solver_exists(self):
        assert os.path.isfile(SOLVER), f"File {SOLVER} does not exist"

    def test_runs_db_exists(self):
        assert os.path.isfile(RUNS_DB), f"File {RUNS_DB} does not exist"

    def test_config_yaml_exists(self):
        assert os.path.isfile(CONFIG_YAML), f"File {CONFIG_YAML} does not exist"


class TestDatabaseSchemaPreserved:
    """Test that the database schema is unchanged."""

    def test_runs_table_exists(self):
        conn = sqlite3.connect(RUNS_DB)
        cursor = conn.cursor()
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='runs'")
        result = cursor.fetchone()
        conn.close()
        assert result is not None, "Table 'runs' does not exist in database"

    def test_runs_table_has_correct_schema(self):
        conn = sqlite3.connect(RUNS_DB)
        cursor = conn.cursor()
        cursor.execute("PRAGMA table_info(runs)")
        columns = {row[1]: row[2].upper() for row in cursor.fetchall()}
        conn.close()

        expected_columns = {
            'id': 'INTEGER',
            'solver': 'TEXT',
            'params': 'TEXT',
            'objective': 'REAL',
            'timestamp': 'TEXT'
        }

        for col_name, col_type in expected_columns.items():
            assert col_name in columns, f"Column '{col_name}' missing from runs table"
            assert columns[col_name] == col_type, \
                f"Column '{col_name}' has type '{columns[col_name]}', expected '{col_type}'"


class TestExistingDataPreserved:
    """Test that the original 5 rows are preserved."""

    def test_at_least_five_rows_exist(self):
        """Ensure the original 5 rows were not deleted."""
        conn = sqlite3.connect(RUNS_DB)
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM runs")
        count = cursor.fetchone()[0]
        conn.close()
        assert count >= 5, f"Expected at least 5 rows in runs table (original data), found {count}"


class TestTrackerFunctionality:
    """Test that running track.py now correctly inserts objective values."""

    def test_track_py_runs_successfully(self):
        """track.py should exit with code 0."""
        result = subprocess.run(
            ["python3", TRACK_PY],
            capture_output=True,
            text=True,
            cwd=MLOPS_DIR
        )
        assert result.returncode == 0, \
            f"track.py failed with return code {result.returncode}. stderr: {result.stderr}"

    def test_track_py_inserts_correct_objective(self):
        """Running track.py should insert a row with objective=42.5 (not NULL)."""
        # Get current row count
        conn = sqlite3.connect(RUNS_DB)
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM runs")
        initial_count = cursor.fetchone()[0]
        conn.close()

        # Run the tracker
        result = subprocess.run(
            ["python3", TRACK_PY],
            capture_output=True,
            text=True,
            cwd=MLOPS_DIR
        )
        assert result.returncode == 0, \
            f"track.py failed with return code {result.returncode}. stderr: {result.stderr}"

        # Check the latest row
        conn = sqlite3.connect(RUNS_DB)
        cursor = conn.cursor()
        cursor.execute("SELECT objective FROM runs ORDER BY id DESC LIMIT 1")
        row = cursor.fetchone()
        conn.close()

        assert row is not None, "No rows found in runs table after running track.py"
        objective = row[0]
        assert objective is not None, \
            "Objective value is still NULL - the bug has not been fixed"
        assert abs(objective - 42.5) < 0.001, \
            f"Expected objective to be 42.5, got {objective}"

    def test_sqlite_command_returns_correct_value(self):
        """Verify using sqlite3 command line that the latest objective is 42.5."""
        # First run track.py to ensure there's a new row
        subprocess.run(
            ["python3", TRACK_PY],
            capture_output=True,
            text=True,
            cwd=MLOPS_DIR
        )

        # Use sqlite3 command to check
        result = subprocess.run(
            ["sqlite3", RUNS_DB, "SELECT objective FROM runs ORDER BY id DESC LIMIT 1"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, f"sqlite3 command failed: {result.stderr}"

        output = result.stdout.strip()
        assert output != "" and output.lower() != "null", \
            f"Objective is NULL or empty - bug not fixed. Got: '{output}'"

        try:
            value = float(output)
            assert abs(value - 42.5) < 0.001, \
                f"Expected objective 42.5, got {value}"
        except ValueError:
            pytest.fail(f"Could not parse objective value as float: '{output}'")


class TestNoHardcodedValues:
    """Test that the fix doesn't hardcode 42.5."""

    def test_no_hardcoded_42_5_in_track_py(self):
        """track.py should not contain hardcoded 42.5."""
        with open(TRACK_PY, 'r') as f:
            content = f.read()
        assert "42.5" not in content, \
            "track.py contains hardcoded '42.5' - this is not a valid fix"

    def test_no_hardcoded_42_5_in_parser_py(self):
        """parser.py should not contain hardcoded 42.5."""
        with open(PARSER_PY, 'r') as f:
            content = f.read()
        assert "42.5" not in content, \
            "parser.py contains hardcoded '42.5' - this is not a valid fix"

    def test_no_hardcoded_42_5_in_config_yaml(self):
        """config.yaml should not contain hardcoded 42.5."""
        with open(CONFIG_YAML, 'r') as f:
            content = f.read()
        assert "42.5" not in content, \
            "config.yaml contains hardcoded '42.5' - this is not a valid fix"

    def test_grep_finds_no_hardcoded_values(self):
        """grep command should find no matches for 42.5 in the fix files."""
        result = subprocess.run(
            ["grep", "-E", r"42\.5", TRACK_PY, PARSER_PY, CONFIG_YAML],
            capture_output=True,
            text=True
        )
        # grep returns 1 if no matches found (which is what we want)
        assert result.returncode == 1, \
            f"Found hardcoded '42.5' in files: {result.stdout}"


class TestSolverUnchanged:
    """Test that the solver binary was not modified."""

    def test_solver_still_outputs_correct_format(self):
        """Solver should still output in standard format."""
        result = subprocess.run([SOLVER], capture_output=True, text=True)
        assert result.returncode == 0, f"Solver failed: {result.stderr}"

        output = result.stdout
        assert "GLOP Solver" in output, "Solver output changed - should contain 'GLOP Solver'"
        assert "Status: OPTIMAL" in output, "Solver output changed - should contain 'Status: OPTIMAL'"
        assert "Objective: 42.5" in output, "Solver output changed - should contain 'Objective: 42.5'"
        assert "Iterations:" in output, "Solver output changed - should contain 'Iterations:'"

    def test_solver_is_executable(self):
        """Solver should still be executable."""
        assert os.access(SOLVER, os.X_OK), f"Solver {SOLVER} is no longer executable"


class TestTrackPyCoreLogicPreserved:
    """Test that track.py still uses wrapper, parser, and db insert."""

    def test_track_py_imports_or_uses_parser(self):
        """track.py should still reference the parser module."""
        with open(TRACK_PY, 'r') as f:
            content = f.read()
        assert "parser" in content.lower(), \
            "track.py no longer references parser - core logic may have been removed"

    def test_track_py_uses_database(self):
        """track.py should still use sqlite/database operations."""
        with open(TRACK_PY, 'r') as f:
            content = f.read()
        assert "sqlite" in content.lower() or "runs.db" in content or "INSERT" in content.upper(), \
            "track.py no longer appears to use the database"

    def test_track_py_is_valid_python(self):
        """track.py should still be valid Python."""
        result = subprocess.run(
            ["python3", "-m", "py_compile", TRACK_PY],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, f"track.py has syntax errors: {result.stderr}"

    def test_parser_py_is_valid_python(self):
        """parser.py should still be valid Python."""
        result = subprocess.run(
            ["python3", "-m", "py_compile", PARSER_PY],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, f"parser.py has syntax errors: {result.stderr}"


class TestFixIsGeneric:
    """Test that the fix works generically, not just for 42.5."""

    def test_parser_extracts_objective_from_standard_format(self):
        """
        Verify the parser can extract objective values from standard format.
        This tests that the fix is generic and not hardcoded.
        """
        # Import and test the parser directly if possible
        import sys
        if MLOPS_DIR not in sys.path:
            sys.path.insert(0, MLOPS_DIR)

        try:
            # Try to import and test parser directly
            import importlib.util
            spec = importlib.util.spec_from_file_location("parser", PARSER_PY)
            parser_module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(parser_module)

            # Find a function that parses output
            test_output = "GLOP Solver v2.1\nStatus: OPTIMAL\nObjective: 99.9\nIterations: 15\n"

            # Try common function names
            parse_func = None
            for func_name in ['parse', 'parse_output', 'extract_objective', 'get_objective']:
                if hasattr(parser_module, func_name):
                    parse_func = getattr(parser_module, func_name)
                    break

            if parse_func:
                result = parse_func(test_output)
                if result is not None:
                    assert abs(float(result) - 99.9) < 0.001, \
                        f"Parser should extract 99.9 from test output, got {result}"
        except Exception:
            # If we can't test the parser directly, that's okay
            # The main functionality test already verifies it works
            pass
