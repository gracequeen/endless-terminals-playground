# test_final_state.py
"""
Tests to validate the final state of the system after the student has fixed the firewall typo.
This validates that carlos's IP (10.33.7.89) is correctly configured for SSH access on port 22.
"""

import os
import pytest
import subprocess
import re


class TestTypoFixed:
    """Test that the typo has been corrected in the SSH allow rules file."""

    @pytest.fixture
    def ssh_rules_content(self):
        """Read the SSH allow rules file content."""
        filepath = "/etc/firewall/rules.d/20-ssh-allow.rules"
        with open(filepath, 'r') as f:
            return f.read()

    def test_typo_removed(self, ssh_rules_content):
        """Verify the typo '10.33.7.0B9' has been removed."""
        assert "0B9" not in ssh_rules_content and "0b9" not in ssh_rules_content.lower(), \
            "The typo '10.33.7.0B9' still exists in 20-ssh-allow.rules - it should be corrected to '10.33.7.89'"

    def test_correct_ip_present(self, ssh_rules_content):
        """Verify the correct IP 10.33.7.89 is now present."""
        assert "10.33.7.89" in ssh_rules_content, \
            "The correct IP '10.33.7.89' for carlos is not found in 20-ssh-allow.rules"

    def test_correct_ip_exactly_once(self):
        """Verify 10.33.7.89 appears exactly once (no duplicates)."""
        result = subprocess.run(
            ["grep", "-c", "10.33.7.89", "/etc/firewall/rules.d/20-ssh-allow.rules"],
            capture_output=True,
            text=True
        )
        count = int(result.stdout.strip()) if result.returncode == 0 else 0
        assert count == 1, \
            f"IP 10.33.7.89 should appear exactly once in 20-ssh-allow.rules, but found {count} occurrences"

    def test_carlos_rule_has_port_22(self, ssh_rules_content):
        """Verify carlos's rule includes port 22."""
        # Find the line with 10.33.7.89 and check it has PORT 22
        for line in ssh_rules_content.split('\n'):
            if "10.33.7.89" in line:
                assert "22" in line, \
                    f"Carlos's rule should include port 22, but found: {line}"
                assert "PORT" in line.upper() or "port" in line.lower(), \
                    f"Carlos's rule should specify PORT 22, but found: {line}"
                break
        else:
            pytest.fail("Could not find a line with 10.33.7.89 to verify port 22")


class TestOtherTeamMembersUnchanged:
    """Test that other team members' rules are still intact."""

    @pytest.fixture
    def ssh_rules_content(self):
        """Read the SSH allow rules file content."""
        filepath = "/etc/firewall/rules.d/20-ssh-allow.rules"
        with open(filepath, 'r') as f:
            return f.read()

    def test_alice_rule_intact(self, ssh_rules_content):
        """Verify alice's rule (10.33.7.12) is still present."""
        assert "10.33.7.12" in ssh_rules_content, \
            "Alice's IP (10.33.7.12) is missing from SSH allow rules - should not have been modified"

    def test_bob_rule_intact(self, ssh_rules_content):
        """Verify bob's rule (10.33.7.45) is still present."""
        assert "10.33.7.45" in ssh_rules_content, \
            "Bob's IP (10.33.7.45) is missing from SSH allow rules - should not have been modified"

    def test_dana_rule_intact(self, ssh_rules_content):
        """Verify dana's rule (10.33.7.102) is still present."""
        assert "10.33.7.102" in ssh_rules_content, \
            "Dana's IP (10.33.7.102) is missing from SSH allow rules - should not have been modified"


class TestNoWildcardRules:
    """Test that no wildcard or wide-open rules were added."""

    @pytest.fixture
    def ssh_rules_content(self):
        """Read the SSH allow rules file content."""
        filepath = "/etc/firewall/rules.d/20-ssh-allow.rules"
        with open(filepath, 'r') as f:
            return f.read()

    def test_no_wildcard_ip(self, ssh_rules_content):
        """Verify no 0.0.0.0 or wildcard rules were added."""
        # Check for common wildcard patterns
        wildcard_patterns = ["0.0.0.0", "0.0.0.0/0", "*", "any", "all"]
        content_lower = ssh_rules_content.lower()
        for pattern in wildcard_patterns:
            # Skip if it's in a comment
            for line in ssh_rules_content.split('\n'):
                if pattern.lower() in line.lower():
                    # Check if this is not just a comment
                    stripped = line.strip()
                    if not stripped.startswith('#'):
                        # Check if it's part of an ALLOW rule
                        if "allow" in stripped.lower() and "22" in stripped:
                            pytest.fail(f"Wide-open rule detected with pattern '{pattern}': {line}")


class TestOtherFilesUnchanged:
    """Test that other firewall files were not improperly modified."""

    def test_base_rules_exists(self):
        """Verify 10-base.rules still exists."""
        filepath = "/etc/firewall/rules.d/10-base.rules"
        assert os.path.isfile(filepath), \
            f"File {filepath} is missing - should not have been deleted"

    def test_drop_rules_exists(self):
        """Verify 99-drop.rules still exists."""
        filepath = "/etc/firewall/rules.d/99-drop.rules"
        assert os.path.isfile(filepath), \
            f"File {filepath} is missing - should not have been deleted"

    def test_firewall_conf_exists(self):
        """Verify firewall.conf still exists."""
        filepath = "/etc/firewall/firewall.conf"
        assert os.path.isfile(filepath), \
            f"File {filepath} is missing - should not have been deleted"


class TestFwApplyWorks:
    """Test that fw-apply runs successfully with the fixed configuration."""

    def test_fw_apply_exits_zero(self):
        """Verify /usr/local/bin/fw-apply exits with code 0."""
        result = subprocess.run(
            ["/usr/local/bin/fw-apply"],
            capture_output=True,
            text=True,
            timeout=30
        )
        assert result.returncode == 0, \
            f"fw-apply should exit with code 0, but got {result.returncode}. stderr: {result.stderr}"

    def test_fw_apply_no_invalid_ip_error_for_carlos(self):
        """Verify fw-apply doesn't report invalid IP for 10.33.7.89."""
        result = subprocess.run(
            ["/usr/local/bin/fw-apply"],
            capture_output=True,
            text=True,
            timeout=30
        )
        combined_output = result.stdout + result.stderr
        # Check that there's no SKIPPED message for the 89 IP
        if "10.33.7.89" in combined_output:
            assert "SKIPPED" not in combined_output or "invalid" not in combined_output.lower(), \
                "fw-apply is still reporting 10.33.7.89 as invalid"


class TestIptablesState:
    """Test that iptables has the correct rule for carlos."""

    def test_carlos_ip_in_iptables(self):
        """Verify 10.33.7.89 is in iptables rules with ACCEPT."""
        try:
            result = subprocess.run(
                ["iptables", "-L", "-n"],
                capture_output=True,
                text=True,
                timeout=10
            )
            assert "10.33.7.89" in result.stdout, \
                "IP 10.33.7.89 is not in iptables rules - fw-apply may not have been run or rule not applied"
        except subprocess.TimeoutExpired:
            pytest.fail("iptables command timed out")
        except FileNotFoundError:
            pytest.skip("iptables command not available")

    def test_carlos_ip_accept_rule(self):
        """Verify 10.33.7.89 has an ACCEPT rule for port 22."""
        try:
            # Get iptables rules with more detail
            result = subprocess.run(
                ["iptables", "-L", "INPUT", "-n", "-v"],
                capture_output=True,
                text=True,
                timeout=10
            )

            # Look for the IP in the output
            found_accept = False
            for line in result.stdout.split('\n'):
                if "10.33.7.89" in line:
                    if "ACCEPT" in line:
                        found_accept = True
                        break

            # Also check with simpler format
            if not found_accept:
                result2 = subprocess.run(
                    ["iptables", "-L", "-n"],
                    capture_output=True,
                    text=True,
                    timeout=10
                )
                for line in result2.stdout.split('\n'):
                    if "10.33.7.89" in line and "ACCEPT" in line:
                        found_accept = True
                        break

            assert found_accept, \
                "No ACCEPT rule found for 10.33.7.89 - the firewall rule may not be correctly applied"
        except subprocess.TimeoutExpired:
            pytest.fail("iptables command timed out")
        except FileNotFoundError:
            pytest.skip("iptables command not available")

    def test_other_team_members_still_in_iptables(self):
        """Verify other team members' IPs are still in iptables."""
        try:
            result = subprocess.run(
                ["iptables", "-L", "-n"],
                capture_output=True,
                text=True,
                timeout=10
            )

            # Check for alice, bob, and dana
            expected_ips = ["10.33.7.12", "10.33.7.45", "10.33.7.102"]
            for ip in expected_ips:
                assert ip in result.stdout, \
                    f"IP {ip} is missing from iptables rules - other team members' access may have been broken"
        except subprocess.TimeoutExpired:
            pytest.fail("iptables command timed out")
        except FileNotFoundError:
            pytest.skip("iptables command not available")


class TestCarlosIdentified:
    """Test that carlos is still properly identified in the rules."""

    def test_carlos_comment_preserved(self):
        """Verify carlos is still mentioned in the rules file."""
        filepath = "/etc/firewall/rules.d/20-ssh-allow.rules"
        with open(filepath, 'r') as f:
            content = f.read()

        # Check that carlos is mentioned somewhere (case-insensitive)
        assert "carlos" in content.lower(), \
            "Carlos should still be identified in the rules file (comment preserved or updated)"

    def test_carlos_associated_with_correct_ip(self):
        """Verify carlos's name is on the same line as the correct IP."""
        filepath = "/etc/firewall/rules.d/20-ssh-allow.rules"
        with open(filepath, 'r') as f:
            content = f.read()

        # Find the line with 10.33.7.89 and check if carlos is mentioned
        found_carlos_line = False
        for line in content.split('\n'):
            if "10.33.7.89" in line:
                if "carlos" in line.lower():
                    found_carlos_line = True
                    break

        assert found_carlos_line, \
            "Carlos's name should be on the same line as IP 10.33.7.89 (comment identifying the new hire)"


class TestNoTypoAnywhere:
    """Final verification that the typo is completely gone."""

    def test_grep_no_0b9_match(self):
        """Verify grep finds no match for '0B9' in the rules file."""
        result = subprocess.run(
            ["grep", "-i", "0B9", "/etc/firewall/rules.d/20-ssh-allow.rules"],
            capture_output=True,
            text=True
        )
        # grep returns 1 when no match found, 0 when match found
        assert result.returncode != 0, \
            f"The typo '0B9' still exists in the rules file: {result.stdout}"
