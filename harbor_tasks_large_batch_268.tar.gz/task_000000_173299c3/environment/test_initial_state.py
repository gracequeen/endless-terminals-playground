# test_initial_state.py
"""
Tests to validate the initial state of the system before the student performs the action.
This validates the firewall configuration with the typo that needs to be fixed.
"""

import os
import pytest
import subprocess


class TestFirewallDirectoryStructure:
    """Test that the firewall directory structure exists as expected."""

    def test_firewall_directory_exists(self):
        """Verify /etc/firewall/ directory exists."""
        assert os.path.isdir("/etc/firewall"), \
            "Directory /etc/firewall/ does not exist"

    def test_rules_directory_exists(self):
        """Verify /etc/firewall/rules.d/ directory exists."""
        assert os.path.isdir("/etc/firewall/rules.d"), \
            "Directory /etc/firewall/rules.d/ does not exist"

    def test_log_directory_exists(self):
        """Verify /var/log/firewall/ directory exists."""
        assert os.path.isdir("/var/log/firewall"), \
            "Directory /var/log/firewall/ does not exist"


class TestFirewallConfigFiles:
    """Test that required firewall configuration files exist."""

    def test_base_rules_exists(self):
        """Verify 10-base.rules file exists."""
        filepath = "/etc/firewall/rules.d/10-base.rules"
        assert os.path.isfile(filepath), \
            f"File {filepath} does not exist - base deny-all policy file missing"

    def test_ssh_allow_rules_exists(self):
        """Verify 20-ssh-allow.rules file exists."""
        filepath = "/etc/firewall/rules.d/20-ssh-allow.rules"
        assert os.path.isfile(filepath), \
            f"File {filepath} does not exist - SSH allowlist file missing"

    def test_drop_rules_exists(self):
        """Verify 99-drop.rules file exists."""
        filepath = "/etc/firewall/rules.d/99-drop.rules"
        assert os.path.isfile(filepath), \
            f"File {filepath} does not exist - final drop rule file missing"

    def test_firewall_conf_exists(self):
        """Verify firewall.conf file exists."""
        filepath = "/etc/firewall/firewall.conf"
        assert os.path.isfile(filepath), \
            f"File {filepath} does not exist - main firewall config missing"

    def test_hosts_allow_exists(self):
        """Verify hosts.allow file exists."""
        filepath = "/etc/firewall/hosts.allow"
        assert os.path.isfile(filepath), \
            f"File {filepath} does not exist - supplementary IP allowlist missing"

    def test_fw_apply_script_exists(self):
        """Verify fw-apply script exists and is executable."""
        filepath = "/usr/local/bin/fw-apply"
        assert os.path.isfile(filepath), \
            f"File {filepath} does not exist - firewall apply script missing"
        assert os.access(filepath, os.X_OK), \
            f"File {filepath} is not executable"

    def test_apply_log_exists(self):
        """Verify apply.log file exists."""
        filepath = "/var/log/firewall/apply.log"
        assert os.path.isfile(filepath), \
            f"File {filepath} does not exist - firewall apply log missing"


class TestSSHAllowRulesContent:
    """Test the content of the SSH allow rules file to verify initial state with typo."""

    @pytest.fixture
    def ssh_rules_content(self):
        """Read the SSH allow rules file content."""
        filepath = "/etc/firewall/rules.d/20-ssh-allow.rules"
        with open(filepath, 'r') as f:
            return f.read()

    def test_alice_rule_exists(self, ssh_rules_content):
        """Verify alice's rule exists."""
        assert "10.33.7.12" in ssh_rules_content, \
            "Alice's IP (10.33.7.12) not found in SSH allow rules"
        assert "alice" in ssh_rules_content.lower(), \
            "Alice's comment not found in SSH allow rules"

    def test_bob_rule_exists(self, ssh_rules_content):
        """Verify bob's rule exists."""
        assert "10.33.7.45" in ssh_rules_content, \
            "Bob's IP (10.33.7.45) not found in SSH allow rules"
        assert "bob" in ssh_rules_content.lower(), \
            "Bob's comment not found in SSH allow rules"

    def test_dana_rule_exists(self, ssh_rules_content):
        """Verify dana's rule exists."""
        assert "10.33.7.102" in ssh_rules_content, \
            "Dana's IP (10.33.7.102) not found in SSH allow rules"
        assert "dana" in ssh_rules_content.lower(), \
            "Dana's comment not found in SSH allow rules"

    def test_carlos_typo_exists(self, ssh_rules_content):
        """Verify the typo '10.33.7.0B9' exists (this is the bug to fix)."""
        assert "10.33.7.0B9" in ssh_rules_content or "10.33.7.0b9" in ssh_rules_content.lower(), \
            "The typo '10.33.7.0B9' for carlos not found - initial state should have this bug"

    def test_carlos_comment_exists(self, ssh_rules_content):
        """Verify carlos is mentioned in the rules."""
        assert "carlos" in ssh_rules_content.lower(), \
            "Carlos's comment not found in SSH allow rules"

    def test_correct_carlos_ip_not_present(self, ssh_rules_content):
        """Verify the correct IP 10.33.7.89 is NOT present (this is what needs to be fixed)."""
        assert "10.33.7.89" not in ssh_rules_content, \
            "The correct IP 10.33.7.89 already exists - initial state should have the typo instead"


class TestFirewallLogContent:
    """Test the firewall apply log to verify it shows the skipped invalid IP."""

    @pytest.fixture
    def log_content(self):
        """Read the firewall apply log content."""
        filepath = "/var/log/firewall/apply.log"
        with open(filepath, 'r') as f:
            return f.read()

    def test_log_shows_invalid_ip_skipped(self, log_content):
        """Verify the log shows the invalid IP was skipped."""
        assert "SKIPPED" in log_content and "invalid" in log_content.lower(), \
            "Log should show that an invalid IP was skipped"

    def test_log_shows_0b9_error(self, log_content):
        """Verify the log mentions the typo IP."""
        assert "0B9" in log_content or "0b9" in log_content.lower(), \
            "Log should mention the invalid IP '10.33.7.0B9'"


class TestFirewallConfContent:
    """Test the main firewall configuration file."""

    def test_allowlist_file_configured(self):
        """Verify firewall.conf references hosts.allow."""
        filepath = "/etc/firewall/firewall.conf"
        with open(filepath, 'r') as f:
            content = f.read()
        assert "hosts.allow" in content, \
            "firewall.conf should reference hosts.allow file"


class TestCurrentIptablesState:
    """Test the current iptables state to verify carlos's IP is not allowed."""

    def test_carlos_ip_not_in_iptables(self):
        """Verify 10.33.7.89 is NOT currently in iptables rules."""
        try:
            result = subprocess.run(
                ["iptables", "-L", "-n"],
                capture_output=True,
                text=True,
                timeout=10
            )
            # The correct IP should NOT be present
            assert "10.33.7.89" not in result.stdout, \
                "IP 10.33.7.89 should NOT be in iptables rules initially (this is the problem to fix)"
        except subprocess.TimeoutExpired:
            pytest.fail("iptables command timed out")
        except FileNotFoundError:
            pytest.skip("iptables command not available")

    def test_typo_ip_not_in_iptables(self):
        """Verify the typo IP is also not in iptables (it's invalid so shouldn't be there)."""
        try:
            result = subprocess.run(
                ["iptables", "-L", "-n"],
                capture_output=True,
                text=True,
                timeout=10
            )
            assert "0B9" not in result.stdout and "0b9" not in result.stdout.lower(), \
                "Invalid IP '10.33.7.0B9' should not be in iptables rules"
        except subprocess.TimeoutExpired:
            pytest.fail("iptables command timed out")
        except FileNotFoundError:
            pytest.skip("iptables command not available")


class TestFilePermissions:
    """Test that the agent can modify the necessary files."""

    def test_ssh_rules_writable(self):
        """Verify 20-ssh-allow.rules is writable."""
        filepath = "/etc/firewall/rules.d/20-ssh-allow.rules"
        assert os.access(filepath, os.W_OK), \
            f"File {filepath} is not writable - agent needs write access to fix the typo"


class TestRequiredTools:
    """Test that required tools are available."""

    def test_python3_available(self):
        """Verify python3 is available."""
        result = subprocess.run(
            ["which", "python3"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            "python3 is not available in PATH"

    def test_grep_available(self):
        """Verify grep is available."""
        result = subprocess.run(
            ["which", "grep"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            "grep is not available in PATH"

    def test_sed_available(self):
        """Verify sed is available."""
        result = subprocess.run(
            ["which", "sed"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            "sed is not available in PATH"
