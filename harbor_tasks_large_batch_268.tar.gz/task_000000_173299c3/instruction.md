New hire can't SSH into the dev box from their workstation — gets connection timeout. I added their IP to the allowlist yesterday same as everyone else's, tested from my machine fine. Their IP is 10.33.7.89, should be able to reach port 22 like the rest of the team. They're not behind a VPN or anything weird, just regular office network.

Firewall rules are in /etc/firewall/rules.d/, we use that custom iptables wrapper thing the previous admin set up. Can you figure out why they're blocked and fix it? Don't want to just open 22 to everyone obviously.
