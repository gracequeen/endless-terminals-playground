# test_final_state.py
"""
Tests to validate the final state after the student has fixed the MLOps experiment tracking issue.
This verifies:
1. The database query returns all three experiments for Jan 15
2. The timestamps in the database are corrected to UTC
3. The ingest.py script is fixed for future ingests
4. The metadata.json files are unchanged
5. The database schema and structure is preserved
"""

import pytest
import os
import json
import sqlite3
import subprocess
import hashlib
from pathlib import Path


MLOPS_DIR = Path("/home/user/mlops")
TRACKER_DB = MLOPS_DIR / "tracker.db"
INGEST_SCRIPT = MLOPS_DIR / "ingest.py"
ENV_FILE = MLOPS_DIR / ".env"
ARTIFACTS_DIR = MLOPS_DIR / "artifacts"

EXPERIMENTS = ["exp_001", "exp_002", "exp_003"]

# Expected correct UTC times that should now be in the database
EXPECTED_UTC_TIMES = {
    "exp_001": "2024-01-15T02:15:00",
    "exp_002": "2024-01-15T07:45:00",
    "exp_003": "2024-01-15T14:30:00",
}

# Expected metadata.json content (must be unchanged)
EXPECTED_METADATA_TIMES = {
    "exp_001": "2024-01-15T02:15:00",
    "exp_002": "2024-01-15T07:45:00",
    "exp_003": "2024-01-15T14:30:00",
}


class TestCriticalQuery:
    """Test that the critical query now returns all three experiments."""

    def test_query_returns_all_three_experiments(self):
        """The main query must return all three experiment IDs."""
        conn = sqlite3.connect(TRACKER_DB)
        try:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT experiment_id FROM runs 
                WHERE start_time >= '2024-01-15 00:00:00' 
                AND start_time < '2024-01-16 00:00:00'
                ORDER BY experiment_id
            """)
            results = [row[0] for row in cursor.fetchall()]

            assert len(results) == 3, \
                f"Query should return exactly 3 experiments, got {len(results)}: {results}"
            assert results == ["exp_001", "exp_002", "exp_003"], \
                f"Query should return exp_001, exp_002, exp_003 in order. Got: {results}"
        finally:
            conn.close()

    def test_query_via_sqlite3_command(self):
        """Verify the query works via sqlite3 command line as specified in the task."""
        result = subprocess.run(
            [
                "sqlite3", str(TRACKER_DB),
                "SELECT experiment_id FROM runs WHERE start_time >= '2024-01-15 00:00:00' AND start_time < '2024-01-16 00:00:00' ORDER BY experiment_id"
            ],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, f"sqlite3 command failed: {result.stderr}"

        lines = [line.strip() for line in result.stdout.strip().split('\n') if line.strip()]
        assert len(lines) == 3, \
            f"sqlite3 query should return 3 lines, got {len(lines)}: {lines}"
        assert lines == ["exp_001", "exp_002", "exp_003"], \
            f"sqlite3 query should return exp_001, exp_002, exp_003. Got: {lines}"


class TestDatabaseTimestampsCorrected:
    """Test that the database timestamps are corrected to UTC."""

    @pytest.mark.parametrize("exp_id", EXPERIMENTS)
    def test_experiment_has_correct_utc_timestamp(self, exp_id):
        """Each experiment should now have the correct UTC timestamp."""
        conn = sqlite3.connect(TRACKER_DB)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT start_time FROM runs WHERE experiment_id = ?", (exp_id,))
            result = cursor.fetchone()

            assert result is not None, f"Experiment {exp_id} not found in database"
            stored_time = result[0]
            expected_time = EXPECTED_UTC_TIMES[exp_id]

            # Check that the time is on Jan 15 and matches expected UTC time
            assert "2024-01-15" in stored_time, \
                f"Experiment {exp_id} should have Jan 15 date, got {stored_time}"

            # Allow for slight format variations (T vs space, with/without Z)
            # The key is that the hour/minute matches the expected UTC time
            expected_hour_minute = expected_time[11:16]  # e.g., "02:15"
            assert expected_hour_minute in stored_time, \
                f"Experiment {exp_id} should have time {expected_hour_minute}, got {stored_time}"
        finally:
            conn.close()

    def test_all_experiments_on_jan_15(self):
        """All experiments should now have Jan 15 dates in the database."""
        conn = sqlite3.connect(TRACKER_DB)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT experiment_id, start_time FROM runs ORDER BY experiment_id")
            results = cursor.fetchall()

            for exp_id, start_time in results:
                assert "2024-01-15" in start_time, \
                    f"Experiment {exp_id} should have 2024-01-15 in start_time, got {start_time}"
        finally:
            conn.close()


class TestDatabaseSchemaPreserved:
    """Test that the database schema is preserved."""

    def test_runs_table_exists(self):
        """The runs table must still exist."""
        conn = sqlite3.connect(TRACKER_DB)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='runs'")
            result = cursor.fetchone()
            assert result is not None, "Table 'runs' no longer exists in tracker.db"
        finally:
            conn.close()

    def test_runs_table_has_correct_columns(self):
        """The runs table must still have the expected columns."""
        expected_columns = {"id", "experiment_id", "start_time", "end_time", "status"}

        conn = sqlite3.connect(TRACKER_DB)
        try:
            cursor = conn.cursor()
            cursor.execute("PRAGMA table_info(runs)")
            columns = {row[1] for row in cursor.fetchall()}

            assert columns == expected_columns, \
                f"Runs table columns changed. Expected {expected_columns}, got {columns}"
        finally:
            conn.close()

    def test_all_three_experiments_still_exist(self):
        """All three experiment rows must still exist (not deleted/recreated)."""
        conn = sqlite3.connect(TRACKER_DB)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT experiment_id FROM runs ORDER BY experiment_id")
            exp_ids = [row[0] for row in cursor.fetchall()]

            assert len(exp_ids) >= 3, \
                f"Database should have at least 3 experiments, got {len(exp_ids)}"
            for exp_id in EXPERIMENTS:
                assert exp_id in exp_ids, \
                    f"Experiment {exp_id} is missing from database"
        finally:
            conn.close()


class TestMetadataFilesUnchanged:
    """Test that metadata.json files are unchanged (byte-identical)."""

    @pytest.mark.parametrize("exp_id", EXPERIMENTS)
    def test_metadata_file_exists(self, exp_id):
        """Each metadata.json file must still exist."""
        metadata_file = ARTIFACTS_DIR / exp_id / "metadata.json"
        assert metadata_file.exists(), f"Metadata file {metadata_file} is missing"

    @pytest.mark.parametrize("exp_id", EXPERIMENTS)
    def test_metadata_content_unchanged(self, exp_id):
        """Metadata.json content should be unchanged with correct UTC times."""
        metadata_file = ARTIFACTS_DIR / exp_id / "metadata.json"
        with open(metadata_file, 'r') as f:
            data = json.load(f)

        assert data["experiment_id"] == exp_id, \
            f"Metadata experiment_id changed for {exp_id}"

        expected_time = EXPECTED_METADATA_TIMES[exp_id]
        # Check that the start_time still contains the expected UTC time
        assert expected_time[:16] in data["start_time"], \
            f"Metadata start_time for {exp_id} was modified. Expected to contain {expected_time[:16]}, got {data['start_time']}"


class TestArtifactDirectoriesUnchanged:
    """Test that artifact directories are not modified."""

    @pytest.mark.parametrize("exp_id", EXPERIMENTS)
    def test_artifact_directory_exists(self, exp_id):
        """Each artifact directory must still exist."""
        exp_dir = ARTIFACTS_DIR / exp_id
        assert exp_dir.exists(), f"Artifact directory {exp_dir} is missing"
        assert exp_dir.is_dir(), f"{exp_dir} is not a directory"


class TestIngestScriptFixed:
    """Test that ingest.py is fixed for future ingests."""

    def test_ingest_script_exists(self):
        """The ingest.py script must still exist."""
        assert INGEST_SCRIPT.exists(), f"Ingest script {INGEST_SCRIPT} is missing"

    def test_ingest_script_stores_utc(self):
        """
        The ingest.py script should be fixed to store UTC times.
        This can be achieved by:
        - Removing/ignoring MLOPS_TZ for timestamp storage
        - Not converting UTC to local time before storing
        - Using timezone-aware UTC times
        """
        with open(INGEST_SCRIPT, 'r') as f:
            content = f.read()

        # The script should either:
        # 1. Not use MLOPS_TZ for time conversion anymore
        # 2. Or explicitly store UTC regardless of MLOPS_TZ
        # 3. Or the problematic conversion code should be removed/commented

        # Check for signs that the timezone conversion bug is fixed
        # The original bug was converting UTC to local time before storing

        # One approach: check if pytz localize/convert is no longer applied to stored time
        # Another approach: check if the script now ignores MLOPS_TZ or handles it correctly

        # We'll check that the script doesn't have the problematic pattern of
        # converting utcnow to a local timezone and then storing as naive string

        # Look for common fix patterns
        has_fix_indicators = (
            # Script might now use timezone-aware UTC
            "timezone.utc" in content or
            "UTC" in content or
            # Script might ignore MLOPS_TZ for storage
            "# MLOPS_TZ" in content or  # commented out
            # Script might have removed the conversion
            content.count("localize") == 0 or
            # Script might store isoformat directly without conversion
            ("utcnow" in content and "astimezone" not in content and 
             ("localize" not in content or "MLOPS_TZ" not in content))
        )

        # Alternative: the .env file might have MLOPS_TZ removed
        env_fixed = False
        if ENV_FILE.exists():
            with open(ENV_FILE, 'r') as f:
                env_content = f.read()
            # If MLOPS_TZ is removed or commented out
            if "MLOPS_TZ" not in env_content or env_content.strip() == "" or \
               all(line.strip().startswith('#') for line in env_content.split('\n') if 'MLOPS_TZ' in line):
                env_fixed = True

        assert has_fix_indicators or env_fixed, \
            "ingest.py should be fixed to store UTC times regardless of MLOPS_TZ setting"


class TestDatabaseStringsContainJan15:
    """Test using string extraction that all experiments have Jan 15 dates."""

    def test_grep_shows_jan15_for_all_experiments(self):
        """Using strings extraction, all experiments should show Jan 15 dates."""
        # Read the database file and look for date strings
        result = subprocess.run(
            ["strings", str(TRACKER_DB)],
            capture_output=True,
            text=True
        )

        output = result.stdout

        # Count occurrences of 2024-01-15 (should be at least 3 for the three experiments)
        jan15_count = output.count("2024-01-15")

        # Should not have 2024-01-14 for any experiment times anymore
        # (Note: there might be other dates in the DB, so we check specific patterns)

        assert jan15_count >= 3, \
            f"Database should contain at least 3 occurrences of '2024-01-15', found {jan15_count}"

    def test_no_corrupted_jan14_timestamps(self):
        """The corrupted Jan 14 timestamps should no longer exist for these experiments."""
        conn = sqlite3.connect(TRACKER_DB)
        try:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT experiment_id, start_time FROM runs 
                WHERE experiment_id IN ('exp_001', 'exp_002', 'exp_003')
                AND start_time LIKE '2024-01-14%'
            """)
            results = cursor.fetchall()

            assert len(results) == 0, \
                f"Found experiments with corrupted Jan 14 dates: {results}"
        finally:
            conn.close()


class TestFutureIngestBehavior:
    """Test that future ingests would store correct UTC times."""

    def test_ingest_script_is_syntactically_valid(self):
        """The modified ingest.py should be syntactically valid Python."""
        result = subprocess.run(
            ["python3", "-m", "py_compile", str(INGEST_SCRIPT)],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            f"ingest.py has syntax errors: {result.stderr}"

    def test_ingest_script_can_be_imported(self):
        """The ingest.py script should be importable without errors."""
        # Create a test script that tries to import ingest
        test_code = f"""
import sys
sys.path.insert(0, '{MLOPS_DIR}')
try:
    # Just check syntax and imports, don't run the main logic
    import ast
    with open('{INGEST_SCRIPT}', 'r') as f:
        ast.parse(f.read())
    print('OK')
except Exception as e:
    print(f'ERROR: {{e}}')
    sys.exit(1)
"""
        result = subprocess.run(
            ["python3", "-c", test_code],
            capture_output=True,
            text=True,
            cwd=str(MLOPS_DIR)
        )
        assert "OK" in result.stdout or result.returncode == 0, \
            f"ingest.py cannot be parsed: {result.stderr}"
