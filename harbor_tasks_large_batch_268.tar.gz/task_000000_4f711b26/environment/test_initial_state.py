# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student performs the action.
This verifies the MLOps experiment tracking environment is set up with the described bug.
"""

import pytest
import os
import json
import sqlite3
import subprocess
from pathlib import Path


MLOPS_DIR = Path("/home/user/mlops")
TRACKER_DB = MLOPS_DIR / "tracker.db"
INGEST_SCRIPT = MLOPS_DIR / "ingest.py"
ENV_FILE = MLOPS_DIR / ".env"
ARTIFACTS_DIR = MLOPS_DIR / "artifacts"

EXPERIMENTS = ["exp_001", "exp_002", "exp_003"]

# Expected corrupted times in the database (PST, -8h from UTC)
EXPECTED_DB_TIMES = {
    "exp_001": "2024-01-14T18:15:00",
    "exp_002": "2024-01-14T23:45:00",
    "exp_003": "2024-01-15T06:30:00",
}

# Expected correct UTC times in metadata.json files
EXPECTED_METADATA_TIMES = {
    "exp_001": "2024-01-15T02:15:00",
    "exp_002": "2024-01-15T07:45:00",
    "exp_003": "2024-01-15T14:30:00",
}


class TestMLOpsDirectoryStructure:
    """Test that the MLOps directory structure exists."""

    def test_mlops_directory_exists(self):
        """The /home/user/mlops directory must exist."""
        assert MLOPS_DIR.exists(), f"MLOps directory {MLOPS_DIR} does not exist"
        assert MLOPS_DIR.is_dir(), f"{MLOPS_DIR} is not a directory"

    def test_tracker_db_exists(self):
        """The tracker.db SQLite database must exist."""
        assert TRACKER_DB.exists(), f"Tracker database {TRACKER_DB} does not exist"
        assert TRACKER_DB.is_file(), f"{TRACKER_DB} is not a file"

    def test_ingest_script_exists(self):
        """The ingest.py script must exist."""
        assert INGEST_SCRIPT.exists(), f"Ingest script {INGEST_SCRIPT} does not exist"
        assert INGEST_SCRIPT.is_file(), f"{INGEST_SCRIPT} is not a file"

    def test_env_file_exists(self):
        """The .env file must exist."""
        assert ENV_FILE.exists(), f"Environment file {ENV_FILE} does not exist"
        assert ENV_FILE.is_file(), f"{ENV_FILE} is not a file"

    def test_artifacts_directory_exists(self):
        """The artifacts directory must exist."""
        assert ARTIFACTS_DIR.exists(), f"Artifacts directory {ARTIFACTS_DIR} does not exist"
        assert ARTIFACTS_DIR.is_dir(), f"{ARTIFACTS_DIR} is not a directory"


class TestExperimentDirectories:
    """Test that experiment directories and metadata files exist."""

    @pytest.mark.parametrize("exp_id", EXPERIMENTS)
    def test_experiment_directory_exists(self, exp_id):
        """Each experiment directory must exist."""
        exp_dir = ARTIFACTS_DIR / exp_id
        assert exp_dir.exists(), f"Experiment directory {exp_dir} does not exist"
        assert exp_dir.is_dir(), f"{exp_dir} is not a directory"

    @pytest.mark.parametrize("exp_id", EXPERIMENTS)
    def test_metadata_json_exists(self, exp_id):
        """Each experiment must have a metadata.json file."""
        metadata_file = ARTIFACTS_DIR / exp_id / "metadata.json"
        assert metadata_file.exists(), f"Metadata file {metadata_file} does not exist"
        assert metadata_file.is_file(), f"{metadata_file} is not a file"

    @pytest.mark.parametrize("exp_id", EXPERIMENTS)
    def test_metadata_json_is_valid(self, exp_id):
        """Each metadata.json must be valid JSON with required fields."""
        metadata_file = ARTIFACTS_DIR / exp_id / "metadata.json"
        with open(metadata_file, 'r') as f:
            data = json.load(f)

        assert "experiment_id" in data, f"metadata.json for {exp_id} missing 'experiment_id' field"
        assert "start_time" in data, f"metadata.json for {exp_id} missing 'start_time' field"
        assert data["experiment_id"] == exp_id, f"experiment_id mismatch in {exp_id}/metadata.json"

    @pytest.mark.parametrize("exp_id", EXPERIMENTS)
    def test_metadata_has_correct_utc_time(self, exp_id):
        """Metadata.json files must contain the correct UTC times (Jan 15)."""
        metadata_file = ARTIFACTS_DIR / exp_id / "metadata.json"
        with open(metadata_file, 'r') as f:
            data = json.load(f)

        start_time = data["start_time"]
        expected_time = EXPECTED_METADATA_TIMES[exp_id]

        # Check that the time starts with the expected prefix (allowing for slight variations in format)
        assert start_time.startswith("2024-01-15"), \
            f"Metadata for {exp_id} should show Jan 15 UTC time, but got {start_time}"
        assert expected_time in start_time or start_time.startswith(expected_time[:16]), \
            f"Metadata for {exp_id} expected time starting with {expected_time[:16]}, got {start_time}"


class TestDatabaseSchema:
    """Test that the database has the correct schema."""

    def test_database_is_valid_sqlite(self):
        """The tracker.db must be a valid SQLite database."""
        conn = sqlite3.connect(TRACKER_DB)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT sqlite_version()")
            version = cursor.fetchone()
            assert version is not None, "Could not query SQLite version"
        finally:
            conn.close()

    def test_runs_table_exists(self):
        """The runs table must exist."""
        conn = sqlite3.connect(TRACKER_DB)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='runs'")
            result = cursor.fetchone()
            assert result is not None, "Table 'runs' does not exist in tracker.db"
        finally:
            conn.close()

    def test_runs_table_has_correct_columns(self):
        """The runs table must have the expected columns."""
        expected_columns = {"id", "experiment_id", "start_time", "end_time", "status"}

        conn = sqlite3.connect(TRACKER_DB)
        try:
            cursor = conn.cursor()
            cursor.execute("PRAGMA table_info(runs)")
            columns = {row[1] for row in cursor.fetchall()}

            assert columns == expected_columns, \
                f"Runs table columns mismatch. Expected {expected_columns}, got {columns}"
        finally:
            conn.close()


class TestDatabaseContent:
    """Test that the database contains the expected (corrupted) data."""

    def test_all_experiments_exist_in_db(self):
        """All three experiments must exist in the database."""
        conn = sqlite3.connect(TRACKER_DB)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT experiment_id FROM runs ORDER BY experiment_id")
            exp_ids = [row[0] for row in cursor.fetchall()]

            for exp_id in EXPERIMENTS:
                assert exp_id in exp_ids, f"Experiment {exp_id} not found in database"
        finally:
            conn.close()

    @pytest.mark.parametrize("exp_id", EXPERIMENTS)
    def test_experiment_has_corrupted_timestamp(self, exp_id):
        """Each experiment should have the corrupted (PST) timestamp, not UTC."""
        conn = sqlite3.connect(TRACKER_DB)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT start_time FROM runs WHERE experiment_id = ?", (exp_id,))
            result = cursor.fetchone()

            assert result is not None, f"Experiment {exp_id} not found in database"
            stored_time = result[0]
            expected_time = EXPECTED_DB_TIMES[exp_id]

            # The stored time should match the corrupted PST time
            assert stored_time.startswith(expected_time[:16]), \
                f"Experiment {exp_id} should have corrupted time starting with {expected_time[:16]}, got {stored_time}"
        finally:
            conn.close()

    def test_query_returns_no_results_for_jan_15(self):
        """The problematic query should return incomplete results (the bug condition)."""
        conn = sqlite3.connect(TRACKER_DB)
        try:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT experiment_id FROM runs 
                WHERE start_time >= '2024-01-15 00:00:00' 
                AND start_time < '2024-01-16 00:00:00'
                ORDER BY experiment_id
            """)
            results = [row[0] for row in cursor.fetchall()]

            # Due to the bug, not all experiments should be returned
            # exp_001 and exp_002 have times on Jan 14 (PST), only exp_003 might match
            assert len(results) < 3, \
                f"Query should NOT return all 3 experiments due to the bug. Got {len(results)}: {results}"
        finally:
            conn.close()


class TestEnvironmentConfiguration:
    """Test that the environment is configured with the problematic MLOPS_TZ setting."""

    def test_env_file_contains_mlops_tz(self):
        """The .env file must contain the MLOPS_TZ setting."""
        with open(ENV_FILE, 'r') as f:
            content = f.read()

        assert "MLOPS_TZ" in content, ".env file does not contain MLOPS_TZ setting"
        assert "America/Los_Angeles" in content, \
            ".env file should have MLOPS_TZ=America/Los_Angeles"


class TestIngestScript:
    """Test that the ingest.py script exists and has the problematic code patterns."""

    def test_ingest_script_is_readable(self):
        """The ingest.py script must be readable."""
        with open(INGEST_SCRIPT, 'r') as f:
            content = f.read()
        assert len(content) > 0, "ingest.py is empty"

    def test_ingest_script_uses_utcnow(self):
        """The ingest.py script should use datetime.utcnow()."""
        with open(INGEST_SCRIPT, 'r') as f:
            content = f.read()

        assert "utcnow" in content, \
            "ingest.py should contain 'utcnow' as mentioned in the task description"

    def test_ingest_script_references_mlops_tz(self):
        """The ingest.py script should reference MLOPS_TZ environment variable."""
        with open(INGEST_SCRIPT, 'r') as f:
            content = f.read()

        assert "MLOPS_TZ" in content, \
            "ingest.py should reference MLOPS_TZ environment variable"

    def test_ingest_script_uses_dotenv(self):
        """The ingest.py script should use python-dotenv."""
        with open(INGEST_SCRIPT, 'r') as f:
            content = f.read()

        assert "dotenv" in content, \
            "ingest.py should use python-dotenv to load environment variables"


class TestPythonEnvironment:
    """Test that required Python packages are available."""

    def test_pytz_installed(self):
        """pytz must be installed."""
        result = subprocess.run(
            ["python3", "-c", "import pytz; print(pytz.__version__)"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "pytz is not installed"

    def test_python_dotenv_installed(self):
        """python-dotenv must be installed."""
        result = subprocess.run(
            ["python3", "-c", "import dotenv; print('ok')"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "python-dotenv is not installed"

    def test_sqlite3_available(self):
        """sqlite3 must be available."""
        result = subprocess.run(
            ["which", "sqlite3"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "sqlite3 command not available"


class TestDirectoryWritable:
    """Test that the mlops directory is writable."""

    def test_mlops_dir_is_writable(self):
        """The /home/user/mlops directory must be writable."""
        assert os.access(MLOPS_DIR, os.W_OK), f"{MLOPS_DIR} is not writable"

    def test_tracker_db_is_writable(self):
        """The tracker.db file must be writable."""
        assert os.access(TRACKER_DB, os.W_OK), f"{TRACKER_DB} is not writable"

    def test_ingest_script_is_writable(self):
        """The ingest.py file must be writable."""
        assert os.access(INGEST_SCRIPT, os.W_OK), f"{INGEST_SCRIPT} is not writable"

    def test_env_file_is_writable(self):
        """The .env file must be writable."""
        assert os.access(ENV_FILE, os.W_OK), f"{ENV_FILE} is not writable"
