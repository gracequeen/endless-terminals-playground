# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the deploy script fix task.
"""

import os
import stat
import subprocess
import pytest


class TestDeployScriptExists:
    """Verify the deploy script exists and is executable."""

    def test_deploy_script_exists(self):
        """The deploy script must exist at /home/user/release/deploy.sh"""
        script_path = "/home/user/release/deploy.sh"
        assert os.path.isfile(script_path), (
            f"Deploy script not found at {script_path}. "
            "The script must exist for this task."
        )

    def test_deploy_script_is_executable(self):
        """The deploy script must be executable."""
        script_path = "/home/user/release/deploy.sh"
        assert os.path.isfile(script_path), f"Script not found at {script_path}"
        mode = os.stat(script_path).st_mode
        assert mode & stat.S_IXUSR, (
            f"Deploy script at {script_path} is not executable by owner. "
            "Expected executable permissions."
        )

    def test_deploy_script_is_bash_script(self):
        """The deploy script should start with a bash shebang."""
        script_path = "/home/user/release/deploy.sh"
        with open(script_path, 'r') as f:
            first_line = f.readline().strip()
        assert first_line == "#!/bin/bash", (
            f"Deploy script should start with '#!/bin/bash', "
            f"but found: '{first_line}'"
        )


class TestDeployScriptContent:
    """Verify the deploy script has the expected buggy content."""

    def test_script_contains_deploy_root(self):
        """Script should define DEPLOY_ROOT variable."""
        script_path = "/home/user/release/deploy.sh"
        with open(script_path, 'r') as f:
            content = f.read()
        assert 'DEPLOY_ROOT="/srv/app"' in content, (
            "Script should contain DEPLOY_ROOT=\"/srv/app\" variable definition"
        )

    def test_script_contains_releases_dir(self):
        """Script should define RELEASES_DIR variable."""
        script_path = "/home/user/release/deploy.sh"
        with open(script_path, 'r') as f:
            content = f.read()
        assert 'RELEASES_DIR="$DEPLOY_ROOT/releases"' in content, (
            "Script should contain RELEASES_DIR variable definition"
        )

    def test_script_contains_new_release_43(self):
        """Script should have NEW_RELEASE set to release-43."""
        script_path = "/home/user/release/deploy.sh"
        with open(script_path, 'r') as f:
            content = f.read()
        assert 'NEW_RELEASE="release-43"' in content, (
            "Script should contain NEW_RELEASE=\"release-43\" variable definition"
        )

    def test_script_uses_atomic_pattern(self):
        """Script should use atomic symlink swap pattern with mv -T."""
        script_path = "/home/user/release/deploy.sh"
        with open(script_path, 'r') as f:
            content = f.read()
        assert 'mv -T' in content, (
            "Script should use 'mv -T' for atomic symlink swap pattern"
        )

    def test_script_creates_temp_link(self):
        """Script should create a temp link as part of atomic swap."""
        script_path = "/home/user/release/deploy.sh"
        with open(script_path, 'r') as f:
            content = f.read()
        assert 'TEMP_LINK=' in content, (
            "Script should define TEMP_LINK variable for atomic swap"
        )


class TestReleasesDirectory:
    """Verify the releases directory structure exists."""

    def test_srv_app_exists(self):
        """/srv/app directory must exist."""
        assert os.path.isdir("/srv/app"), (
            "/srv/app directory does not exist. "
            "This is required for the deploy task."
        )

    def test_releases_dir_exists(self):
        """/srv/app/releases directory must exist."""
        assert os.path.isdir("/srv/app/releases"), (
            "/srv/app/releases directory does not exist. "
            "This is required for the deploy task."
        )

    @pytest.mark.parametrize("release", ["release-40", "release-41", "release-42", "release-43"])
    def test_release_directories_exist(self, release):
        """All release directories (40-43) must exist."""
        release_path = f"/srv/app/releases/{release}"
        assert os.path.isdir(release_path), (
            f"Release directory {release_path} does not exist. "
            f"Expected all releases from release-40 to release-43."
        )


class TestReleaseContents:
    """Verify each release directory has the expected structure."""

    @pytest.mark.parametrize("release", ["release-40", "release-41", "release-42", "release-43"])
    def test_release_has_bin_app(self, release):
        """Each release should have bin/app executable."""
        app_path = f"/srv/app/releases/{release}/bin/app"
        assert os.path.isfile(app_path), (
            f"Expected {app_path} to exist in release directory"
        )

    @pytest.mark.parametrize("release", ["release-40", "release-41", "release-42", "release-43"])
    def test_release_has_config(self, release):
        """Each release should have config/app.conf."""
        config_path = f"/srv/app/releases/{release}/config/app.conf"
        assert os.path.isfile(config_path), (
            f"Expected {config_path} to exist in release directory"
        )

    @pytest.mark.parametrize("release", ["release-40", "release-41", "release-42", "release-43"])
    def test_release_has_lib_dir(self, release):
        """Each release should have lib/ directory."""
        lib_path = f"/srv/app/releases/{release}/lib"
        assert os.path.isdir(lib_path), (
            f"Expected {lib_path} directory to exist in release directory"
        )


class TestCurrentSymlink:
    """Verify the current symlink state."""

    def test_current_symlink_exists(self):
        """/srv/app/current must exist as a symlink."""
        current_path = "/srv/app/current"
        assert os.path.islink(current_path), (
            f"{current_path} should be a symlink, but it is not. "
            "The initial state requires a symlink pointing to release-42."
        )

    def test_current_points_to_release_42(self):
        """/srv/app/current must point to release-42."""
        current_path = "/srv/app/current"
        # Get the resolved path
        resolved = os.path.realpath(current_path)
        expected = "/srv/app/releases/release-42"
        assert resolved == expected, (
            f"/srv/app/current should resolve to {expected}, "
            f"but resolves to {resolved}. "
            "Initial state requires current -> release-42."
        )

    def test_current_is_absolute_symlink(self):
        """/srv/app/current should be an absolute symlink to release-42."""
        current_path = "/srv/app/current"
        link_target = os.readlink(current_path)
        expected_target = "/srv/app/releases/release-42"
        assert link_target == expected_target, (
            f"/srv/app/current symlink target should be absolute path "
            f"'{expected_target}', but found '{link_target}'. "
            "Initial state requires an absolute symlink."
        )


class TestPermissions:
    """Verify write permissions for the task."""

    def test_srv_app_writable(self):
        """/srv/app should be writable."""
        assert os.access("/srv/app", os.W_OK), (
            "/srv/app is not writable. "
            "The agent user needs write access to complete this task."
        )

    def test_releases_dir_writable(self):
        """/srv/app/releases should be writable."""
        assert os.access("/srv/app/releases", os.W_OK), (
            "/srv/app/releases is not writable. "
            "The agent user needs write access to complete this task."
        )

    def test_deploy_script_writable(self):
        """The deploy script should be writable for fixing."""
        script_path = "/home/user/release/deploy.sh"
        assert os.access(script_path, os.W_OK), (
            f"{script_path} is not writable. "
            "The agent user needs write access to fix the script."
        )


class TestRelease43Accessible:
    """Verify release-43 is properly set up for deployment."""

    def test_release_43_bin_app_executable(self):
        """release-43/bin/app should be executable."""
        app_path = "/srv/app/releases/release-43/bin/app"
        assert os.path.isfile(app_path), f"{app_path} does not exist"
        mode = os.stat(app_path).st_mode
        assert mode & stat.S_IXUSR, (
            f"{app_path} should be executable"
        )

    def test_release_43_fully_accessible(self):
        """release-43 directory should be readable and executable (traversable)."""
        release_path = "/srv/app/releases/release-43"
        assert os.access(release_path, os.R_OK | os.X_OK), (
            f"{release_path} should be readable and traversable"
        )
