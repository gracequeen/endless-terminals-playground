Deploy script at /home/user/release/deploy.sh is failing on the symlink rotation step — it's supposed to atomically swap /srv/app/current to point at the new release dir, but something's off. The deploy log shows it ran to completion with exit 0, yet /srv/app/current still points at the old release (release-42) instead of the new one (release-43). I've run it three times now, same result every time.

    The weird part is if I manually run `ln -sfn /srv/app/releases/release-43 /srv/app/current` it works fine. So the command itself isn't broken, but something in the script's logic is silently doing the wrong thing. Maybe a quoting issue or path expansion? I honestly don't know.

    Need the deploy script fixed so running it actually swaps current -> release-43. Don't just hack around it by running the ln command separately — the script needs to work because CI calls it.
