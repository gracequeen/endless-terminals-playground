# test_final_state.py
"""
Tests to validate the final state after the student has fixed the deploy script.
The script should correctly swap /srv/app/current to point at release-43.
"""

import os
import stat
import subprocess
import re
import pytest


class TestDeployScriptStillExists:
    """Verify the deploy script still exists and is executable after fix."""

    def test_deploy_script_exists(self):
        """The deploy script must still exist at /home/user/release/deploy.sh"""
        script_path = "/home/user/release/deploy.sh"
        assert os.path.isfile(script_path), (
            f"Deploy script not found at {script_path}. "
            "The script must exist after the fix."
        )

    def test_deploy_script_is_executable(self):
        """The deploy script must still be executable."""
        script_path = "/home/user/release/deploy.sh"
        assert os.path.isfile(script_path), f"Script not found at {script_path}"
        mode = os.stat(script_path).st_mode
        assert mode & stat.S_IXUSR, (
            f"Deploy script at {script_path} is not executable by owner. "
            "Expected executable permissions."
        )

    def test_deploy_script_is_bash_script(self):
        """The deploy script should still start with a bash shebang."""
        script_path = "/home/user/release/deploy.sh"
        with open(script_path, 'r') as f:
            first_line = f.readline().strip()
        assert first_line == "#!/bin/bash", (
            f"Deploy script should start with '#!/bin/bash', "
            f"but found: '{first_line}'"
        )


class TestDeployScriptPreservesAtomicPattern:
    """Verify the script still uses the atomic symlink swap pattern."""

    def test_script_uses_mv_T_for_atomic_swap(self):
        """Script must still use 'mv -T' for atomic symlink swap."""
        script_path = "/home/user/release/deploy.sh"
        with open(script_path, 'r') as f:
            content = f.read()
        assert 'mv -T' in content or 'mv  -T' in content, (
            "Script must use 'mv -T' for atomic symlink swap pattern. "
            "Do not replace with 'ln -sfn' directly as that's not atomic."
        )

    def test_script_does_not_use_ln_sfn_directly_on_current(self):
        """Script should NOT use 'ln -sfn ... current' directly (not atomic)."""
        script_path = "/home/user/release/deploy.sh"
        with open(script_path, 'r') as f:
            content = f.read()
        # Check for pattern like 'ln -sfn ... $CURRENT_LINK' or 'ln -sfn ... /srv/app/current'
        # at end of line (indicating direct overwrite, not atomic pattern)
        pattern = r'ln\s+-sfn\s+.*\$CURRENT_LINK\s*$|ln\s+-sfn\s+.*/srv/app/current\s*$'
        matches = re.findall(pattern, content, re.MULTILINE)
        assert len(matches) == 0, (
            "Script should NOT use 'ln -sfn' directly on $CURRENT_LINK or /srv/app/current. "
            "The atomic pattern (create temp link, mv -T) must be preserved. "
            f"Found: {matches}"
        )

    def test_script_creates_temp_link(self):
        """Script should still create a temp link as part of atomic swap."""
        script_path = "/home/user/release/deploy.sh"
        with open(script_path, 'r') as f:
            content = f.read()
        # Check for temp link creation pattern
        assert 'TEMP_LINK' in content or '.tmp' in content, (
            "Script should still use a temporary link for atomic swap pattern"
        )

    def test_script_still_has_new_release_variable(self):
        """Script should still use NEW_RELEASE variable (not hardcoded paths)."""
        script_path = "/home/user/release/deploy.sh"
        with open(script_path, 'r') as f:
            content = f.read()
        assert 'NEW_RELEASE=' in content, (
            "Script should still define NEW_RELEASE variable. "
            "The fix should be general, not hardcoded for release-43."
        )


class TestReleasesDirectoryIntact:
    """Verify all release directories are still intact."""

    @pytest.mark.parametrize("release", ["release-40", "release-41", "release-42", "release-43"])
    def test_release_directories_still_exist(self, release):
        """All release directories (40-43) must still exist."""
        release_path = f"/srv/app/releases/{release}"
        assert os.path.isdir(release_path), (
            f"Release directory {release_path} should still exist. "
            f"The fix should not remove or modify release directories."
        )

    @pytest.mark.parametrize("release", ["release-40", "release-41", "release-42", "release-43"])
    def test_release_has_bin_app(self, release):
        """Each release should still have bin/app."""
        app_path = f"/srv/app/releases/{release}/bin/app"
        assert os.path.isfile(app_path), (
            f"Expected {app_path} to still exist in release directory"
        )


class TestDeployScriptExecution:
    """Test that running the deploy script works correctly."""

    @pytest.fixture(autouse=True)
    def reset_and_run_deploy(self):
        """Reset current symlink to release-42, then run the deploy script."""
        current_path = "/srv/app/current"

        # Reset symlink to release-42 (absolute path) to simulate initial state
        if os.path.islink(current_path) or os.path.exists(current_path):
            os.remove(current_path)
        os.symlink("/srv/app/releases/release-42", current_path)

        # Verify reset worked
        assert os.readlink(current_path) == "/srv/app/releases/release-42", (
            "Failed to reset symlink for test"
        )

        # Run the deploy script
        result = subprocess.run(
            ["bash", "/home/user/release/deploy.sh"],
            capture_output=True,
            text=True
        )

        self.script_result = result
        yield
        # No cleanup needed

    def test_deploy_script_exits_zero(self):
        """The deploy script should exit with code 0."""
        assert self.script_result.returncode == 0, (
            f"Deploy script should exit with code 0, but got {self.script_result.returncode}. "
            f"stdout: {self.script_result.stdout}\n"
            f"stderr: {self.script_result.stderr}"
        )

    def test_current_symlink_exists_after_deploy(self):
        """/srv/app/current must exist as a symlink after deploy."""
        current_path = "/srv/app/current"
        assert os.path.islink(current_path), (
            f"{current_path} should be a symlink after deploy, but it is not."
        )

    def test_current_resolves_to_release_43(self):
        """/srv/app/current must resolve to /srv/app/releases/release-43."""
        current_path = "/srv/app/current"
        resolved = os.path.realpath(current_path)
        expected = "/srv/app/releases/release-43"
        assert resolved == expected, (
            f"/srv/app/current should resolve to {expected}, "
            f"but resolves to {resolved}. "
            "The deploy script fix should make the symlink point to release-43."
        )

    def test_readlink_f_shows_release_43(self):
        """readlink -f /srv/app/current should return /srv/app/releases/release-43."""
        result = subprocess.run(
            ["readlink", "-f", "/srv/app/current"],
            capture_output=True,
            text=True
        )
        resolved = result.stdout.strip()
        expected = "/srv/app/releases/release-43"
        assert resolved == expected, (
            f"'readlink -f /srv/app/current' should return {expected}, "
            f"but returned {resolved}. "
            "The symlink is not resolving correctly to release-43."
        )

    def test_current_bin_app_accessible(self):
        """ls /srv/app/current/bin/app should succeed (symlink resolves correctly)."""
        result = subprocess.run(
            ["ls", "/srv/app/current/bin/app"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"'ls /srv/app/current/bin/app' should succeed, but failed. "
            f"This means the symlink doesn't resolve to a valid release. "
            f"stderr: {result.stderr}"
        )

    def test_current_config_accessible(self):
        """/srv/app/current/config/app.conf should be accessible."""
        config_path = "/srv/app/current/config/app.conf"
        assert os.path.isfile(config_path), (
            f"{config_path} should be accessible through the current symlink. "
            "This indicates the symlink is not resolving correctly."
        )


class TestSymlinkResolutionMultipleRuns:
    """Test that the script works correctly on multiple runs."""

    def test_script_works_after_reset(self):
        """Script should work correctly when run after resetting to release-42."""
        current_path = "/srv/app/current"

        # Reset to release-42
        if os.path.islink(current_path) or os.path.exists(current_path):
            os.remove(current_path)
        os.symlink("/srv/app/releases/release-42", current_path)

        # Run deploy
        result = subprocess.run(
            ["bash", "/home/user/release/deploy.sh"],
            capture_output=True,
            text=True
        )

        assert result.returncode == 0, f"Script failed: {result.stderr}"

        resolved = os.path.realpath(current_path)
        assert resolved == "/srv/app/releases/release-43", (
            f"After running deploy script, current should resolve to release-43, "
            f"but resolves to {resolved}"
        )


class TestScriptGenerality:
    """Test that the fix is general and would work for other releases."""

    def test_script_uses_variables_not_hardcoded_paths(self):
        """The ln command in the script should use variables, not hardcoded release-43."""
        script_path = "/home/user/release/deploy.sh"
        with open(script_path, 'r') as f:
            content = f.read()

        # Find all ln commands
        ln_commands = re.findall(r'ln\s+-s[^\n]*', content)

        # Check that none of them have hardcoded "release-43" path that bypasses variables
        for cmd in ln_commands:
            # It's okay to have release-43 in the NEW_RELEASE variable definition
            # but not directly in the ln command as a literal path
            if '/srv/app/releases/release-43' in cmd:
                # This might be okay if it's using variable expansion
                # But a fully hardcoded path would break generality
                pass

        # The script should reference $NEW_RELEASE or $RELEASES_DIR/$NEW_RELEASE
        # or similar variable-based paths
        assert '$NEW_RELEASE' in content or '${NEW_RELEASE}' in content, (
            "Script should use $NEW_RELEASE variable in the symlink creation, "
            "not hardcoded paths. The fix should be general."
        )
