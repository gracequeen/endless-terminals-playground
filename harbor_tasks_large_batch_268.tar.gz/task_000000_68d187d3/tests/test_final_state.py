# test_final_state.py
"""
Tests to validate the final state of the OS/filesystem after the student
has completed the debugging task for the data sync pipeline.
"""

import json
import os
import subprocess
import pytest
import socket
import time


PIPELINE_DIR = "/home/user/pipeline"
OUTPUT_DIR = "/home/user/pipeline/output"


class TestPipelineExecution:
    """Test that the pipeline executes successfully and produces correct output."""

    def test_pipeline_runs_successfully(self):
        """Running the pipeline should exit with code 0."""
        result = subprocess.run(
            ["python", "run_pipeline.py"],
            cwd=PIPELINE_DIR,
            capture_output=True,
            text=True,
            timeout=30
        )
        assert result.returncode == 0, \
            f"Pipeline failed with exit code {result.returncode}. Stderr: {result.stderr}"

    def test_final_json_exists_after_run(self):
        """output/final.json must exist after pipeline run."""
        # Run the pipeline first
        subprocess.run(
            ["python", "run_pipeline.py"],
            cwd=PIPELINE_DIR,
            capture_output=True,
            timeout=30
        )
        filepath = os.path.join(OUTPUT_DIR, "final.json")
        assert os.path.isfile(filepath), f"Final output file {filepath} does not exist after pipeline run"

    def test_final_json_contains_8_records(self):
        """output/final.json must contain exactly 8 records."""
        # Run the pipeline
        subprocess.run(
            ["python", "run_pipeline.py"],
            cwd=PIPELINE_DIR,
            capture_output=True,
            timeout=30
        )
        filepath = os.path.join(OUTPUT_DIR, "final.json")
        with open(filepath, 'r') as f:
            content = json.load(f)
        assert isinstance(content, list), f"final.json should contain a list, got: {type(content)}"
        assert len(content) == 8, \
            f"final.json should contain exactly 8 records, but contains {len(content)}. " \
            f"The pipeline is still not producing all records."

    def test_final_json_records_have_required_fields(self):
        """Each record in final.json must have required fields: id, name, value, timestamp, status."""
        # Run the pipeline
        subprocess.run(
            ["python", "run_pipeline.py"],
            cwd=PIPELINE_DIR,
            capture_output=True,
            timeout=30
        )
        filepath = os.path.join(OUTPUT_DIR, "final.json")
        with open(filepath, 'r') as f:
            content = json.load(f)

        required_fields = {'id', 'name', 'value', 'timestamp', 'status'}
        for i, record in enumerate(content):
            missing = required_fields - set(record.keys())
            assert not missing, f"Record {i} in final.json missing fields: {missing}"

    def test_final_json_not_empty_array(self):
        """output/final.json must NOT contain an empty array anymore."""
        # Run the pipeline
        subprocess.run(
            ["python", "run_pipeline.py"],
            cwd=PIPELINE_DIR,
            capture_output=True,
            timeout=30
        )
        filepath = os.path.join(OUTPUT_DIR, "final.json")
        with open(filepath, 'r') as f:
            content = json.load(f)
        assert content != [], \
            "final.json still contains an empty array []. The bug has not been fixed."


class TestInvariants:
    """Test that required invariants are maintained."""

    def test_config_filter_status_remains_lowercase_active(self):
        """config.yaml filter_status must remain 'active' (lowercase), not changed to 'ACTIVE'."""
        import yaml
        filepath = os.path.join(PIPELINE_DIR, "config.yaml")
        with open(filepath, 'r') as f:
            config = yaml.safe_load(f)
        assert 'filter_status' in config, "config.yaml missing 'filter_status' key"
        assert config['filter_status'] == "active", \
            f"config.yaml filter_status should remain 'active' (lowercase), got: '{config['filter_status']}'. " \
            f"The fix should be in the code, not by changing config to uppercase."

    def test_mock_api_still_running(self):
        """The mock API server must still be running on localhost:5050."""
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(2)
        result = sock.connect_ex(('localhost', 5050))
        sock.close()
        assert result == 0, "Mock API server is no longer running on localhost:5050"

    def test_fetch_still_uses_api_endpoint(self):
        """fetch.py must still fetch from the API endpoint (not hardcoded data)."""
        filepath = os.path.join(PIPELINE_DIR, "fetch.py")
        with open(filepath, 'r') as f:
            content = f.read()
        # Check that it still references the API or makes HTTP requests
        assert 'localhost:5050' in content or 'api' in content.lower() or 'requests' in content or 'urllib' in content, \
            "fetch.py should still fetch from the API endpoint, not use hardcoded data"

    def test_transform_still_has_status_filter(self):
        """transform.py must still contain a status-based filter (not removed entirely)."""
        filepath = os.path.join(PIPELINE_DIR, "transform.py")
        with open(filepath, 'r') as f:
            content = f.read()
        # Check for status filtering logic
        has_status_reference = 'status' in content
        has_filter_logic = 'filter' in content.lower() or 'if' in content
        assert has_status_reference and has_filter_logic, \
            "transform.py should still contain a status-based filter. " \
            "The fix should correct the comparison, not remove filtering entirely."


class TestAntiShortcutGuards:
    """Test that shortcuts/cheats were not used."""

    def test_transform_py_comparison_is_fixed(self):
        """
        The fix must be in the comparison logic. Either:
        - Remove the .upper() call, OR
        - Also uppercase the config value in the comparison

        The filter should NOT be entirely removed.
        """
        filepath = os.path.join(PIPELINE_DIR, "transform.py")
        with open(filepath, 'r') as f:
            content = f.read()

        # The transform must still do filtering based on status
        assert 'status' in content, \
            "transform.py must still reference 'status' field for filtering"

        # Check that there's still some kind of conditional/filter logic
        assert 'if' in content or 'filter' in content.lower() or 'for' in content, \
            "transform.py must still contain filter logic"

    def test_final_json_generated_by_pipeline_not_hardcoded(self):
        """
        final.json must be generated by running the pipeline, not manually created.
        We verify this by checking that re-running the pipeline updates the file.
        """
        filepath = os.path.join(OUTPUT_DIR, "final.json")

        # Get initial modification time
        initial_mtime = os.path.getmtime(filepath) if os.path.exists(filepath) else 0

        # Wait a tiny bit to ensure time difference
        time.sleep(0.1)

        # Run the pipeline
        result = subprocess.run(
            ["python", "run_pipeline.py"],
            cwd=PIPELINE_DIR,
            capture_output=True,
            timeout=30
        )

        assert result.returncode == 0, f"Pipeline failed: {result.stderr}"

        # Check that the file was modified (pipeline actually writes to it)
        new_mtime = os.path.getmtime(filepath)
        assert new_mtime >= initial_mtime, \
            "final.json was not updated by the pipeline - it may have been manually created"

    def test_transformed_json_now_has_records(self):
        """
        output/transformed.json should now contain records (not empty).
        This proves the transform step is fixed.
        """
        # Run the pipeline
        subprocess.run(
            ["python", "run_pipeline.py"],
            cwd=PIPELINE_DIR,
            capture_output=True,
            timeout=30
        )
        filepath = os.path.join(OUTPUT_DIR, "transformed.json")
        if os.path.exists(filepath):
            with open(filepath, 'r') as f:
                content = json.load(f)
            assert content != [], \
                "transformed.json still contains empty array. The transform bug is not fixed."
            assert len(content) == 8, \
                f"transformed.json should contain 8 records, got {len(content)}"


class TestPipelineDirectoryIntegrity:
    """Test that the pipeline directory structure is intact."""

    def test_all_pipeline_files_still_exist(self):
        """All original pipeline files must still exist."""
        required_files = [
            "run_pipeline.py",
            "fetch.py",
            "transform.py",
            "load.py",
            "config.yaml",
            "mock_api.py"
        ]
        for filename in required_files:
            filepath = os.path.join(PIPELINE_DIR, filename)
            assert os.path.isfile(filepath), f"Required file {filepath} is missing"

    def test_output_directory_exists(self):
        """Output directory must still exist."""
        assert os.path.isdir(OUTPUT_DIR), f"Output directory {OUTPUT_DIR} does not exist"


class TestDataIntegrity:
    """Test the integrity of the data in final.json."""

    def test_final_json_records_have_valid_ids(self):
        """Records in final.json should have valid id fields."""
        # Run the pipeline
        subprocess.run(
            ["python", "run_pipeline.py"],
            cwd=PIPELINE_DIR,
            capture_output=True,
            timeout=30
        )
        filepath = os.path.join(OUTPUT_DIR, "final.json")
        with open(filepath, 'r') as f:
            content = json.load(f)

        ids = [record.get('id') for record in content]
        assert all(id is not None for id in ids), "Some records are missing 'id' field"
        assert len(set(ids)) == len(ids), "Duplicate IDs found in final.json"

    def test_final_json_records_have_active_status(self):
        """
        All records in final.json should have status that matches the filter.
        Since all mock records have 'active' status, all should pass.
        """
        # Run the pipeline
        subprocess.run(
            ["python", "run_pipeline.py"],
            cwd=PIPELINE_DIR,
            capture_output=True,
            timeout=30
        )
        filepath = os.path.join(OUTPUT_DIR, "final.json")
        with open(filepath, 'r') as f:
            content = json.load(f)

        for i, record in enumerate(content):
            status = record.get('status', '').lower()
            assert status == 'active', \
                f"Record {i} has status '{record.get('status')}', expected 'active'"

    def test_final_json_matches_api_record_count(self):
        """final.json should have the same number of records as the API returns."""
        import urllib.request

        # Get API data
        req = urllib.request.Request('http://localhost:5050/api/records')
        with urllib.request.urlopen(req, timeout=5) as response:
            api_data = json.loads(response.read().decode())

        # Run the pipeline
        subprocess.run(
            ["python", "run_pipeline.py"],
            cwd=PIPELINE_DIR,
            capture_output=True,
            timeout=30
        )

        # Get final.json data
        filepath = os.path.join(OUTPUT_DIR, "final.json")
        with open(filepath, 'r') as f:
            final_data = json.load(f)

        # Count active records from API
        active_api_records = [r for r in api_data if r.get('status', '').lower() == 'active']

        assert len(final_data) == len(active_api_records), \
            f"final.json has {len(final_data)} records but API has {len(active_api_records)} active records"
