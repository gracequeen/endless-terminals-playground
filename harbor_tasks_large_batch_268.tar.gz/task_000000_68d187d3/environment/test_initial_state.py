# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the debugging task for the data sync pipeline.
"""

import json
import os
import subprocess
import pytest
import socket
import time


PIPELINE_DIR = "/home/user/pipeline"
OUTPUT_DIR = "/home/user/pipeline/output"


class TestPipelineDirectoryStructure:
    """Test that the pipeline directory and required files exist."""

    def test_pipeline_directory_exists(self):
        """Pipeline directory must exist."""
        assert os.path.isdir(PIPELINE_DIR), f"Pipeline directory {PIPELINE_DIR} does not exist"

    def test_run_pipeline_py_exists(self):
        """run_pipeline.py orchestrator must exist."""
        filepath = os.path.join(PIPELINE_DIR, "run_pipeline.py")
        assert os.path.isfile(filepath), f"Orchestrator {filepath} does not exist"

    def test_fetch_py_exists(self):
        """fetch.py must exist."""
        filepath = os.path.join(PIPELINE_DIR, "fetch.py")
        assert os.path.isfile(filepath), f"Fetch module {filepath} does not exist"

    def test_transform_py_exists(self):
        """transform.py must exist."""
        filepath = os.path.join(PIPELINE_DIR, "transform.py")
        assert os.path.isfile(filepath), f"Transform module {filepath} does not exist"

    def test_load_py_exists(self):
        """load.py must exist."""
        filepath = os.path.join(PIPELINE_DIR, "load.py")
        assert os.path.isfile(filepath), f"Load module {filepath} does not exist"

    def test_config_yaml_exists(self):
        """config.yaml must exist."""
        filepath = os.path.join(PIPELINE_DIR, "config.yaml")
        assert os.path.isfile(filepath), f"Config file {filepath} does not exist"

    def test_mock_api_py_exists(self):
        """mock_api.py must exist."""
        filepath = os.path.join(PIPELINE_DIR, "mock_api.py")
        assert os.path.isfile(filepath), f"Mock API script {filepath} does not exist"

    def test_output_directory_exists(self):
        """Output directory must exist."""
        assert os.path.isdir(OUTPUT_DIR), f"Output directory {OUTPUT_DIR} does not exist"

    def test_output_directory_is_writable(self):
        """Output directory must be writable."""
        assert os.access(OUTPUT_DIR, os.W_OK), f"Output directory {OUTPUT_DIR} is not writable"

    def test_pipeline_directory_is_writable(self):
        """Pipeline directory must be writable."""
        assert os.access(PIPELINE_DIR, os.W_OK), f"Pipeline directory {PIPELINE_DIR} is not writable"


class TestInitialOutputState:
    """Test the initial state of output files."""

    def test_final_json_exists(self):
        """output/final.json must exist."""
        filepath = os.path.join(OUTPUT_DIR, "final.json")
        assert os.path.isfile(filepath), f"Final output file {filepath} does not exist"

    def test_final_json_contains_empty_array(self):
        """output/final.json must contain an empty array initially."""
        filepath = os.path.join(OUTPUT_DIR, "final.json")
        with open(filepath, 'r') as f:
            content = json.load(f)
        assert content == [], f"final.json should contain empty array [], but contains: {content}"

    def test_fetched_json_exists(self):
        """output/fetched.json must exist (proves fetch works)."""
        filepath = os.path.join(OUTPUT_DIR, "fetched.json")
        assert os.path.isfile(filepath), f"Fetched data file {filepath} does not exist"

    def test_fetched_json_contains_8_records(self):
        """output/fetched.json must contain 8 records."""
        filepath = os.path.join(OUTPUT_DIR, "fetched.json")
        with open(filepath, 'r') as f:
            content = json.load(f)
        assert isinstance(content, list), f"fetched.json should contain a list, got: {type(content)}"
        assert len(content) == 8, f"fetched.json should contain 8 records, but contains {len(content)}"

    def test_fetched_json_records_have_required_fields(self):
        """Each record in fetched.json must have required fields."""
        filepath = os.path.join(OUTPUT_DIR, "fetched.json")
        with open(filepath, 'r') as f:
            content = json.load(f)
        required_fields = {'id', 'name', 'value', 'timestamp', 'status'}
        for i, record in enumerate(content):
            missing = required_fields - set(record.keys())
            assert not missing, f"Record {i} in fetched.json missing fields: {missing}"

    def test_transformed_json_exists(self):
        """output/transformed.json must exist (the smoking gun)."""
        filepath = os.path.join(OUTPUT_DIR, "transformed.json")
        assert os.path.isfile(filepath), f"Transformed data file {filepath} does not exist"

    def test_transformed_json_contains_empty_array(self):
        """output/transformed.json must contain empty array (the bug symptom)."""
        filepath = os.path.join(OUTPUT_DIR, "transformed.json")
        with open(filepath, 'r') as f:
            content = json.load(f)
        assert content == [], f"transformed.json should contain empty array [] (the bug), but contains: {content}"


class TestConfigFile:
    """Test the configuration file state."""

    def test_config_has_filter_status_active(self):
        """config.yaml must have filter_status set to 'active' (lowercase)."""
        import yaml
        filepath = os.path.join(PIPELINE_DIR, "config.yaml")
        with open(filepath, 'r') as f:
            config = yaml.safe_load(f)
        assert 'filter_status' in config, "config.yaml missing 'filter_status' key"
        assert config['filter_status'] == "active", \
            f"config.yaml filter_status should be 'active', got: {config['filter_status']}"


class TestMockAPIServer:
    """Test that the mock API server is running and responding."""

    def test_port_5050_is_listening(self):
        """Port 5050 must be listening (mock API server)."""
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(2)
        result = sock.connect_ex(('localhost', 5050))
        sock.close()
        assert result == 0, "Mock API server is not listening on localhost:5050"

    def test_mock_api_process_is_running(self):
        """A Python process running mock_api.py should be active."""
        result = subprocess.run(
            ["pgrep", "-f", "mock_api.py"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "No process running mock_api.py found"

    def test_api_endpoint_returns_data(self):
        """GET /api/records must return data."""
        import urllib.request
        import urllib.error

        try:
            req = urllib.request.Request('http://localhost:5050/api/records')
            with urllib.request.urlopen(req, timeout=5) as response:
                data = json.loads(response.read().decode())
                assert isinstance(data, list), f"API should return a list, got: {type(data)}"
        except urllib.error.URLError as e:
            pytest.fail(f"Could not connect to mock API at localhost:5050: {e}")

    def test_api_returns_8_records(self):
        """API must return exactly 8 records."""
        import urllib.request

        req = urllib.request.Request('http://localhost:5050/api/records')
        with urllib.request.urlopen(req, timeout=5) as response:
            data = json.loads(response.read().decode())
        assert len(data) == 8, f"API should return 8 records, got {len(data)}"

    def test_api_records_have_required_fields(self):
        """API records must have required fields: id, name, value, timestamp, status."""
        import urllib.request

        req = urllib.request.Request('http://localhost:5050/api/records')
        with urllib.request.urlopen(req, timeout=5) as response:
            data = json.loads(response.read().decode())

        required_fields = {'id', 'name', 'value', 'timestamp', 'status'}
        for i, record in enumerate(data):
            missing = required_fields - set(record.keys())
            assert not missing, f"API record {i} missing fields: {missing}"


class TestTransformBugPresent:
    """Test that the bug is present in transform.py (the .upper() call)."""

    def test_transform_py_contains_upper_call(self):
        """transform.py should contain the buggy .upper() call."""
        filepath = os.path.join(PIPELINE_DIR, "transform.py")
        with open(filepath, 'r') as f:
            content = f.read()
        assert '.upper()' in content, \
            "transform.py should contain the buggy .upper() call that causes the filter mismatch"

    def test_transform_py_contains_status_filter(self):
        """transform.py should contain a status-based filter condition."""
        filepath = os.path.join(PIPELINE_DIR, "transform.py")
        with open(filepath, 'r') as f:
            content = f.read()
        assert 'status' in content and 'filter' in content.lower(), \
            "transform.py should contain a status-based filter"


class TestPythonEnvironment:
    """Test that required Python packages are available."""

    def test_python3_available(self):
        """Python 3 must be available."""
        result = subprocess.run(
            ["python3", "--version"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "Python 3 is not available"

    def test_flask_installed(self):
        """Flask must be installed."""
        result = subprocess.run(
            ["python3", "-c", "import flask"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "Flask is not installed"

    def test_pyyaml_installed(self):
        """PyYAML must be installed."""
        result = subprocess.run(
            ["python3", "-c", "import yaml"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "PyYAML is not installed"

    def test_requests_installed(self):
        """requests must be installed."""
        result = subprocess.run(
            ["python3", "-c", "import requests"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "requests is not installed"
