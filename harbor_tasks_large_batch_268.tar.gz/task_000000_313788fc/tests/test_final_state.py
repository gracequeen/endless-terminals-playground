# test_final_state.py
"""
Tests to validate the final state of the OS/filesystem after the student
has completed the backup rotation directory setup task.
"""

import os
import stat
import subprocess
import pytest


class TestFinalState:
    """Validate the final state after the task is performed."""

    def test_backups_directory_exists(self):
        """Verify /home/user/backups exists."""
        assert os.path.exists("/home/user/backups"), \
            "/home/user/backups does not exist - the backups directory must be created"

    def test_backups_directory_is_directory(self):
        """Verify /home/user/backups is a directory."""
        assert os.path.isdir("/home/user/backups"), \
            "/home/user/backups exists but is not a directory"

    def test_daily_0_exists(self):
        """Verify /home/user/backups/daily.0 exists."""
        assert os.path.exists("/home/user/backups/daily.0"), \
            "/home/user/backups/daily.0 does not exist - this directory must be created"

    def test_daily_0_is_directory(self):
        """Verify /home/user/backups/daily.0 is a directory."""
        assert os.path.isdir("/home/user/backups/daily.0"), \
            "/home/user/backups/daily.0 exists but is not a directory"

    def test_daily_1_exists(self):
        """Verify /home/user/backups/daily.1 exists."""
        assert os.path.exists("/home/user/backups/daily.1"), \
            "/home/user/backups/daily.1 does not exist - this directory must be created"

    def test_daily_1_is_directory(self):
        """Verify /home/user/backups/daily.1 is a directory."""
        assert os.path.isdir("/home/user/backups/daily.1"), \
            "/home/user/backups/daily.1 exists but is not a directory"

    def test_daily_2_exists(self):
        """Verify /home/user/backups/daily.2 exists."""
        assert os.path.exists("/home/user/backups/daily.2"), \
            "/home/user/backups/daily.2 does not exist - this directory must be created"

    def test_daily_2_is_directory(self):
        """Verify /home/user/backups/daily.2 is a directory."""
        assert os.path.isdir("/home/user/backups/daily.2"), \
            "/home/user/backups/daily.2 exists but is not a directory"

    def test_daily_0_permissions(self):
        """Verify /home/user/backups/daily.0 has permissions 750."""
        mode = os.stat("/home/user/backups/daily.0").st_mode
        perms = stat.S_IMODE(mode)
        expected_perms = 0o750
        assert perms == expected_perms, \
            f"/home/user/backups/daily.0 has permissions {oct(perms)} but expected 0o750 (750)"

    def test_daily_1_permissions(self):
        """Verify /home/user/backups/daily.1 has permissions 750."""
        mode = os.stat("/home/user/backups/daily.1").st_mode
        perms = stat.S_IMODE(mode)
        expected_perms = 0o750
        assert perms == expected_perms, \
            f"/home/user/backups/daily.1 has permissions {oct(perms)} but expected 0o750 (750)"

    def test_daily_2_permissions(self):
        """Verify /home/user/backups/daily.2 has permissions 750."""
        mode = os.stat("/home/user/backups/daily.2").st_mode
        perms = stat.S_IMODE(mode)
        expected_perms = 0o750
        assert perms == expected_perms, \
            f"/home/user/backups/daily.2 has permissions {oct(perms)} but expected 0o750 (750)"

    def test_stat_command_verification(self):
        """Verify permissions using stat command as specified in truth."""
        result = subprocess.run(
            ["stat", "-c", "%a", 
             "/home/user/backups/daily.0",
             "/home/user/backups/daily.1",
             "/home/user/backups/daily.2"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            f"stat command failed: {result.stderr}"

        lines = result.stdout.strip().split('\n')
        assert len(lines) == 3, \
            f"Expected 3 lines of output from stat, got {len(lines)}: {lines}"

        for i, line in enumerate(lines):
            assert line.strip() == "750", \
                f"daily.{i} has permissions '{line.strip()}' but expected '750'"

    def test_no_extra_files_in_backups(self):
        """Verify no extra files or directories exist under /home/user/backups."""
        expected_entries = {"daily.0", "daily.1", "daily.2"}
        actual_entries = set(os.listdir("/home/user/backups"))

        extra_entries = actual_entries - expected_entries
        missing_entries = expected_entries - actual_entries

        assert not extra_entries, \
            f"Unexpected files/directories found in /home/user/backups: {extra_entries}"
        assert not missing_entries, \
            f"Missing required directories in /home/user/backups: {missing_entries}"

    def test_daily_directories_are_empty(self):
        """Verify the daily directories are empty as specified."""
        for i in range(3):
            dir_path = f"/home/user/backups/daily.{i}"
            contents = os.listdir(dir_path)
            assert len(contents) == 0, \
                f"{dir_path} is not empty, contains: {contents}"
