# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the backup rotation directory setup task.
"""

import os
import stat
import subprocess
import pytest


class TestInitialState:
    """Validate the initial state before the task is performed."""

    def test_home_user_exists(self):
        """Verify /home/user exists."""
        assert os.path.exists("/home/user"), \
            "/home/user does not exist - this directory must exist before the task"

    def test_home_user_is_directory(self):
        """Verify /home/user is a directory."""
        assert os.path.isdir("/home/user"), \
            "/home/user exists but is not a directory"

    def test_home_user_is_writable(self):
        """Verify /home/user is writable."""
        assert os.access("/home/user", os.W_OK), \
            "/home/user is not writable - write permission is required to create backups directory"

    def test_backups_directory_does_not_exist(self):
        """Verify /home/user/backups does not exist yet."""
        assert not os.path.exists("/home/user/backups"), \
            "/home/user/backups already exists - it should not exist before the task"

    def test_mkdir_available(self):
        """Verify mkdir command is available."""
        result = subprocess.run(
            ["which", "mkdir"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            "mkdir command is not available - coreutils must be installed"

    def test_chmod_available(self):
        """Verify chmod command is available."""
        result = subprocess.run(
            ["which", "chmod"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            "chmod command is not available - coreutils must be installed"

    def test_stat_available(self):
        """Verify stat command is available (needed for verification)."""
        result = subprocess.run(
            ["which", "stat"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            "stat command is not available - coreutils must be installed"
