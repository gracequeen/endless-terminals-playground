# test_initial_state.py
"""
Tests to validate the initial state of the system before the student
adds the last_login column to the users table.
"""

import os
import sqlite3
import subprocess
import pytest


DB_PATH = "/home/user/app/data.db"
APP_DIR = "/home/user/app"


class TestDirectoryStructure:
    """Test that required directories exist and are writable."""

    def test_app_directory_exists(self):
        """The /home/user/app/ directory must exist."""
        assert os.path.isdir(APP_DIR), f"Directory {APP_DIR} does not exist"

    def test_app_directory_is_writable(self):
        """The /home/user/app/ directory must be writable."""
        assert os.access(APP_DIR, os.W_OK), f"Directory {APP_DIR} is not writable"


class TestDatabaseFile:
    """Test that the database file exists and is accessible."""

    def test_database_file_exists(self):
        """The database file /home/user/app/data.db must exist."""
        assert os.path.isfile(DB_PATH), f"Database file {DB_PATH} does not exist"

    def test_database_file_is_writable(self):
        """The database file must be writable by the agent."""
        assert os.access(DB_PATH, os.W_OK), f"Database file {DB_PATH} is not writable"

    def test_database_is_sqlite3(self):
        """The file must be a valid SQLite 3 database."""
        # SQLite3 files start with "SQLite format 3"
        with open(DB_PATH, 'rb') as f:
            header = f.read(16)
        assert header.startswith(b'SQLite format 3'), \
            f"{DB_PATH} is not a valid SQLite 3 database (invalid header)"


class TestSqlite3CLI:
    """Test that sqlite3 CLI is available."""

    def test_sqlite3_cli_available(self):
        """The sqlite3 command-line tool must be available."""
        result = subprocess.run(['which', 'sqlite3'], capture_output=True)
        assert result.returncode == 0, "sqlite3 CLI is not available in PATH"


class TestUsersTableSchema:
    """Test that the users table has the expected initial schema."""

    @pytest.fixture
    def db_connection(self):
        """Provide a database connection."""
        conn = sqlite3.connect(DB_PATH)
        yield conn
        conn.close()

    def test_users_table_exists(self, db_connection):
        """The users table must exist in the database."""
        cursor = db_connection.cursor()
        cursor.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='users';"
        )
        result = cursor.fetchone()
        assert result is not None, "Table 'users' does not exist in the database"

    def test_users_table_has_id_column(self, db_connection):
        """The users table must have an 'id' column."""
        cursor = db_connection.cursor()
        cursor.execute("PRAGMA table_info(users);")
        columns = {row[1]: row for row in cursor.fetchall()}
        assert 'id' in columns, "Column 'id' not found in users table"
        # Check it's INTEGER PRIMARY KEY
        col_info = columns['id']
        assert col_info[2].upper() == 'INTEGER', \
            f"Column 'id' should be INTEGER, got {col_info[2]}"
        assert col_info[5] == 1, "Column 'id' should be PRIMARY KEY"

    def test_users_table_has_email_column(self, db_connection):
        """The users table must have an 'email' column that is NOT NULL."""
        cursor = db_connection.cursor()
        cursor.execute("PRAGMA table_info(users);")
        columns = {row[1]: row for row in cursor.fetchall()}
        assert 'email' in columns, "Column 'email' not found in users table"
        col_info = columns['email']
        assert col_info[2].upper() == 'TEXT', \
            f"Column 'email' should be TEXT, got {col_info[2]}"
        assert col_info[3] == 1, "Column 'email' should be NOT NULL"

    def test_users_table_has_created_at_column(self, db_connection):
        """The users table must have a 'created_at' column that is NOT NULL."""
        cursor = db_connection.cursor()
        cursor.execute("PRAGMA table_info(users);")
        columns = {row[1]: row for row in cursor.fetchall()}
        assert 'created_at' in columns, "Column 'created_at' not found in users table"
        col_info = columns['created_at']
        assert col_info[2].upper() == 'TEXT', \
            f"Column 'created_at' should be TEXT, got {col_info[2]}"
        assert col_info[3] == 1, "Column 'created_at' should be NOT NULL"

    def test_users_table_does_not_have_last_login_column(self, db_connection):
        """The users table must NOT already have a 'last_login' column."""
        cursor = db_connection.cursor()
        cursor.execute("PRAGMA table_info(users);")
        columns = {row[1]: row for row in cursor.fetchall()}
        assert 'last_login' not in columns, \
            "Column 'last_login' already exists in users table - initial state is wrong"

    def test_users_table_has_exactly_three_columns(self, db_connection):
        """The users table should have exactly 3 columns initially."""
        cursor = db_connection.cursor()
        cursor.execute("PRAGMA table_info(users);")
        columns = cursor.fetchall()
        assert len(columns) == 3, \
            f"Expected 3 columns in users table, found {len(columns)}: {[c[1] for c in columns]}"


class TestUsersTableData:
    """Test that the users table has the expected data."""

    @pytest.fixture
    def db_connection(self):
        """Provide a database connection."""
        conn = sqlite3.connect(DB_PATH)
        yield conn
        conn.close()

    def test_users_table_has_50000_rows(self, db_connection):
        """The users table must have exactly 50,000 rows."""
        cursor = db_connection.cursor()
        cursor.execute("SELECT COUNT(*) FROM users;")
        count = cursor.fetchone()[0]
        assert count == 50000, \
            f"Expected 50,000 rows in users table, found {count}"

    def test_users_table_data_is_valid(self, db_connection):
        """Verify that the data in users table is valid (spot check)."""
        cursor = db_connection.cursor()
        # Check that all rows have non-null values for required columns
        cursor.execute(
            "SELECT COUNT(*) FROM users WHERE id IS NULL OR email IS NULL OR created_at IS NULL;"
        )
        null_count = cursor.fetchone()[0]
        assert null_count == 0, \
            f"Found {null_count} rows with NULL values in required columns"

    def test_users_table_ids_are_unique(self, db_connection):
        """Verify that all IDs are unique."""
        cursor = db_connection.cursor()
        cursor.execute("SELECT COUNT(DISTINCT id) FROM users;")
        distinct_count = cursor.fetchone()[0]
        assert distinct_count == 50000, \
            f"Expected 50,000 unique IDs, found {distinct_count}"
