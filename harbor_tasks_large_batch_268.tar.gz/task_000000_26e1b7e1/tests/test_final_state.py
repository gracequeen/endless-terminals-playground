# test_final_state.py
"""
Tests to validate the final state of the system after the student
has added the last_login column to the users table.
"""

import os
import sqlite3
import subprocess
import pytest


DB_PATH = "/home/user/app/data.db"
APP_DIR = "/home/user/app"


class TestDatabaseFileIntegrity:
    """Test that the database file still exists and is valid."""

    def test_database_file_exists(self):
        """The database file /home/user/app/data.db must still exist."""
        assert os.path.isfile(DB_PATH), f"Database file {DB_PATH} does not exist"

    def test_database_is_sqlite3(self):
        """The file must still be a valid SQLite 3 database."""
        with open(DB_PATH, 'rb') as f:
            header = f.read(16)
        assert header.startswith(b'SQLite format 3'), \
            f"{DB_PATH} is not a valid SQLite 3 database (invalid header)"


class TestLastLoginColumnExists:
    """Test that the last_login column has been added correctly."""

    @pytest.fixture
    def db_connection(self):
        """Provide a database connection."""
        conn = sqlite3.connect(DB_PATH)
        yield conn
        conn.close()

    def test_last_login_column_exists(self, db_connection):
        """The users table must have a 'last_login' column."""
        cursor = db_connection.cursor()
        cursor.execute("PRAGMA table_info(users);")
        columns = {row[1]: row for row in cursor.fetchall()}
        assert 'last_login' in columns, \
            "Column 'last_login' not found in users table. The column was not added."

    def test_last_login_column_is_nullable(self, db_connection):
        """The last_login column must be nullable (notnull=0)."""
        cursor = db_connection.cursor()
        cursor.execute("PRAGMA table_info(users);")
        columns = {row[1]: row for row in cursor.fetchall()}
        assert 'last_login' in columns, "Column 'last_login' not found"
        col_info = columns['last_login']
        # col_info[3] is the notnull flag: 0 means nullable, 1 means NOT NULL
        assert col_info[3] == 0, \
            f"Column 'last_login' should be nullable (notnull=0), but notnull={col_info[3]}"

    def test_last_login_column_has_no_default(self, db_connection):
        """The last_login column must have no default value."""
        cursor = db_connection.cursor()
        cursor.execute("PRAGMA table_info(users);")
        columns = {row[1]: row for row in cursor.fetchall()}
        assert 'last_login' in columns, "Column 'last_login' not found"
        col_info = columns['last_login']
        # col_info[4] is the default value: should be None (NULL) or empty
        default_value = col_info[4]
        assert default_value is None or default_value == '', \
            f"Column 'last_login' should have no default value, but has default='{default_value}'"

    def test_last_login_column_type_is_acceptable(self, db_connection):
        """The last_login column should have TEXT or TIMESTAMP type (SQLite is flexible)."""
        cursor = db_connection.cursor()
        cursor.execute("PRAGMA table_info(users);")
        columns = {row[1]: row for row in cursor.fetchall()}
        assert 'last_login' in columns, "Column 'last_login' not found"
        col_info = columns['last_login']
        col_type = col_info[2].upper() if col_info[2] else ''
        # SQLite is flexible with types, common choices for timestamp would be TEXT, TIMESTAMP, DATETIME, etc.
        # We accept any type since SQLite doesn't enforce column types strictly
        # The key requirement is that the column exists and is nullable with no default


class TestLastLoginColumnFunctionality:
    """Test that the last_login column actually works."""

    def test_select_last_login_succeeds_via_cli(self):
        """Selecting last_login must succeed (column actually exists in schema)."""
        result = subprocess.run(
            ['sqlite3', DB_PATH, 'SELECT last_login FROM users LIMIT 1;'],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            f"SELECT last_login FROM users failed: {result.stderr}"

    def test_select_last_login_returns_null(self):
        """Existing rows should have NULL for last_login."""
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute("SELECT last_login FROM users LIMIT 1;")
        result = cursor.fetchone()
        conn.close()
        assert result is not None, "Query returned no rows"
        assert result[0] is None, \
            f"Expected last_login to be NULL for existing rows, got {result[0]}"


class TestDataPreservation:
    """Test that existing data has been preserved."""

    @pytest.fixture
    def db_connection(self):
        """Provide a database connection."""
        conn = sqlite3.connect(DB_PATH)
        yield conn
        conn.close()

    def test_row_count_unchanged(self, db_connection):
        """The users table must still have exactly 50,000 rows."""
        cursor = db_connection.cursor()
        cursor.execute("SELECT COUNT(*) FROM users;")
        count = cursor.fetchone()[0]
        assert count == 50000, \
            f"Expected 50,000 rows in users table, found {count}. Data may have been lost or corrupted."

    def test_row_count_via_cli(self):
        """Verify row count using sqlite3 CLI."""
        result = subprocess.run(
            ['sqlite3', DB_PATH, 'SELECT COUNT(*) FROM users;'],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, f"Query failed: {result.stderr}"
        count = int(result.stdout.strip())
        assert count == 50000, \
            f"Expected 50,000 rows, CLI returned {count}"

    def test_original_columns_still_exist(self, db_connection):
        """The original columns (id, email, created_at) must still exist."""
        cursor = db_connection.cursor()
        cursor.execute("PRAGMA table_info(users);")
        columns = {row[1]: row for row in cursor.fetchall()}

        assert 'id' in columns, "Column 'id' is missing - data may have been corrupted"
        assert 'email' in columns, "Column 'email' is missing - data may have been corrupted"
        assert 'created_at' in columns, "Column 'created_at' is missing - data may have been corrupted"

    def test_original_data_not_null(self, db_connection):
        """Original columns should still have no NULL values."""
        cursor = db_connection.cursor()
        cursor.execute(
            "SELECT COUNT(*) FROM users WHERE id IS NULL OR email IS NULL OR created_at IS NULL;"
        )
        null_count = cursor.fetchone()[0]
        assert null_count == 0, \
            f"Found {null_count} rows with NULL values in original columns - data may have been corrupted"

    def test_ids_still_unique(self, db_connection):
        """All IDs should still be unique."""
        cursor = db_connection.cursor()
        cursor.execute("SELECT COUNT(DISTINCT id) FROM users;")
        distinct_count = cursor.fetchone()[0]
        assert distinct_count == 50000, \
            f"Expected 50,000 unique IDs, found {distinct_count} - data may have been corrupted"


class TestNoUnwantedChanges:
    """Test that no unwanted changes were made to the database."""

    @pytest.fixture
    def db_connection(self):
        """Provide a database connection."""
        conn = sqlite3.connect(DB_PATH)
        yield conn
        conn.close()

    def test_users_table_has_exactly_four_columns(self, db_connection):
        """The users table should now have exactly 4 columns."""
        cursor = db_connection.cursor()
        cursor.execute("PRAGMA table_info(users);")
        columns = cursor.fetchall()
        column_names = [c[1] for c in columns]
        assert len(columns) == 4, \
            f"Expected 4 columns in users table, found {len(columns)}: {column_names}"

    def test_no_extra_tables_created(self, db_connection):
        """No additional tables should have been created."""
        cursor = db_connection.cursor()
        cursor.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%';"
        )
        tables = [row[0] for row in cursor.fetchall()]
        assert tables == ['users'], \
            f"Expected only 'users' table, found: {tables}"

    def test_column_is_real_not_view(self, db_connection):
        """The last_login column must be a real column, not from a view."""
        cursor = db_connection.cursor()
        # Check that 'users' is a table, not a view
        cursor.execute(
            "SELECT type FROM sqlite_master WHERE name='users';"
        )
        result = cursor.fetchone()
        assert result is not None, "users not found in sqlite_master"
        assert result[0] == 'table', \
            f"'users' should be a table, not a {result[0]}"
