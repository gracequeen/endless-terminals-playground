# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the artifact sync debugging task.
"""

import os
import subprocess
import stat
import pytest


# === Directory Structure Tests ===

def test_sync_directory_exists():
    """Verify /home/user/sync directory exists"""
    path = "/home/user/sync"
    assert os.path.isdir(path), f"Directory {path} does not exist"


def test_artifacts_directory_exists():
    """Verify /home/user/artifacts directory exists"""
    path = "/home/user/artifacts"
    assert os.path.isdir(path), f"Directory {path} does not exist"


def test_staging_directory_exists():
    """Verify /home/user/staging directory exists"""
    path = "/home/user/staging"
    assert os.path.isdir(path), f"Directory {path} does not exist"


# === Sync Script and Config Tests ===

def test_sync_script_exists():
    """Verify sync.sh wrapper script exists"""
    path = "/home/user/sync/sync.sh"
    assert os.path.isfile(path), f"Sync script {path} does not exist"


def test_sync_script_is_executable():
    """Verify sync.sh is executable"""
    path = "/home/user/sync/sync.sh"
    assert os.access(path, os.X_OK), f"Sync script {path} is not executable"


def test_sync_script_is_bash():
    """Verify sync.sh is a bash script"""
    path = "/home/user/sync/sync.sh"
    with open(path, 'r') as f:
        first_line = f.readline()
    assert 'bash' in first_line or 'sh' in first_line, \
        f"Sync script {path} does not appear to be a shell script (first line: {first_line})"


def test_sync_script_contains_rsync():
    """Verify sync.sh contains rsync invocation"""
    path = "/home/user/sync/sync.sh"
    with open(path, 'r') as f:
        content = f.read()
    assert 'rsync' in content, f"Sync script {path} does not contain 'rsync' command"


def test_sync_config_exists():
    """Verify sync.conf configuration file exists"""
    path = "/home/user/sync/sync.conf"
    assert os.path.isfile(path), f"Config file {path} does not exist"


def test_sync_config_contains_required_vars():
    """Verify sync.conf contains expected configuration variables"""
    path = "/home/user/sync/sync.conf"
    with open(path, 'r') as f:
        content = f.read()

    required_vars = ['RSYNC_OPTS', 'BLOCK_SIZE', 'SRC_DIR', 'DST_DIR', 'TRANSFORM_LARGE']
    missing = [var for var in required_vars if var not in content]
    assert not missing, f"Config file {path} missing variables: {missing}"


def test_sync_config_block_size():
    """Verify BLOCK_SIZE is set to 65536 in config"""
    path = "/home/user/sync/sync.conf"
    with open(path, 'r') as f:
        content = f.read()
    assert 'BLOCK_SIZE=65536' in content or 'BLOCK_SIZE="65536"' in content, \
        f"Config file {path} should have BLOCK_SIZE=65536"


def test_sync_config_transform_large_enabled():
    """Verify TRANSFORM_LARGE is enabled (this is the buggy feature)"""
    path = "/home/user/sync/sync.conf"
    with open(path, 'r') as f:
        content = f.read()
    assert 'TRANSFORM_LARGE=1' in content or 'TRANSFORM_LARGE="1"' in content, \
        f"Config file {path} should have TRANSFORM_LARGE=1"


# === Source Artifact Tests ===

def test_small_tool_exists():
    """Verify small_tool artifact exists"""
    path = "/home/user/artifacts/small_tool"
    assert os.path.isfile(path), f"Artifact {path} does not exist"


def test_small_tool_is_executable():
    """Verify small_tool is executable"""
    path = "/home/user/artifacts/small_tool"
    assert os.access(path, os.X_OK), f"Artifact {path} is not executable"


def test_small_tool_is_small():
    """Verify small_tool is under 64KB (should not trigger the bug)"""
    path = "/home/user/artifacts/small_tool"
    size = os.path.getsize(path)
    assert size < 65536, f"small_tool should be under 64KB, but is {size} bytes"
    assert size > 0, f"small_tool should not be empty"


def test_small_tool_is_elf():
    """Verify small_tool is a valid ELF binary"""
    path = "/home/user/artifacts/small_tool"
    result = subprocess.run(['file', path], capture_output=True, text=True)
    assert 'ELF' in result.stdout, f"small_tool should be an ELF binary, got: {result.stdout}"


def test_build_helper_exists():
    """Verify build_helper artifact exists"""
    path = "/home/user/artifacts/build_helper"
    assert os.path.isfile(path), f"Artifact {path} does not exist"


def test_build_helper_is_executable():
    """Verify build_helper is executable"""
    path = "/home/user/artifacts/build_helper"
    assert os.access(path, os.X_OK), f"Artifact {path} is not executable"


def test_build_helper_is_large():
    """Verify build_helper is over 64KB (should trigger the bug)"""
    path = "/home/user/artifacts/build_helper"
    size = os.path.getsize(path)
    assert size > 65536, f"build_helper should be over 64KB to trigger bug, but is {size} bytes"


def test_build_helper_is_elf():
    """Verify build_helper is a valid ELF binary"""
    path = "/home/user/artifacts/build_helper"
    result = subprocess.run(['file', path], capture_output=True, text=True)
    assert 'ELF' in result.stdout, f"build_helper should be an ELF binary, got: {result.stdout}"


def test_libutil_exists():
    """Verify libutil.so artifact exists"""
    path = "/home/user/artifacts/libutil.so"
    assert os.path.isfile(path), f"Artifact {path} does not exist"


def test_libutil_is_large():
    """Verify libutil.so is over 64KB (should trigger the bug)"""
    path = "/home/user/artifacts/libutil.so"
    size = os.path.getsize(path)
    assert size > 65536, f"libutil.so should be over 64KB to trigger bug, but is {size} bytes"


def test_libutil_is_elf():
    """Verify libutil.so is a valid ELF shared library"""
    path = "/home/user/artifacts/libutil.so"
    result = subprocess.run(['file', path], capture_output=True, text=True)
    assert 'ELF' in result.stdout, f"libutil.so should be an ELF binary, got: {result.stdout}"
    assert 'shared object' in result.stdout.lower() or 'dynamically linked' in result.stdout.lower(), \
        f"libutil.so should be a shared library, got: {result.stdout}"


# === Staging Directory Initial State ===

def test_staging_is_empty_or_minimal():
    """Verify staging directory is empty or nearly empty initially"""
    path = "/home/user/staging"
    contents = os.listdir(path)
    # Filter out hidden files like .rsync-partial
    visible_contents = [f for f in contents if not f.startswith('.')]
    assert len(visible_contents) == 0, \
        f"Staging directory should be empty initially, but contains: {visible_contents}"


# === Required Tools Tests ===

def test_rsync_available():
    """Verify rsync is installed and available"""
    result = subprocess.run(['which', 'rsync'], capture_output=True, text=True)
    assert result.returncode == 0, "rsync is not installed or not in PATH"


def test_base64_available():
    """Verify base64 is installed and available"""
    result = subprocess.run(['which', 'base64'], capture_output=True, text=True)
    assert result.returncode == 0, "base64 is not installed or not in PATH"


def test_python3_available():
    """Verify python3 is installed and available"""
    result = subprocess.run(['which', 'python3'], capture_output=True, text=True)
    assert result.returncode == 0, "python3 is not installed or not in PATH"


def test_file_command_available():
    """Verify file command is installed (for checking ELF headers)"""
    result = subprocess.run(['which', 'file'], capture_output=True, text=True)
    assert result.returncode == 0, "file command is not installed or not in PATH"


def test_stat_command_available():
    """Verify stat command is installed (used by sync.sh)"""
    result = subprocess.run(['which', 'stat'], capture_output=True, text=True)
    assert result.returncode == 0, "stat command is not installed or not in PATH"


# === Writability Tests ===

def test_sync_directory_writable():
    """Verify /home/user/sync is writable"""
    path = "/home/user/sync"
    assert os.access(path, os.W_OK), f"Directory {path} is not writable"


def test_sync_script_writable():
    """Verify sync.sh is writable (for fixing the bug)"""
    path = "/home/user/sync/sync.sh"
    assert os.access(path, os.W_OK), f"File {path} is not writable"


def test_sync_config_writable():
    """Verify sync.conf is writable (for potential config fixes)"""
    path = "/home/user/sync/sync.conf"
    assert os.access(path, os.W_OK), f"File {path} is not writable"


def test_staging_directory_writable():
    """Verify staging directory is writable"""
    path = "/home/user/staging"
    assert os.access(path, os.W_OK), f"Directory {path} is not writable"


# === Source Artifact Execution Tests ===

def test_small_tool_executes():
    """Verify small_tool can execute and produces expected output"""
    path = "/home/user/artifacts/small_tool"
    result = subprocess.run([path], capture_output=True, text=True, timeout=5)
    assert result.returncode == 0, f"small_tool failed to execute: {result.stderr}"
    assert "small works" in result.stdout, \
        f"small_tool should print 'small works', got: {result.stdout}"


def test_build_helper_executes():
    """Verify build_helper can execute and produces expected output"""
    path = "/home/user/artifacts/build_helper"
    result = subprocess.run([path], capture_output=True, text=True, timeout=5)
    assert result.returncode == 0, f"build_helper failed to execute: {result.stderr}"
    assert "build helper works" in result.stdout, \
        f"build_helper should print 'build helper works', got: {result.stdout}"
