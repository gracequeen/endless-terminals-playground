# test_final_state.py
"""
Tests to validate the final state after the artifact sync debugging task is completed.
Verifies that the sync mechanism works correctly and produces byte-identical copies.
"""

import os
import subprocess
import hashlib
import pytest


def get_file_hash(filepath):
    """Calculate SHA256 hash of a file"""
    sha256 = hashlib.sha256()
    with open(filepath, 'rb') as f:
        for chunk in iter(lambda: f.read(8192), b''):
            sha256.update(chunk)
    return sha256.hexdigest()


def files_are_identical(file1, file2):
    """Check if two files are byte-identical"""
    if not os.path.exists(file1) or not os.path.exists(file2):
        return False
    if os.path.getsize(file1) != os.path.getsize(file2):
        return False
    return get_file_hash(file1) == get_file_hash(file2)


# === Sync Script Execution Test ===

def test_sync_script_exits_zero():
    """Verify running sync.sh exits with code 0"""
    result = subprocess.run(
        ['/home/user/sync/sync.sh'],
        capture_output=True,
        text=True,
        timeout=60,
        cwd='/home/user/sync'
    )
    assert result.returncode == 0, \
        f"sync.sh should exit 0, but exited {result.returncode}. stderr: {result.stderr}, stdout: {result.stdout}"


# === File Identity Tests ===

def test_small_tool_is_byte_identical():
    """Verify staging/small_tool is byte-identical to artifacts/small_tool"""
    src = "/home/user/artifacts/small_tool"
    dst = "/home/user/staging/small_tool"

    assert os.path.exists(dst), f"Destination file {dst} does not exist after sync"
    assert files_are_identical(src, dst), \
        f"small_tool is not byte-identical. Source hash: {get_file_hash(src)}, Dest hash: {get_file_hash(dst)}"


def test_build_helper_is_byte_identical():
    """Verify staging/build_helper is byte-identical to artifacts/build_helper"""
    src = "/home/user/artifacts/build_helper"
    dst = "/home/user/staging/build_helper"

    assert os.path.exists(dst), f"Destination file {dst} does not exist after sync"
    assert files_are_identical(src, dst), \
        f"build_helper is not byte-identical. Source hash: {get_file_hash(src)}, Dest hash: {get_file_hash(dst)}"


def test_libutil_is_byte_identical():
    """Verify staging/libutil.so is byte-identical to artifacts/libutil.so"""
    src = "/home/user/artifacts/libutil.so"
    dst = "/home/user/staging/libutil.so"

    assert os.path.exists(dst), f"Destination file {dst} does not exist after sync"
    assert files_are_identical(src, dst), \
        f"libutil.so is not byte-identical. Source hash: {get_file_hash(src)}, Dest hash: {get_file_hash(dst)}"


# === ELF Validity Tests ===

def test_staging_build_helper_is_valid_elf():
    """Verify staging/build_helper is recognized as a valid ELF 64-bit binary"""
    path = "/home/user/staging/build_helper"
    assert os.path.exists(path), f"File {path} does not exist"

    result = subprocess.run(['file', path], capture_output=True, text=True)
    assert 'ELF 64-bit' in result.stdout, \
        f"build_helper should be 'ELF 64-bit', but file reports: {result.stdout.strip()}"
    # Make sure it's not corrupted/reported as data
    assert 'data' not in result.stdout.lower() or 'ELF' in result.stdout, \
        f"build_helper appears corrupted, file reports: {result.stdout.strip()}"


def test_staging_small_tool_is_valid_elf():
    """Verify staging/small_tool is recognized as a valid ELF binary"""
    path = "/home/user/staging/small_tool"
    assert os.path.exists(path), f"File {path} does not exist"

    result = subprocess.run(['file', path], capture_output=True, text=True)
    assert 'ELF' in result.stdout, \
        f"small_tool should be an ELF binary, but file reports: {result.stdout.strip()}"


def test_staging_libutil_is_valid_elf():
    """Verify staging/libutil.so is recognized as a valid ELF shared library"""
    path = "/home/user/staging/libutil.so"
    assert os.path.exists(path), f"File {path} does not exist"

    result = subprocess.run(['file', path], capture_output=True, text=True)
    assert 'ELF' in result.stdout, \
        f"libutil.so should be an ELF binary, but file reports: {result.stdout.strip()}"


# === Execution Tests ===

def test_staging_build_helper_executes_correctly():
    """Verify staging/build_helper executes and prints expected output"""
    path = "/home/user/staging/build_helper"
    assert os.path.exists(path), f"File {path} does not exist"

    # Ensure it's executable
    os.chmod(path, 0o755)

    result = subprocess.run([path], capture_output=True, text=True, timeout=5)
    assert result.returncode == 0, \
        f"build_helper failed to execute with return code {result.returncode}. stderr: {result.stderr}"
    assert "build helper works" in result.stdout, \
        f"build_helper should print 'build helper works', got stdout: '{result.stdout}', stderr: '{result.stderr}'"


def test_staging_small_tool_executes_correctly():
    """Verify staging/small_tool executes and prints expected output"""
    path = "/home/user/staging/small_tool"
    assert os.path.exists(path), f"File {path} does not exist"

    # Ensure it's executable
    os.chmod(path, 0o755)

    result = subprocess.run([path], capture_output=True, text=True, timeout=5)
    assert result.returncode == 0, \
        f"small_tool failed to execute with return code {result.returncode}. stderr: {result.stderr}"
    assert "small works" in result.stdout, \
        f"small_tool should print 'small works', got stdout: '{result.stdout}', stderr: '{result.stderr}'"


# === Source File Integrity Tests (Invariants) ===

def test_source_small_tool_unchanged():
    """Verify source small_tool is still a valid, working ELF"""
    path = "/home/user/artifacts/small_tool"
    assert os.path.exists(path), f"Source file {path} should still exist"

    result = subprocess.run([path], capture_output=True, text=True, timeout=5)
    assert result.returncode == 0, f"Source small_tool should still execute"
    assert "small works" in result.stdout, f"Source small_tool should still work correctly"


def test_source_build_helper_unchanged():
    """Verify source build_helper is still a valid, working ELF"""
    path = "/home/user/artifacts/build_helper"
    assert os.path.exists(path), f"Source file {path} should still exist"

    result = subprocess.run([path], capture_output=True, text=True, timeout=5)
    assert result.returncode == 0, f"Source build_helper should still execute"
    assert "build helper works" in result.stdout, f"Source build_helper should still work correctly"


def test_source_libutil_unchanged():
    """Verify source libutil.so is still a valid ELF"""
    path = "/home/user/artifacts/libutil.so"
    assert os.path.exists(path), f"Source file {path} should still exist"

    result = subprocess.run(['file', path], capture_output=True, text=True)
    assert 'ELF' in result.stdout, f"Source libutil.so should still be a valid ELF"


# === Anti-Shortcut Guards ===

def test_sync_script_still_uses_rsync():
    """Verify sync.sh still contains rsync (not replaced with cp/scp)"""
    path = "/home/user/sync/sync.sh"
    assert os.path.exists(path), f"Sync script {path} should still exist"

    with open(path, 'r') as f:
        content = f.read()

    assert 'rsync' in content, \
        "sync.sh must still contain rsync invocation - cannot be replaced with simple cp/scp"


def test_sync_script_is_still_functional():
    """Verify sync.sh is still a bash/shell script"""
    path = "/home/user/sync/sync.sh"
    with open(path, 'r') as f:
        first_line = f.readline()

    assert 'bash' in first_line or 'sh' in first_line, \
        f"sync.sh should still be a shell script, first line: {first_line}"


def test_block_size_not_inflated():
    """Verify BLOCK_SIZE in sync.conf is <= 65536 (anti-shortcut check)"""
    path = "/home/user/sync/sync.conf"
    assert os.path.exists(path), f"Config file {path} should still exist"

    with open(path, 'r') as f:
        content = f.read()

    # Parse BLOCK_SIZE value
    import re
    match = re.search(r'BLOCK_SIZE[=\s]+["\']?(\d+)["\']?', content)
    if match:
        block_size = int(match.group(1))
        assert block_size <= 65536, \
            f"BLOCK_SIZE must be <= 65536 (found {block_size}). Cannot bypass bug by inflating block size."


def test_sync_config_exists():
    """Verify sync.conf still exists"""
    path = "/home/user/sync/sync.conf"
    assert os.path.exists(path), f"Config file {path} should still exist"


# === Comprehensive Sync Re-run Test ===

def test_sync_is_idempotent():
    """Verify running sync.sh again still works and files remain identical"""
    # Run sync again
    result = subprocess.run(
        ['/home/user/sync/sync.sh'],
        capture_output=True,
        text=True,
        timeout=60,
        cwd='/home/user/sync'
    )
    assert result.returncode == 0, \
        f"sync.sh should be idempotent and exit 0 on re-run. Exit: {result.returncode}"

    # Verify files still identical after re-run
    assert files_are_identical(
        "/home/user/artifacts/build_helper",
        "/home/user/staging/build_helper"
    ), "build_helper should remain byte-identical after re-running sync"
