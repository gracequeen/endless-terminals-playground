Our artifact sync from the build farm to the staging mirror is silently corrupting binaries — rsync says everything transferred fine, checksums match on both sides according to the logs, but when QA pulls from staging the ELF headers are garbage. Only happens on files over ~60KB, smaller stuff is fine. The weird part is if I manually scp the same file it works perfectly.

Setup is at /home/user/sync — there's a wrapper script that handles the transfer and a config for rsync. Source artifacts are in /home/user/artifacts, destination mirror is /home/user/staging. I've left a few test binaries in artifacts to reproduce with. The 72KB one definitely breaks, the 8KB one doesn't.

Need the sync to actually work — run the wrapper, binaries land intact on the staging side.
