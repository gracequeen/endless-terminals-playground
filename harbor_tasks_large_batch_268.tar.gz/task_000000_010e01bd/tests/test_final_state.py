# test_final_state.py
"""
Tests to validate the final state of the OS/filesystem after the student
has fixed the audit script to handle broken symlinks.
"""

import csv
import os
import subprocess
import tempfile

import pytest


HOME = "/home/user"
AUDIT_DIR = os.path.join(HOME, "audit")
SCRIPT_PATH = os.path.join(AUDIT_DIR, "gen_report.py")
OUTPUT_DIR = os.path.join(AUDIT_DIR, "output")
OUTPUT_CSV = os.path.join(OUTPUT_DIR, "Q2_2024_access.csv")
COMPLIANCE_DATA_DIR = os.path.join(HOME, "compliance_data")

# Expected broken symlinks that must still exist
BROKEN_SYMLINKS = [
    (
        os.path.join(COMPLIANCE_DATA_DIR, "hr", "records", "2024", "pension_link.dat"),
        "/mnt/archive/pension_2024.dat",
    ),
    (
        os.path.join(COMPLIANCE_DATA_DIR, "finance", "q2", "backup_link.csv"),
        "/backup/old/finance_q2.csv",
    ),
    (
        os.path.join(COMPLIANCE_DATA_DIR, "legal", "contracts", "archive_ref.txt"),
        "/storage/legal_archive.txt",
    ),
]


class TestScriptExecutesSuccessfully:
    """Tests that the script now runs without errors."""

    def test_script_exits_zero(self):
        """Running the script should exit with code 0."""
        result = subprocess.run(
            ["python3", SCRIPT_PATH],
            capture_output=True,
            text=True,
            cwd=AUDIT_DIR
        )
        assert result.returncode == 0, (
            f"Script exited with code {result.returncode}. "
            f"stdout: {result.stdout}\nstderr: {result.stderr}"
        )

    def test_script_produces_no_unhandled_exceptions(self):
        """The script should not produce unhandled exception tracebacks."""
        result = subprocess.run(
            ["python3", SCRIPT_PATH],
            capture_output=True,
            text=True,
            cwd=AUDIT_DIR
        )
        error_indicators = ["Traceback (most recent call last)", "FileNotFoundError", "PermissionError"]
        for indicator in error_indicators:
            assert indicator not in result.stderr, (
                f"Script produced error containing '{indicator}': {result.stderr}"
            )


class TestOutputCSVExists:
    """Tests for the output CSV file existence and basic properties."""

    def test_output_csv_exists(self):
        """The output CSV file must exist."""
        # First run the script to ensure output is generated
        subprocess.run(["python3", SCRIPT_PATH], cwd=AUDIT_DIR, capture_output=True)
        assert os.path.isfile(OUTPUT_CSV), (
            f"Output CSV file {OUTPUT_CSV} does not exist"
        )

    def test_output_csv_is_readable(self):
        """The output CSV file must be readable."""
        subprocess.run(["python3", SCRIPT_PATH], cwd=AUDIT_DIR, capture_output=True)
        assert os.access(OUTPUT_CSV, os.R_OK), (
            f"Output CSV file {OUTPUT_CSV} is not readable"
        )

    def test_output_csv_is_not_empty(self):
        """The output CSV file must not be empty."""
        subprocess.run(["python3", SCRIPT_PATH], cwd=AUDIT_DIR, capture_output=True)
        size = os.path.getsize(OUTPUT_CSV)
        assert size > 0, f"Output CSV file {OUTPUT_CSV} is empty"


class TestCSVContent:
    """Tests for the content of the output CSV file."""

    @pytest.fixture(autouse=True)
    def run_script_first(self):
        """Ensure the script is run before testing CSV content."""
        subprocess.run(["python3", SCRIPT_PATH], cwd=AUDIT_DIR, capture_output=True)

    def test_csv_is_parseable(self):
        """The CSV file must be parseable by Python's csv module."""
        try:
            with open(OUTPUT_CSV, "r", newline="") as f:
                reader = csv.reader(f)
                rows = list(reader)
            assert len(rows) > 0, "CSV file has no rows"
        except csv.Error as e:
            pytest.fail(f"CSV file is not parseable: {e}")

    def test_csv_has_header_row(self):
        """The CSV file must have a header row with appropriate columns."""
        with open(OUTPUT_CSV, "r", newline="") as f:
            reader = csv.reader(f)
            header = next(reader)

        # Check that header has at least 3 columns (filename, mtime, owner or similar)
        assert len(header) >= 3, (
            f"CSV header should have at least 3 columns, found {len(header)}: {header}"
        )

        # Check for expected column name patterns (case-insensitive, flexible naming)
        header_lower = [h.lower() for h in header]
        header_str = " ".join(header_lower)

        has_filename = any(
            term in header_str for term in ["file", "name", "path"]
        )
        has_mtime = any(
            term in header_str for term in ["mtime", "time", "modified", "date"]
        )
        has_owner = any(
            term in header_str for term in ["owner", "user", "uid"]
        )

        assert has_filename, f"CSV header missing filename-related column: {header}"
        assert has_mtime, f"CSV header missing mtime-related column: {header}"
        assert has_owner, f"CSV header missing owner-related column: {header}"

    def test_csv_has_sufficient_data_rows(self):
        """The CSV should have at least 37 data rows (regular files)."""
        with open(OUTPUT_CSV, "r", newline="") as f:
            reader = csv.reader(f)
            rows = list(reader)

        # Subtract 1 for header row
        data_rows = len(rows) - 1
        assert data_rows >= 37, (
            f"CSV should have at least 37 data rows for regular files, "
            f"found {data_rows}"
        )

    def test_csv_rows_have_consistent_columns(self):
        """All CSV rows should have the same number of columns."""
        with open(OUTPUT_CSV, "r", newline="") as f:
            reader = csv.reader(f)
            rows = list(reader)

        if len(rows) < 2:
            pytest.fail("CSV has fewer than 2 rows (header + data)")

        header_cols = len(rows[0])
        for i, row in enumerate(rows[1:], start=2):
            assert len(row) == header_cols, (
                f"Row {i} has {len(row)} columns, expected {header_cols}: {row}"
            )

    def test_csv_contains_compliance_data_paths(self):
        """The CSV should contain paths from the compliance_data directory."""
        with open(OUTPUT_CSV, "r", newline="") as f:
            content = f.read()

        assert "compliance_data" in content, (
            "CSV does not appear to contain paths from compliance_data directory"
        )


class TestBrokenSymlinksPreserved:
    """Tests that the broken symlinks still exist (invariant)."""

    @pytest.mark.parametrize("symlink_path,target_path", BROKEN_SYMLINKS)
    def test_broken_symlink_still_exists(self, symlink_path, target_path):
        """Each broken symlink must still exist."""
        assert os.path.islink(symlink_path), (
            f"Broken symlink {symlink_path} was deleted - it should be preserved"
        )

    @pytest.mark.parametrize("symlink_path,target_path", BROKEN_SYMLINKS)
    def test_broken_symlink_still_broken(self, symlink_path, target_path):
        """Each broken symlink should still be broken (target doesn't exist)."""
        assert os.path.islink(symlink_path) and not os.path.exists(symlink_path), (
            f"Symlink {symlink_path} is no longer broken - "
            "the fix should handle broken symlinks, not fix them"
        )

    @pytest.mark.parametrize("symlink_path,target_path", BROKEN_SYMLINKS)
    def test_broken_symlink_target_unchanged(self, symlink_path, target_path):
        """Each broken symlink should still point to its original target."""
        actual_target = os.readlink(symlink_path)
        assert actual_target == target_path, (
            f"Symlink {symlink_path} now points to {actual_target}, "
            f"expected original target {target_path}"
        )


class TestDirectoryStructurePreserved:
    """Tests that the compliance_data directory structure is preserved."""

    def test_compliance_data_directory_exists(self):
        """The compliance_data directory must still exist."""
        assert os.path.isdir(COMPLIANCE_DATA_DIR), (
            f"Directory {COMPLIANCE_DATA_DIR} was deleted"
        )

    def test_expected_subdirectories_exist(self):
        """Expected subdirectories should still exist."""
        expected_subdirs = ["hr", "finance", "legal"]
        for subdir in expected_subdirs:
            subdir_path = os.path.join(COMPLIANCE_DATA_DIR, subdir)
            assert os.path.isdir(subdir_path), (
                f"Subdirectory {subdir_path} was deleted"
            )

    def test_file_count_not_reduced(self):
        """The number of files should not have been significantly reduced."""
        file_count = 0
        for root, dirs, files in os.walk(COMPLIANCE_DATA_DIR):
            file_count += len(files)
        assert file_count >= 30, (
            f"File count in {COMPLIANCE_DATA_DIR} is {file_count}, "
            "expected at least 30 - files may have been deleted"
        )


class TestGenericBrokenSymlinkHandling:
    """Anti-shortcut test: verify the fix handles broken symlinks generically."""

    def test_handles_new_broken_symlink(self):
        """
        Create a new broken symlink and verify the script still works.
        This ensures the fix is generic, not hardcoded for specific paths.
        """
        # Create a new broken symlink
        test_symlink = os.path.join(COMPLIANCE_DATA_DIR, "test_broken_link")
        test_target = "/nonexistent_target_for_testing"

        # Clean up if it exists from a previous run
        if os.path.islink(test_symlink):
            os.unlink(test_symlink)

        try:
            # Create the broken symlink
            os.symlink(test_target, test_symlink)

            # Verify it's broken
            assert os.path.islink(test_symlink), "Failed to create test symlink"
            assert not os.path.exists(test_symlink), "Test symlink is not broken"

            # Run the script
            result = subprocess.run(
                ["python3", SCRIPT_PATH],
                capture_output=True,
                text=True,
                cwd=AUDIT_DIR
            )

            # Script should still exit 0
            assert result.returncode == 0, (
                f"Script failed with new broken symlink. Exit code: {result.returncode}. "
                f"stderr: {result.stderr}"
            )

            # Output CSV should still be valid
            assert os.path.isfile(OUTPUT_CSV), "Output CSV not created"
            with open(OUTPUT_CSV, "r", newline="") as f:
                reader = csv.reader(f)
                rows = list(reader)
            assert len(rows) > 1, "CSV has no data rows after adding new broken symlink"

        finally:
            # Clean up the test symlink
            if os.path.islink(test_symlink):
                os.unlink(test_symlink)


class TestScriptNotHardcoded:
    """Tests to ensure the script fix is not hardcoded to skip specific paths."""

    def test_script_does_not_hardcode_symlink_paths(self):
        """The script should not contain hardcoded paths to the broken symlinks."""
        with open(SCRIPT_PATH, "r") as f:
            content = f.read()

        hardcoded_indicators = [
            "pension_link.dat",
            "backup_link.csv", 
            "archive_ref.txt",
            "/mnt/archive/pension_2024.dat",
            "/backup/old/finance_q2.csv",
            "/storage/legal_archive.txt",
        ]

        for indicator in hardcoded_indicators:
            assert indicator not in content, (
                f"Script appears to hardcode specific symlink path '{indicator}'. "
                "The fix should handle broken symlinks generically."
            )

    def test_script_still_processes_full_tree(self):
        """The script should still use os.walk to process the full tree."""
        with open(SCRIPT_PATH, "r") as f:
            content = f.read()

        assert "os.walk" in content, (
            "Script no longer uses os.walk() - it should still traverse the full tree"
        )

        assert "compliance_data" in content, (
            "Script no longer references compliance_data directory"
        )
