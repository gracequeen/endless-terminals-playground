# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the audit script fix task.
"""

import os
import stat
import subprocess
import sys

import pytest


HOME = "/home/user"
AUDIT_DIR = os.path.join(HOME, "audit")
SCRIPT_PATH = os.path.join(AUDIT_DIR, "gen_report.py")
OUTPUT_DIR = os.path.join(AUDIT_DIR, "output")
COMPLIANCE_DATA_DIR = os.path.join(HOME, "compliance_data")

# Expected broken symlinks
BROKEN_SYMLINKS = [
    (
        os.path.join(COMPLIANCE_DATA_DIR, "hr", "records", "2024", "pension_link.dat"),
        "/mnt/archive/pension_2024.dat",
    ),
    (
        os.path.join(COMPLIANCE_DATA_DIR, "finance", "q2", "backup_link.csv"),
        "/backup/old/finance_q2.csv",
    ),
    (
        os.path.join(COMPLIANCE_DATA_DIR, "legal", "contracts", "archive_ref.txt"),
        "/storage/legal_archive.txt",
    ),
]


class TestAuditDirectoryStructure:
    """Tests for the audit directory structure."""

    def test_audit_directory_exists(self):
        """The /home/user/audit directory must exist."""
        assert os.path.isdir(AUDIT_DIR), f"Directory {AUDIT_DIR} does not exist"

    def test_gen_report_script_exists(self):
        """The gen_report.py script must exist."""
        assert os.path.isfile(SCRIPT_PATH), f"Script {SCRIPT_PATH} does not exist"

    def test_gen_report_script_is_executable(self):
        """The gen_report.py script must be executable."""
        assert os.access(SCRIPT_PATH, os.X_OK), f"Script {SCRIPT_PATH} is not executable"

    def test_gen_report_script_is_readable(self):
        """The gen_report.py script must be readable."""
        assert os.access(SCRIPT_PATH, os.R_OK), f"Script {SCRIPT_PATH} is not readable"

    def test_output_directory_exists(self):
        """The /home/user/audit/output directory must exist."""
        assert os.path.isdir(OUTPUT_DIR), f"Directory {OUTPUT_DIR} does not exist"

    def test_output_directory_is_writable(self):
        """The output directory must be writable."""
        assert os.access(OUTPUT_DIR, os.W_OK), f"Directory {OUTPUT_DIR} is not writable"


class TestComplianceDataStructure:
    """Tests for the compliance_data directory structure."""

    def test_compliance_data_directory_exists(self):
        """The /home/user/compliance_data directory must exist."""
        assert os.path.isdir(COMPLIANCE_DATA_DIR), (
            f"Directory {COMPLIANCE_DATA_DIR} does not exist"
        )

    def test_compliance_data_is_readable(self):
        """The compliance_data directory must be readable."""
        assert os.access(COMPLIANCE_DATA_DIR, os.R_OK), (
            f"Directory {COMPLIANCE_DATA_DIR} is not readable"
        )

    def test_compliance_data_is_executable(self):
        """The compliance_data directory must be executable (traversable)."""
        assert os.access(COMPLIANCE_DATA_DIR, os.X_OK), (
            f"Directory {COMPLIANCE_DATA_DIR} is not executable/traversable"
        )

    def test_compliance_data_has_subdirectories(self):
        """The compliance_data directory should have subdirectories."""
        subdirs = [
            d for d in os.listdir(COMPLIANCE_DATA_DIR)
            if os.path.isdir(os.path.join(COMPLIANCE_DATA_DIR, d))
        ]
        assert len(subdirs) >= 3, (
            f"Expected at least 3 subdirectories in {COMPLIANCE_DATA_DIR}, "
            f"found {len(subdirs)}: {subdirs}"
        )

    def test_compliance_data_has_files(self):
        """The compliance_data tree should contain approximately 40 files."""
        file_count = 0
        for root, dirs, files in os.walk(COMPLIANCE_DATA_DIR):
            file_count += len(files)
        assert file_count >= 30, (
            f"Expected at least 30 files in {COMPLIANCE_DATA_DIR} tree, "
            f"found {file_count}"
        )

    def test_expected_subdirectories_exist(self):
        """Expected subdirectories (hr, finance, legal) should exist."""
        expected_subdirs = ["hr", "finance", "legal"]
        for subdir in expected_subdirs:
            subdir_path = os.path.join(COMPLIANCE_DATA_DIR, subdir)
            assert os.path.isdir(subdir_path), (
                f"Expected subdirectory {subdir_path} does not exist"
            )


class TestBrokenSymlinks:
    """Tests for the broken symlinks that cause the script to fail."""

    @pytest.mark.parametrize("symlink_path,target_path", BROKEN_SYMLINKS)
    def test_symlink_exists(self, symlink_path, target_path):
        """Each broken symlink must exist as a symlink."""
        assert os.path.islink(symlink_path), (
            f"Expected symlink at {symlink_path} does not exist or is not a symlink"
        )

    @pytest.mark.parametrize("symlink_path,target_path", BROKEN_SYMLINKS)
    def test_symlink_target_does_not_exist(self, symlink_path, target_path):
        """The target of each broken symlink must not exist."""
        assert not os.path.exists(target_path), (
            f"Symlink target {target_path} unexpectedly exists - "
            "it should be missing to create the broken symlink scenario"
        )

    @pytest.mark.parametrize("symlink_path,target_path", BROKEN_SYMLINKS)
    def test_symlink_is_broken(self, symlink_path, target_path):
        """Each symlink should be broken (os.path.exists returns False for broken symlinks)."""
        # os.path.exists() returns False for broken symlinks
        assert os.path.islink(symlink_path) and not os.path.exists(symlink_path), (
            f"Symlink {symlink_path} should be broken but appears to be valid"
        )

    @pytest.mark.parametrize("symlink_path,target_path", BROKEN_SYMLINKS)
    def test_symlink_points_to_expected_target(self, symlink_path, target_path):
        """Each symlink should point to the expected (non-existent) target."""
        actual_target = os.readlink(symlink_path)
        assert actual_target == target_path, (
            f"Symlink {symlink_path} points to {actual_target}, "
            f"expected {target_path}"
        )

    @pytest.mark.parametrize("symlink_path,target_path", BROKEN_SYMLINKS)
    def test_os_stat_raises_error_on_broken_symlink(self, symlink_path, target_path):
        """os.stat() should raise FileNotFoundError on broken symlinks."""
        with pytest.raises(FileNotFoundError):
            os.stat(symlink_path)


class TestScriptContent:
    """Tests to verify the script has expected characteristics."""

    def test_script_uses_os_walk(self):
        """The script should use os.walk() for directory traversal."""
        with open(SCRIPT_PATH, "r") as f:
            content = f.read()
        assert "os.walk" in content, (
            f"Script {SCRIPT_PATH} does not appear to use os.walk()"
        )

    def test_script_uses_os_stat(self):
        """The script should use os.stat() which causes the issue with broken symlinks."""
        with open(SCRIPT_PATH, "r") as f:
            content = f.read()
        assert "os.stat" in content, (
            f"Script {SCRIPT_PATH} does not appear to use os.stat()"
        )

    def test_script_references_compliance_data(self):
        """The script should reference the compliance_data directory."""
        with open(SCRIPT_PATH, "r") as f:
            content = f.read()
        assert "compliance_data" in content, (
            f"Script {SCRIPT_PATH} does not reference compliance_data directory"
        )

    def test_script_references_output_csv(self):
        """The script should reference the output CSV file."""
        with open(SCRIPT_PATH, "r") as f:
            content = f.read()
        assert "Q2_2024_access.csv" in content or "output" in content, (
            f"Script {SCRIPT_PATH} does not appear to reference output CSV"
        )


class TestPythonEnvironment:
    """Tests for the Python environment."""

    def test_python3_available(self):
        """Python 3 must be available."""
        result = subprocess.run(
            ["python3", "--version"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "python3 is not available"

    def test_python_version_is_3_11_or_higher(self):
        """Python version should be 3.11 or higher."""
        result = subprocess.run(
            ["python3", "-c", "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "Failed to get Python version"
        version = result.stdout.strip()
        major, minor = map(int, version.split("."))
        assert (major, minor) >= (3, 11), (
            f"Python version {version} is less than required 3.11"
        )


class TestScriptFailsCurrently:
    """Test that the script currently fails due to the broken symlinks."""

    def test_script_fails_with_current_state(self):
        """The script should fail when run in the current state."""
        result = subprocess.run(
            ["python3", SCRIPT_PATH],
            capture_output=True,
            text=True,
            cwd=AUDIT_DIR
        )
        # The script should fail (non-zero exit code) due to broken symlinks
        assert result.returncode != 0, (
            "Script unexpectedly succeeded - it should fail due to broken symlinks. "
            f"stdout: {result.stdout}, stderr: {result.stderr}"
        )

    def test_script_error_mentions_file_not_found(self):
        """The script error should mention FileNotFoundError or similar."""
        result = subprocess.run(
            ["python3", SCRIPT_PATH],
            capture_output=True,
            text=True,
            cwd=AUDIT_DIR
        )
        # Check that the error is related to file not found
        error_output = result.stderr + result.stdout
        assert (
            "FileNotFoundError" in error_output or
            "No such file or directory" in error_output or
            "Errno 2" in error_output
        ), (
            f"Expected FileNotFoundError in script output, got: {error_output}"
        )
