# test_final_state.py
"""
Tests to validate the final state after the student makes install.sh executable.
"""

import os
import stat
import subprocess
import pytest


DOTFILES_DIR = "/home/user/dotfiles"
INSTALL_SCRIPT = "/home/user/dotfiles/install.sh"
EXPECTED_DOTFILES = ["install.sh", ".bashrc", ".vimrc", ".gitconfig"]


class TestInstallScriptExecutable:
    """Verify the install.sh script is now executable."""

    def test_install_script_exists(self):
        """The install.sh script must still exist."""
        assert os.path.exists(INSTALL_SCRIPT), (
            f"Install script {INSTALL_SCRIPT} does not exist. "
            "It should not have been deleted or moved."
        )

    def test_install_script_is_file(self):
        """The install.sh must still be a regular file."""
        assert os.path.isfile(INSTALL_SCRIPT), (
            f"{INSTALL_SCRIPT} is not a regular file. "
            "It should not have been replaced with a directory or symlink."
        )

    def test_install_script_is_executable_by_owner(self):
        """The install.sh script must be executable (at minimum u+x)."""
        assert os.access(INSTALL_SCRIPT, os.X_OK), (
            f"{INSTALL_SCRIPT} is NOT executable. "
            "The task requires making the script executable so it can be run. "
            "Use 'chmod +x /home/user/dotfiles/install.sh' or similar."
        )

    def test_install_script_executable_bit_set(self):
        """The install.sh script must have at least the owner execute bit set."""
        file_stat = os.stat(INSTALL_SCRIPT)
        mode = stat.S_IMODE(file_stat.st_mode)
        has_user_execute = bool(mode & stat.S_IXUSR)
        assert has_user_execute, (
            f"{INSTALL_SCRIPT} does not have the owner execute bit (u+x) set. "
            f"Current permissions: {oct(mode)}. "
            "The script needs to be executable by the owner."
        )

    def test_install_script_test_x_exits_zero(self):
        """Running 'test -x /home/user/dotfiles/install.sh' must exit 0."""
        result = subprocess.run(
            ["test", "-x", INSTALL_SCRIPT],
            capture_output=True
        )
        assert result.returncode == 0, (
            f"'test -x {INSTALL_SCRIPT}' exited with code {result.returncode}. "
            "Expected exit code 0, indicating the file is executable."
        )

    def test_install_script_is_still_readable(self):
        """The install.sh script must still be readable."""
        assert os.access(INSTALL_SCRIPT, os.R_OK), (
            f"{INSTALL_SCRIPT} is not readable. "
            "Making it executable should not have removed read permissions."
        )


class TestInstallScriptContentUnchanged:
    """Verify the contents of install.sh were not modified."""

    def test_install_script_has_content(self):
        """The install.sh script should not be empty."""
        file_size = os.path.getsize(INSTALL_SCRIPT)
        assert file_size > 0, (
            f"{INSTALL_SCRIPT} is empty. "
            "The script content should not have been deleted."
        )

    def test_install_script_starts_with_shebang(self):
        """The install.sh script should still be a valid bash script."""
        with open(INSTALL_SCRIPT, 'r') as f:
            first_line = f.readline().strip()
        assert first_line.startswith("#!"), (
            f"{INSTALL_SCRIPT} does not start with a shebang (#!). "
            "The script content should not have been modified."
        )

    def test_install_script_contains_bash_shebang(self):
        """The install.sh script should have a bash shebang."""
        with open(INSTALL_SCRIPT, 'r') as f:
            first_line = f.readline().strip()
        assert "bash" in first_line or "sh" in first_line, (
            f"{INSTALL_SCRIPT} shebang '{first_line}' doesn't reference bash/sh. "
            "The script content should not have been modified."
        )


class TestOtherDotfilesUnchanged:
    """Verify other files in the dotfiles directory are unchanged."""

    @pytest.mark.parametrize("filename", EXPECTED_DOTFILES)
    def test_dotfile_still_exists(self, filename):
        """Each expected dotfile must still exist."""
        filepath = os.path.join(DOTFILES_DIR, filename)
        assert os.path.exists(filepath), (
            f"Expected file {filepath} no longer exists. "
            "Other files in the dotfiles directory should not be modified."
        )

    @pytest.mark.parametrize("filename", EXPECTED_DOTFILES)
    def test_dotfile_is_still_regular_file(self, filename):
        """Each expected dotfile must still be a regular file."""
        filepath = os.path.join(DOTFILES_DIR, filename)
        assert os.path.isfile(filepath), (
            f"{filepath} is not a regular file. "
            "Other files should not have been replaced with directories or symlinks."
        )


class TestOwnershipUnchanged:
    """Verify file ownership has not changed."""

    def test_dotfiles_still_owned_by_user(self):
        """The dotfiles directory should still be owned by 'user'."""
        import pwd
        file_stat = os.stat(DOTFILES_DIR)
        owner_uid = file_stat.st_uid
        try:
            owner_name = pwd.getpwuid(owner_uid).pw_name
        except KeyError:
            owner_name = str(owner_uid)
        assert owner_name == "user", (
            f"{DOTFILES_DIR} is now owned by '{owner_name}', expected 'user'. "
            "Ownership should not have changed."
        )

    def test_install_script_still_owned_by_user(self):
        """The install.sh script should still be owned by 'user'."""
        import pwd
        file_stat = os.stat(INSTALL_SCRIPT)
        owner_uid = file_stat.st_uid
        try:
            owner_name = pwd.getpwuid(owner_uid).pw_name
        except KeyError:
            owner_name = str(owner_uid)
        assert owner_name == "user", (
            f"{INSTALL_SCRIPT} is now owned by '{owner_name}', expected 'user'. "
            "Ownership should not have changed when making the file executable."
        )


class TestDotfilesDirectoryIntact:
    """Verify the dotfiles directory structure is intact."""

    def test_dotfiles_directory_exists(self):
        """The /home/user/dotfiles/ directory must still exist."""
        assert os.path.exists(DOTFILES_DIR), (
            f"Directory {DOTFILES_DIR} no longer exists."
        )

    def test_dotfiles_is_directory(self):
        """The /home/user/dotfiles/ path must still be a directory."""
        assert os.path.isdir(DOTFILES_DIR), (
            f"{DOTFILES_DIR} is no longer a directory."
        )

    def test_dotfiles_directory_is_writable(self):
        """The /home/user/dotfiles/ directory must still be writable."""
        assert os.access(DOTFILES_DIR, os.W_OK), (
            f"Directory {DOTFILES_DIR} is no longer writable."
        )
