# test_initial_state.py
"""
Tests to validate the initial state before the student makes install.sh executable.
"""

import os
import stat
import pytest


DOTFILES_DIR = "/home/user/dotfiles"
INSTALL_SCRIPT = "/home/user/dotfiles/install.sh"
EXPECTED_DOTFILES = ["install.sh", ".bashrc", ".vimrc", ".gitconfig"]


class TestDotfilesDirectoryExists:
    """Verify the dotfiles directory exists and is accessible."""

    def test_dotfiles_directory_exists(self):
        """The /home/user/dotfiles/ directory must exist."""
        assert os.path.exists(DOTFILES_DIR), (
            f"Directory {DOTFILES_DIR} does not exist. "
            "The dotfiles repo should already be cloned."
        )

    def test_dotfiles_is_directory(self):
        """The /home/user/dotfiles/ path must be a directory."""
        assert os.path.isdir(DOTFILES_DIR), (
            f"{DOTFILES_DIR} exists but is not a directory."
        )

    def test_dotfiles_directory_is_writable(self):
        """The /home/user/dotfiles/ directory must be writable by the user."""
        assert os.access(DOTFILES_DIR, os.W_OK), (
            f"Directory {DOTFILES_DIR} is not writable. "
            "It should be owned by user and writable."
        )


class TestDotfilesContents:
    """Verify the expected files exist in the dotfiles directory."""

    @pytest.mark.parametrize("filename", EXPECTED_DOTFILES)
    def test_dotfile_exists(self, filename):
        """Each expected dotfile must exist in the dotfiles directory."""
        filepath = os.path.join(DOTFILES_DIR, filename)
        assert os.path.exists(filepath), (
            f"Expected file {filepath} does not exist. "
            f"The dotfiles directory should contain: {', '.join(EXPECTED_DOTFILES)}"
        )

    @pytest.mark.parametrize("filename", EXPECTED_DOTFILES)
    def test_dotfile_is_regular_file(self, filename):
        """Each expected dotfile must be a regular file."""
        filepath = os.path.join(DOTFILES_DIR, filename)
        if os.path.exists(filepath):
            assert os.path.isfile(filepath), (
                f"{filepath} exists but is not a regular file."
            )


class TestInstallScriptInitialState:
    """Verify the install.sh script is in the correct initial state (not executable)."""

    def test_install_script_exists(self):
        """The install.sh script must exist."""
        assert os.path.exists(INSTALL_SCRIPT), (
            f"Install script {INSTALL_SCRIPT} does not exist. "
            "It should be present in the dotfiles directory."
        )

    def test_install_script_is_file(self):
        """The install.sh must be a regular file."""
        assert os.path.isfile(INSTALL_SCRIPT), (
            f"{INSTALL_SCRIPT} is not a regular file."
        )

    def test_install_script_is_readable(self):
        """The install.sh script must be readable."""
        assert os.access(INSTALL_SCRIPT, os.R_OK), (
            f"{INSTALL_SCRIPT} is not readable. "
            "It should have at least read permissions (644)."
        )

    def test_install_script_is_not_executable(self):
        """The install.sh script must NOT be executable initially."""
        assert not os.access(INSTALL_SCRIPT, os.X_OK), (
            f"{INSTALL_SCRIPT} is already executable. "
            "Initial state requires it to NOT be executable (permissions 644)."
        )

    def test_install_script_permissions_are_644(self):
        """The install.sh script should have permissions 644 (rw-r--r--)."""
        file_stat = os.stat(INSTALL_SCRIPT)
        mode = stat.S_IMODE(file_stat.st_mode)
        expected_mode = 0o644
        assert mode == expected_mode, (
            f"{INSTALL_SCRIPT} has permissions {oct(mode)}, expected {oct(expected_mode)} (644). "
            "The file should be readable but not executable."
        )

    def test_install_script_has_content(self):
        """The install.sh script should not be empty."""
        file_size = os.path.getsize(INSTALL_SCRIPT)
        assert file_size > 0, (
            f"{INSTALL_SCRIPT} is empty. "
            "It should contain valid bash script content."
        )

    def test_install_script_starts_with_shebang(self):
        """The install.sh script should be a valid bash script (starts with shebang)."""
        with open(INSTALL_SCRIPT, 'r') as f:
            first_line = f.readline().strip()
        assert first_line.startswith("#!"), (
            f"{INSTALL_SCRIPT} does not start with a shebang (#!). "
            "It should be a valid bash script."
        )


class TestOwnership:
    """Verify file ownership is correct."""

    def test_dotfiles_owned_by_user(self):
        """The dotfiles directory should be owned by 'user'."""
        import pwd
        file_stat = os.stat(DOTFILES_DIR)
        owner_uid = file_stat.st_uid
        try:
            owner_name = pwd.getpwuid(owner_uid).pw_name
        except KeyError:
            owner_name = str(owner_uid)
        assert owner_name == "user", (
            f"{DOTFILES_DIR} is owned by '{owner_name}', expected 'user'."
        )

    def test_install_script_owned_by_user(self):
        """The install.sh script should be owned by 'user'."""
        import pwd
        file_stat = os.stat(INSTALL_SCRIPT)
        owner_uid = file_stat.st_uid
        try:
            owner_name = pwd.getpwuid(owner_uid).pw_name
        except KeyError:
            owner_name = str(owner_uid)
        assert owner_name == "user", (
            f"{INSTALL_SCRIPT} is owned by '{owner_name}', expected 'user'."
        )
