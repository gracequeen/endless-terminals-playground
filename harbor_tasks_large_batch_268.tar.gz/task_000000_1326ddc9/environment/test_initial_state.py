# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the credential rotation task.
"""

import os
import pytest


class TestDirectoryStructure:
    """Verify required directories exist."""

    def test_gateway_directory_exists(self):
        """The /home/user/gateway/ directory must exist."""
        assert os.path.isdir("/home/user/gateway"), \
            "Directory /home/user/gateway/ does not exist"

    def test_gateway_config_directory_exists(self):
        """The /home/user/gateway/config/ directory must exist."""
        assert os.path.isdir("/home/user/gateway/config"), \
            "Directory /home/user/gateway/config/ does not exist"

    def test_gateway_services_directory_exists(self):
        """The /home/user/gateway/config/services/ directory must exist."""
        assert os.path.isdir("/home/user/gateway/config/services"), \
            "Directory /home/user/gateway/config/services/ does not exist"

    def test_creds_directory_exists(self):
        """The /home/user/creds/ directory must exist."""
        assert os.path.isdir("/home/user/creds"), \
            "Directory /home/user/creds/ does not exist"


class TestConfigFilesExist:
    """Verify all required config files exist."""

    def test_main_yaml_exists(self):
        """The main.yaml config file must exist."""
        path = "/home/user/gateway/config/main.yaml"
        assert os.path.isfile(path), f"Config file {path} does not exist"

    def test_auth_yaml_exists(self):
        """The auth.yaml config file must exist."""
        path = "/home/user/gateway/config/services/auth.yaml"
        assert os.path.isfile(path), f"Config file {path} does not exist"

    def test_billing_yaml_exists(self):
        """The billing.yaml config file must exist."""
        path = "/home/user/gateway/config/services/billing.yaml"
        assert os.path.isfile(path), f"Config file {path} does not exist"

    def test_rotation_patch_exists(self):
        """The rotation.patch file must exist."""
        path = "/home/user/creds/rotation.patch"
        assert os.path.isfile(path), f"Patch file {path} does not exist"


class TestMainYamlContent:
    """Verify main.yaml has expected initial content."""

    @pytest.fixture
    def main_yaml_content(self):
        with open("/home/user/gateway/config/main.yaml", "r") as f:
            return f.read()

    def test_main_yaml_has_old_api_key(self, main_yaml_content):
        """main.yaml must contain the old API key before rotation."""
        assert 'sk_old_a8f3e2b1c9d0' in main_yaml_content, \
            "main.yaml does not contain the old API key 'sk_old_a8f3e2b1c9d0'"

    def test_main_yaml_has_gateway_name(self, main_yaml_content):
        """main.yaml must have the staging gateway name."""
        assert 'staging-gw-01' in main_yaml_content, \
            "main.yaml does not contain 'staging-gw-01'"

    def test_main_yaml_has_region(self, main_yaml_content):
        """main.yaml must have the region configured."""
        assert 'us-east-2' in main_yaml_content, \
            "main.yaml does not contain region 'us-east-2'"

    def test_main_yaml_has_timeout(self, main_yaml_content):
        """main.yaml must have timeout_ms configured."""
        assert 'timeout_ms: 30000' in main_yaml_content, \
            "main.yaml does not contain 'timeout_ms: 30000'"

    def test_main_yaml_has_max_connections(self, main_yaml_content):
        """main.yaml must have max_connections configured."""
        assert 'max_connections: 500' in main_yaml_content, \
            "main.yaml does not contain 'max_connections: 500'"


class TestAuthYamlContent:
    """Verify auth.yaml has expected initial content."""

    @pytest.fixture
    def auth_yaml_content(self):
        with open("/home/user/gateway/config/services/auth.yaml", "r") as f:
            return f.read()

    def test_auth_yaml_has_old_api_key(self, auth_yaml_content):
        """auth.yaml must contain the old API key before rotation."""
        assert 'sk_old_a8f3e2b1c9d0' in auth_yaml_content, \
            "auth.yaml does not contain the old API key 'sk_old_a8f3e2b1c9d0'"

    def test_auth_yaml_has_service_name(self, auth_yaml_content):
        """auth.yaml must have service: auth."""
        assert 'service: auth' in auth_yaml_content, \
            "auth.yaml does not contain 'service: auth'"

    def test_auth_yaml_has_endpoint(self, auth_yaml_content):
        """auth.yaml must have the auth endpoint."""
        assert 'https://auth.internal.example.com' in auth_yaml_content, \
            "auth.yaml does not contain the auth endpoint"

    def test_auth_yaml_has_retry_count_3(self, auth_yaml_content):
        """auth.yaml must have retry_count: 3 (current value, not the stale 2)."""
        assert 'retry_count: 3' in auth_yaml_content, \
            "auth.yaml does not contain 'retry_count: 3' - this is the current value that differs from the patch"

    def test_auth_yaml_has_circuit_breaker(self, auth_yaml_content):
        """auth.yaml must have circuit_breaker configuration."""
        assert 'circuit_breaker:' in auth_yaml_content, \
            "auth.yaml does not contain circuit_breaker configuration"


class TestBillingYamlContent:
    """Verify billing.yaml has expected initial content."""

    @pytest.fixture
    def billing_yaml_content(self):
        with open("/home/user/gateway/config/services/billing.yaml", "r") as f:
            return f.read()

    def test_billing_yaml_has_old_api_key(self, billing_yaml_content):
        """billing.yaml must contain the old API key before rotation."""
        assert 'sk_old_a8f3e2b1c9d0' in billing_yaml_content, \
            "billing.yaml does not contain the old API key 'sk_old_a8f3e2b1c9d0'"

    def test_billing_yaml_has_service_name(self, billing_yaml_content):
        """billing.yaml must have service: billing."""
        assert 'service: billing' in billing_yaml_content, \
            "billing.yaml does not contain 'service: billing'"

    def test_billing_yaml_has_endpoint(self, billing_yaml_content):
        """billing.yaml must have the billing endpoint."""
        assert 'https://billing.internal.example.com' in billing_yaml_content, \
            "billing.yaml does not contain the billing endpoint"

    def test_billing_yaml_has_retry_count_5(self, billing_yaml_content):
        """billing.yaml must have retry_count: 5."""
        assert 'retry_count: 5' in billing_yaml_content, \
            "billing.yaml does not contain 'retry_count: 5'"

    def test_billing_yaml_has_rate_limit(self, billing_yaml_content):
        """billing.yaml must have rate_limit configuration."""
        assert 'rate_limit:' in billing_yaml_content, \
            "billing.yaml does not contain rate_limit configuration"


class TestPatchFileContent:
    """Verify the rotation.patch file has expected content with known issues."""

    @pytest.fixture
    def patch_content(self):
        with open("/home/user/creds/rotation.patch", "r") as f:
            return f.read()

    def test_patch_contains_new_api_key(self, patch_content):
        """The patch must contain the new API key to apply."""
        assert 'sk_new_7x9m4k2p5q8r' in patch_content, \
            "rotation.patch does not contain the new API key 'sk_new_7x9m4k2p5q8r'"

    def test_patch_contains_old_api_key(self, patch_content):
        """The patch must reference the old API key being replaced."""
        assert 'sk_old_a8f3e2b1c9d0' in patch_content, \
            "rotation.patch does not contain the old API key 'sk_old_a8f3e2b1c9d0'"

    def test_patch_references_main_yaml(self, patch_content):
        """The patch must reference main.yaml."""
        assert 'main.yaml' in patch_content, \
            "rotation.patch does not reference main.yaml"

    def test_patch_references_auth_yaml(self, patch_content):
        """The patch must reference auth.yaml."""
        assert 'auth.yaml' in patch_content, \
            "rotation.patch does not reference auth.yaml"

    def test_patch_references_billing_yaml(self, patch_content):
        """The patch must reference billing.yaml."""
        assert 'billing.yaml' in patch_content, \
            "rotation.patch does not reference billing.yaml"

    def test_patch_has_absolute_paths(self, patch_content):
        """The patch should have absolute paths (part of the problem)."""
        assert '/home/user/gateway/config/' in patch_content, \
            "rotation.patch does not contain absolute paths as expected"

    def test_patch_has_stale_retry_count(self, patch_content):
        """The patch should have the stale retry_count: 2 (part of the problem)."""
        assert 'retry_count: 2' in patch_content, \
            "rotation.patch does not contain the stale 'retry_count: 2' context line"


class TestFilesAreWritable:
    """Verify all files that need to be modified are writable."""

    def test_main_yaml_is_writable(self):
        """main.yaml must be writable."""
        path = "/home/user/gateway/config/main.yaml"
        assert os.access(path, os.W_OK), f"{path} is not writable"

    def test_auth_yaml_is_writable(self):
        """auth.yaml must be writable."""
        path = "/home/user/gateway/config/services/auth.yaml"
        assert os.access(path, os.W_OK), f"{path} is not writable"

    def test_billing_yaml_is_writable(self):
        """billing.yaml must be writable."""
        path = "/home/user/gateway/config/services/billing.yaml"
        assert os.access(path, os.W_OK), f"{path} is not writable"

    def test_patch_file_is_readable(self):
        """rotation.patch must be readable."""
        path = "/home/user/creds/rotation.patch"
        assert os.access(path, os.R_OK), f"{path} is not readable"


class TestNoNewKeyYet:
    """Verify the new API key is not already in the config files."""

    def test_main_yaml_no_new_key(self):
        """main.yaml must not already have the new API key."""
        with open("/home/user/gateway/config/main.yaml", "r") as f:
            content = f.read()
        assert 'sk_new_7x9m4k2p5q8r' not in content, \
            "main.yaml already contains the new API key - rotation may have already occurred"

    def test_auth_yaml_no_new_key(self):
        """auth.yaml must not already have the new API key."""
        with open("/home/user/gateway/config/services/auth.yaml", "r") as f:
            content = f.read()
        assert 'sk_new_7x9m4k2p5q8r' not in content, \
            "auth.yaml already contains the new API key - rotation may have already occurred"

    def test_billing_yaml_no_new_key(self):
        """billing.yaml must not already have the new API key."""
        with open("/home/user/gateway/config/services/billing.yaml", "r") as f:
            content = f.read()
        assert 'sk_new_7x9m4k2p5q8r' not in content, \
            "billing.yaml already contains the new API key - rotation may have already occurred"
