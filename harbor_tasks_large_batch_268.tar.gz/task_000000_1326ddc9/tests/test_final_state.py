# test_final_state.py
"""
Tests to validate the final state of the OS/filesystem after the student
has completed the credential rotation task.
"""

import os
import subprocess
import pytest


class TestNewApiKeyPresent:
    """Verify all config files contain the new API key."""

    def test_main_yaml_has_new_api_key(self):
        """main.yaml must contain the new API key after rotation."""
        with open("/home/user/gateway/config/main.yaml", "r") as f:
            content = f.read()
        assert 'sk_new_7x9m4k2p5q8r' in content, \
            "main.yaml does not contain the new API key 'sk_new_7x9m4k2p5q8r' - rotation incomplete"

    def test_auth_yaml_has_new_api_key(self):
        """auth.yaml must contain the new API key after rotation."""
        with open("/home/user/gateway/config/services/auth.yaml", "r") as f:
            content = f.read()
        assert 'sk_new_7x9m4k2p5q8r' in content, \
            "auth.yaml does not contain the new API key 'sk_new_7x9m4k2p5q8r' - rotation incomplete"

    def test_billing_yaml_has_new_api_key(self):
        """billing.yaml must contain the new API key after rotation."""
        with open("/home/user/gateway/config/services/billing.yaml", "r") as f:
            content = f.read()
        assert 'sk_new_7x9m4k2p5q8r' in content, \
            "billing.yaml does not contain the new API key 'sk_new_7x9m4k2p5q8r' - rotation incomplete"


class TestOldApiKeyRemoved:
    """Verify the old API key has been completely removed from all config files."""

    def test_main_yaml_no_old_api_key(self):
        """main.yaml must not contain the old API key after rotation."""
        with open("/home/user/gateway/config/main.yaml", "r") as f:
            content = f.read()
        assert 'sk_old_a8f3e2b1c9d0' not in content, \
            "main.yaml still contains the old API key 'sk_old_a8f3e2b1c9d0' - rotation incomplete"

    def test_auth_yaml_no_old_api_key(self):
        """auth.yaml must not contain the old API key after rotation."""
        with open("/home/user/gateway/config/services/auth.yaml", "r") as f:
            content = f.read()
        assert 'sk_old_a8f3e2b1c9d0' not in content, \
            "auth.yaml still contains the old API key 'sk_old_a8f3e2b1c9d0' - rotation incomplete"

    def test_billing_yaml_no_old_api_key(self):
        """billing.yaml must not contain the old API key after rotation."""
        with open("/home/user/gateway/config/services/billing.yaml", "r") as f:
            content = f.read()
        assert 'sk_old_a8f3e2b1c9d0' not in content, \
            "billing.yaml still contains the old API key 'sk_old_a8f3e2b1c9d0' - rotation incomplete"


class TestExactlyOneNewKeyPerFile:
    """Verify each config file has exactly one occurrence of the new API key."""

    def test_main_yaml_single_new_key(self):
        """main.yaml must have exactly one occurrence of the new API key."""
        with open("/home/user/gateway/config/main.yaml", "r") as f:
            content = f.read()
        count = content.count('sk_new_7x9m4k2p5q8r')
        assert count == 1, \
            f"main.yaml has {count} occurrences of new API key, expected exactly 1"

    def test_auth_yaml_single_new_key(self):
        """auth.yaml must have exactly one occurrence of the new API key."""
        with open("/home/user/gateway/config/services/auth.yaml", "r") as f:
            content = f.read()
        count = content.count('sk_new_7x9m4k2p5q8r')
        assert count == 1, \
            f"auth.yaml has {count} occurrences of new API key, expected exactly 1"

    def test_billing_yaml_single_new_key(self):
        """billing.yaml must have exactly one occurrence of the new API key."""
        with open("/home/user/gateway/config/services/billing.yaml", "r") as f:
            content = f.read()
        count = content.count('sk_new_7x9m4k2p5q8r')
        assert count == 1, \
            f"billing.yaml has {count} occurrences of new API key, expected exactly 1"


class TestMainYamlInvariants:
    """Verify main.yaml retains all non-api_key settings."""

    @pytest.fixture
    def main_yaml_content(self):
        with open("/home/user/gateway/config/main.yaml", "r") as f:
            return f.read()

    def test_main_yaml_has_gateway_name(self, main_yaml_content):
        """main.yaml must retain the staging gateway name."""
        assert 'staging-gw-01' in main_yaml_content, \
            "main.yaml is missing 'staging-gw-01' - config corrupted"

    def test_main_yaml_has_region(self, main_yaml_content):
        """main.yaml must retain the region configuration."""
        assert 'us-east-2' in main_yaml_content, \
            "main.yaml is missing region 'us-east-2' - config corrupted"

    def test_main_yaml_has_timeout(self, main_yaml_content):
        """main.yaml must retain timeout_ms configuration."""
        assert 'timeout_ms: 30000' in main_yaml_content or 'timeout_ms:30000' in main_yaml_content.replace(' ', ''), \
            "main.yaml is missing 'timeout_ms: 30000' - config corrupted"

    def test_main_yaml_has_max_connections(self, main_yaml_content):
        """main.yaml must retain max_connections configuration."""
        assert 'max_connections: 500' in main_yaml_content or 'max_connections:500' in main_yaml_content.replace(' ', ''), \
            "main.yaml is missing 'max_connections: 500' - config corrupted"

    def test_main_yaml_has_logging_level(self, main_yaml_content):
        """main.yaml must retain logging level configuration."""
        assert 'level: info' in main_yaml_content or 'level:info' in main_yaml_content.replace(' ', ''), \
            "main.yaml is missing 'level: info' - logging config corrupted"

    def test_main_yaml_has_logging_format(self, main_yaml_content):
        """main.yaml must retain logging format configuration."""
        assert 'format: json' in main_yaml_content or 'format:json' in main_yaml_content.replace(' ', ''), \
            "main.yaml is missing 'format: json' - logging config corrupted"


class TestAuthYamlInvariants:
    """Verify auth.yaml retains all non-api_key settings, especially retry_count: 3."""

    @pytest.fixture
    def auth_yaml_content(self):
        with open("/home/user/gateway/config/services/auth.yaml", "r") as f:
            return f.read()

    def test_auth_yaml_has_service_name(self, auth_yaml_content):
        """auth.yaml must retain service: auth."""
        assert 'service: auth' in auth_yaml_content or 'service:auth' in auth_yaml_content.replace(' ', ''), \
            "auth.yaml is missing 'service: auth' - config corrupted"

    def test_auth_yaml_has_endpoint(self, auth_yaml_content):
        """auth.yaml must retain the auth endpoint."""
        assert 'https://auth.internal.example.com' in auth_yaml_content, \
            "auth.yaml is missing the auth endpoint - config corrupted"

    def test_auth_yaml_has_retry_count_3(self, auth_yaml_content):
        """auth.yaml must retain retry_count: 3 (NOT the stale value of 2 from the patch)."""
        # Check for retry_count: 3, allowing for minor whitespace variations
        assert 'retry_count: 3' in auth_yaml_content or 'retry_count:3' in auth_yaml_content.replace(' ', ''), \
            "auth.yaml must have 'retry_count: 3' - this is the current value that must be preserved (not the stale '2' from the patch)"

    def test_auth_yaml_no_retry_count_2(self, auth_yaml_content):
        """auth.yaml must NOT have retry_count: 2 (the stale value from the patch)."""
        # Make sure the stale value wasn't incorrectly applied
        normalized = auth_yaml_content.replace(' ', '')
        assert 'retry_count:2' not in normalized, \
            "auth.yaml has 'retry_count: 2' which is the stale value from the patch - should be 'retry_count: 3'"

    def test_auth_yaml_has_circuit_breaker(self, auth_yaml_content):
        """auth.yaml must retain circuit_breaker configuration."""
        assert 'circuit_breaker:' in auth_yaml_content, \
            "auth.yaml is missing circuit_breaker configuration - config corrupted"

    def test_auth_yaml_has_circuit_breaker_enabled(self, auth_yaml_content):
        """auth.yaml must retain circuit_breaker enabled: true."""
        assert 'enabled: true' in auth_yaml_content or 'enabled:true' in auth_yaml_content.replace(' ', ''), \
            "auth.yaml is missing circuit_breaker 'enabled: true' - config corrupted"

    def test_auth_yaml_has_circuit_breaker_threshold(self, auth_yaml_content):
        """auth.yaml must retain circuit_breaker threshold: 5."""
        assert 'threshold: 5' in auth_yaml_content or 'threshold:5' in auth_yaml_content.replace(' ', ''), \
            "auth.yaml is missing circuit_breaker 'threshold: 5' - config corrupted"


class TestBillingYamlInvariants:
    """Verify billing.yaml retains all non-api_key settings."""

    @pytest.fixture
    def billing_yaml_content(self):
        with open("/home/user/gateway/config/services/billing.yaml", "r") as f:
            return f.read()

    def test_billing_yaml_has_service_name(self, billing_yaml_content):
        """billing.yaml must retain service: billing."""
        assert 'service: billing' in billing_yaml_content or 'service:billing' in billing_yaml_content.replace(' ', ''), \
            "billing.yaml is missing 'service: billing' - config corrupted"

    def test_billing_yaml_has_endpoint(self, billing_yaml_content):
        """billing.yaml must retain the billing endpoint."""
        assert 'https://billing.internal.example.com' in billing_yaml_content, \
            "billing.yaml is missing the billing endpoint - config corrupted"

    def test_billing_yaml_has_retry_count_5(self, billing_yaml_content):
        """billing.yaml must retain retry_count: 5."""
        assert 'retry_count: 5' in billing_yaml_content or 'retry_count:5' in billing_yaml_content.replace(' ', ''), \
            "billing.yaml is missing 'retry_count: 5' - config corrupted"

    def test_billing_yaml_has_rate_limit(self, billing_yaml_content):
        """billing.yaml must retain rate_limit configuration."""
        assert 'rate_limit:' in billing_yaml_content, \
            "billing.yaml is missing rate_limit configuration - config corrupted"

    def test_billing_yaml_has_rate_limit_value(self, billing_yaml_content):
        """billing.yaml must retain requests_per_minute: 100."""
        assert 'requests_per_minute: 100' in billing_yaml_content or 'requests_per_minute:100' in billing_yaml_content.replace(' ', ''), \
            "billing.yaml is missing 'requests_per_minute: 100' - config corrupted"


class TestFilesStillExist:
    """Verify all config files still exist after the operation."""

    def test_main_yaml_exists(self):
        """main.yaml must still exist."""
        path = "/home/user/gateway/config/main.yaml"
        assert os.path.isfile(path), f"Config file {path} no longer exists"

    def test_auth_yaml_exists(self):
        """auth.yaml must still exist."""
        path = "/home/user/gateway/config/services/auth.yaml"
        assert os.path.isfile(path), f"Config file {path} no longer exists"

    def test_billing_yaml_exists(self):
        """billing.yaml must still exist."""
        path = "/home/user/gateway/config/services/billing.yaml"
        assert os.path.isfile(path), f"Config file {path} no longer exists"


class TestGrepValidation:
    """Use grep to validate the final state as specified in the task."""

    def test_grep_new_key_main_yaml(self):
        """grep must find the new key in main.yaml."""
        result = subprocess.run(
            ['grep', 'sk_new_7x9m4k2p5q8r', '/home/user/gateway/config/main.yaml'],
            capture_output=True, text=True
        )
        assert result.returncode == 0, \
            "grep did not find 'sk_new_7x9m4k2p5q8r' in main.yaml"

    def test_grep_new_key_auth_yaml(self):
        """grep must find the new key in auth.yaml."""
        result = subprocess.run(
            ['grep', 'sk_new_7x9m4k2p5q8r', '/home/user/gateway/config/services/auth.yaml'],
            capture_output=True, text=True
        )
        assert result.returncode == 0, \
            "grep did not find 'sk_new_7x9m4k2p5q8r' in auth.yaml"

    def test_grep_new_key_billing_yaml(self):
        """grep must find the new key in billing.yaml."""
        result = subprocess.run(
            ['grep', 'sk_new_7x9m4k2p5q8r', '/home/user/gateway/config/services/billing.yaml'],
            capture_output=True, text=True
        )
        assert result.returncode == 0, \
            "grep did not find 'sk_new_7x9m4k2p5q8r' in billing.yaml"

    def test_grep_no_old_key_anywhere(self):
        """grep must NOT find the old key in any config file."""
        files = [
            '/home/user/gateway/config/main.yaml',
            '/home/user/gateway/config/services/auth.yaml',
            '/home/user/gateway/config/services/billing.yaml'
        ]
        for filepath in files:
            result = subprocess.run(
                ['grep', 'sk_old_a8f3e2b1c9d0', filepath],
                capture_output=True, text=True
            )
            assert result.returncode != 0, \
                f"grep found old key 'sk_old_a8f3e2b1c9d0' in {filepath} - rotation incomplete"


class TestYamlStructureValid:
    """Basic validation that YAML structure wasn't corrupted."""

    def test_main_yaml_has_gateway_section(self):
        """main.yaml must have a gateway section."""
        with open("/home/user/gateway/config/main.yaml", "r") as f:
            content = f.read()
        assert 'gateway:' in content, \
            "main.yaml is missing 'gateway:' section - YAML structure corrupted"

    def test_main_yaml_has_logging_section(self):
        """main.yaml must have a logging section."""
        with open("/home/user/gateway/config/main.yaml", "r") as f:
            content = f.read()
        assert 'logging:' in content, \
            "main.yaml is missing 'logging:' section - YAML structure corrupted"

    def test_auth_yaml_has_circuit_breaker_section(self):
        """auth.yaml must have a circuit_breaker section."""
        with open("/home/user/gateway/config/services/auth.yaml", "r") as f:
            content = f.read()
        assert 'circuit_breaker:' in content, \
            "auth.yaml is missing 'circuit_breaker:' section - YAML structure corrupted"

    def test_billing_yaml_has_rate_limit_section(self):
        """billing.yaml must have a rate_limit section."""
        with open("/home/user/gateway/config/services/billing.yaml", "r") as f:
            content = f.read()
        assert 'rate_limit:' in content, \
            "billing.yaml is missing 'rate_limit:' section - YAML structure corrupted"
