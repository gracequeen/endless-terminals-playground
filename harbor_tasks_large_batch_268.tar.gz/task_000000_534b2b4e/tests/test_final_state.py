# test_final_state.py
"""
Tests to validate the final state of the OS/filesystem after the student
has fixed the config merger script.
"""

import os
import subprocess
import pytest
import configparser
from pathlib import Path


# Base paths
DOCTOOLS_DIR = Path("/home/user/doctools")
FRAGMENTS_DIR = DOCTOOLS_DIR / "fragments"
MERGE_SCRIPT = DOCTOOLS_DIR / "merge_configs.py"
OUTPUT_DIR = DOCTOOLS_DIR / "output"
MASTER_INI = OUTPUT_DIR / "master.ini"


class TestScriptExecution:
    """Test that the merge script runs successfully."""

    def test_script_exits_zero(self):
        """Running the merge script should exit with code 0."""
        result = subprocess.run(
            ["python3", str(MERGE_SCRIPT)],
            capture_output=True,
            text=True,
            cwd=str(DOCTOOLS_DIR)
        )
        assert result.returncode == 0, (
            f"Script exited with code {result.returncode}. "
            f"Stderr: {result.stderr}\nStdout: {result.stdout}"
        )

    def test_output_directory_created(self):
        """The output directory should exist after running the script."""
        # Run the script first to ensure output is generated
        subprocess.run(
            ["python3", str(MERGE_SCRIPT)],
            capture_output=True,
            cwd=str(DOCTOOLS_DIR)
        )
        assert OUTPUT_DIR.exists(), f"Output directory {OUTPUT_DIR} was not created"
        assert OUTPUT_DIR.is_dir(), f"{OUTPUT_DIR} is not a directory"

    def test_master_ini_created(self):
        """The master.ini file should exist after running the script."""
        subprocess.run(
            ["python3", str(MERGE_SCRIPT)],
            capture_output=True,
            cwd=str(DOCTOOLS_DIR)
        )
        assert MASTER_INI.exists(), f"Master config file {MASTER_INI} was not created"
        assert MASTER_INI.is_file(), f"{MASTER_INI} is not a file"


class TestMasterIniStructure:
    """Test the structure of the generated master.ini."""

    @pytest.fixture(autouse=True)
    def run_merge_script(self):
        """Ensure the merge script has been run before each test."""
        subprocess.run(
            ["python3", str(MERGE_SCRIPT)],
            capture_output=True,
            cwd=str(DOCTOOLS_DIR)
        )

    def test_exactly_four_sections(self):
        """master.ini must contain exactly 4 sections."""
        result = subprocess.run(
            ["grep", "-c", r"^\[", str(MASTER_INI)],
            capture_output=True,
            text=True
        )
        section_count = int(result.stdout.strip())
        assert section_count == 4, (
            f"Expected exactly 4 sections in master.ini, found {section_count}"
        )

    def test_has_database_section(self):
        """master.ini must contain [database] section."""
        config = configparser.ConfigParser()
        config.read(str(MASTER_INI))
        assert config.has_section("database"), (
            "master.ini is missing [database] section"
        )

    def test_has_api_section(self):
        """master.ini must contain [api] section."""
        config = configparser.ConfigParser()
        config.read(str(MASTER_INI))
        assert config.has_section("api"), (
            "master.ini is missing [api] section"
        )

    def test_has_storage_section(self):
        """master.ini must contain [storage] section."""
        config = configparser.ConfigParser()
        config.read(str(MASTER_INI))
        assert config.has_section("storage"), (
            "master.ini is missing [storage] section"
        )

    def test_has_auth_section(self):
        """master.ini must contain [auth] section."""
        config = configparser.ConfigParser()
        config.read(str(MASTER_INI))
        assert config.has_section("auth"), (
            "master.ini is missing [auth] section"
        )


class TestDatabaseSection:
    """Test the [database] section values."""

    @pytest.fixture(autouse=True)
    def run_merge_script(self):
        """Ensure the merge script has been run before each test."""
        subprocess.run(
            ["python3", str(MERGE_SCRIPT)],
            capture_output=True,
            cwd=str(DOCTOOLS_DIR)
        )

    def test_database_port_exact_value(self):
        """database.port must be exactly 5432 (not truncated to 543)."""
        result = subprocess.run(
            [
                "python3", "-c",
                "import configparser; c=configparser.ConfigParser(); "
                f"c.read('{MASTER_INI}'); print(c.get('database','port'))"
            ],
            capture_output=True,
            text=True
        )
        port_value = result.stdout.strip()
        assert port_value == "5432", (
            f"database.port should be '5432', got '{port_value}'. "
            "Value appears to be truncated or corrupted."
        )

    def test_database_has_host(self):
        """database section must have host key."""
        config = configparser.ConfigParser()
        config.read(str(MASTER_INI))
        assert config.has_option("database", "host"), (
            "[database] section is missing 'host' key"
        )
        host = config.get("database", "host")
        assert "db.internal.corp" in host, (
            f"database.host should contain 'db.internal.corp', got '{host}'"
        )

    def test_database_has_name(self):
        """database section must have name key."""
        config = configparser.ConfigParser()
        config.read(str(MASTER_INI))
        assert config.has_option("database", "name"), (
            "[database] section is missing 'name' key"
        )
        name = config.get("database", "name")
        assert "docs_production" in name, (
            f"database.name should contain 'docs_production', got '{name}'"
        )

    def test_database_has_three_keys(self):
        """database section must have exactly 3 keys."""
        config = configparser.ConfigParser()
        config.read(str(MASTER_INI))
        items = dict(config.items("database"))
        assert len(items) == 3, (
            f"[database] section should have 3 keys, found {len(items)}: {list(items.keys())}"
        )


class TestApiSection:
    """Test the [api] section values."""

    @pytest.fixture(autouse=True)
    def run_merge_script(self):
        """Ensure the merge script has been run before each test."""
        subprocess.run(
            ["python3", str(MERGE_SCRIPT)],
            capture_output=True,
            cwd=str(DOCTOOLS_DIR)
        )

    def test_api_endpoint_contains_v2_docs(self):
        """api.endpoint must contain 'v2/docs' (URL path preserved)."""
        config = configparser.ConfigParser()
        config.read(str(MASTER_INI))
        endpoint = config.get("api", "endpoint")
        assert "v2/docs" in endpoint, (
            f"api.endpoint should contain 'v2/docs', got '{endpoint}'. "
            "URL appears to be truncated or corrupted."
        )

    def test_api_endpoint_has_full_domain(self):
        """api.endpoint must contain the full domain."""
        config = configparser.ConfigParser()
        config.read(str(MASTER_INI))
        endpoint = config.get("api", "endpoint")
        assert "api.internal.corp" in endpoint, (
            f"api.endpoint should contain 'api.internal.corp', got '{endpoint}'"
        )

    def test_api_has_timeout(self):
        """api section must have timeout key."""
        config = configparser.ConfigParser()
        config.read(str(MASTER_INI))
        assert config.has_option("api", "timeout"), (
            "[api] section is missing 'timeout' key"
        )
        timeout = config.get("api", "timeout")
        assert "30" in timeout, (
            f"api.timeout should be '30', got '{timeout}'"
        )

    def test_api_has_retries(self):
        """api section must have retries key."""
        config = configparser.ConfigParser()
        config.read(str(MASTER_INI))
        assert config.has_option("api", "retries"), (
            "[api] section is missing 'retries' key"
        )
        retries = config.get("api", "retries")
        assert "3" in retries, (
            f"api.retries should be '3', got '{retries}'"
        )

    def test_api_has_three_keys(self):
        """api section must have exactly 3 keys."""
        config = configparser.ConfigParser()
        config.read(str(MASTER_INI))
        items = dict(config.items("api"))
        assert len(items) == 3, (
            f"[api] section should have 3 keys, found {len(items)}: {list(items.keys())}"
        )


class TestStorageSection:
    """Test the [storage] section values."""

    @pytest.fixture(autouse=True)
    def run_merge_script(self):
        """Ensure the merge script has been run before each test."""
        subprocess.run(
            ["python3", str(MERGE_SCRIPT)],
            capture_output=True,
            cwd=str(DOCTOOLS_DIR)
        )

    def test_storage_max_size_exact_value(self):
        """storage.max_size must be exactly 10737418240."""
        config = configparser.ConfigParser()
        config.read(str(MASTER_INI))
        max_size = config.get("storage", "max_size").strip()
        # Remove any trailing comments if present
        if ";" in max_size:
            max_size = max_size.split(";")[0].strip()
        assert max_size == "10737418240", (
            f"storage.max_size should be '10737418240', got '{max_size}'. "
            "Value appears to be truncated or corrupted."
        )

    def test_storage_max_size_length(self):
        """storage.max_size must have length 11 (length of '10737418240')."""
        result = subprocess.run(
            [
                "python3", "-c",
                "import configparser; c=configparser.ConfigParser(); "
                f"c.read('{MASTER_INI}'); v=c.get('storage','max_size').strip(); "
                "v=v.split(';')[0].strip() if ';' in v else v; print(len(v))"
            ],
            capture_output=True,
            text=True
        )
        length = int(result.stdout.strip())
        assert length == 11, (
            f"storage.max_size should have length 11, got {length}. "
            "Value appears to be truncated."
        )

    def test_storage_has_bucket(self):
        """storage section must have bucket key."""
        config = configparser.ConfigParser()
        config.read(str(MASTER_INI))
        assert config.has_option("storage", "bucket"), (
            "[storage] section is missing 'bucket' key"
        )
        bucket = config.get("storage", "bucket")
        assert "s3://" in bucket and "doctools-artifacts-prod" in bucket, (
            f"storage.bucket should contain 's3://doctools-artifacts-prod', got '{bucket}'"
        )

    def test_storage_has_region(self):
        """storage section must have region key."""
        config = configparser.ConfigParser()
        config.read(str(MASTER_INI))
        assert config.has_option("storage", "region"), (
            "[storage] section is missing 'region' key"
        )
        region = config.get("storage", "region")
        assert "us-east-1" in region, (
            f"storage.region should be 'us-east-1', got '{region}'"
        )

    def test_storage_has_three_keys(self):
        """storage section must have exactly 3 keys."""
        config = configparser.ConfigParser()
        config.read(str(MASTER_INI))
        items = dict(config.items("storage"))
        assert len(items) == 3, (
            f"[storage] section should have 3 keys, found {len(items)}: {list(items.keys())}"
        )


class TestAuthSection:
    """Test the [auth] section values."""

    @pytest.fixture(autouse=True)
    def run_merge_script(self):
        """Ensure the merge script has been run before each test."""
        subprocess.run(
            ["python3", str(MERGE_SCRIPT)],
            capture_output=True,
            cwd=str(DOCTOOLS_DIR)
        )

    def test_auth_client_id_exact_value(self):
        """auth.client_id must be exactly 0oa1b2c3d4e5f6g7h8i9."""
        config = configparser.ConfigParser()
        config.read(str(MASTER_INI))
        client_id = config.get("auth", "client_id").strip()
        assert client_id == "0oa1b2c3d4e5f6g7h8i9", (
            f"auth.client_id should be '0oa1b2c3d4e5f6g7h8i9', got '{client_id}'"
        )

    def test_auth_has_provider(self):
        """auth section must have provider key."""
        config = configparser.ConfigParser()
        config.read(str(MASTER_INI))
        assert config.has_option("auth", "provider"), (
            "[auth] section is missing 'provider' key"
        )
        provider = config.get("auth", "provider")
        assert "okta" in provider, (
            f"auth.provider should be 'okta', got '{provider}'"
        )

    def test_auth_has_redirect_uri(self):
        """auth section must have redirect_uri key."""
        config = configparser.ConfigParser()
        config.read(str(MASTER_INI))
        assert config.has_option("auth", "redirect_uri"), (
            "[auth] section is missing 'redirect_uri' key"
        )
        redirect_uri = config.get("auth", "redirect_uri")
        assert "docs.internal.corp" in redirect_uri and "oauth/callback" in redirect_uri, (
            f"auth.redirect_uri should contain 'docs.internal.corp/oauth/callback', got '{redirect_uri}'"
        )

    def test_auth_has_three_keys(self):
        """auth section must have exactly 3 keys."""
        config = configparser.ConfigParser()
        config.read(str(MASTER_INI))
        items = dict(config.items("auth"))
        assert len(items) == 3, (
            f"[auth] section should have 3 keys, found {len(items)}: {list(items.keys())}"
        )


class TestNoCarriageReturns:
    """Test that no values contain embedded carriage return characters."""

    @pytest.fixture(autouse=True)
    def run_merge_script(self):
        """Ensure the merge script has been run before each test."""
        subprocess.run(
            ["python3", str(MERGE_SCRIPT)],
            capture_output=True,
            cwd=str(DOCTOOLS_DIR)
        )

    def test_no_carriage_returns_in_values(self):
        """No values in master.ini should contain \\r characters."""
        config = configparser.ConfigParser()
        config.read(str(MASTER_INI))

        for section in config.sections():
            for key, value in config.items(section):
                assert "\r" not in value, (
                    f"Value for [{section}].{key} contains carriage return character: {repr(value)}"
                )

    def test_no_carriage_returns_in_raw_file(self):
        """The raw master.ini file should not have \\r in value portions."""
        content = MASTER_INI.read_text()
        # Check that values don't have embedded \r (CRLF at line ends is OK in some cases,
        # but \r in the middle of values is not)
        lines = content.split("\n")
        for line in lines:
            if "=" in line and not line.strip().startswith("["):
                key_value = line.split("=", 1)
                if len(key_value) == 2:
                    value = key_value[1]
                    # Value should not have \r except possibly at the very end
                    value_stripped = value.rstrip("\r\n")
                    assert "\r" not in value_stripped, (
                        f"Value contains embedded carriage return: {repr(line)}"
                    )


class TestTotalKeyValuePairs:
    """Test that all 12 key-value pairs are present."""

    @pytest.fixture(autouse=True)
    def run_merge_script(self):
        """Ensure the merge script has been run before each test."""
        subprocess.run(
            ["python3", str(MERGE_SCRIPT)],
            capture_output=True,
            cwd=str(DOCTOOLS_DIR)
        )

    def test_total_twelve_keys(self):
        """master.ini must contain exactly 12 key-value pairs (3 per section)."""
        config = configparser.ConfigParser()
        config.read(str(MASTER_INI))

        total_keys = 0
        for section in config.sections():
            total_keys += len(config.options(section))

        assert total_keys == 12, (
            f"Expected 12 total key-value pairs, found {total_keys}"
        )


class TestFragmentsUnchanged:
    """Test that fragment files remain unchanged (invariant)."""

    def test_still_four_fragment_files(self):
        """There should still be exactly 4 .ini files in fragments/."""
        ini_files = list(FRAGMENTS_DIR.glob("*.ini"))
        assert len(ini_files) == 4, (
            f"Expected 4 fragment files, found {len(ini_files)}: {[f.name for f in ini_files]}"
        )

    def test_database_ini_still_exists(self):
        """database.ini should still exist in fragments/."""
        assert (FRAGMENTS_DIR / "database.ini").exists(), (
            "database.ini was removed or renamed"
        )

    def test_api_ini_still_exists(self):
        """api.ini should still exist in fragments/."""
        assert (FRAGMENTS_DIR / "api.ini").exists(), (
            "api.ini was removed or renamed"
        )

    def test_storage_ini_still_exists(self):
        """storage.ini should still exist in fragments/."""
        assert (FRAGMENTS_DIR / "storage.ini").exists(), (
            "storage.ini was removed or renamed"
        )

    def test_auth_ini_still_exists(self):
        """auth.ini should still exist in fragments/."""
        assert (FRAGMENTS_DIR / "auth.ini").exists(), (
            "auth.ini was removed or renamed"
        )


class TestScriptStillUsesConfigParser:
    """Test that the script still uses configparser (anti-shortcut guard)."""

    def test_script_imports_configparser(self):
        """Script must still import configparser."""
        content = MERGE_SCRIPT.read_text()
        assert "import configparser" in content or "from configparser" in content, (
            "Script must still use configparser module - manual parsing is not allowed"
        )

    def test_script_uses_configparser_class(self):
        """Script must still use ConfigParser class."""
        content = MERGE_SCRIPT.read_text()
        assert "ConfigParser" in content, (
            "Script must still use ConfigParser class"
        )

    def test_script_reads_from_fragments_dir(self):
        """Script must still read from fragments directory."""
        content = MERGE_SCRIPT.read_text()
        assert "fragments" in content, (
            "Script must still read from fragments directory"
        )

    def test_script_writes_to_master_ini(self):
        """Script must still write to master.ini."""
        content = MERGE_SCRIPT.read_text()
        assert "master.ini" in content, (
            "Script must still write to master.ini"
        )


class TestAntiShortcutGuards:
    """Additional anti-shortcut guards to prevent hardcoding."""

    @pytest.fixture(autouse=True)
    def run_merge_script(self):
        """Ensure the merge script has been run before each test."""
        subprocess.run(
            ["python3", str(MERGE_SCRIPT)],
            capture_output=True,
            cwd=str(DOCTOOLS_DIR)
        )

    def test_script_does_not_hardcode_values(self):
        """Script should not hardcode the expected values directly."""
        content = MERGE_SCRIPT.read_text()
        # Check that script doesn't just write hardcoded values
        hardcoded_patterns = [
            "port = 5432",
            "port=5432",
            "'5432'",
            '"5432"',
            "max_size = 10737418240",
            "max_size=10737418240",
        ]
        # Allow these in comments but not in actual code
        code_lines = [line for line in content.split("\n") 
                      if line.strip() and not line.strip().startswith("#")]
        code_content = "\n".join(code_lines)

        # It's OK to have these values if they're being read from files,
        # but we check that the script still uses read() to get fragment data
        assert ".read(" in content or ".read_file(" in content or ".read_string(" in content, (
            "Script must read fragment files using ConfigParser.read() or similar methods"
        )

    def test_output_is_parseable_by_configparser(self):
        """The output master.ini must be parseable by a fresh ConfigParser."""
        config = configparser.ConfigParser()
        try:
            config.read(str(MASTER_INI))
        except Exception as e:
            pytest.fail(f"master.ini is not parseable by ConfigParser: {e}")

        assert len(config.sections()) == 4, (
            f"Parsed config should have 4 sections, got {len(config.sections())}"
        )
