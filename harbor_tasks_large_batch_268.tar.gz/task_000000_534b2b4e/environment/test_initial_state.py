# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the config merger fix task.
"""

import os
import subprocess
import pytest
from pathlib import Path


# Base paths
DOCTOOLS_DIR = Path("/home/user/doctools")
FRAGMENTS_DIR = DOCTOOLS_DIR / "fragments"
MERGE_SCRIPT = DOCTOOLS_DIR / "merge_configs.py"
OUTPUT_DIR = DOCTOOLS_DIR / "output"


class TestDirectoryStructure:
    """Test that required directories exist."""

    def test_doctools_directory_exists(self):
        assert DOCTOOLS_DIR.exists(), f"Directory {DOCTOOLS_DIR} does not exist"
        assert DOCTOOLS_DIR.is_dir(), f"{DOCTOOLS_DIR} is not a directory"

    def test_fragments_directory_exists(self):
        assert FRAGMENTS_DIR.exists(), f"Directory {FRAGMENTS_DIR} does not exist"
        assert FRAGMENTS_DIR.is_dir(), f"{FRAGMENTS_DIR} is not a directory"

    def test_doctools_is_writable(self):
        assert os.access(DOCTOOLS_DIR, os.W_OK), f"{DOCTOOLS_DIR} is not writable"

    def test_output_directory_does_not_exist_initially(self):
        # The output directory should not exist initially (script creates it)
        assert not OUTPUT_DIR.exists(), (
            f"Output directory {OUTPUT_DIR} should not exist initially - "
            "the script is supposed to create it"
        )


class TestMergeScript:
    """Test that the merge_configs.py script exists and is valid."""

    def test_merge_script_exists(self):
        assert MERGE_SCRIPT.exists(), f"Script {MERGE_SCRIPT} does not exist"
        assert MERGE_SCRIPT.is_file(), f"{MERGE_SCRIPT} is not a file"

    def test_merge_script_is_readable(self):
        assert os.access(MERGE_SCRIPT, os.R_OK), f"{MERGE_SCRIPT} is not readable"

    def test_merge_script_is_valid_python(self):
        """Verify the script can be parsed as valid Python."""
        result = subprocess.run(
            ["python3", "-m", "py_compile", str(MERGE_SCRIPT)],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"Script {MERGE_SCRIPT} is not valid Python: {result.stderr}"
        )

    def test_merge_script_uses_configparser(self):
        """Verify the script imports and uses configparser."""
        content = MERGE_SCRIPT.read_text()
        assert "import configparser" in content or "from configparser" in content, (
            "Script must use configparser module"
        )
        assert "ConfigParser" in content, (
            "Script must use ConfigParser class"
        )

    def test_merge_script_reads_from_fragments(self):
        """Verify script references fragments directory."""
        content = MERGE_SCRIPT.read_text()
        assert "fragments" in content.lower(), (
            "Script must reference fragments directory"
        )

    def test_merge_script_writes_to_output(self):
        """Verify script references output directory and master.ini."""
        content = MERGE_SCRIPT.read_text()
        assert "output" in content.lower(), "Script must reference output directory"
        assert "master.ini" in content, "Script must reference master.ini"


class TestFragmentFiles:
    """Test that all 4 fragment .ini files exist with expected content."""

    EXPECTED_FRAGMENTS = ["database.ini", "api.ini", "storage.ini", "auth.ini"]

    def test_exactly_four_ini_files_exist(self):
        ini_files = list(FRAGMENTS_DIR.glob("*.ini"))
        assert len(ini_files) == 4, (
            f"Expected exactly 4 .ini files in {FRAGMENTS_DIR}, "
            f"found {len(ini_files)}: {[f.name for f in ini_files]}"
        )

    def test_database_ini_exists(self):
        db_ini = FRAGMENTS_DIR / "database.ini"
        assert db_ini.exists(), f"{db_ini} does not exist"
        assert db_ini.is_file(), f"{db_ini} is not a file"

    def test_api_ini_exists(self):
        api_ini = FRAGMENTS_DIR / "api.ini"
        assert api_ini.exists(), f"{api_ini} does not exist"
        assert api_ini.is_file(), f"{api_ini} is not a file"

    def test_storage_ini_exists(self):
        storage_ini = FRAGMENTS_DIR / "storage.ini"
        assert storage_ini.exists(), f"{storage_ini} does not exist"
        assert storage_ini.is_file(), f"{storage_ini} is not a file"

    def test_auth_ini_exists(self):
        auth_ini = FRAGMENTS_DIR / "auth.ini"
        assert auth_ini.exists(), f"{auth_ini} does not exist"
        assert auth_ini.is_file(), f"{auth_ini} is not a file"

    def test_database_ini_has_database_section(self):
        content = (FRAGMENTS_DIR / "database.ini").read_text()
        assert "[database]" in content, "database.ini must contain [database] section"

    def test_database_ini_has_port_5432(self):
        """The source file should have port = 5432 (the correct value)."""
        content = (FRAGMENTS_DIR / "database.ini").read_text()
        assert "port" in content.lower(), "database.ini must contain port key"
        assert "5432" in content, "database.ini must contain port value 5432"

    def test_api_ini_has_api_section(self):
        content = (FRAGMENTS_DIR / "api.ini").read_text()
        assert "[api]" in content, "api.ini must contain [api] section"

    def test_api_ini_has_endpoint(self):
        content = (FRAGMENTS_DIR / "api.ini").read_text()
        assert "endpoint" in content.lower(), "api.ini must contain endpoint key"
        assert "api.internal.corp" in content, "api.ini must contain the API URL"

    def test_storage_ini_has_storage_section(self):
        content = (FRAGMENTS_DIR / "storage.ini").read_text()
        assert "[storage]" in content, "storage.ini must contain [storage] section"

    def test_storage_ini_has_max_size(self):
        content = (FRAGMENTS_DIR / "storage.ini").read_text()
        assert "max_size" in content.lower(), "storage.ini must contain max_size key"
        assert "10737418240" in content, "storage.ini must contain max_size value 10737418240"

    def test_auth_ini_has_auth_section(self):
        content = (FRAGMENTS_DIR / "auth.ini").read_text()
        assert "[auth]" in content, "auth.ini must contain [auth] section"

    def test_auth_ini_has_client_id(self):
        content = (FRAGMENTS_DIR / "auth.ini").read_text()
        assert "client_id" in content.lower(), "auth.ini must contain client_id key"
        assert "0oa1b2c3d4e5f6g7h8i9" in content, (
            "auth.ini must contain client_id value 0oa1b2c3d4e5f6g7h8i9"
        )


class TestBugConditions:
    """Test that the bug-inducing conditions exist in the fragment files."""

    def test_fragments_have_problematic_content(self):
        """
        Verify that at least some fragments have content that would trigger
        the interpolation bug (% characters in comments or values).
        """
        all_content = ""
        for ini_file in FRAGMENTS_DIR.glob("*.ini"):
            all_content += ini_file.read_text()

        # The bug involves % characters being interpreted by ConfigParser
        # At least one file should have % in it (either in comments or values)
        has_percent = "%" in all_content
        has_crlf = "\r\n" in all_content or "\r" in all_content

        # We expect at least one of these conditions to be true for the bug to manifest
        assert has_percent or has_crlf, (
            "Expected fragment files to contain % characters or CRLF line endings "
            "that would trigger the interpolation/parsing bug"
        )


class TestPythonEnvironment:
    """Test that required Python environment is available."""

    def test_python3_available(self):
        result = subprocess.run(
            ["python3", "--version"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "python3 is not available"

    def test_python3_version_adequate(self):
        """Verify Python 3.10+ is available."""
        result = subprocess.run(
            ["python3", "-c", "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "Could not determine Python version"
        version = result.stdout.strip()
        major, minor = map(int, version.split('.'))
        assert major >= 3 and minor >= 10, (
            f"Python 3.10+ required, found {version}"
        )

    def test_configparser_available(self):
        """Verify configparser module is available (stdlib)."""
        result = subprocess.run(
            ["python3", "-c", "import configparser; print('ok')"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "configparser module is not available"
        assert "ok" in result.stdout, "configparser module import failed"


class TestScriptCanRun:
    """Test that the script can be executed (even if output is buggy)."""

    def test_script_runs_without_syntax_error(self):
        """
        Verify the script can at least start running.
        We don't check the output correctness here - that's the bug to fix.
        """
        result = subprocess.run(
            ["python3", "-c", f"import sys; sys.path.insert(0, '{DOCTOOLS_DIR}'); exec(open('{MERGE_SCRIPT}').read().replace('if __name__', 'if False and __name__'))"],
            capture_output=True,
            text=True,
            cwd=str(DOCTOOLS_DIR)
        )
        # Just checking it can be loaded, not executed
        assert result.returncode == 0 or "No such file" not in result.stderr, (
            f"Script has issues loading: {result.stderr}"
        )
