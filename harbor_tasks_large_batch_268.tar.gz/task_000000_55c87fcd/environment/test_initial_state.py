# test_initial_state.py
"""
Tests to validate the initial state of the filesystem before the student
performs the webhook validator debugging task.
"""

import os
import json
import pytest


HOME = "/home/user"
VALIDATOR_DIR = os.path.join(HOME, "validator")
SAMPLES_DIR = os.path.join(VALIDATOR_DIR, "samples")


class TestValidatorDirectoryStructure:
    """Test that the validator directory and its structure exist."""

    def test_validator_directory_exists(self):
        """The /home/user/validator directory must exist."""
        assert os.path.isdir(VALIDATOR_DIR), (
            f"Directory {VALIDATOR_DIR} does not exist. "
            "The validator directory must be present for this task."
        )

    def test_samples_directory_exists(self):
        """The /home/user/validator/samples directory must exist."""
        assert os.path.isdir(SAMPLES_DIR), (
            f"Directory {SAMPLES_DIR} does not exist. "
            "The samples directory must be present for this task."
        )


class TestCheckPyScript:
    """Test that check.py exists and has expected characteristics."""

    def test_check_py_exists(self):
        """The check.py script must exist."""
        check_py_path = os.path.join(VALIDATOR_DIR, "check.py")
        assert os.path.isfile(check_py_path), (
            f"File {check_py_path} does not exist. "
            "The webhook validator script must be present."
        )

    def test_check_py_is_readable(self):
        """The check.py script must be readable."""
        check_py_path = os.path.join(VALIDATOR_DIR, "check.py")
        assert os.access(check_py_path, os.R_OK), (
            f"File {check_py_path} is not readable."
        )

    def test_check_py_is_python_script(self):
        """The check.py should be a Python script (contains Python code)."""
        check_py_path = os.path.join(VALIDATOR_DIR, "check.py")
        with open(check_py_path, "r") as f:
            content = f.read()
        # Check for common Python patterns
        assert "import" in content or "def " in content, (
            f"File {check_py_path} does not appear to be a Python script."
        )

    def test_check_py_has_reasonable_size(self):
        """The check.py should be approximately 150 lines (non-trivial script)."""
        check_py_path = os.path.join(VALIDATOR_DIR, "check.py")
        with open(check_py_path, "r") as f:
            lines = f.readlines()
        # Allow some flexibility: between 50 and 300 lines
        assert 50 <= len(lines) <= 300, (
            f"File {check_py_path} has {len(lines)} lines, expected ~150 lines. "
            "The script should be a substantial webhook validator."
        )


class TestSecretsEnv:
    """Test that secrets.env exists with expected structure."""

    def test_secrets_env_exists(self):
        """The secrets.env file must exist."""
        secrets_path = os.path.join(VALIDATOR_DIR, "secrets.env")
        assert os.path.isfile(secrets_path), (
            f"File {secrets_path} does not exist. "
            "The secrets file must be present for this task."
        )

    def test_secrets_env_contains_stripe_secret(self):
        """secrets.env must contain STRIPE_SECRET."""
        secrets_path = os.path.join(VALIDATOR_DIR, "secrets.env")
        with open(secrets_path, "r") as f:
            content = f.read()
        assert "STRIPE_SECRET=" in content, (
            f"File {secrets_path} does not contain STRIPE_SECRET. "
            "The Stripe webhook secret must be configured."
        )

    def test_secrets_env_contains_github_secret(self):
        """secrets.env must contain GITHUB_SECRET."""
        secrets_path = os.path.join(VALIDATOR_DIR, "secrets.env")
        with open(secrets_path, "r") as f:
            content = f.read()
        assert "GITHUB_SECRET=" in content, (
            f"File {secrets_path} does not contain GITHUB_SECRET. "
            "The GitHub webhook secret must be configured."
        )

    def test_secrets_env_contains_internal_public_key(self):
        """secrets.env must contain INTERNAL_PUBLIC_KEY."""
        secrets_path = os.path.join(VALIDATOR_DIR, "secrets.env")
        with open(secrets_path, "r") as f:
            content = f.read()
        assert "INTERNAL_PUBLIC_KEY=" in content, (
            f"File {secrets_path} does not contain INTERNAL_PUBLIC_KEY. "
            "The internal service public key must be configured."
        )


class TestSampleFiles:
    """Test that all required sample files exist with proper structure."""

    EXPECTED_SAMPLES = [
        "stripe_valid.json",
        "stripe_invalid.json",
        "github_valid.json",
        "github_invalid.json",
        "internal_valid.json",
        "internal_invalid.json",
    ]

    @pytest.mark.parametrize("sample_file", EXPECTED_SAMPLES)
    def test_sample_file_exists(self, sample_file):
        """Each sample file must exist."""
        sample_path = os.path.join(SAMPLES_DIR, sample_file)
        assert os.path.isfile(sample_path), (
            f"Sample file {sample_path} does not exist. "
            f"The {sample_file} sample must be present for testing."
        )

    @pytest.mark.parametrize("sample_file", EXPECTED_SAMPLES)
    def test_sample_file_is_valid_json(self, sample_file):
        """Each sample file must be valid JSON."""
        sample_path = os.path.join(SAMPLES_DIR, sample_file)
        with open(sample_path, "r") as f:
            try:
                data = json.load(f)
            except json.JSONDecodeError as e:
                pytest.fail(
                    f"Sample file {sample_path} is not valid JSON: {e}"
                )

    @pytest.mark.parametrize("sample_file", EXPECTED_SAMPLES)
    def test_sample_file_has_headers(self, sample_file):
        """Each sample file must have a 'headers' field."""
        sample_path = os.path.join(SAMPLES_DIR, sample_file)
        with open(sample_path, "r") as f:
            data = json.load(f)
        assert "headers" in data, (
            f"Sample file {sample_path} does not have 'headers' field. "
            "Each sample must include service-specific signature headers."
        )

    @pytest.mark.parametrize("sample_file", EXPECTED_SAMPLES)
    def test_sample_file_has_body(self, sample_file):
        """Each sample file must have a 'body' field."""
        sample_path = os.path.join(SAMPLES_DIR, sample_file)
        with open(sample_path, "r") as f:
            data = json.load(f)
        assert "body" in data, (
            f"Sample file {sample_path} does not have 'body' field. "
            "Each sample must include the raw payload body."
        )

    @pytest.mark.parametrize("sample_file", EXPECTED_SAMPLES)
    def test_sample_file_has_expected(self, sample_file):
        """Each sample file must have an 'expected' field (boolean)."""
        sample_path = os.path.join(SAMPLES_DIR, sample_file)
        with open(sample_path, "r") as f:
            data = json.load(f)
        assert "expected" in data, (
            f"Sample file {sample_path} does not have 'expected' field. "
            "Each sample must indicate whether it should validate or not."
        )
        assert isinstance(data["expected"], bool), (
            f"Sample file {sample_path} 'expected' field is not a boolean."
        )


class TestSampleFileExpectedValues:
    """Test that sample files have correct expected values."""

    def test_stripe_valid_expects_true(self):
        """stripe_valid.json should expect validation to succeed."""
        sample_path = os.path.join(SAMPLES_DIR, "stripe_valid.json")
        with open(sample_path, "r") as f:
            data = json.load(f)
        assert data["expected"] is True, (
            f"stripe_valid.json should have expected=true, got {data['expected']}"
        )

    def test_stripe_invalid_expects_false(self):
        """stripe_invalid.json should expect validation to fail."""
        sample_path = os.path.join(SAMPLES_DIR, "stripe_invalid.json")
        with open(sample_path, "r") as f:
            data = json.load(f)
        assert data["expected"] is False, (
            f"stripe_invalid.json should have expected=false, got {data['expected']}"
        )

    def test_github_valid_expects_true(self):
        """github_valid.json should expect validation to succeed."""
        sample_path = os.path.join(SAMPLES_DIR, "github_valid.json")
        with open(sample_path, "r") as f:
            data = json.load(f)
        assert data["expected"] is True, (
            f"github_valid.json should have expected=true, got {data['expected']}"
        )

    def test_github_invalid_expects_false(self):
        """github_invalid.json should expect validation to fail."""
        sample_path = os.path.join(SAMPLES_DIR, "github_invalid.json")
        with open(sample_path, "r") as f:
            data = json.load(f)
        assert data["expected"] is False, (
            f"github_invalid.json should have expected=false, got {data['expected']}"
        )

    def test_internal_valid_expects_true(self):
        """internal_valid.json should expect validation to succeed."""
        sample_path = os.path.join(SAMPLES_DIR, "internal_valid.json")
        with open(sample_path, "r") as f:
            data = json.load(f)
        assert data["expected"] is True, (
            f"internal_valid.json should have expected=true, got {data['expected']}"
        )

    def test_internal_invalid_expects_false(self):
        """internal_invalid.json should expect validation to fail."""
        sample_path = os.path.join(SAMPLES_DIR, "internal_invalid.json")
        with open(sample_path, "r") as f:
            data = json.load(f)
        assert data["expected"] is False, (
            f"internal_invalid.json should have expected=false, got {data['expected']}"
        )


class TestServiceSpecificHeaders:
    """Test that sample files have appropriate service-specific headers."""

    def test_stripe_samples_have_stripe_signature(self):
        """Stripe samples should have Stripe-Signature header."""
        for name in ["stripe_valid.json", "stripe_invalid.json"]:
            sample_path = os.path.join(SAMPLES_DIR, name)
            with open(sample_path, "r") as f:
                data = json.load(f)
            headers = data.get("headers", {})
            # Check for Stripe-Signature (case variations possible)
            header_keys_lower = {k.lower(): k for k in headers.keys()}
            assert "stripe-signature" in header_keys_lower, (
                f"{name} should have 'Stripe-Signature' header for Stripe webhook validation."
            )

    def test_github_samples_have_github_signature(self):
        """GitHub samples should have X-Hub-Signature header."""
        for name in ["github_valid.json", "github_invalid.json"]:
            sample_path = os.path.join(SAMPLES_DIR, name)
            with open(sample_path, "r") as f:
                data = json.load(f)
            headers = data.get("headers", {})
            header_keys_lower = {k.lower(): k for k in headers.keys()}
            assert "x-hub-signature" in header_keys_lower, (
                f"{name} should have 'X-Hub-Signature' header for GitHub webhook validation."
            )

    def test_internal_samples_have_signature_header(self):
        """Internal samples should have some signature header."""
        for name in ["internal_valid.json", "internal_invalid.json"]:
            sample_path = os.path.join(SAMPLES_DIR, name)
            with open(sample_path, "r") as f:
                data = json.load(f)
            headers = data.get("headers", {})
            # Internal service could use various header names
            header_keys_lower = [k.lower() for k in headers.keys()]
            has_sig_header = any(
                "signature" in k or "sig" in k or "x-signature" in k 
                for k in header_keys_lower
            )
            assert has_sig_header or len(headers) > 0, (
                f"{name} should have signature-related headers for internal service validation."
            )


class TestGitHubSampleHasEncodingHint:
    """Test that GitHub sample has the body_encoding hint mentioned in the task."""

    def test_github_valid_has_body_encoding_hint(self):
        """github_valid.json should have body_encoding field (mentioned in task as ignored)."""
        sample_path = os.path.join(SAMPLES_DIR, "github_valid.json")
        with open(sample_path, "r") as f:
            data = json.load(f)
        # The task mentions there's a body_encoding hint that the code ignores
        assert "body_encoding" in data, (
            f"github_valid.json should have 'body_encoding' field as mentioned in the task. "
            "This hint field is supposed to be ignored by the buggy code."
        )


class TestValidatorDirectoryWritable:
    """Test that the validator directory is writable for fixes."""

    def test_validator_directory_is_writable(self):
        """The validator directory must be writable to apply fixes."""
        assert os.access(VALIDATOR_DIR, os.W_OK), (
            f"Directory {VALIDATOR_DIR} is not writable. "
            "The student needs write access to fix the bugs."
        )

    def test_check_py_is_writable(self):
        """The check.py file must be writable to apply fixes."""
        check_py_path = os.path.join(VALIDATOR_DIR, "check.py")
        assert os.access(check_py_path, os.W_OK), (
            f"File {check_py_path} is not writable. "
            "The student needs write access to fix the bugs."
        )
