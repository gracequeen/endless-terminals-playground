I've got a webhook validator at /home/user/validator/check.py that's supposed to verify incoming payloads from three different services — each one signs their JSON differently. Stripe uses HMAC-SHA256 with a timestamp prefix, GitHub does HMAC-SHA1 on the raw body, and our internal service uses Ed25519 on a canonical JSON form.

Thing is, it's passing payloads it should reject and rejecting ones it should accept. I've been testing with sample payloads in /home/user/validator/samples/ and running `python check.py samples/stripe_valid.json` etc. The stripe ones seem mostly okay but github_valid.json fails when it shouldn't, and internal_invalid.json passes when it definitely shouldn't (I manually corrupted that signature).

Secrets are in /home/user/validator/secrets.env. Pretty sure those are right — I copy-pasted them from the service dashboards myself. Might be an encoding thing? Or maybe the canonicalization? idk, I've been staring at this for hours.
