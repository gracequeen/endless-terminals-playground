# test_final_state.py
"""
Tests to validate the final state after the student has fixed the webhook validator.
The validator must correctly validate all six sample payloads according to their expected results.
"""

import os
import subprocess
import re
import pytest


HOME = "/home/user"
VALIDATOR_DIR = os.path.join(HOME, "validator")
SAMPLES_DIR = os.path.join(VALIDATOR_DIR, "samples")
CHECK_PY = os.path.join(VALIDATOR_DIR, "check.py")
SECRETS_ENV = os.path.join(VALIDATOR_DIR, "secrets.env")


class TestValidatorCorrectness:
    """Test that the validator correctly validates all sample payloads."""

    def test_stripe_valid_returns_valid(self):
        """stripe_valid.json should be validated as VALID with exit code 0."""
        sample_path = os.path.join(SAMPLES_DIR, "stripe_valid.json")
        result = subprocess.run(
            ["python", CHECK_PY, sample_path],
            capture_output=True,
            text=True,
            cwd=VALIDATOR_DIR
        )
        assert result.returncode == 0, (
            f"stripe_valid.json should exit with code 0, got {result.returncode}.\n"
            f"stdout: {result.stdout}\nstderr: {result.stderr}"
        )
        assert "VALID" in result.stdout.upper(), (
            f"stripe_valid.json should print 'VALID', got stdout: {result.stdout}"
        )

    def test_stripe_invalid_returns_invalid(self):
        """stripe_invalid.json should be validated as INVALID with exit code 1."""
        sample_path = os.path.join(SAMPLES_DIR, "stripe_invalid.json")
        result = subprocess.run(
            ["python", CHECK_PY, sample_path],
            capture_output=True,
            text=True,
            cwd=VALIDATOR_DIR
        )
        assert result.returncode == 1, (
            f"stripe_invalid.json should exit with code 1, got {result.returncode}.\n"
            f"stdout: {result.stdout}\nstderr: {result.stderr}"
        )
        assert "INVALID" in result.stdout.upper(), (
            f"stripe_invalid.json should print 'INVALID', got stdout: {result.stdout}"
        )

    def test_github_valid_returns_valid(self):
        """github_valid.json should be validated as VALID with exit code 0."""
        sample_path = os.path.join(SAMPLES_DIR, "github_valid.json")
        result = subprocess.run(
            ["python", CHECK_PY, sample_path],
            capture_output=True,
            text=True,
            cwd=VALIDATOR_DIR
        )
        assert result.returncode == 0, (
            f"github_valid.json should exit with code 0, got {result.returncode}.\n"
            f"stdout: {result.stdout}\nstderr: {result.stderr}"
        )
        assert "VALID" in result.stdout.upper(), (
            f"github_valid.json should print 'VALID', got stdout: {result.stdout}"
        )

    def test_github_invalid_returns_invalid(self):
        """github_invalid.json should be validated as INVALID with exit code 1."""
        sample_path = os.path.join(SAMPLES_DIR, "github_invalid.json")
        result = subprocess.run(
            ["python", CHECK_PY, sample_path],
            capture_output=True,
            text=True,
            cwd=VALIDATOR_DIR
        )
        assert result.returncode == 1, (
            f"github_invalid.json should exit with code 1, got {result.returncode}.\n"
            f"stdout: {result.stdout}\nstderr: {result.stderr}"
        )
        assert "INVALID" in result.stdout.upper(), (
            f"github_invalid.json should print 'INVALID', got stdout: {result.stdout}"
        )

    def test_internal_valid_returns_valid(self):
        """internal_valid.json should be validated as VALID with exit code 0."""
        sample_path = os.path.join(SAMPLES_DIR, "internal_valid.json")
        result = subprocess.run(
            ["python", CHECK_PY, sample_path],
            capture_output=True,
            text=True,
            cwd=VALIDATOR_DIR
        )
        assert result.returncode == 0, (
            f"internal_valid.json should exit with code 0, got {result.returncode}.\n"
            f"stdout: {result.stdout}\nstderr: {result.stderr}"
        )
        assert "VALID" in result.stdout.upper(), (
            f"internal_valid.json should print 'VALID', got stdout: {result.stdout}"
        )

    def test_internal_invalid_returns_invalid(self):
        """internal_invalid.json should be validated as INVALID with exit code 1."""
        sample_path = os.path.join(SAMPLES_DIR, "internal_invalid.json")
        result = subprocess.run(
            ["python", CHECK_PY, sample_path],
            capture_output=True,
            text=True,
            cwd=VALIDATOR_DIR
        )
        assert result.returncode == 1, (
            f"internal_invalid.json should exit with code 1, got {result.returncode}.\n"
            f"stdout: {result.stdout}\nstderr: {result.stderr}"
        )
        assert "INVALID" in result.stdout.upper(), (
            f"internal_invalid.json should print 'INVALID', got stdout: {result.stdout}"
        )


class TestInvariantsPreserved:
    """Test that invariants are preserved (secrets.env unchanged, samples unchanged)."""

    def test_secrets_env_unchanged(self):
        """secrets.env should remain unchanged with the original secrets."""
        with open(SECRETS_ENV, "r") as f:
            content = f.read()

        # Check for expected secret values
        assert "STRIPE_SECRET=whsec_test1234567890abcdef" in content, (
            "secrets.env should contain the original STRIPE_SECRET value."
        )
        assert "GITHUB_SECRET=gh_secret_abc123" in content, (
            "secrets.env should contain the original GITHUB_SECRET value."
        )
        assert "INTERNAL_PUBLIC_KEY=MCowBQYDK2VwAyEAZjK4MXlqJ8s9kGmD3vWP7yN1hRtBxYcEfQA2LkS5Tm0=" in content, (
            "secrets.env should contain the original INTERNAL_PUBLIC_KEY value."
        )

    def test_check_py_still_exists(self):
        """check.py must still exist."""
        assert os.path.isfile(CHECK_PY), (
            f"File {CHECK_PY} no longer exists. The script must be preserved."
        )

    def test_samples_directory_still_exists(self):
        """samples directory must still exist."""
        assert os.path.isdir(SAMPLES_DIR), (
            f"Directory {SAMPLES_DIR} no longer exists."
        )


class TestAntiShortcutGuards:
    """Test that the solution doesn't use shortcuts/hardcoding."""

    def test_no_hardcoded_filename_checks(self):
        """The script must not hardcode expected results per filename."""
        with open(CHECK_PY, "r") as f:
            content = f.read()

        # Use grep-like check for forbidden patterns
        forbidden_patterns = [
            r'stripe_valid',
            r'github_valid',
            r'internal_valid',
            r'stripe_invalid',
            r'github_invalid',
            r'internal_invalid',
        ]

        for pattern in forbidden_patterns:
            # Check if the pattern appears in a suspicious context (not in comments)
            lines = content.split('\n')
            for line_num, line in enumerate(lines, 1):
                # Skip comment lines
                stripped = line.strip()
                if stripped.startswith('#'):
                    continue
                # Check for pattern in non-comment code
                if re.search(pattern, line, re.IGNORECASE):
                    # Allow it if it's in a string that's part of error message or documentation
                    # But fail if it looks like a conditional check
                    if re.search(rf'if.*["\'].*{pattern}', line, re.IGNORECASE):
                        pytest.fail(
                            f"Line {line_num} appears to hardcode filename '{pattern}': {line}"
                        )
                    if re.search(rf'{pattern}.*in\s+', line, re.IGNORECASE):
                        pytest.fail(
                            f"Line {line_num} appears to check for filename '{pattern}': {line}"
                        )

    def test_no_forced_return_true(self):
        """The script must not have forced 'return True' shortcuts."""
        with open(CHECK_PY, "r") as f:
            content = f.read()

        # Look for suspicious patterns like "return True  # hack" or similar
        lines = content.split('\n')
        for line_num, line in enumerate(lines, 1):
            stripped = line.strip()
            # Skip pure comment lines
            if stripped.startswith('#'):
                continue
            # Check for return True with suspicious comment
            if re.search(r'return\s+True\s*#.*(?:hack|force|always|skip)', line, re.IGNORECASE):
                pytest.fail(
                    f"Line {line_num} has suspicious forced return: {line}"
                )

    def test_script_uses_hmac_module(self):
        """The script must use the hmac module for HMAC verification."""
        with open(CHECK_PY, "r") as f:
            content = f.read()

        assert "import hmac" in content or "from hmac" in content, (
            "The script must import and use the hmac module for HMAC verification."
        )
        assert "hmac." in content or "compare_digest" in content, (
            "The script must actually use hmac functions for verification."
        )

    def test_script_uses_hashlib(self):
        """The script must use hashlib for hashing."""
        with open(CHECK_PY, "r") as f:
            content = f.read()

        assert "import hashlib" in content or "from hashlib" in content, (
            "The script must import hashlib for cryptographic hashing."
        )

    def test_script_has_ed25519_verification(self):
        """The script must perform Ed25519 verification for internal service."""
        with open(CHECK_PY, "r") as f:
            content = f.read()

        # Check for Ed25519-related code
        has_ed25519 = (
            "Ed25519" in content or
            "ed25519" in content.lower() or
            "verify" in content.lower()
        )
        assert has_ed25519, (
            "The script must include Ed25519 verification logic for the internal service."
        )

    def test_script_has_three_service_handlers(self):
        """The script must handle all three services (Stripe, GitHub, Internal)."""
        with open(CHECK_PY, "r") as f:
            content = f.read().lower()

        assert "stripe" in content, (
            "The script must handle Stripe webhook validation."
        )
        assert "github" in content, (
            "The script must handle GitHub webhook validation."
        )
        assert "internal" in content, (
            "The script must handle internal service webhook validation."
        )


class TestScriptFunctionality:
    """Test that the script runs without crashing on various inputs."""

    def test_script_handles_missing_file_gracefully(self):
        """The script should handle missing files gracefully (not crash with traceback)."""
        result = subprocess.run(
            ["python", CHECK_PY, "/nonexistent/file.json"],
            capture_output=True,
            text=True,
            cwd=VALIDATOR_DIR
        )
        # Should exit non-zero but not with a Python traceback as the only output
        # (some error message is expected)
        assert result.returncode != 0, (
            "Script should exit non-zero for missing file."
        )

    def test_script_is_valid_python(self):
        """The script must be valid Python that can be parsed."""
        result = subprocess.run(
            ["python", "-m", "py_compile", CHECK_PY],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"check.py has Python syntax errors:\n{result.stderr}"
        )


class TestAllSamplesPassExpectedResults:
    """Comprehensive test that all samples match their expected results."""

    SAMPLES = [
        ("stripe_valid.json", 0, True),
        ("stripe_invalid.json", 1, False),
        ("github_valid.json", 0, True),
        ("github_invalid.json", 1, False),
        ("internal_valid.json", 0, True),
        ("internal_invalid.json", 1, False),
    ]

    @pytest.mark.parametrize("sample_name,expected_exit,expected_valid", SAMPLES)
    def test_sample_validation(self, sample_name, expected_exit, expected_valid):
        """Each sample should validate according to its expected result."""
        sample_path = os.path.join(SAMPLES_DIR, sample_name)
        result = subprocess.run(
            ["python", CHECK_PY, sample_path],
            capture_output=True,
            text=True,
            cwd=VALIDATOR_DIR
        )

        validity_str = "VALID" if expected_valid else "INVALID"

        assert result.returncode == expected_exit, (
            f"{sample_name}: Expected exit code {expected_exit}, got {result.returncode}.\n"
            f"stdout: {result.stdout}\nstderr: {result.stderr}"
        )

        if expected_valid:
            # Should say VALID but not INVALID
            stdout_upper = result.stdout.upper()
            # Check that it says VALID and doesn't say INVALID (or says VALID before INVALID)
            assert "VALID" in stdout_upper, (
                f"{sample_name}: Expected output to contain 'VALID', got: {result.stdout}"
            )
            # Make sure it's not saying INVALID
            if "INVALID" in stdout_upper:
                # INVALID contains VALID, so we need to be careful
                # Check if it only says INVALID (which contains VALID)
                valid_pos = stdout_upper.find("VALID")
                invalid_pos = stdout_upper.find("INVALID")
                if invalid_pos != -1 and (valid_pos == -1 or invalid_pos <= valid_pos):
                    pytest.fail(
                        f"{sample_name}: Expected 'VALID' but got 'INVALID': {result.stdout}"
                    )
        else:
            assert "INVALID" in result.stdout.upper(), (
                f"{sample_name}: Expected output to contain 'INVALID', got: {result.stdout}"
            )
