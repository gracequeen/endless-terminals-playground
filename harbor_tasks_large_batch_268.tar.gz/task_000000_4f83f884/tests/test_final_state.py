# test_final_state.py
"""
Tests to validate the final state of the operating system after the student
has created a Python venv at /home/user/audit_env with pip upgraded and
requirements.txt in place.
"""

import os
import subprocess
import pytest


class TestVenvStructure:
    """Validate the venv directory structure exists and is correct."""

    def test_audit_env_directory_exists(self):
        """Verify /home/user/audit_env directory exists."""
        assert os.path.isdir("/home/user/audit_env"), (
            "/home/user/audit_env directory does not exist. "
            "The venv must be created at this location."
        )

    def test_venv_bin_directory_exists(self):
        """Verify /home/user/audit_env/bin directory exists."""
        assert os.path.isdir("/home/user/audit_env/bin"), (
            "/home/user/audit_env/bin directory does not exist. "
            "This is required for a valid Python venv."
        )

    def test_venv_python_exists_and_executable(self):
        """Verify /home/user/audit_env/bin/python exists and is executable."""
        python_path = "/home/user/audit_env/bin/python"
        assert os.path.exists(python_path), (
            f"{python_path} does not exist. "
            "The venv must have a Python executable."
        )
        assert os.access(python_path, os.X_OK), (
            f"{python_path} is not executable. "
            "The Python executable must have execute permissions."
        )

    def test_venv_pip_exists_and_executable(self):
        """Verify /home/user/audit_env/bin/pip exists and is executable."""
        pip_path = "/home/user/audit_env/bin/pip"
        assert os.path.exists(pip_path), (
            f"{pip_path} does not exist. "
            "The venv must have a pip executable."
        )
        assert os.access(pip_path, os.X_OK), (
            f"{pip_path} is not executable. "
            "The pip executable must have execute permissions."
        )


class TestVenvFunctionality:
    """Validate the venv is functional."""

    def test_venv_python_reports_correct_prefix(self):
        """Verify the venv Python reports audit_env in sys.prefix."""
        result = subprocess.run(
            ["/home/user/audit_env/bin/python", "-c", "import sys; print(sys.prefix)"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "Failed to run Python from the venv. "
            f"Error: {result.stderr}"
        )
        assert "audit_env" in result.stdout, (
            f"The venv Python's sys.prefix does not contain 'audit_env'. "
            f"Got: {result.stdout.strip()}. "
            "The venv may not be properly configured."
        )

    def test_venv_pip_version_command_succeeds(self):
        """Verify pip --version succeeds in the venv."""
        result = subprocess.run(
            ["/home/user/audit_env/bin/pip", "--version"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "'/home/user/audit_env/bin/pip --version' failed. "
            f"Error: {result.stderr}"
        )

    def test_venv_pip_upgraded_to_23_or_higher(self):
        """Verify pip in the venv is version 23.0 or higher."""
        result = subprocess.run(
            ["/home/user/audit_env/bin/pip", "--version"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "Failed to get pip version from the venv. "
            f"Error: {result.stderr}"
        )

        # Parse version from output like "pip 23.3.1 from /path/to/pip (python 3.x)"
        output = result.stdout.strip()
        parts = output.split()
        assert len(parts) >= 2 and parts[0] == "pip", (
            f"Unexpected pip version output format: {output}"
        )

        version_str = parts[1]
        version_parts = version_str.split(".")
        major_version = int(version_parts[0])

        assert major_version >= 23, (
            f"pip version in venv is {version_str}, but >= 23.0 is required. "
            "pip must be upgraded inside the venv."
        )


class TestRequirementsFile:
    """Validate the requirements.txt file."""

    def test_requirements_file_exists(self):
        """Verify /home/user/audit_env/requirements.txt exists."""
        req_path = "/home/user/audit_env/requirements.txt"
        assert os.path.isfile(req_path), (
            f"{req_path} does not exist. "
            "A requirements.txt file must be created in the venv directory."
        )

    def test_requirements_contains_pandas(self):
        """Verify requirements.txt contains pandas."""
        result = subprocess.run(
            ["grep", "-qE", "^pandas$", "/home/user/audit_env/requirements.txt"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "requirements.txt does not contain 'pandas' on its own line. "
            "The file must list pandas as a required package."
        )

    def test_requirements_contains_openpyxl(self):
        """Verify requirements.txt contains openpyxl."""
        result = subprocess.run(
            ["grep", "-qE", "^openpyxl$", "/home/user/audit_env/requirements.txt"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "requirements.txt does not contain 'openpyxl' on its own line. "
            "The file must list openpyxl as a required package."
        )

    def test_requirements_has_exactly_two_lines(self):
        """Verify requirements.txt has exactly 2 non-empty lines."""
        req_path = "/home/user/audit_env/requirements.txt"
        with open(req_path, "r") as f:
            lines = [line.strip() for line in f if line.strip()]

        assert len(lines) == 2, (
            f"requirements.txt should have exactly 2 non-empty lines (pandas and openpyxl), "
            f"but found {len(lines)} lines: {lines}"
        )


class TestPackagesNotInstalled:
    """Validate that pandas and openpyxl are NOT installed in the venv."""

    def test_pandas_not_installed(self):
        """Verify pandas is not installed in the venv."""
        result = subprocess.run(
            ["/home/user/audit_env/bin/pip", "show", "pandas"],
            capture_output=True,
            text=True
        )
        assert result.returncode != 0, (
            "pandas is installed in the venv, but it should NOT be installed. "
            "Only the requirements.txt file should be in place, not the actual packages."
        )

    def test_openpyxl_not_installed(self):
        """Verify openpyxl is not installed in the venv."""
        result = subprocess.run(
            ["/home/user/audit_env/bin/pip", "show", "openpyxl"],
            capture_output=True,
            text=True
        )
        assert result.returncode != 0, (
            "openpyxl is installed in the venv, but it should NOT be installed. "
            "Only the requirements.txt file should be in place, not the actual packages."
        )

    def test_only_baseline_packages_installed(self):
        """Verify only baseline packages (pip, setuptools, wheel) are installed."""
        result = subprocess.run(
            ["/home/user/audit_env/bin/pip", "list", "--format=freeze"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "Failed to list packages in the venv. "
            f"Error: {result.stderr}"
        )

        # Parse installed packages
        installed = set()
        for line in result.stdout.strip().split("\n"):
            if line and "==" in line:
                pkg_name = line.split("==")[0].lower()
                installed.add(pkg_name)

        # Allowed baseline packages
        allowed = {"pip", "setuptools", "wheel"}

        # Check for unexpected packages
        unexpected = installed - allowed
        assert not unexpected, (
            f"Unexpected packages installed in venv: {unexpected}. "
            "Only pip, setuptools, and wheel should be present."
        )


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
