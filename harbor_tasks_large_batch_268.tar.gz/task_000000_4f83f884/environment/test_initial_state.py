# test_initial_state.py
"""
Tests to validate the initial state of the operating system before the student
creates a Python venv at /home/user/audit_env.
"""

import os
import subprocess
import pytest


class TestInitialState:
    """Validate the OS state before the task is performed."""

    def test_home_user_exists(self):
        """Verify /home/user directory exists."""
        assert os.path.isdir("/home/user"), (
            "/home/user directory does not exist. "
            "The home directory must exist before creating the venv."
        )

    def test_home_user_is_writable(self):
        """Verify /home/user directory is writable."""
        assert os.access("/home/user", os.W_OK), (
            "/home/user directory is not writable. "
            "Write permissions are required to create the venv."
        )

    def test_audit_env_does_not_exist(self):
        """Verify /home/user/audit_env does not exist yet."""
        assert not os.path.exists("/home/user/audit_env"), (
            "/home/user/audit_env already exists. "
            "The venv directory should not exist before the task is performed."
        )

    def test_python3_available(self):
        """Verify python3 is available in PATH."""
        result = subprocess.run(
            ["which", "python3"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "python3 is not available in PATH. "
            "Python 3 must be installed and accessible as 'python3'."
        )

    def test_python3_version_310_or_higher(self):
        """Verify Python version is 3.10 or higher."""
        result = subprocess.run(
            ["python3", "--version"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "Failed to get Python version."

        # Parse version from output like "Python 3.10.12"
        version_output = result.stdout.strip()
        version_str = version_output.split()[1]
        version_parts = version_str.split(".")
        major = int(version_parts[0])
        minor = int(version_parts[1])

        assert major == 3 and minor >= 10, (
            f"Python version is {version_str}, but 3.10+ is required. "
            "Please install Python 3.10 or higher."
        )

    def test_venv_module_available(self):
        """Verify the venv module is installed and available."""
        result = subprocess.run(
            ["python3", "-c", "import venv"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "Python venv module is not available. "
            "The venv module must be installed (e.g., python3-venv package on Debian/Ubuntu)."
        )

    def test_pip_available_system_wide(self):
        """Verify pip is available system-wide."""
        # Try pip3 first, then pip
        result = subprocess.run(
            ["which", "pip3"],
            capture_output=True,
            text=True
        )
        if result.returncode != 0:
            result = subprocess.run(
                ["which", "pip"],
                capture_output=True,
                text=True
            )

        assert result.returncode == 0, (
            "pip is not available system-wide. "
            "pip must be installed and accessible as 'pip' or 'pip3'."
        )

    def test_pip_functional(self):
        """Verify pip is functional and can show version."""
        # Try pip3 first, then pip
        result = subprocess.run(
            ["pip3", "--version"],
            capture_output=True,
            text=True
        )
        if result.returncode != 0:
            result = subprocess.run(
                ["pip", "--version"],
                capture_output=True,
                text=True
            )

        assert result.returncode == 0, (
            "pip is not functional. "
            "'pip --version' or 'pip3 --version' must succeed."
        )
        assert "pip" in result.stdout.lower(), (
            "pip version output is unexpected. "
            f"Got: {result.stdout}"
        )


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
