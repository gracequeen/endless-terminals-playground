# test_final_state.py
"""
Tests to validate the final state of the system after the student has completed the task.
This verifies that:
1. newuser can now use pip successfully (immediate fix)
2. The create_user.sh script no longer contains the broken mirror config (root cause fix)
3. Required invariants are maintained
"""

import os
import pwd
import subprocess
import pytest


class TestNewuserPipWorks:
    """Verify that newuser can now use pip successfully."""

    def test_newuser_pip_dry_run_succeeds(self):
        """pip install --dry-run numpy should succeed for newuser."""
        # Run pip as newuser to verify it works
        result = subprocess.run(
            ['su', '-', 'newuser', '-c', 'pip install --dry-run numpy'],
            capture_output=True,
            text=True,
            timeout=60
        )

        assert result.returncode == 0, (
            f"pip install --dry-run numpy failed for newuser.\n"
            f"Exit code: {result.returncode}\n"
            f"stdout: {result.stdout}\n"
            f"stderr: {result.stderr}\n"
            "The pip configuration for newuser is still broken."
        )

    def test_newuser_pip_uses_pypi_org(self):
        """pip should be using pypi.org (not the broken internal mirror)."""
        result = subprocess.run(
            ['su', '-', 'newuser', '-c', 'pip install --dry-run -v numpy 2>&1'],
            capture_output=True,
            text=True,
            shell=False,
            timeout=60
        )

        # The output should NOT reference the broken internal mirror
        combined_output = result.stdout + result.stderr
        assert 'pypi.internal.corp.local' not in combined_output, (
            "pip is still trying to use pypi.internal.corp.local.\n"
            f"Output: {combined_output[:1000]}\n"
            "The broken mirror URL should be removed from newuser's pip configuration."
        )

    def test_newuser_pip_conf_fixed(self):
        """newuser's pip.conf should be fixed (removed, empty, or pointing to working PyPI)."""
        pip_conf = '/home/newuser/.config/pip/pip.conf'

        # Option 1: File doesn't exist (acceptable)
        if not os.path.exists(pip_conf):
            return

        # Option 2: File exists but is empty or doesn't have the broken URL
        if os.path.isfile(pip_conf):
            with open(pip_conf, 'r') as f:
                content = f.read()

            assert 'pypi.internal.corp.local' not in content, (
                f"File {pip_conf} still contains 'pypi.internal.corp.local'.\n"
                f"Content: {content}\n"
                "The broken internal mirror URL must be removed from newuser's pip.conf."
            )


class TestProvisioningScriptFixed:
    """Verify the create_user.sh script has been fixed."""

    def test_create_user_script_still_exists(self):
        """The create_user.sh script must still exist (not deleted)."""
        script = '/opt/admin/create_user.sh'
        assert os.path.isfile(script), (
            f"Script {script} does not exist. "
            "The script should be fixed, not deleted."
        )

    def test_create_user_script_is_executable(self):
        """The create_user.sh script should still be executable."""
        script = '/opt/admin/create_user.sh'
        if not os.path.isfile(script):
            pytest.skip("Script doesn't exist")

        assert os.access(script, os.X_OK), (
            f"Script {script} is not executable. "
            "The script should remain a valid executable shell script."
        )

    def test_create_user_script_no_broken_mirror(self):
        """The create_user.sh script must NOT contain the broken mirror URL."""
        script = '/opt/admin/create_user.sh'
        if not os.path.isfile(script):
            pytest.skip("Script doesn't exist")

        with open(script, 'r') as f:
            content = f.read()

        assert 'pypi.internal.corp.local' not in content, (
            f"Script {script} still contains 'pypi.internal.corp.local'.\n"
            "The broken internal mirror configuration must be removed or commented out "
            "to prevent new users from getting the broken pip config."
        )

    def test_create_user_script_valid_syntax(self):
        """The create_user.sh script must have valid shell syntax."""
        script = '/opt/admin/create_user.sh'
        if not os.path.isfile(script):
            pytest.skip("Script doesn't exist")

        # Use bash -n to check syntax without executing
        result = subprocess.run(
            ['bash', '-n', script],
            capture_output=True,
            text=True
        )

        assert result.returncode == 0, (
            f"Script {script} has syntax errors.\n"
            f"Error: {result.stderr}\n"
            "The script must remain a valid shell script after modifications."
        )


class TestOlduserUnchanged:
    """Verify olduser's home directory is unchanged (invariant)."""

    def test_olduser_still_exists(self):
        """olduser account must still exist."""
        try:
            pwd.getpwnam('olduser')
        except KeyError:
            pytest.fail("User 'olduser' no longer exists. This account should not be modified.")

    def test_olduser_home_still_exists(self):
        """olduser home directory must still exist."""
        home = '/home/olduser'
        assert os.path.isdir(home), (
            f"Home directory {home} no longer exists. "
            "olduser's home directory should not be deleted."
        )

    def test_olduser_pip_still_works(self):
        """pip should still work for olduser."""
        result = subprocess.run(
            ['su', '-', 'olduser', '-c', 'pip install --dry-run numpy'],
            capture_output=True,
            text=True,
            timeout=60
        )

        assert result.returncode == 0, (
            f"pip install --dry-run numpy failed for olduser.\n"
            f"Exit code: {result.returncode}\n"
            f"stderr: {result.stderr}\n"
            "olduser's pip functionality should remain working."
        )

    def test_olduser_no_broken_pip_conf(self):
        """olduser should still NOT have the broken pip config."""
        pip_conf = '/home/olduser/.config/pip/pip.conf'

        if not os.path.exists(pip_conf):
            # Expected state - no pip.conf
            return

        if os.path.isfile(pip_conf):
            with open(pip_conf, 'r') as f:
                content = f.read()

            assert 'pypi.internal.corp.local' not in content, (
                f"File {pip_conf} now contains 'pypi.internal.corp.local'. "
                "olduser's configuration should not have been modified to add the broken URL."
            )


class TestSystemPipConfigUnchanged:
    """Verify system-wide pip configuration is unchanged (invariant)."""

    def test_etc_pip_conf_unchanged(self):
        """System-wide /etc/pip.conf should not have the broken mirror added."""
        etc_pip_conf = '/etc/pip.conf'

        if not os.path.exists(etc_pip_conf):
            # No system-wide config - that's fine
            return

        with open(etc_pip_conf, 'r') as f:
            content = f.read()

        # If it exists, it should not have the broken internal mirror
        # (unless it was there before, but based on the task it shouldn't be)
        assert 'pypi.internal.corp.local' not in content, (
            f"System-wide {etc_pip_conf} contains 'pypi.internal.corp.local'. "
            "The fix should be user-specific, not system-wide."
        )


class TestBothUsersFunctional:
    """Final verification that both users can use pip."""

    def test_newuser_can_check_pip_version(self):
        """newuser should be able to run pip --version."""
        result = subprocess.run(
            ['su', '-', 'newuser', '-c', 'pip --version'],
            capture_output=True,
            text=True,
            timeout=30
        )

        assert result.returncode == 0, (
            f"pip --version failed for newuser.\n"
            f"stderr: {result.stderr}"
        )

    def test_olduser_can_check_pip_version(self):
        """olduser should be able to run pip --version."""
        result = subprocess.run(
            ['su', '-', 'olduser', '-c', 'pip --version'],
            capture_output=True,
            text=True,
            timeout=30
        )

        assert result.returncode == 0, (
            f"pip --version failed for olduser.\n"
            f"stderr: {result.stderr}"
        )
