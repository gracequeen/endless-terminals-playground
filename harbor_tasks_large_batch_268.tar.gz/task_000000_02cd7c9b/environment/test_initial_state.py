# test_initial_state.py
"""
Tests to validate the initial state of the system before the student performs the action.
This verifies the broken pip configuration scenario for newuser vs olduser.
"""

import os
import pwd
import subprocess
import pytest


class TestUsersExist:
    """Verify both test user accounts exist."""

    def test_newuser_exists(self):
        """newuser account must exist."""
        try:
            pwd.getpwnam('newuser')
        except KeyError:
            pytest.fail("User 'newuser' does not exist. This account is required for testing.")

    def test_olduser_exists(self):
        """olduser account must exist."""
        try:
            pwd.getpwnam('olduser')
        except KeyError:
            pytest.fail("User 'olduser' does not exist. This account is required for testing.")


class TestHomeDirectories:
    """Verify home directories exist and are accessible."""

    def test_newuser_home_exists(self):
        """newuser home directory must exist."""
        home = '/home/newuser'
        assert os.path.isdir(home), f"Home directory {home} does not exist"

    def test_olduser_home_exists(self):
        """olduser home directory must exist."""
        home = '/home/olduser'
        assert os.path.isdir(home), f"Home directory {home} does not exist"


class TestPipConfiguration:
    """Verify the pip configuration state that causes the issue."""

    def test_newuser_has_pip_conf(self):
        """newuser must have a pip.conf file (the broken config)."""
        pip_conf = '/home/newuser/.config/pip/pip.conf'
        assert os.path.isfile(pip_conf), (
            f"File {pip_conf} does not exist. "
            "newuser should have a pip.conf with the broken internal mirror config."
        )

    def test_newuser_pip_conf_has_broken_mirror(self):
        """newuser's pip.conf must contain the broken internal mirror URL."""
        pip_conf = '/home/newuser/.config/pip/pip.conf'
        if not os.path.isfile(pip_conf):
            pytest.skip("pip.conf doesn't exist, skipping content check")

        with open(pip_conf, 'r') as f:
            content = f.read()

        assert 'pypi.internal.corp.local' in content, (
            f"File {pip_conf} does not contain 'pypi.internal.corp.local'. "
            "The broken internal mirror URL should be present in newuser's pip.conf."
        )

    def test_olduser_no_pip_conf_or_no_broken_config(self):
        """olduser should NOT have a pip.conf with the broken mirror."""
        pip_conf = '/home/olduser/.config/pip/pip.conf'

        # Either the file doesn't exist, or it doesn't contain the broken URL
        if not os.path.exists(pip_conf):
            # This is the expected state - no pip.conf
            return

        if os.path.isfile(pip_conf):
            with open(pip_conf, 'r') as f:
                content = f.read()
            assert 'pypi.internal.corp.local' not in content, (
                f"File {pip_conf} contains 'pypi.internal.corp.local'. "
                "olduser should NOT have the broken internal mirror config."
            )


class TestProvisioningScript:
    """Verify the provisioning script exists and contains the problematic code."""

    def test_create_user_script_exists(self):
        """The create_user.sh script must exist."""
        script = '/opt/admin/create_user.sh'
        assert os.path.isfile(script), (
            f"Script {script} does not exist. "
            "The provisioning script is required for this task."
        )

    def test_create_user_script_is_readable(self):
        """The create_user.sh script must be readable."""
        script = '/opt/admin/create_user.sh'
        assert os.access(script, os.R_OK), (
            f"Script {script} is not readable. "
            "The agent needs to read the script to diagnose the issue."
        )

    def test_create_user_script_contains_broken_mirror(self):
        """The create_user.sh script must contain the broken mirror configuration."""
        script = '/opt/admin/create_user.sh'
        if not os.path.isfile(script):
            pytest.skip("Script doesn't exist, skipping content check")

        with open(script, 'r') as f:
            content = f.read()

        assert 'pypi.internal.corp.local' in content, (
            f"Script {script} does not contain 'pypi.internal.corp.local'. "
            "The script should have the section that creates the broken pip.conf."
        )

    def test_create_user_script_creates_pip_conf(self):
        """The script should have code that creates pip.conf."""
        script = '/opt/admin/create_user.sh'
        if not os.path.isfile(script):
            pytest.skip("Script doesn't exist, skipping content check")

        with open(script, 'r') as f:
            content = f.read()

        assert 'pip.conf' in content or 'pip/pip.conf' in content, (
            f"Script {script} does not reference pip.conf. "
            "The script should contain code that creates the pip configuration."
        )


class TestSystemPip:
    """Verify pip is installed and functional system-wide."""

    def test_pip_is_installed(self):
        """pip must be installed on the system."""
        result = subprocess.run(
            ['which', 'pip'],
            capture_output=True,
            text=True
        )
        if result.returncode != 0:
            result = subprocess.run(
                ['which', 'pip3'],
                capture_output=True,
                text=True
            )
        assert result.returncode == 0, (
            "pip (or pip3) is not installed or not in PATH. "
            "pip is required for this task."
        )

    def test_python_is_installed(self):
        """Python 3 must be installed."""
        result = subprocess.run(
            ['python3', '--version'],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "Python 3 is not installed or not working. "
            "Python is required for this task."
        )


class TestEtcSkel:
    """Verify /etc/skel exists (the red herring mentioned in the task)."""

    def test_etc_skel_exists(self):
        """/etc/skel directory must exist."""
        assert os.path.isdir('/etc/skel'), (
            "/etc/skel directory does not exist. "
            "This is mentioned in the task description."
        )


class TestOptAdminDirectory:
    """Verify the /opt/admin directory structure."""

    def test_opt_admin_exists(self):
        """/opt/admin directory must exist."""
        assert os.path.isdir('/opt/admin'), (
            "/opt/admin directory does not exist. "
            "This directory should contain the create_user.sh script."
        )
