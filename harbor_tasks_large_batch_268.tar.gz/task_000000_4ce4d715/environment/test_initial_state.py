# test_initial_state.py
"""
Tests to validate the initial state of the operating system / filesystem
before the student performs the database migration task.
"""

import os
import sqlite3
import subprocess
import pytest


class TestInitialState:
    """Test suite to verify the initial state before migration."""

    def test_app_directory_exists(self):
        """Verify /home/user/app/ directory exists."""
        app_dir = "/home/user/app"
        assert os.path.isdir(app_dir), f"Directory {app_dir} does not exist"

    def test_migrations_directory_exists(self):
        """Verify /home/user/app/migrations/ directory exists."""
        migrations_dir = "/home/user/app/migrations"
        assert os.path.isdir(migrations_dir), f"Directory {migrations_dir} does not exist"

    def test_database_file_exists(self):
        """Verify /home/user/app/data.db exists."""
        db_path = "/home/user/app/data.db"
        assert os.path.isfile(db_path), f"Database file {db_path} does not exist"

    def test_database_is_writable(self):
        """Verify the database file is writable."""
        db_path = "/home/user/app/data.db"
        assert os.access(db_path, os.W_OK), f"Database file {db_path} is not writable"

    def test_app_directory_is_writable(self):
        """Verify /home/user/app/ directory is writable."""
        app_dir = "/home/user/app"
        assert os.access(app_dir, os.W_OK), f"Directory {app_dir} is not writable"

    def test_migration_script_exists(self):
        """Verify the migration script exists at the expected location."""
        migration_path = "/home/user/app/migrations/003_add_last_login.sql"
        assert os.path.isfile(migration_path), f"Migration script {migration_path} does not exist"

    def test_migration_script_contains_alter_table(self):
        """Verify the migration script contains the expected ALTER TABLE statement."""
        migration_path = "/home/user/app/migrations/003_add_last_login.sql"
        with open(migration_path, 'r') as f:
            content = f.read()
        assert "ALTER TABLE users ADD COLUMN last_login" in content, \
            "Migration script does not contain expected ALTER TABLE statement"
        assert "TIMESTAMP" in content.upper(), \
            "Migration script does not specify TIMESTAMP type"

    def test_sqlite3_cli_installed(self):
        """Verify sqlite3 CLI is installed and accessible."""
        result = subprocess.run(["which", "sqlite3"], capture_output=True, text=True)
        assert result.returncode == 0, "sqlite3 CLI is not installed or not in PATH"

    def test_database_is_valid_sqlite3(self):
        """Verify the database file is a valid SQLite3 database."""
        db_path = "/home/user/app/data.db"
        try:
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            cursor.execute("SELECT sqlite_version();")
            conn.close()
        except sqlite3.DatabaseError as e:
            pytest.fail(f"Database file is not a valid SQLite3 database: {e}")

    def test_users_table_exists(self):
        """Verify the users table exists in the database."""
        db_path = "/home/user/app/data.db"
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='users';")
        result = cursor.fetchone()
        conn.close()
        assert result is not None, "Table 'users' does not exist in the database"

    def test_users_table_has_expected_columns(self):
        """Verify the users table has the expected columns (id, username, email, created_at)."""
        db_path = "/home/user/app/data.db"
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute("PRAGMA table_info(users);")
        columns = cursor.fetchall()
        conn.close()

        column_names = [col[1] for col in columns]
        expected_columns = ['id', 'username', 'email', 'created_at']

        for expected in expected_columns:
            assert expected in column_names, \
                f"Column '{expected}' is missing from users table. Found columns: {column_names}"

    def test_users_table_does_not_have_last_login_column(self):
        """Verify the users table does NOT yet have a last_login column (migration not run)."""
        db_path = "/home/user/app/data.db"
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute("PRAGMA table_info(users);")
        columns = cursor.fetchall()
        conn.close()

        column_names = [col[1] for col in columns]
        assert 'last_login' not in column_names, \
            "Column 'last_login' already exists - migration may have already been run"

    def test_users_table_has_five_rows(self):
        """Verify the users table has 5 rows of sample data."""
        db_path = "/home/user/app/data.db"
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM users;")
        count = cursor.fetchone()[0]
        conn.close()
        assert count == 5, f"Expected 5 rows in users table, found {count}"

    def test_users_table_has_valid_data(self):
        """Verify the users table has valid data in all required columns."""
        db_path = "/home/user/app/data.db"
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT id, username, email, created_at FROM users;")
        rows = cursor.fetchall()
        conn.close()

        assert len(rows) == 5, f"Expected 5 rows, found {len(rows)}"

        for row in rows:
            id_val, username, email, created_at = row
            assert id_val is not None, "Found row with NULL id"
            assert username is not None and len(username) > 0, f"Row {id_val} has invalid username"
            assert email is not None and '@' in email, f"Row {id_val} has invalid email"
            assert created_at is not None, f"Row {id_val} has NULL created_at"

    def test_id_column_is_integer_primary_key(self):
        """Verify the id column is INTEGER PRIMARY KEY."""
        db_path = "/home/user/app/data.db"
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute("PRAGMA table_info(users);")
        columns = cursor.fetchall()
        conn.close()

        # Find the id column
        id_col = None
        for col in columns:
            if col[1] == 'id':
                id_col = col
                break

        assert id_col is not None, "Column 'id' not found"
        # col format: (cid, name, type, notnull, dflt_value, pk)
        assert 'INTEGER' in id_col[2].upper(), f"Column 'id' type is not INTEGER, got {id_col[2]}"
        assert id_col[5] == 1, "Column 'id' is not a primary key"

    def test_username_column_is_text(self):
        """Verify the username column is TEXT type."""
        db_path = "/home/user/app/data.db"
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute("PRAGMA table_info(users);")
        columns = cursor.fetchall()
        conn.close()

        username_col = None
        for col in columns:
            if col[1] == 'username':
                username_col = col
                break

        assert username_col is not None, "Column 'username' not found"
        assert 'TEXT' in username_col[2].upper(), f"Column 'username' type is not TEXT, got {username_col[2]}"

    def test_email_column_is_text(self):
        """Verify the email column is TEXT type."""
        db_path = "/home/user/app/data.db"
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute("PRAGMA table_info(users);")
        columns = cursor.fetchall()
        conn.close()

        email_col = None
        for col in columns:
            if col[1] == 'email':
                email_col = col
                break

        assert email_col is not None, "Column 'email' not found"
        assert 'TEXT' in email_col[2].upper(), f"Column 'email' type is not TEXT, got {email_col[2]}"

    def test_created_at_column_is_text(self):
        """Verify the created_at column is TEXT type."""
        db_path = "/home/user/app/data.db"
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute("PRAGMA table_info(users);")
        columns = cursor.fetchall()
        conn.close()

        created_at_col = None
        for col in columns:
            if col[1] == 'created_at':
                created_at_col = col
                break

        assert created_at_col is not None, "Column 'created_at' not found"
        assert 'TEXT' in created_at_col[2].upper(), f"Column 'created_at' type is not TEXT, got {created_at_col[2]}"
