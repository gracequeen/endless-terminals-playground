# test_final_state.py
"""
Tests to validate the final state of the operating system / filesystem
after the student has completed the database migration task.
"""

import os
import sqlite3
import subprocess
import pytest


class TestFinalState:
    """Test suite to verify the final state after migration."""

    def test_database_file_still_exists(self):
        """Verify /home/user/app/data.db still exists."""
        db_path = "/home/user/app/data.db"
        assert os.path.isfile(db_path), f"Database file {db_path} does not exist"

    def test_database_is_valid_sqlite3(self):
        """Verify the database file is still a valid SQLite3 database."""
        db_path = "/home/user/app/data.db"
        try:
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            cursor.execute("SELECT sqlite_version();")
            conn.close()
        except sqlite3.DatabaseError as e:
            pytest.fail(f"Database file is not a valid SQLite3 database: {e}")

    def test_users_table_still_exists(self):
        """Verify the users table still exists in the database."""
        db_path = "/home/user/app/data.db"
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='users';")
        result = cursor.fetchone()
        conn.close()
        assert result is not None, "Table 'users' does not exist in the database"

    def test_last_login_column_exists(self):
        """Verify the last_login column now exists in the users table."""
        db_path = "/home/user/app/data.db"
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute("PRAGMA table_info(users);")
        columns = cursor.fetchall()
        conn.close()

        column_names = [col[1] for col in columns]
        assert 'last_login' in column_names, \
            f"Column 'last_login' does not exist in users table. Found columns: {column_names}"

    def test_last_login_column_type_is_timestamp(self):
        """Verify the last_login column has TIMESTAMP type."""
        db_path = "/home/user/app/data.db"
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute("PRAGMA table_info(users);")
        columns = cursor.fetchall()
        conn.close()

        last_login_col = None
        for col in columns:
            if col[1] == 'last_login':
                last_login_col = col
                break

        assert last_login_col is not None, "Column 'last_login' not found"
        # col format: (cid, name, type, notnull, dflt_value, pk)
        col_type = last_login_col[2].upper() if last_login_col[2] else ""
        assert 'TIMESTAMP' in col_type, \
            f"Column 'last_login' type should contain TIMESTAMP, got '{last_login_col[2]}'"

    def test_last_login_column_is_nullable(self):
        """Verify the last_login column is nullable (no NOT NULL constraint)."""
        db_path = "/home/user/app/data.db"
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute("PRAGMA table_info(users);")
        columns = cursor.fetchall()
        conn.close()

        last_login_col = None
        for col in columns:
            if col[1] == 'last_login':
                last_login_col = col
                break

        assert last_login_col is not None, "Column 'last_login' not found"
        # col format: (cid, name, type, notnull, dflt_value, pk)
        # notnull is at index 3, should be 0 for nullable
        assert last_login_col[3] == 0, \
            f"Column 'last_login' should be nullable (notnull=0), but notnull={last_login_col[3]}"

    def test_original_columns_still_exist(self):
        """Verify all original columns (id, username, email, created_at) still exist."""
        db_path = "/home/user/app/data.db"
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute("PRAGMA table_info(users);")
        columns = cursor.fetchall()
        conn.close()

        column_names = [col[1] for col in columns]
        expected_columns = ['id', 'username', 'email', 'created_at']

        for expected in expected_columns:
            assert expected in column_names, \
                f"Original column '{expected}' is missing from users table. Found columns: {column_names}"

    def test_users_table_still_has_five_rows(self):
        """Verify the users table still has 5 rows (no rows deleted)."""
        db_path = "/home/user/app/data.db"
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM users;")
        count = cursor.fetchone()[0]
        conn.close()
        assert count == 5, \
            f"Expected 5 rows in users table, found {count}. Original data may have been lost."

    def test_all_existing_rows_have_null_last_login(self):
        """Verify all existing rows have NULL for last_login column."""
        db_path = "/home/user/app/data.db"
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT id, last_login FROM users;")
        rows = cursor.fetchall()
        conn.close()

        for row in rows:
            id_val, last_login = row
            assert last_login is None, \
                f"Row with id={id_val} has last_login={last_login}, expected NULL"

    def test_original_data_intact_id_values(self):
        """Verify original id values are intact (data wasn't recreated)."""
        db_path = "/home/user/app/data.db"
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT id FROM users ORDER BY id;")
        ids = [row[0] for row in cursor.fetchall()]
        conn.close()

        assert len(ids) == 5, f"Expected 5 rows, found {len(ids)}"
        # IDs should be sequential starting from 1 (typical for sample data)
        for i, id_val in enumerate(ids, start=1):
            assert id_val == i, \
                f"Expected id={i} at position {i}, found id={id_val}. Data may have been recreated."

    def test_original_data_intact_usernames_exist(self):
        """Verify original username values still exist and are non-empty."""
        db_path = "/home/user/app/data.db"
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT id, username FROM users;")
        rows = cursor.fetchall()
        conn.close()

        for row in rows:
            id_val, username = row
            assert username is not None, \
                f"Row with id={id_val} has NULL username - original data may have been lost"
            assert len(username) > 0, \
                f"Row with id={id_val} has empty username - original data may have been lost"

    def test_original_data_intact_emails_exist(self):
        """Verify original email values still exist and contain @."""
        db_path = "/home/user/app/data.db"
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT id, email FROM users;")
        rows = cursor.fetchall()
        conn.close()

        for row in rows:
            id_val, email = row
            assert email is not None, \
                f"Row with id={id_val} has NULL email - original data may have been lost"
            assert '@' in email, \
                f"Row with id={id_val} has invalid email '{email}' - original data may have been lost"

    def test_original_data_intact_created_at_exists(self):
        """Verify original created_at values still exist."""
        db_path = "/home/user/app/data.db"
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT id, created_at FROM users;")
        rows = cursor.fetchall()
        conn.close()

        for row in rows:
            id_val, created_at = row
            assert created_at is not None, \
                f"Row with id={id_val} has NULL created_at - original data may have been lost"

    def test_sqlite3_cli_shows_last_login_column(self):
        """Verify sqlite3 CLI PRAGMA table_info shows last_login column."""
        result = subprocess.run(
            ["sqlite3", "/home/user/app/data.db", "PRAGMA table_info(users);"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, f"sqlite3 command failed: {result.stderr}"
        assert 'last_login' in result.stdout, \
            f"Column 'last_login' not found in PRAGMA table_info output: {result.stdout}"

    def test_id_column_still_integer_primary_key(self):
        """Verify the id column is still INTEGER PRIMARY KEY."""
        db_path = "/home/user/app/data.db"
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute("PRAGMA table_info(users);")
        columns = cursor.fetchall()
        conn.close()

        id_col = None
        for col in columns:
            if col[1] == 'id':
                id_col = col
                break

        assert id_col is not None, "Column 'id' not found"
        assert 'INTEGER' in id_col[2].upper(), \
            f"Column 'id' type changed from INTEGER to {id_col[2]}"
        assert id_col[5] == 1, "Column 'id' is no longer a primary key"

    def test_username_column_still_text(self):
        """Verify the username column is still TEXT type."""
        db_path = "/home/user/app/data.db"
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute("PRAGMA table_info(users);")
        columns = cursor.fetchall()
        conn.close()

        username_col = None
        for col in columns:
            if col[1] == 'username':
                username_col = col
                break

        assert username_col is not None, "Column 'username' not found"
        assert 'TEXT' in username_col[2].upper(), \
            f"Column 'username' type changed from TEXT to {username_col[2]}"

    def test_email_column_still_text(self):
        """Verify the email column is still TEXT type."""
        db_path = "/home/user/app/data.db"
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute("PRAGMA table_info(users);")
        columns = cursor.fetchall()
        conn.close()

        email_col = None
        for col in columns:
            if col[1] == 'email':
                email_col = col
                break

        assert email_col is not None, "Column 'email' not found"
        assert 'TEXT' in email_col[2].upper(), \
            f"Column 'email' type changed from TEXT to {email_col[2]}"

    def test_created_at_column_still_text(self):
        """Verify the created_at column is still TEXT type."""
        db_path = "/home/user/app/data.db"
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute("PRAGMA table_info(users);")
        columns = cursor.fetchall()
        conn.close()

        created_at_col = None
        for col in columns:
            if col[1] == 'created_at':
                created_at_col = col
                break

        assert created_at_col is not None, "Column 'created_at' not found"
        assert 'TEXT' in created_at_col[2].upper(), \
            f"Column 'created_at' type changed from TEXT to {created_at_col[2]}"
