# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the rsync task to sync .tar.gz files from artifacts to backup.
"""

import os
import subprocess
import pytest


class TestSourceDirectoryStructure:
    """Verify the source directory /home/user/artifacts/release/ exists with expected files."""

    def test_artifacts_release_directory_exists(self):
        """The source directory must exist."""
        path = "/home/user/artifacts/release"
        assert os.path.isdir(path), f"Source directory {path} does not exist"

    def test_build_1_0_tar_gz_exists(self):
        """build-1.0.tar.gz must exist in source."""
        path = "/home/user/artifacts/release/build-1.0.tar.gz"
        assert os.path.isfile(path), f"File {path} does not exist"

    def test_build_1_0_tar_gz_size(self):
        """build-1.0.tar.gz must be 1024 bytes."""
        path = "/home/user/artifacts/release/build-1.0.tar.gz"
        size = os.path.getsize(path)
        assert size == 1024, f"File {path} should be 1024 bytes, got {size}"

    def test_build_1_1_tar_gz_exists(self):
        """build-1.1.tar.gz must exist in source."""
        path = "/home/user/artifacts/release/build-1.1.tar.gz"
        assert os.path.isfile(path), f"File {path} does not exist"

    def test_build_1_1_tar_gz_size(self):
        """build-1.1.tar.gz must be 2048 bytes."""
        path = "/home/user/artifacts/release/build-1.1.tar.gz"
        size = os.path.getsize(path)
        assert size == 2048, f"File {path} should be 2048 bytes, got {size}"

    def test_build_1_2_tar_gz_exists(self):
        """build-1.2.tar.gz must exist in source."""
        path = "/home/user/artifacts/release/build-1.2.tar.gz"
        assert os.path.isfile(path), f"File {path} does not exist"

    def test_build_1_2_tar_gz_size(self):
        """build-1.2.tar.gz must be 512 bytes."""
        path = "/home/user/artifacts/release/build-1.2.tar.gz"
        size = os.path.getsize(path)
        assert size == 512, f"File {path} should be 512 bytes, got {size}"

    def test_main_o_exists(self):
        """main.o must exist in source (junk file to be excluded)."""
        path = "/home/user/artifacts/release/main.o"
        assert os.path.isfile(path), f"File {path} does not exist"

    def test_main_o_size(self):
        """main.o must be 256 bytes."""
        path = "/home/user/artifacts/release/main.o"
        size = os.path.getsize(path)
        assert size == 256, f"File {path} should be 256 bytes, got {size}"

    def test_utils_o_exists(self):
        """utils.o must exist in source (junk file to be excluded)."""
        path = "/home/user/artifacts/release/utils.o"
        assert os.path.isfile(path), f"File {path} does not exist"

    def test_utils_o_size(self):
        """utils.o must be 128 bytes."""
        path = "/home/user/artifacts/release/utils.o"
        size = os.path.getsize(path)
        assert size == 128, f"File {path} should be 128 bytes, got {size}"

    def test_compile_log_exists(self):
        """compile.log must exist in source (junk file to be excluded)."""
        path = "/home/user/artifacts/release/compile.log"
        assert os.path.isfile(path), f"File {path} does not exist"

    def test_compile_log_size(self):
        """compile.log must be 4096 bytes."""
        path = "/home/user/artifacts/release/compile.log"
        size = os.path.getsize(path)
        assert size == 4096, f"File {path} should be 4096 bytes, got {size}"

    def test_link_log_exists(self):
        """link.log must exist in source (junk file to be excluded)."""
        path = "/home/user/artifacts/release/link.log"
        assert os.path.isfile(path), f"File {path} does not exist"

    def test_link_log_size(self):
        """link.log must be 2048 bytes."""
        path = "/home/user/artifacts/release/link.log"
        size = os.path.getsize(path)
        assert size == 2048, f"File {path} should be 2048 bytes, got {size}"


class TestDebugSubdirectory:
    """Verify the debug/ subdirectory exists with expected files."""

    def test_debug_directory_exists(self):
        """The debug subdirectory must exist."""
        path = "/home/user/artifacts/release/debug"
        assert os.path.isdir(path), f"Debug subdirectory {path} does not exist"

    def test_debug_1_0_tar_gz_exists(self):
        """debug-1.0.tar.gz must exist in debug subdirectory."""
        path = "/home/user/artifacts/release/debug/debug-1.0.tar.gz"
        assert os.path.isfile(path), f"File {path} does not exist"

    def test_debug_1_0_tar_gz_size(self):
        """debug-1.0.tar.gz must be 768 bytes."""
        path = "/home/user/artifacts/release/debug/debug-1.0.tar.gz"
        size = os.path.getsize(path)
        assert size == 768, f"File {path} should be 768 bytes, got {size}"

    def test_trace_o_exists(self):
        """trace.o must exist in debug subdirectory (junk file to be excluded)."""
        path = "/home/user/artifacts/release/debug/trace.o"
        assert os.path.isfile(path), f"File {path} does not exist"

    def test_trace_o_size(self):
        """trace.o must be 64 bytes."""
        path = "/home/user/artifacts/release/debug/trace.o"
        size = os.path.getsize(path)
        assert size == 64, f"File {path} should be 64 bytes, got {size}"


class TestBackupDirectory:
    """Verify the backup destination directory exists and is empty."""

    def test_backup_release_directory_exists(self):
        """The backup destination directory must exist."""
        path = "/home/user/backup/release"
        assert os.path.isdir(path), f"Backup directory {path} does not exist"

    def test_backup_release_directory_is_empty(self):
        """The backup destination directory must be empty initially."""
        path = "/home/user/backup/release"
        contents = os.listdir(path)
        assert len(contents) == 0, (
            f"Backup directory {path} should be empty but contains: {contents}"
        )


class TestRsyncInstalled:
    """Verify rsync is installed and available."""

    def test_rsync_is_installed(self):
        """rsync command must be available."""
        result = subprocess.run(
            ["which", "rsync"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "rsync is not installed or not in PATH. "
            f"'which rsync' returned: {result.stderr}"
        )

    def test_rsync_is_executable(self):
        """rsync must be executable."""
        result = subprocess.run(
            ["rsync", "--version"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"rsync is not working properly. Error: {result.stderr}"
        )


class TestPathsWritable:
    """Verify that required paths are writable."""

    def test_backup_release_is_writable(self):
        """The backup destination must be writable."""
        path = "/home/user/backup/release"
        assert os.access(path, os.W_OK), f"Directory {path} is not writable"

    def test_home_user_is_writable(self):
        """/home/user must be writable."""
        path = "/home/user"
        assert os.access(path, os.W_OK), f"Directory {path} is not writable"
