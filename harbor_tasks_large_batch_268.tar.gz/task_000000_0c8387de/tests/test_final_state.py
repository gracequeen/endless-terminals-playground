# test_final_state.py
"""
Tests to validate the final state of the OS/filesystem after the student
has completed the rsync task to sync only .tar.gz files from artifacts to backup.
"""

import os
import hashlib
import subprocess
import pytest


def get_file_md5(filepath):
    """Calculate MD5 checksum of a file."""
    hash_md5 = hashlib.md5()
    with open(filepath, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            hash_md5.update(chunk)
    return hash_md5.hexdigest()


class TestBackupContainsTarGzFiles:
    """Verify that all .tar.gz files have been synced to the backup directory."""

    def test_backup_release_directory_exists(self):
        """The backup destination directory must exist."""
        path = "/home/user/backup/release"
        assert os.path.isdir(path), f"Backup directory {path} does not exist"

    def test_build_1_0_tar_gz_exists_in_backup(self):
        """build-1.0.tar.gz must exist in backup."""
        path = "/home/user/backup/release/build-1.0.tar.gz"
        assert os.path.isfile(path), f"File {path} was not synced to backup"

    def test_build_1_1_tar_gz_exists_in_backup(self):
        """build-1.1.tar.gz must exist in backup."""
        path = "/home/user/backup/release/build-1.1.tar.gz"
        assert os.path.isfile(path), f"File {path} was not synced to backup"

    def test_build_1_2_tar_gz_exists_in_backup(self):
        """build-1.2.tar.gz must exist in backup."""
        path = "/home/user/backup/release/build-1.2.tar.gz"
        assert os.path.isfile(path), f"File {path} was not synced to backup"

    def test_debug_subdirectory_exists_in_backup(self):
        """The debug subdirectory must exist in backup (for recursive sync)."""
        path = "/home/user/backup/release/debug"
        assert os.path.isdir(path), (
            f"Debug subdirectory {path} was not created in backup - "
            "rsync may not have been run recursively"
        )

    def test_debug_1_0_tar_gz_exists_in_backup(self):
        """debug-1.0.tar.gz must exist in backup/debug/ (verifies recursive behavior)."""
        path = "/home/user/backup/release/debug/debug-1.0.tar.gz"
        assert os.path.isfile(path), (
            f"File {path} was not synced to backup - "
            "rsync may not have synced subdirectory .tar.gz files"
        )


class TestBackupFileIntegrity:
    """Verify that synced files are identical to source files via checksum."""

    def test_build_1_0_tar_gz_checksum_matches(self):
        """build-1.0.tar.gz in backup must match source checksum."""
        src = "/home/user/artifacts/release/build-1.0.tar.gz"
        dst = "/home/user/backup/release/build-1.0.tar.gz"
        if os.path.isfile(dst):
            src_md5 = get_file_md5(src)
            dst_md5 = get_file_md5(dst)
            assert src_md5 == dst_md5, (
                f"Checksum mismatch for build-1.0.tar.gz: "
                f"source={src_md5}, backup={dst_md5}"
            )

    def test_build_1_1_tar_gz_checksum_matches(self):
        """build-1.1.tar.gz in backup must match source checksum."""
        src = "/home/user/artifacts/release/build-1.1.tar.gz"
        dst = "/home/user/backup/release/build-1.1.tar.gz"
        if os.path.isfile(dst):
            src_md5 = get_file_md5(src)
            dst_md5 = get_file_md5(dst)
            assert src_md5 == dst_md5, (
                f"Checksum mismatch for build-1.1.tar.gz: "
                f"source={src_md5}, backup={dst_md5}"
            )

    def test_build_1_2_tar_gz_checksum_matches(self):
        """build-1.2.tar.gz in backup must match source checksum."""
        src = "/home/user/artifacts/release/build-1.2.tar.gz"
        dst = "/home/user/backup/release/build-1.2.tar.gz"
        if os.path.isfile(dst):
            src_md5 = get_file_md5(src)
            dst_md5 = get_file_md5(dst)
            assert src_md5 == dst_md5, (
                f"Checksum mismatch for build-1.2.tar.gz: "
                f"source={src_md5}, backup={dst_md5}"
            )

    def test_debug_1_0_tar_gz_checksum_matches(self):
        """debug-1.0.tar.gz in backup must match source checksum."""
        src = "/home/user/artifacts/release/debug/debug-1.0.tar.gz"
        dst = "/home/user/backup/release/debug/debug-1.0.tar.gz"
        if os.path.isfile(dst):
            src_md5 = get_file_md5(src)
            dst_md5 = get_file_md5(dst)
            assert src_md5 == dst_md5, (
                f"Checksum mismatch for debug-1.0.tar.gz: "
                f"source={src_md5}, backup={dst_md5}"
            )


class TestNoJunkFilesInBackup:
    """Verify that no .o or .log files were copied to backup."""

    def test_no_o_files_in_backup_root(self):
        """No .o files should exist in backup/release/."""
        backup_dir = "/home/user/backup/release"
        if os.path.isdir(backup_dir):
            o_files = [f for f in os.listdir(backup_dir) if f.endswith('.o')]
            assert len(o_files) == 0, (
                f".o files found in backup root: {o_files} - "
                "rsync include/exclude filter not working correctly"
            )

    def test_no_log_files_in_backup_root(self):
        """No .log files should exist in backup/release/."""
        backup_dir = "/home/user/backup/release"
        if os.path.isdir(backup_dir):
            log_files = [f for f in os.listdir(backup_dir) if f.endswith('.log')]
            assert len(log_files) == 0, (
                f".log files found in backup root: {log_files} - "
                "rsync include/exclude filter not working correctly"
            )

    def test_no_o_files_in_backup_debug(self):
        """No .o files should exist in backup/release/debug/."""
        debug_dir = "/home/user/backup/release/debug"
        if os.path.isdir(debug_dir):
            o_files = [f for f in os.listdir(debug_dir) if f.endswith('.o')]
            assert len(o_files) == 0, (
                f".o files found in backup/debug: {o_files} - "
                "rsync include/exclude filter not working for subdirectories"
            )

    def test_find_no_non_tar_gz_files(self):
        """find command must return empty for non-.tar.gz files in backup."""
        result = subprocess.run(
            ["find", "/home/user/backup/release", "-type", "f", "!", "-name", "*.tar.gz"],
            capture_output=True,
            text=True
        )
        found_files = result.stdout.strip()
        assert found_files == "", (
            f"Non-.tar.gz files found in backup: {found_files} - "
            "only .tar.gz files should have been synced"
        )


class TestBackupOnlyContainsExpectedFiles:
    """Verify the backup contains exactly the expected files, no more, no less."""

    def test_backup_has_exactly_four_tar_gz_files(self):
        """Backup should contain exactly 4 .tar.gz files total."""
        result = subprocess.run(
            ["find", "/home/user/backup/release", "-type", "f", "-name", "*.tar.gz"],
            capture_output=True,
            text=True
        )
        tar_gz_files = [f for f in result.stdout.strip().split('\n') if f]
        assert len(tar_gz_files) == 4, (
            f"Expected exactly 4 .tar.gz files in backup, found {len(tar_gz_files)}: {tar_gz_files}"
        )

    def test_backup_file_list_is_correct(self):
        """Verify the exact list of files in backup."""
        expected_files = {
            "/home/user/backup/release/build-1.0.tar.gz",
            "/home/user/backup/release/build-1.1.tar.gz",
            "/home/user/backup/release/build-1.2.tar.gz",
            "/home/user/backup/release/debug/debug-1.0.tar.gz",
        }
        result = subprocess.run(
            ["find", "/home/user/backup/release", "-type", "f"],
            capture_output=True,
            text=True
        )
        actual_files = {f for f in result.stdout.strip().split('\n') if f}
        assert actual_files == expected_files, (
            f"Backup file list mismatch.\n"
            f"Expected: {expected_files}\n"
            f"Actual: {actual_files}\n"
            f"Missing: {expected_files - actual_files}\n"
            f"Extra: {actual_files - expected_files}"
        )


class TestSourceUnchanged:
    """Verify that source files are still present (not moved)."""

    def test_source_build_1_0_still_exists(self):
        """Source build-1.0.tar.gz must still exist."""
        path = "/home/user/artifacts/release/build-1.0.tar.gz"
        assert os.path.isfile(path), f"Source file {path} was removed (should be copied, not moved)"

    def test_source_build_1_1_still_exists(self):
        """Source build-1.1.tar.gz must still exist."""
        path = "/home/user/artifacts/release/build-1.1.tar.gz"
        assert os.path.isfile(path), f"Source file {path} was removed (should be copied, not moved)"

    def test_source_build_1_2_still_exists(self):
        """Source build-1.2.tar.gz must still exist."""
        path = "/home/user/artifacts/release/build-1.2.tar.gz"
        assert os.path.isfile(path), f"Source file {path} was removed (should be copied, not moved)"

    def test_source_debug_1_0_still_exists(self):
        """Source debug-1.0.tar.gz must still exist."""
        path = "/home/user/artifacts/release/debug/debug-1.0.tar.gz"
        assert os.path.isfile(path), f"Source file {path} was removed (should be copied, not moved)"

    def test_source_junk_files_still_exist(self):
        """Source junk files (.o, .log) must still exist (not deleted)."""
        junk_files = [
            "/home/user/artifacts/release/main.o",
            "/home/user/artifacts/release/utils.o",
            "/home/user/artifacts/release/compile.log",
            "/home/user/artifacts/release/link.log",
            "/home/user/artifacts/release/debug/trace.o",
        ]
        for path in junk_files:
            assert os.path.isfile(path), (
                f"Source junk file {path} was removed - source should be unchanged"
            )
