# test_initial_state.py
"""
Tests to validate the initial state before the student performs the JSON to CSV conversion task.
"""

import json
import os
import pytest
import shutil
import subprocess


class TestInitialState:
    """Validate the operating system and filesystem state before the task."""

    def test_results_directory_exists(self):
        """Verify that /home/user/results/ directory exists."""
        results_dir = "/home/user/results"
        assert os.path.isdir(results_dir), (
            f"Directory {results_dir} does not exist. "
            "The results directory must exist before the task can be performed."
        )

    def test_results_directory_is_writable(self):
        """Verify that /home/user/results/ directory is writable."""
        results_dir = "/home/user/results"
        assert os.access(results_dir, os.W_OK), (
            f"Directory {results_dir} is not writable. "
            "The results directory must be writable to create the CSV output file."
        )

    def test_json_file_exists(self):
        """Verify that /home/user/results/run_output.json exists."""
        json_file = "/home/user/results/run_output.json"
        assert os.path.isfile(json_file), (
            f"File {json_file} does not exist. "
            "The source JSON file must exist before conversion can be performed."
        )

    def test_json_file_is_readable(self):
        """Verify that /home/user/results/run_output.json is readable."""
        json_file = "/home/user/results/run_output.json"
        assert os.access(json_file, os.R_OK), (
            f"File {json_file} is not readable. "
            "The source JSON file must be readable to extract test results."
        )

    def test_json_file_contains_valid_json(self):
        """Verify that the JSON file contains valid JSON."""
        json_file = "/home/user/results/run_output.json"
        try:
            with open(json_file, 'r') as f:
                data = json.load(f)
        except json.JSONDecodeError as e:
            pytest.fail(
                f"File {json_file} does not contain valid JSON: {e}. "
                "The source file must contain valid JSON data."
            )

    def test_json_file_contains_array(self):
        """Verify that the JSON file contains a JSON array."""
        json_file = "/home/user/results/run_output.json"
        with open(json_file, 'r') as f:
            data = json.load(f)
        assert isinstance(data, list), (
            f"File {json_file} does not contain a JSON array. "
            f"Expected a list/array, got {type(data).__name__}."
        )

    def test_json_file_contains_five_records(self):
        """Verify that the JSON file contains exactly 5 test result records."""
        json_file = "/home/user/results/run_output.json"
        with open(json_file, 'r') as f:
            data = json.load(f)
        assert len(data) == 5, (
            f"File {json_file} should contain exactly 5 test results, "
            f"but found {len(data)} records."
        )

    def test_json_records_have_required_fields(self):
        """Verify that each JSON record has the required fields for CSV extraction."""
        json_file = "/home/user/results/run_output.json"
        required_fields = {"test_name", "status", "duration_ms"}

        with open(json_file, 'r') as f:
            data = json.load(f)

        for i, record in enumerate(data):
            assert isinstance(record, dict), (
                f"Record {i} in {json_file} is not a JSON object. "
                f"Expected dict, got {type(record).__name__}."
            )
            missing_fields = required_fields - set(record.keys())
            assert not missing_fields, (
                f"Record {i} in {json_file} is missing required fields: {missing_fields}. "
                "Each test result must have test_name, status, and duration_ms fields."
            )

    def test_json_content_matches_expected(self):
        """Verify that the JSON content matches the expected test results."""
        json_file = "/home/user/results/run_output.json"
        expected_data = [
            {"test_name": "test_login", "status": "passed", "duration_ms": 142, "suite": "auth", "timestamp": "2024-01-15T10:23:01Z"},
            {"test_name": "test_logout", "status": "passed", "duration_ms": 89, "suite": "auth", "timestamp": "2024-01-15T10:23:02Z"},
            {"test_name": "test_signup_validation", "status": "failed", "duration_ms": 203, "suite": "auth", "timestamp": "2024-01-15T10:23:03Z"},
            {"test_name": "test_dashboard_load", "status": "passed", "duration_ms": 567, "suite": "ui", "timestamp": "2024-01-15T10:23:05Z"},
            {"test_name": "test_api_health", "status": "passed", "duration_ms": 31, "suite": "api", "timestamp": "2024-01-15T10:23:06Z"}
        ]

        with open(json_file, 'r') as f:
            data = json.load(f)

        assert data == expected_data, (
            f"File {json_file} content does not match expected test results. "
            "The JSON file should contain the specific test result data for this task."
        )

    def test_python3_available(self):
        """Verify that Python 3.11+ is available."""
        result = subprocess.run(
            ["python3", "--version"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "Python 3 is not available. "
            "Python 3.11+ must be installed to perform this task."
        )

        # Parse version
        version_output = result.stdout.strip()
        # Format: "Python 3.x.y"
        version_parts = version_output.split()[1].split('.')
        major = int(version_parts[0])
        minor = int(version_parts[1])

        assert major == 3 and minor >= 11, (
            f"Python version {version_output} found, but Python 3.11+ is required."
        )

    def test_python_json_module_available(self):
        """Verify that Python json module is available."""
        result = subprocess.run(
            ["python3", "-c", "import json; print('ok')"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0 and "ok" in result.stdout, (
            "Python json module is not available. "
            "The json module is required for parsing the input file."
        )

    def test_python_csv_module_available(self):
        """Verify that Python csv module is available."""
        result = subprocess.run(
            ["python3", "-c", "import csv; print('ok')"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0 and "ok" in result.stdout, (
            "Python csv module is not available. "
            "The csv module is required for creating the output file."
        )

    def test_jq_installed(self):
        """Verify that jq is installed."""
        assert shutil.which("jq") is not None, (
            "jq is not installed or not in PATH. "
            "jq should be available as an alternative tool for JSON processing."
        )

    def test_csv_output_file_does_not_exist(self):
        """Verify that the output CSV file does not already exist."""
        csv_file = "/home/user/results/run_output.csv"
        assert not os.path.exists(csv_file), (
            f"File {csv_file} already exists. "
            "The output file should not exist before the task is performed."
        )
