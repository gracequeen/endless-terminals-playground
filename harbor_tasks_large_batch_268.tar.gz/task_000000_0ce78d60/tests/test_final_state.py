# test_final_state.py
"""
Tests to validate the final state after the student has completed the JSON to CSV conversion task.
"""

import csv
import json
import os
import pytest


class TestFinalState:
    """Validate the operating system and filesystem state after the task is completed."""

    def test_csv_file_exists(self):
        """Verify that /home/user/results/run_output.csv exists."""
        csv_file = "/home/user/results/run_output.csv"
        assert os.path.isfile(csv_file), (
            f"File {csv_file} does not exist. "
            "The CSV output file must be created as part of this task."
        )

    def test_csv_file_is_readable(self):
        """Verify that /home/user/results/run_output.csv is readable."""
        csv_file = "/home/user/results/run_output.csv"
        assert os.access(csv_file, os.R_OK), (
            f"File {csv_file} is not readable. "
            "The CSV output file must be readable."
        )

    def test_csv_file_not_empty(self):
        """Verify that the CSV file is not empty."""
        csv_file = "/home/user/results/run_output.csv"
        file_size = os.path.getsize(csv_file)
        assert file_size > 0, (
            f"File {csv_file} is empty. "
            "The CSV file should contain header and data rows."
        )

    def test_csv_has_correct_header(self):
        """Verify that the CSV file has the correct header row."""
        csv_file = "/home/user/results/run_output.csv"
        expected_header = ["test_name", "status", "duration_ms"]

        with open(csv_file, 'r', newline='') as f:
            reader = csv.reader(f)
            try:
                header = next(reader)
            except StopIteration:
                pytest.fail(f"File {csv_file} is empty, no header row found.")

        assert header == expected_header, (
            f"CSV header is incorrect. "
            f"Expected: {expected_header}, Got: {header}. "
            "The header must be exactly: test_name,status,duration_ms"
        )

    def test_csv_has_exactly_five_data_rows(self):
        """Verify that the CSV file has exactly 5 data rows (plus header)."""
        csv_file = "/home/user/results/run_output.csv"

        with open(csv_file, 'r', newline='') as f:
            reader = csv.reader(f)
            rows = list(reader)

        # Should have 1 header + 5 data rows = 6 total rows
        data_row_count = len(rows) - 1  # Subtract header
        assert data_row_count == 5, (
            f"CSV file should have exactly 5 data rows, but found {data_row_count}. "
            "There should be one row for each test result from the JSON file."
        )

    def test_csv_data_rows_have_three_columns(self):
        """Verify that each data row has exactly 3 columns."""
        csv_file = "/home/user/results/run_output.csv"

        with open(csv_file, 'r', newline='') as f:
            reader = csv.reader(f)
            next(reader)  # Skip header
            for i, row in enumerate(reader, start=1):
                assert len(row) == 3, (
                    f"Data row {i} has {len(row)} columns, expected 3. "
                    f"Row content: {row}. "
                    "Each row must have test_name, status, and duration_ms."
                )

    def test_csv_contains_correct_test_names(self):
        """Verify that the CSV contains the correct test names."""
        csv_file = "/home/user/results/run_output.csv"
        expected_test_names = {
            "test_login",
            "test_logout",
            "test_signup_validation",
            "test_dashboard_load",
            "test_api_health"
        }

        with open(csv_file, 'r', newline='') as f:
            reader = csv.DictReader(f)
            actual_test_names = {row["test_name"] for row in reader}

        assert actual_test_names == expected_test_names, (
            f"CSV test names do not match expected. "
            f"Expected: {expected_test_names}, Got: {actual_test_names}. "
            f"Missing: {expected_test_names - actual_test_names}, "
            f"Extra: {actual_test_names - expected_test_names}"
        )

    def test_csv_contains_correct_data(self):
        """Verify that the CSV contains the correct data for all test results."""
        csv_file = "/home/user/results/run_output.csv"

        # Expected data as a dict keyed by test_name for easier comparison
        expected_data = {
            "test_login": {"status": "passed", "duration_ms": "142"},
            "test_logout": {"status": "passed", "duration_ms": "89"},
            "test_signup_validation": {"status": "failed", "duration_ms": "203"},
            "test_dashboard_load": {"status": "passed", "duration_ms": "567"},
            "test_api_health": {"status": "passed", "duration_ms": "31"}
        }

        with open(csv_file, 'r', newline='') as f:
            reader = csv.DictReader(f)
            for row in reader:
                test_name = row["test_name"]
                assert test_name in expected_data, (
                    f"Unexpected test name '{test_name}' found in CSV."
                )

                expected = expected_data[test_name]
                assert row["status"] == expected["status"], (
                    f"Status mismatch for '{test_name}'. "
                    f"Expected: {expected['status']}, Got: {row['status']}"
                )

                # Compare duration_ms as strings (CSV values are strings)
                assert str(row["duration_ms"]) == expected["duration_ms"], (
                    f"Duration mismatch for '{test_name}'. "
                    f"Expected: {expected['duration_ms']}, Got: {row['duration_ms']}"
                )

    def test_csv_row_order_matches_json(self):
        """Verify that the CSV rows are in the same order as the JSON array."""
        csv_file = "/home/user/results/run_output.csv"
        expected_order = [
            "test_login",
            "test_logout",
            "test_signup_validation",
            "test_dashboard_load",
            "test_api_health"
        ]

        with open(csv_file, 'r', newline='') as f:
            reader = csv.DictReader(f)
            actual_order = [row["test_name"] for row in reader]

        assert actual_order == expected_order, (
            f"CSV row order does not match JSON order. "
            f"Expected: {expected_order}, Got: {actual_order}"
        )

    def test_json_file_unchanged(self):
        """Verify that the original JSON file is unchanged."""
        json_file = "/home/user/results/run_output.json"

        expected_data = [
            {"test_name": "test_login", "status": "passed", "duration_ms": 142, "suite": "auth", "timestamp": "2024-01-15T10:23:01Z"},
            {"test_name": "test_logout", "status": "passed", "duration_ms": 89, "suite": "auth", "timestamp": "2024-01-15T10:23:02Z"},
            {"test_name": "test_signup_validation", "status": "failed", "duration_ms": 203, "suite": "auth", "timestamp": "2024-01-15T10:23:03Z"},
            {"test_name": "test_dashboard_load", "status": "passed", "duration_ms": 567, "suite": "ui", "timestamp": "2024-01-15T10:23:05Z"},
            {"test_name": "test_api_health", "status": "passed", "duration_ms": 31, "suite": "api", "timestamp": "2024-01-15T10:23:06Z"}
        ]

        assert os.path.isfile(json_file), (
            f"File {json_file} no longer exists. "
            "The original JSON file must not be deleted."
        )

        with open(json_file, 'r') as f:
            actual_data = json.load(f)

        assert actual_data == expected_data, (
            f"File {json_file} has been modified. "
            "The original JSON file must remain unchanged."
        )

    def test_csv_column_order(self):
        """Verify that CSV columns are in the correct order: test_name, status, duration_ms."""
        csv_file = "/home/user/results/run_output.csv"

        with open(csv_file, 'r', newline='') as f:
            reader = csv.reader(f)
            header = next(reader)

            # Verify column order by checking header
            assert header[0] == "test_name", (
                f"First column should be 'test_name', got '{header[0]}'"
            )
            assert header[1] == "status", (
                f"Second column should be 'status', got '{header[1]}'"
            )
            assert header[2] == "duration_ms", (
                f"Third column should be 'duration_ms', got '{header[2]}'"
            )

            # Also verify a data row has values in correct positions
            first_row = next(reader)
            assert first_row[0] == "test_login", (
                f"First data row, first column should be 'test_login', got '{first_row[0]}'"
            )
            assert first_row[1] == "passed", (
                f"First data row, second column should be 'passed', got '{first_row[1]}'"
            )
            assert first_row[2] == "142", (
                f"First data row, third column should be '142', got '{first_row[2]}'"
            )
