# test_final_state.py
"""
Tests to validate the final state of the system after the student has
dumped the top 5 processes by RSS to /home/user/memhogs.txt.
"""

import os
import subprocess
import pytest


class TestOutputFileExists:
    """Test that the output file exists and has correct properties."""

    def test_memhogs_file_exists(self):
        """Verify /home/user/memhogs.txt exists."""
        assert os.path.exists("/home/user/memhogs.txt"), \
            "/home/user/memhogs.txt does not exist - task not completed"

    def test_memhogs_file_is_regular_file(self):
        """Verify /home/user/memhogs.txt is a regular file."""
        assert os.path.isfile("/home/user/memhogs.txt"), \
            "/home/user/memhogs.txt is not a regular file"

    def test_memhogs_file_is_readable(self):
        """Verify /home/user/memhogs.txt is readable."""
        assert os.access("/home/user/memhogs.txt", os.R_OK), \
            "/home/user/memhogs.txt is not readable"


class TestFileLineCount:
    """Test that the file contains exactly 5 lines."""

    def test_exactly_five_lines(self):
        """Verify file contains exactly 5 lines (no header)."""
        with open("/home/user/memhogs.txt", "r") as f:
            content = f.read()

        # Count non-empty lines
        lines = [line for line in content.split('\n') if line.strip()]
        assert len(lines) == 5, \
            f"Expected exactly 5 lines, found {len(lines)} lines"

    def test_wc_l_returns_five(self):
        """Verify wc -l returns 5 for the file."""
        result = subprocess.run(
            ["wc", "-l"],
            stdin=open("/home/user/memhogs.txt", "r"),
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "Failed to run wc -l"
        line_count = int(result.stdout.strip().split()[0])
        assert line_count == 5, \
            f"wc -l returned {line_count}, expected 5"


class TestLineFormat:
    """Test that each line has the correct format: PID RSS_KB COMMAND."""

    def test_each_line_has_three_fields(self):
        """Verify each line has exactly 3 whitespace-separated fields."""
        with open("/home/user/memhogs.txt", "r") as f:
            lines = [line for line in f.read().split('\n') if line.strip()]

        for i, line in enumerate(lines, 1):
            fields = line.split()
            assert len(fields) == 3, \
                f"Line {i} has {len(fields)} fields, expected 3: '{line}'"

    def test_awk_field_count_check(self):
        """Verify awk NF!=3 check passes (all lines have 3 fields)."""
        result = subprocess.run(
            ["awk", "NF!=3{exit 1}"],
            stdin=open("/home/user/memhogs.txt", "r"),
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            "Not all lines have exactly 3 fields (awk NF!=3 check failed)"

    def test_pid_field_is_numeric(self):
        """Verify the PID field (first column) is numeric."""
        with open("/home/user/memhogs.txt", "r") as f:
            lines = [line for line in f.read().split('\n') if line.strip()]

        for i, line in enumerate(lines, 1):
            fields = line.split()
            pid = fields[0]
            assert pid.isdigit(), \
                f"Line {i}: PID field '{pid}' is not numeric"

    def test_rss_field_is_numeric(self):
        """Verify the RSS_KB field (second column) is numeric."""
        with open("/home/user/memhogs.txt", "r") as f:
            lines = [line for line in f.read().split('\n') if line.strip()]

        for i, line in enumerate(lines, 1):
            fields = line.split()
            rss = fields[1]
            assert rss.isdigit(), \
                f"Line {i}: RSS_KB field '{rss}' is not numeric"

    def test_command_field_is_non_empty(self):
        """Verify the COMMAND field (third column) is non-empty."""
        with open("/home/user/memhogs.txt", "r") as f:
            lines = [line for line in f.read().split('\n') if line.strip()]

        for i, line in enumerate(lines, 1):
            fields = line.split()
            command = fields[2]
            assert len(command) > 0, \
                f"Line {i}: COMMAND field is empty"


class TestSortOrder:
    """Test that lines are sorted by RSS in descending order."""

    def test_rss_descending_order(self):
        """Verify RSS values are in descending order (highest first)."""
        with open("/home/user/memhogs.txt", "r") as f:
            lines = [line for line in f.read().split('\n') if line.strip()]

        rss_values = []
        for line in lines:
            fields = line.split()
            rss_values.append(int(fields[1]))

        for i in range(len(rss_values) - 1):
            assert rss_values[i] >= rss_values[i + 1], \
                f"RSS values not in descending order: {rss_values[i]} < {rss_values[i + 1]} at lines {i + 1} and {i + 2}"

    def test_awk_descending_order_check(self):
        """Verify awk descending order check passes."""
        result = subprocess.run(
            ["awk", "NR>1 && $2>prev{exit 1} {prev=$2}"],
            stdin=open("/home/user/memhogs.txt", "r"),
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            "RSS column is not in descending order (awk check failed)"


class TestFileEnding:
    """Test that the file ends with a newline."""

    def test_file_ends_with_newline(self):
        """Verify file ends with a newline character."""
        with open("/home/user/memhogs.txt", "rb") as f:
            content = f.read()

        assert len(content) > 0, "File is empty"
        assert content[-1:] == b'\n', \
            "File does not end with a newline character"


class TestDataValidity:
    """Test that the data in the file represents valid process information."""

    def test_pids_are_reasonable(self):
        """Verify PIDs are reasonable positive integers."""
        with open("/home/user/memhogs.txt", "r") as f:
            lines = [line for line in f.read().split('\n') if line.strip()]

        for i, line in enumerate(lines, 1):
            fields = line.split()
            pid = int(fields[0])
            assert pid > 0, \
                f"Line {i}: PID {pid} should be positive"
            assert pid < 10000000, \
                f"Line {i}: PID {pid} seems unreasonably large"

    def test_rss_values_are_reasonable(self):
        """Verify RSS values are reasonable (non-negative)."""
        with open("/home/user/memhogs.txt", "r") as f:
            lines = [line for line in f.read().split('\n') if line.strip()]

        for i, line in enumerate(lines, 1):
            fields = line.split()
            rss = int(fields[1])
            assert rss >= 0, \
                f"Line {i}: RSS {rss} should be non-negative"
