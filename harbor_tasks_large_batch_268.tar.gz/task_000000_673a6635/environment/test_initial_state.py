# test_initial_state.py
"""
Tests to validate the initial state of the system before the student performs
the task of dumping top 5 processes by RSS to /home/user/memhogs.txt.
"""

import os
import subprocess
import shutil
import pytest


class TestRequiredCommands:
    """Test that required commands are available."""

    def test_ps_command_available(self):
        """Verify ps command is available."""
        assert shutil.which("ps") is not None, "ps command is not available"

    def test_awk_command_available(self):
        """Verify awk command is available."""
        assert shutil.which("awk") is not None, "awk command is not available"

    def test_sort_command_available(self):
        """Verify sort command is available."""
        assert shutil.which("sort") is not None, "sort command is not available"

    def test_head_command_available(self):
        """Verify head command is available."""
        assert shutil.which("head") is not None, "head command is not available"


class TestHomeDirectory:
    """Test that /home/user directory exists and is writable."""

    def test_home_user_exists(self):
        """Verify /home/user directory exists."""
        assert os.path.exists("/home/user"), "/home/user directory does not exist"

    def test_home_user_is_directory(self):
        """Verify /home/user is a directory."""
        assert os.path.isdir("/home/user"), "/home/user is not a directory"

    def test_home_user_is_writable(self):
        """Verify /home/user directory is writable."""
        assert os.access("/home/user", os.W_OK), "/home/user directory is not writable"


class TestOutputFileDoesNotExist:
    """Test that the output file does not exist initially."""

    def test_memhogs_file_does_not_exist(self):
        """Verify /home/user/memhogs.txt does not exist."""
        assert not os.path.exists("/home/user/memhogs.txt"), \
            "/home/user/memhogs.txt already exists - it should not exist before the task"


class TestProcessesRunning:
    """Test that there are processes running on the system."""

    def test_processes_exist(self):
        """Verify that processes are running on the system."""
        result = subprocess.run(
            ["ps", "-e", "--no-headers"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "Failed to run ps command"
        lines = result.stdout.strip().split('\n')
        assert len(lines) >= 5, \
            f"Expected at least 5 processes running, found {len(lines)}"

    def test_ps_can_show_rss(self):
        """Verify that ps can display RSS memory information."""
        result = subprocess.run(
            ["ps", "-e", "-o", "pid,rss,comm", "--no-headers"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "Failed to run ps with RSS output"
        lines = result.stdout.strip().split('\n')
        assert len(lines) > 0, "ps returned no output with RSS format"

        # Verify at least one line has the expected format (3 fields)
        for line in lines[:5]:
            fields = line.split()
            assert len(fields) >= 2, \
                f"ps output line does not have expected format: {line}"

    def test_memory_consuming_processes_exist(self):
        """Verify that there are processes consuming memory (RSS > 0)."""
        result = subprocess.run(
            ["ps", "-e", "-o", "pid,rss,comm", "--no-headers"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "Failed to run ps command"

        processes_with_memory = 0
        for line in result.stdout.strip().split('\n'):
            fields = line.split()
            if len(fields) >= 2:
                try:
                    rss = int(fields[1])
                    if rss > 0:
                        processes_with_memory += 1
                except ValueError:
                    continue

        assert processes_with_memory >= 5, \
            f"Expected at least 5 processes with RSS > 0, found {processes_with_memory}"


class TestSystemEnvironment:
    """Test basic system environment requirements."""

    def test_is_linux_system(self):
        """Verify we're running on a Linux system."""
        result = subprocess.run(["uname", "-s"], capture_output=True, text=True)
        assert result.returncode == 0, "Failed to run uname command"
        assert "Linux" in result.stdout, "System is not Linux"

    def test_proc_filesystem_available(self):
        """Verify /proc filesystem is available (needed for process info)."""
        assert os.path.exists("/proc"), "/proc filesystem is not available"
        assert os.path.isdir("/proc"), "/proc is not a directory"
