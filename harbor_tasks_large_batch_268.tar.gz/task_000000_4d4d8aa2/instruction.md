I'm trying to get our release pipeline working on the new build server and the venv is acting weird. Created it at /home/user/deploy/venv, installed requirements.txt, and `python -m pytest tests/` passes fine when I run it from /home/user/deploy. But when I activate the same venv from a different working directory — say cd to /tmp and then source the activate script and run pytest on the same tests — half the imports fail with ModuleNotFoundError for our internal packages.

Same venv, same python, same activate script. Only difference is pwd. That shouldn't matter? The packages are definitely in site-packages, I can see them. But somehow the interpreter only finds them when I'm standing in /home/user/deploy.

Need this working from any directory because the deployment runner cds around. Don't mess with the system python or install anything globally — we have to keep it isolated.
