# test_final_state.py
"""
Tests to validate the final state after the student has fixed the venv import issue.
The deploytool package should be properly installed and importable from any directory.
"""

import os
import subprocess
import sys

import pytest


DEPLOY_DIR = "/home/user/deploy"
VENV_DIR = "/home/user/deploy/venv"
SITE_PACKAGES = "/home/user/deploy/venv/lib/python3.10/site-packages"
VENV_PYTHON = "/home/user/deploy/venv/bin/python"
VENV_PIP = "/home/user/deploy/venv/bin/pip"


class TestDeploytoolProperlyInstalled:
    """Test that deploytool is now properly installed in the venv."""

    def test_pip_show_deploytool_succeeds(self):
        """pip show deploytool should succeed, indicating proper installation."""
        result = subprocess.run(
            [VENV_PIP, "show", "deploytool"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            f"deploytool is not properly installed (pip show failed): {result.stderr}"

    def test_pip_show_location_in_venv(self):
        """pip show should indicate the package is in the venv's site-packages."""
        result = subprocess.run(
            [VENV_PIP, "show", "deploytool"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            f"pip show deploytool failed: {result.stderr}"

        # Parse the output to find Location
        output = result.stdout
        location_found = False
        for line in output.splitlines():
            if line.startswith("Location:"):
                location = line.split(":", 1)[1].strip()
                # Location should be within the venv
                assert VENV_DIR in location or "site-packages" in location, \
                    f"deploytool Location should be in venv but is: {location}"
                location_found = True
                break

        # For editable installs, check for Editable project location
        if not location_found:
            for line in output.splitlines():
                if "Editable" in line and "location" in line.lower():
                    location_found = True
                    break

        assert location_found or "Location:" in output, \
            f"Could not find Location in pip show output: {output}"


class TestImportFromAnyDirectory:
    """Test that deploytool can be imported from any working directory."""

    def test_import_from_tmp(self):
        """Import should work when cwd is /tmp."""
        result = subprocess.run(
            [VENV_PYTHON, "-c", "from deploytool import core; print('ok')"],
            capture_output=True,
            text=True,
            cwd="/tmp"
        )
        assert result.returncode == 0, \
            f"Import failed from /tmp: {result.stderr}"
        assert "ok" in result.stdout, \
            f"Expected 'ok' in output but got: {result.stdout}"

    def test_import_from_var(self):
        """Import should work when cwd is /var."""
        result = subprocess.run(
            [VENV_PYTHON, "-c", "from deploytool import core; print('ok')"],
            capture_output=True,
            text=True,
            cwd="/var"
        )
        assert result.returncode == 0, \
            f"Import failed from /var: {result.stderr}"
        assert "ok" in result.stdout, \
            f"Expected 'ok' in output but got: {result.stdout}"

    def test_import_from_root(self):
        """Import should work when cwd is /."""
        result = subprocess.run(
            [VENV_PYTHON, "-c", "from deploytool import core; print('ok')"],
            capture_output=True,
            text=True,
            cwd="/"
        )
        assert result.returncode == 0, \
            f"Import failed from /: {result.stderr}"
        assert "ok" in result.stdout, \
            f"Expected 'ok' in output but got: {result.stdout}"

    def test_import_from_deploy_dir(self):
        """Import should still work from the deploy directory."""
        result = subprocess.run(
            [VENV_PYTHON, "-c", "from deploytool import core; print('ok')"],
            capture_output=True,
            text=True,
            cwd=DEPLOY_DIR
        )
        assert result.returncode == 0, \
            f"Import failed from {DEPLOY_DIR}: {result.stderr}"
        assert "ok" in result.stdout, \
            f"Expected 'ok' in output but got: {result.stdout}"


class TestPytestFromAnyDirectory:
    """Test that pytest runs successfully from any directory."""

    def test_pytest_from_tmp(self):
        """pytest should pass when run from /tmp."""
        result = subprocess.run(
            [VENV_PYTHON, "-m", "pytest", f"{DEPLOY_DIR}/tests/", "-v"],
            capture_output=True,
            text=True,
            cwd="/tmp"
        )
        assert result.returncode == 0, \
            f"pytest failed from /tmp (exit code {result.returncode}):\nstdout: {result.stdout}\nstderr: {result.stderr}"

    def test_pytest_from_var(self):
        """pytest should pass when run from /var."""
        result = subprocess.run(
            [VENV_PYTHON, "-m", "pytest", f"{DEPLOY_DIR}/tests/", "-v"],
            capture_output=True,
            text=True,
            cwd="/var"
        )
        assert result.returncode == 0, \
            f"pytest failed from /var (exit code {result.returncode}):\nstdout: {result.stdout}\nstderr: {result.stderr}"

    def test_pytest_from_deploy_dir(self):
        """pytest should still pass from the deploy directory."""
        result = subprocess.run(
            [VENV_PYTHON, "-m", "pytest", "tests/", "-v"],
            capture_output=True,
            text=True,
            cwd=DEPLOY_DIR
        )
        assert result.returncode == 0, \
            f"pytest failed from {DEPLOY_DIR} (exit code {result.returncode}):\nstdout: {result.stdout}\nstderr: {result.stderr}"


class TestShellActivationWorks:
    """Test that activating the venv via shell script works from any directory."""

    def test_shell_activation_from_tmp(self):
        """Activating venv and importing should work via shell from /tmp."""
        script = f"""
cd /tmp
source {VENV_DIR}/bin/activate
python -c "from deploytool import core; print('ok')"
"""
        result = subprocess.run(
            ["bash", "-c", script],
            capture_output=True,
            text=True,
            env={}  # Fresh environment, no PYTHONPATH
        )
        assert result.returncode == 0, \
            f"Shell activation and import failed from /tmp: {result.stderr}"
        assert "ok" in result.stdout, \
            f"Expected 'ok' in output but got: {result.stdout}"

    def test_shell_activation_from_var(self):
        """Activating venv and importing should work via shell from /var."""
        script = f"""
cd /var
source {VENV_DIR}/bin/activate
python -c "from deploytool import core; print('ok')"
"""
        result = subprocess.run(
            ["bash", "-c", script],
            capture_output=True,
            text=True,
            env={}  # Fresh environment, no PYTHONPATH
        )
        assert result.returncode == 0, \
            f"Shell activation and import failed from /var: {result.stderr}"
        assert "ok" in result.stdout, \
            f"Expected 'ok' in output but got: {result.stdout}"


class TestInvariants:
    """Test that invariants are maintained."""

    def test_venv_still_exists(self):
        """The venv should still exist at the original location."""
        assert os.path.isdir(VENV_DIR), \
            f"Venv directory {VENV_DIR} no longer exists"

    def test_deploytool_source_unchanged(self):
        """The deploytool source directory should still exist."""
        deploytool_dir = os.path.join(DEPLOY_DIR, "deploytool")
        assert os.path.isdir(deploytool_dir), \
            f"deploytool source directory {deploytool_dir} no longer exists"

        init_file = os.path.join(deploytool_dir, "__init__.py")
        assert os.path.isfile(init_file), \
            f"deploytool/__init__.py no longer exists"

        core_file = os.path.join(deploytool_dir, "core.py")
        assert os.path.isfile(core_file), \
            f"deploytool/core.py no longer exists"

    def test_setup_py_unchanged(self):
        """setup.py should still exist."""
        setup_file = os.path.join(DEPLOY_DIR, "setup.py")
        assert os.path.isfile(setup_file), \
            f"setup.py no longer exists at {setup_file}"

    def test_tests_directory_exists(self):
        """The tests directory should still exist."""
        tests_dir = os.path.join(DEPLOY_DIR, "tests")
        assert os.path.isdir(tests_dir), \
            f"tests directory {tests_dir} no longer exists"


class TestNoSystemPythonModification:
    """Test that system Python was not modified."""

    def test_deploytool_not_in_system_python(self):
        """deploytool should not be importable from system Python."""
        # Try to import deploytool using system python3, should fail
        result = subprocess.run(
            ["python3", "-c", "import deploytool"],
            capture_output=True,
            text=True,
            cwd="/tmp",
            env={"PATH": "/usr/bin:/bin"}  # Ensure we use system python
        )
        # This should fail because deploytool should only be in the venv
        # However, if system python IS the venv python, this test is not applicable
        # We check that it's not globally installed by checking pip3 show
        result = subprocess.run(
            ["pip3", "show", "deploytool"],
            capture_output=True,
            text=True,
            env={"PATH": "/usr/bin:/bin"}
        )
        # If pip3 exists and shows deploytool, that's a problem
        # But pip3 might not exist or might be the same as venv pip
        # More reliable: check /usr/lib/python* and /usr/local/lib/python*
        pass  # This is hard to test reliably without knowing system config

    def test_no_deploytool_in_usr_lib(self):
        """deploytool should not be installed in /usr/lib/python*."""
        import glob
        patterns = [
            "/usr/lib/python*/site-packages/deploytool*",
            "/usr/lib/python*/dist-packages/deploytool*",
            "/usr/local/lib/python*/site-packages/deploytool*",
            "/usr/local/lib/python*/dist-packages/deploytool*",
        ]
        for pattern in patterns:
            matches = glob.glob(pattern)
            assert len(matches) == 0, \
                f"deploytool found in system Python location: {matches}"


class TestNoPythonPathDependency:
    """Test that the fix doesn't rely on PYTHONPATH."""

    def test_import_works_without_pythonpath(self):
        """Import should work even with PYTHONPATH explicitly unset."""
        result = subprocess.run(
            [VENV_PYTHON, "-c", "import os; os.environ.pop('PYTHONPATH', None); from deploytool import core; print('ok')"],
            capture_output=True,
            text=True,
            cwd="/tmp",
            env={"PATH": os.environ.get("PATH", "/usr/bin:/bin")}  # No PYTHONPATH
        )
        assert result.returncode == 0, \
            f"Import failed without PYTHONPATH: {result.stderr}"
        assert "ok" in result.stdout, \
            f"Expected 'ok' in output but got: {result.stdout}"

    def test_fresh_shell_no_exports(self):
        """Test in a completely fresh shell environment."""
        script = f"""
unset PYTHONPATH
cd /tmp
{VENV_PYTHON} -c "from deploytool import core; print('ok')"
"""
        result = subprocess.run(
            ["bash", "-c", script],
            capture_output=True,
            text=True,
            env={"PATH": "/usr/bin:/bin", "HOME": "/tmp"}  # Minimal environment
        )
        assert result.returncode == 0, \
            f"Import failed in fresh shell: {result.stderr}"
        assert "ok" in result.stdout, \
            f"Expected 'ok' in output but got: {result.stdout}"


class TestOtherVenvPackagesStillWork:
    """Test that other packages in the venv still work."""

    def test_requests_still_importable(self):
        """requests should still be importable."""
        result = subprocess.run(
            [VENV_PYTHON, "-c", "import requests; print(requests.__version__)"],
            capture_output=True,
            text=True,
            cwd="/tmp"
        )
        assert result.returncode == 0, \
            f"requests import failed: {result.stderr}"

    def test_pytest_still_importable(self):
        """pytest should still be importable."""
        result = subprocess.run(
            [VENV_PYTHON, "-c", "import pytest; print(pytest.__version__)"],
            capture_output=True,
            text=True,
            cwd="/tmp"
        )
        assert result.returncode == 0, \
            f"pytest import failed: {result.stderr}"
