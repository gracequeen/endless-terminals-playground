# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the action to fix the venv import issue.
"""

import os
import subprocess
import sys

import pytest


HOME = "/home/user"
DEPLOY_DIR = "/home/user/deploy"
VENV_DIR = "/home/user/deploy/venv"
SITE_PACKAGES = "/home/user/deploy/venv/lib/python3.10/site-packages"
PTH_FILE = f"{SITE_PACKAGES}/local.pth"


class TestDirectoryStructure:
    """Test that the expected directory structure exists."""

    def test_deploy_directory_exists(self):
        assert os.path.isdir(DEPLOY_DIR), f"Deploy directory {DEPLOY_DIR} does not exist"

    def test_venv_directory_exists(self):
        assert os.path.isdir(VENV_DIR), f"Venv directory {VENV_DIR} does not exist"

    def test_deploytool_directory_exists(self):
        deploytool_dir = os.path.join(DEPLOY_DIR, "deploytool")
        assert os.path.isdir(deploytool_dir), f"deploytool package directory {deploytool_dir} does not exist"

    def test_tests_directory_exists(self):
        tests_dir = os.path.join(DEPLOY_DIR, "tests")
        assert os.path.isdir(tests_dir), f"tests directory {tests_dir} does not exist"

    def test_site_packages_exists(self):
        assert os.path.isdir(SITE_PACKAGES), f"Site-packages directory {SITE_PACKAGES} does not exist"


class TestRequiredFiles:
    """Test that required files exist."""

    def test_requirements_txt_exists(self):
        req_file = os.path.join(DEPLOY_DIR, "requirements.txt")
        assert os.path.isfile(req_file), f"requirements.txt not found at {req_file}"

    def test_setup_py_exists(self):
        setup_file = os.path.join(DEPLOY_DIR, "setup.py")
        assert os.path.isfile(setup_file), f"setup.py not found at {setup_file}"

    def test_deploytool_init_exists(self):
        init_file = os.path.join(DEPLOY_DIR, "deploytool", "__init__.py")
        assert os.path.isfile(init_file), f"deploytool/__init__.py not found at {init_file}"

    def test_deploytool_core_exists(self):
        core_file = os.path.join(DEPLOY_DIR, "deploytool", "core.py")
        assert os.path.isfile(core_file), f"deploytool/core.py not found at {core_file}"

    def test_test_core_exists(self):
        test_file = os.path.join(DEPLOY_DIR, "tests", "test_core.py")
        assert os.path.isfile(test_file), f"tests/test_core.py not found at {test_file}"

    def test_venv_activate_script_exists(self):
        activate_script = os.path.join(VENV_DIR, "bin", "activate")
        assert os.path.isfile(activate_script), f"venv activate script not found at {activate_script}"

    def test_venv_python_exists(self):
        venv_python = os.path.join(VENV_DIR, "bin", "python")
        assert os.path.isfile(venv_python) or os.path.islink(venv_python), \
            f"venv python not found at {venv_python}"


class TestPthFileIssue:
    """Test that the problematic .pth file exists with the incorrect content."""

    def test_local_pth_file_exists(self):
        assert os.path.isfile(PTH_FILE), \
            f"The problematic local.pth file does not exist at {PTH_FILE}"

    def test_local_pth_contains_dot(self):
        with open(PTH_FILE, "r") as f:
            content = f.read().strip()
        assert content == ".", \
            f"local.pth should contain just '.' but contains: {repr(content)}"


class TestVenvPackages:
    """Test that the venv has the required packages installed."""

    def test_requests_installed(self):
        venv_python = os.path.join(VENV_DIR, "bin", "python")
        result = subprocess.run(
            [venv_python, "-c", "import requests; print(requests.__version__)"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            f"requests package not installed in venv: {result.stderr}"

    def test_pytest_installed(self):
        venv_python = os.path.join(VENV_DIR, "bin", "python")
        result = subprocess.run(
            [venv_python, "-c", "import pytest; print(pytest.__version__)"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            f"pytest package not installed in venv: {result.stderr}"


class TestDeploytoolNotProperlyInstalled:
    """Test that deploytool is NOT properly installed (the bug condition)."""

    def test_deploytool_not_in_pip_list(self):
        """deploytool should NOT appear in pip list as a properly installed package."""
        venv_pip = os.path.join(VENV_DIR, "bin", "pip")
        result = subprocess.run(
            [venv_pip, "show", "deploytool"],
            capture_output=True,
            text=True
        )
        # pip show returns non-zero if package not found
        assert result.returncode != 0, \
            "deploytool should NOT be properly installed yet (pip show should fail)"


class TestImportBehavior:
    """Test that the import works from deploy dir but fails from other dirs."""

    def test_import_works_from_deploy_dir(self):
        """Import should work when cwd is /home/user/deploy (due to the . in .pth)."""
        venv_python = os.path.join(VENV_DIR, "bin", "python")
        result = subprocess.run(
            [venv_python, "-c", "from deploytool import core; print('ok')"],
            capture_output=True,
            text=True,
            cwd=DEPLOY_DIR
        )
        assert result.returncode == 0 and "ok" in result.stdout, \
            f"Import should work from {DEPLOY_DIR} but failed: {result.stderr}"

    def test_import_fails_from_tmp(self):
        """Import should FAIL when cwd is /tmp (the bug we're testing for)."""
        venv_python = os.path.join(VENV_DIR, "bin", "python")
        result = subprocess.run(
            [venv_python, "-c", "from deploytool import core; print('ok')"],
            capture_output=True,
            text=True,
            cwd="/tmp"
        )
        assert result.returncode != 0, \
            "Import should FAIL from /tmp (this is the bug condition that needs fixing)"
        assert "ModuleNotFoundError" in result.stderr or "No module named" in result.stderr, \
            f"Expected ModuleNotFoundError but got: {result.stderr}"


class TestSetupPyContent:
    """Test that setup.py has the expected content."""

    def test_setup_py_has_deploytool_package(self):
        setup_file = os.path.join(DEPLOY_DIR, "setup.py")
        with open(setup_file, "r") as f:
            content = f.read()
        assert "deploytool" in content, \
            "setup.py should reference 'deploytool' package"
        assert "setup(" in content or "setup (" in content, \
            "setup.py should contain a setup() call"


class TestRequirementsTxtContent:
    """Test that requirements.txt has the expected content."""

    def test_requirements_has_requests(self):
        req_file = os.path.join(DEPLOY_DIR, "requirements.txt")
        with open(req_file, "r") as f:
            content = f.read().lower()
        assert "requests" in content, \
            "requirements.txt should contain requests"

    def test_requirements_has_pytest(self):
        req_file = os.path.join(DEPLOY_DIR, "requirements.txt")
        with open(req_file, "r") as f:
            content = f.read().lower()
        assert "pytest" in content, \
            "requirements.txt should contain pytest"


class TestTestFileContent:
    """Test that the test file imports deploytool."""

    def test_test_core_imports_deploytool(self):
        test_file = os.path.join(DEPLOY_DIR, "tests", "test_core.py")
        with open(test_file, "r") as f:
            content = f.read()
        assert "from deploytool import core" in content or "import deploytool" in content, \
            "tests/test_core.py should import from deploytool"


class TestDirectoryWritable:
    """Test that the deploy directory is writable."""

    def test_deploy_dir_writable(self):
        assert os.access(DEPLOY_DIR, os.W_OK), \
            f"{DEPLOY_DIR} is not writable"

    def test_venv_dir_writable(self):
        assert os.access(VENV_DIR, os.W_OK), \
            f"{VENV_DIR} is not writable"

    def test_site_packages_writable(self):
        assert os.access(SITE_PACKAGES, os.W_OK), \
            f"{SITE_PACKAGES} is not writable"


class TestPythonVersion:
    """Test Python version is 3.10."""

    def test_system_python3_available(self):
        result = subprocess.run(
            ["python3", "--version"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "python3 is not available"
        assert "3.10" in result.stdout or "3.10" in result.stderr, \
            f"Expected Python 3.10 but got: {result.stdout} {result.stderr}"

    def test_venv_python_is_3_10(self):
        venv_python = os.path.join(VENV_DIR, "bin", "python")
        result = subprocess.run(
            [venv_python, "--version"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "venv python is not available"
        assert "3.10" in result.stdout or "3.10" in result.stderr, \
            f"Expected venv Python 3.10 but got: {result.stdout} {result.stderr}"
