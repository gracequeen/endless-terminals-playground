# test_final_state.py
"""
Tests to validate the final state after the student has fixed the SSH key audit scanner.
"""

import os
import subprocess
import re
import pytest


class TestKeystoreIntegrity:
    """Tests to verify keystore files remain unchanged."""

    KEYSTORE_PATH = "/home/user/keystore"
    EXPECTED_KEYPAIR_COUNT = 47

    def test_keystore_directory_exists(self):
        """Verify /home/user/keystore/ directory still exists."""
        assert os.path.isdir(self.KEYSTORE_PATH), (
            f"Directory {self.KEYSTORE_PATH} does not exist. "
            "The keystore directory must remain intact."
        )

    def test_all_47_private_keys_still_exist(self):
        """Verify all 47 private key files still exist."""
        missing_keys = []
        for i in range(1, self.EXPECTED_KEYPAIR_COUNT + 1):
            key_name = f"id_{i:03d}"
            key_path = os.path.join(self.KEYSTORE_PATH, key_name)
            if not os.path.isfile(key_path):
                missing_keys.append(key_name)

        assert not missing_keys, (
            f"Missing private key files: {missing_keys}. "
            f"All 47 keypairs must remain intact in {self.KEYSTORE_PATH}"
        )

    def test_all_47_public_keys_still_exist(self):
        """Verify all 47 public key files still exist."""
        missing_keys = []
        for i in range(1, self.EXPECTED_KEYPAIR_COUNT + 1):
            key_name = f"id_{i:03d}.pub"
            key_path = os.path.join(self.KEYSTORE_PATH, key_name)
            if not os.path.isfile(key_path):
                missing_keys.append(key_name)

        assert not missing_keys, (
            f"Missing public key files: {missing_keys}. "
            f"All 47 public keys must remain intact in {self.KEYSTORE_PATH}"
        )


class TestScannerScript:
    """Tests for the scanner script existence and basic properties."""

    SCANNER_PATH = "/home/user/audit/scan.py"

    def test_scanner_script_exists(self):
        """Verify /home/user/audit/scan.py still exists."""
        assert os.path.isfile(self.SCANNER_PATH), (
            f"Scanner script {self.SCANNER_PATH} does not exist. "
            "The scanner script must be present."
        )

    def test_scanner_script_is_valid_python(self):
        """Verify scan.py has valid Python syntax."""
        result = subprocess.run(
            ['python3', '-m', 'py_compile', self.SCANNER_PATH],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"Scanner script {self.SCANNER_PATH} has Python syntax errors: "
            f"{result.stderr}"
        )


class TestScannerOutput:
    """Tests for the scanner's output correctness."""

    SCANNER_PATH = "/home/user/audit/scan.py"
    EXPECTED_WEAK_KEYS = {'id_007', 'id_019', 'id_023', 'id_031', 'id_044'}

    def test_scanner_exits_zero(self):
        """Verify scanner exits with code 0."""
        result = subprocess.run(
            ['python3', self.SCANNER_PATH],
            capture_output=True,
            text=True,
            cwd='/home/user/audit'
        )
        assert result.returncode == 0, (
            f"Scanner exited with code {result.returncode}, expected 0. "
            f"Stderr: {result.stderr}"
        )

    def test_scanner_outputs_exactly_5_lines(self):
        """Verify scanner outputs exactly 5 lines on stdout."""
        result = subprocess.run(
            ['python3', self.SCANNER_PATH],
            capture_output=True,
            text=True,
            cwd='/home/user/audit'
        )

        # Filter out empty lines
        output_lines = [line.strip() for line in result.stdout.strip().split('\n') if line.strip()]

        assert len(output_lines) == 5, (
            f"Scanner output has {len(output_lines)} non-empty lines, expected exactly 5. "
            f"Output was:\n{result.stdout}"
        )

    def test_scanner_reports_correct_weak_keys(self):
        """Verify scanner reports exactly the 5 correct weak keys."""
        result = subprocess.run(
            ['python3', self.SCANNER_PATH],
            capture_output=True,
            text=True,
            cwd='/home/user/audit'
        )

        output_lines = [line.strip() for line in result.stdout.strip().split('\n') if line.strip()]

        # Extract key identifiers from output
        reported_keys = set()
        for line in output_lines:
            # Look for id_XXX pattern in the line
            match = re.search(r'id_\d{3}', line)
            if match:
                reported_keys.add(match.group())
            else:
                # If the line itself is just the key name
                clean_line = line.strip()
                if re.match(r'^id_\d{3}$', clean_line):
                    reported_keys.add(clean_line)

        assert reported_keys == self.EXPECTED_WEAK_KEYS, (
            f"Scanner reported incorrect weak keys. "
            f"Expected: {sorted(self.EXPECTED_WEAK_KEYS)}, "
            f"Got: {sorted(reported_keys)}. "
            f"Missing: {sorted(self.EXPECTED_WEAK_KEYS - reported_keys)}, "
            f"Extra: {sorted(reported_keys - self.EXPECTED_WEAK_KEYS)}"
        )

    def test_scanner_output_contains_id_007(self):
        """Verify id_007 (RSA 1024-bit) is reported as weak."""
        result = subprocess.run(
            ['python3', self.SCANNER_PATH],
            capture_output=True,
            text=True,
            cwd='/home/user/audit'
        )
        assert 'id_007' in result.stdout, (
            "Scanner did not report id_007 as weak. "
            "id_007 is RSA 1024-bit and should be flagged as weak (under 2048)."
        )

    def test_scanner_output_contains_id_019(self):
        """Verify id_019 (DSA) is reported as weak."""
        result = subprocess.run(
            ['python3', self.SCANNER_PATH],
            capture_output=True,
            text=True,
            cwd='/home/user/audit'
        )
        assert 'id_019' in result.stdout, (
            "Scanner did not report id_019 as weak. "
            "id_019 is DSA and should be flagged as weak (any DSA is weak)."
        )

    def test_scanner_output_contains_id_023(self):
        """Verify id_023 (RSA 1536-bit) is reported as weak."""
        result = subprocess.run(
            ['python3', self.SCANNER_PATH],
            capture_output=True,
            text=True,
            cwd='/home/user/audit'
        )
        assert 'id_023' in result.stdout, (
            "Scanner did not report id_023 as weak. "
            "id_023 is RSA 1536-bit and should be flagged as weak (under 2048)."
        )

    def test_scanner_output_contains_id_031(self):
        """Verify id_031 (ECDSA P-192) is reported as weak."""
        result = subprocess.run(
            ['python3', self.SCANNER_PATH],
            capture_output=True,
            text=True,
            cwd='/home/user/audit'
        )
        assert 'id_031' in result.stdout, (
            "Scanner did not report id_031 as weak. "
            "id_031 is ECDSA P-192 and should be flagged as weak (smaller than P-256)."
        )

    def test_scanner_output_contains_id_044(self):
        """Verify id_044 (ECDSA P-256) is reported as weak."""
        result = subprocess.run(
            ['python3', self.SCANNER_PATH],
            capture_output=True,
            text=True,
            cwd='/home/user/audit'
        )
        assert 'id_044' in result.stdout, (
            "Scanner did not report id_044 as weak. "
            "id_044 is ECDSA P-256 and should be flagged as weak (P-256 or smaller)."
        )

    def test_scanner_does_not_report_false_positives(self):
        """Verify scanner does not report the old false positives."""
        result = subprocess.run(
            ['python3', self.SCANNER_PATH],
            capture_output=True,
            text=True,
            cwd='/home/user/audit'
        )

        old_false_positives = ['id_002', 'id_015', 'id_038']
        reported_false_positives = []

        for fp in old_false_positives:
            if fp in result.stdout:
                reported_false_positives.append(fp)

        assert not reported_false_positives, (
            f"Scanner still reports false positives: {reported_false_positives}. "
            "These keys are RSA 2048+ and should NOT be flagged as weak."
        )


class TestAntiShortcutGuards:
    """Tests to ensure the solution doesn't use prohibited shortcuts."""

    SCANNER_PATH = "/home/user/audit/scan.py"
    EXPECTED_WEAK_KEYS = {'id_007', 'id_019', 'id_023', 'id_031', 'id_044'}

    def test_no_hardcoded_answers(self):
        """Verify the answer isn't simply hardcoded."""
        with open(self.SCANNER_PATH, 'r') as f:
            content = f.read()

        # Check for suspicious hardcoding patterns
        # All 5 weak key IDs appearing as literals in a list/set/tuple context
        hardcode_patterns = [
            r'\[\s*[\'"]id_007[\'"]\s*,\s*[\'"]id_019[\'"]\s*,\s*[\'"]id_023[\'"]\s*,\s*[\'"]id_031[\'"]\s*,\s*[\'"]id_044[\'"]\s*\]',
            r'\{\s*[\'"]id_007[\'"]\s*,\s*[\'"]id_019[\'"]\s*,\s*[\'"]id_023[\'"]\s*,\s*[\'"]id_031[\'"]\s*,\s*[\'"]id_044[\'"]\s*\}',
            r'\(\s*[\'"]id_007[\'"]\s*,\s*[\'"]id_019[\'"]\s*,\s*[\'"]id_023[\'"]\s*,\s*[\'"]id_031[\'"]\s*,\s*[\'"]id_044[\'"]\s*\)',
        ]

        for pattern in hardcode_patterns:
            match = re.search(pattern, content, re.IGNORECASE)
            assert not match, (
                "Scanner appears to have hardcoded the answer. "
                "The scanner must actually parse and analyze the keys."
            )

        # Also check if all 5 IDs appear as string literals close together (within 200 chars)
        # This catches more creative hardcoding
        id_positions = []
        for key_id in self.EXPECTED_WEAK_KEYS:
            for match in re.finditer(rf'[\'\"]{key_id}[\'\"]', content):
                id_positions.append(match.start())

        if len(id_positions) >= 5:
            id_positions.sort()
            # Check if all 5 are within a 300 character span
            for i in range(len(id_positions) - 4):
                span = id_positions[i+4] - id_positions[i]
                if span < 300:
                    # This might be hardcoding, but let's be lenient
                    # Only fail if it looks like a direct list
                    snippet = content[id_positions[i]:id_positions[i+4]+10]
                    if re.search(r'(print|return|=)\s*[\[\{\(]', content[max(0,id_positions[i]-50):id_positions[i]]):
                        pytest.fail(
                            "Scanner appears to have hardcoded the answer in a list/set. "
                            "The scanner must actually parse and analyze the keys."
                        )

    def test_uses_key_parsing_logic(self):
        """Verify the scanner contains actual key parsing logic."""
        with open(self.SCANNER_PATH, 'r') as f:
            content = f.read()

        # Should have base64 decoding for parsing key blobs
        has_base64 = 'base64' in content or 'b64decode' in content

        # Should have some form of key type detection
        has_key_type_check = any(kw in content.lower() for kw in [
            'ssh-rsa', 'ssh-dss', 'ecdsa', 'ed25519', 'rsa', 'dsa'
        ])

        # Should have bit length or curve checking logic
        has_strength_check = any(kw in content for kw in [
            '2048', '1024', '256', '384', '521', '192',
            'nistp', 'p-256', 'p-384', 'p-521', 'p-192',
            'modulus', 'bit', 'curve', 'weak'
        ])

        assert has_base64, (
            "Scanner does not appear to use base64 decoding. "
            "Key blob parsing requires base64 decoding."
        )

        assert has_key_type_check, (
            "Scanner does not appear to check key types. "
            "Must detect RSA, DSA, ECDSA, Ed25519 key types."
        )

        assert has_strength_check, (
            "Scanner does not appear to check key strength. "
            "Must check bit lengths and curve sizes."
        )

    def test_limited_subprocess_usage(self):
        """Verify subprocess is not used for all strength analysis."""
        with open(self.SCANNER_PATH, 'r') as f:
            content = f.read()

        # Count ssh-keygen invocations in the code
        ssh_keygen_calls = len(re.findall(r'ssh-keygen', content))
        subprocess_calls = len(re.findall(r'subprocess\.(run|call|Popen|check_output)', content))

        # If using subprocess heavily with ssh-keygen for analysis, that's not allowed
        # But limited use for format conversion is OK
        if ssh_keygen_calls > 0 and subprocess_calls > 0:
            # Check if it's used in a loop for every key (that would be cheating)
            # Look for patterns like ssh-keygen -l which extracts key info
            if re.search(r'ssh-keygen.*-l', content):
                # This is using ssh-keygen for fingerprint/info extraction
                # Check if it's in a loop processing all keys
                loop_with_keygen = re.search(
                    r'for\s+.*:.*\n.*ssh-keygen.*-l',
                    content,
                    re.MULTILINE | re.DOTALL
                )
                assert not loop_with_keygen, (
                    "Scanner appears to use ssh-keygen -l in a loop for strength analysis. "
                    "The bit-length and curve checks must be done by parsing the key blob, "
                    "not by shelling out to ssh-keygen for everything."
                )


class TestNoDependenciesAdded:
    """Tests to verify no new dependencies were installed."""

    def test_paramiko_still_not_installed(self):
        """Verify paramiko is still NOT installed."""
        result = subprocess.run(
            ['python3', '-c', 'import paramiko'],
            capture_output=True,
            text=True
        )
        assert result.returncode != 0, (
            "paramiko is now installed but should not be. "
            "Task requires using stdlib only, no paramiko."
        )

    def test_cryptography_still_not_installed(self):
        """Verify cryptography library is still NOT installed."""
        result = subprocess.run(
            ['python3', '-c', 'import cryptography'],
            capture_output=True,
            text=True
        )
        assert result.returncode != 0, (
            "cryptography library is now installed but should not be. "
            "Task requires using stdlib only, no cryptography library."
        )
