I'm doing a key rotation audit on /home/user/keystore and something's off. We've got 47 keypairs in there (id_*.pub with matching private keys) and I need to flag any that are weak — RSA under 2048, DSA anything, ECDSA with NIST P-256 or smaller, or Ed25519 with a non-standard implementation. Standard stuff.

Wrote a scanner at /home/user/audit/scan.py that parses each pubkey and checks the criteria. Problem is it's reporting 3 weak keys but when I manually checked with ssh-keygen -l on a few of the "weak" ones they look fine? And I'm pretty sure there are actually some weak keys in there that it's missing entirely.

The keystore has some weird legacy formats mixed in — some are RFC4716, some OpenSSH native, maybe one or two PEM-wrapped. Scanner needs to handle all of them correctly. Just need it to actually find the real weak keys and not false-positive on the good ones.
