# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the SSH key audit scanner fix task.
"""

import os
import subprocess
import pytest


class TestKeystoreDirectory:
    """Tests for /home/user/keystore/ directory and its contents."""

    KEYSTORE_PATH = "/home/user/keystore"
    EXPECTED_KEYPAIR_COUNT = 47

    def test_keystore_directory_exists(self):
        """Verify /home/user/keystore/ directory exists."""
        assert os.path.isdir(self.KEYSTORE_PATH), (
            f"Directory {self.KEYSTORE_PATH} does not exist. "
            "The keystore directory must be present for the task."
        )

    def test_keystore_is_writable(self):
        """Verify /home/user/keystore/ is writable."""
        assert os.access(self.KEYSTORE_PATH, os.W_OK), (
            f"Directory {self.KEYSTORE_PATH} is not writable. "
            "The keystore directory must be writable."
        )

    def test_all_47_private_keys_exist(self):
        """Verify all 47 private key files (id_001 through id_047) exist."""
        missing_keys = []
        for i in range(1, self.EXPECTED_KEYPAIR_COUNT + 1):
            key_name = f"id_{i:03d}"
            key_path = os.path.join(self.KEYSTORE_PATH, key_name)
            if not os.path.isfile(key_path):
                missing_keys.append(key_name)

        assert not missing_keys, (
            f"Missing private key files: {missing_keys}. "
            f"Expected 47 private keys (id_001 through id_047) in {self.KEYSTORE_PATH}"
        )

    def test_all_47_public_keys_exist(self):
        """Verify all 47 public key files (id_001.pub through id_047.pub) exist."""
        missing_keys = []
        for i in range(1, self.EXPECTED_KEYPAIR_COUNT + 1):
            key_name = f"id_{i:03d}.pub"
            key_path = os.path.join(self.KEYSTORE_PATH, key_name)
            if not os.path.isfile(key_path):
                missing_keys.append(key_name)

        assert not missing_keys, (
            f"Missing public key files: {missing_keys}. "
            f"Expected 47 public keys (id_001.pub through id_047.pub) in {self.KEYSTORE_PATH}"
        )

    def test_keypairs_are_readable(self):
        """Verify all keypair files are readable."""
        unreadable = []
        for i in range(1, self.EXPECTED_KEYPAIR_COUNT + 1):
            priv_key = os.path.join(self.KEYSTORE_PATH, f"id_{i:03d}")
            pub_key = os.path.join(self.KEYSTORE_PATH, f"id_{i:03d}.pub")
            if not os.access(priv_key, os.R_OK):
                unreadable.append(f"id_{i:03d}")
            if not os.access(pub_key, os.R_OK):
                unreadable.append(f"id_{i:03d}.pub")

        assert not unreadable, (
            f"Unreadable key files: {unreadable}. "
            "All key files must be readable."
        )

    def test_public_keys_have_content(self):
        """Verify public key files are not empty."""
        empty_keys = []
        for i in range(1, self.EXPECTED_KEYPAIR_COUNT + 1):
            pub_key = os.path.join(self.KEYSTORE_PATH, f"id_{i:03d}.pub")
            if os.path.isfile(pub_key) and os.path.getsize(pub_key) == 0:
                empty_keys.append(f"id_{i:03d}.pub")

        assert not empty_keys, (
            f"Empty public key files: {empty_keys}. "
            "All public key files must have content."
        )

    def test_mixed_public_key_formats_present(self):
        """Verify there's a mix of key formats (OpenSSH, RFC4716, PEM)."""
        openssh_count = 0
        rfc4716_count = 0
        pem_count = 0

        for i in range(1, self.EXPECTED_KEYPAIR_COUNT + 1):
            pub_key_path = os.path.join(self.KEYSTORE_PATH, f"id_{i:03d}.pub")
            if os.path.isfile(pub_key_path):
                with open(pub_key_path, 'r', errors='ignore') as f:
                    content = f.read()
                    if content.startswith('---- BEGIN SSH2 PUBLIC KEY ----'):
                        rfc4716_count += 1
                    elif content.startswith('-----BEGIN PUBLIC KEY-----'):
                        pem_count += 1
                    elif content.startswith(('ssh-rsa', 'ssh-dss', 'ecdsa-', 'ssh-ed25519')):
                        openssh_count += 1

        assert openssh_count > 0, (
            "No OpenSSH format public keys found. "
            "Expected approximately 30 OpenSSH format keys."
        )
        assert rfc4716_count > 0, (
            "No RFC4716 format public keys found. "
            "Expected approximately 12 RFC4716 format keys."
        )
        assert pem_count > 0, (
            "No PEM-wrapped public keys found. "
            "Expected approximately 5 PEM format keys."
        )


class TestAuditDirectory:
    """Tests for /home/user/audit/ directory and scanner script."""

    AUDIT_PATH = "/home/user/audit"
    SCANNER_PATH = "/home/user/audit/scan.py"

    def test_audit_directory_exists(self):
        """Verify /home/user/audit/ directory exists."""
        assert os.path.isdir(self.AUDIT_PATH), (
            f"Directory {self.AUDIT_PATH} does not exist. "
            "The audit directory must be present for the task."
        )

    def test_audit_directory_is_writable(self):
        """Verify /home/user/audit/ is writable."""
        assert os.access(self.AUDIT_PATH, os.W_OK), (
            f"Directory {self.AUDIT_PATH} is not writable. "
            "The audit directory must be writable for the student to fix the scanner."
        )

    def test_scanner_script_exists(self):
        """Verify /home/user/audit/scan.py exists."""
        assert os.path.isfile(self.SCANNER_PATH), (
            f"Scanner script {self.SCANNER_PATH} does not exist. "
            "The buggy scanner script must be present for the student to fix."
        )

    def test_scanner_script_is_readable(self):
        """Verify /home/user/audit/scan.py is readable."""
        assert os.access(self.SCANNER_PATH, os.R_OK), (
            f"Scanner script {self.SCANNER_PATH} is not readable. "
            "The scanner script must be readable."
        )

    def test_scanner_script_is_writable(self):
        """Verify /home/user/audit/scan.py is writable."""
        assert os.access(self.SCANNER_PATH, os.W_OK), (
            f"Scanner script {self.SCANNER_PATH} is not writable. "
            "The scanner script must be writable for the student to fix it."
        )

    def test_scanner_script_is_python(self):
        """Verify scan.py appears to be a Python script."""
        with open(self.SCANNER_PATH, 'r', errors='ignore') as f:
            content = f.read()

        # Check for Python indicators
        is_python = (
            'import ' in content or
            'def ' in content or
            'class ' in content or
            content.startswith('#!')
        )

        assert is_python, (
            f"Scanner script {self.SCANNER_PATH} does not appear to be a Python script. "
            "The scanner must be a Python script."
        )

    def test_scanner_script_is_executable_by_python(self):
        """Verify scan.py can be parsed by Python (syntax check)."""
        result = subprocess.run(
            ['python3', '-m', 'py_compile', self.SCANNER_PATH],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"Scanner script {self.SCANNER_PATH} has Python syntax errors: "
            f"{result.stderr}"
        )


class TestRequiredTools:
    """Tests for required system tools availability."""

    def test_python3_available(self):
        """Verify Python 3.11 is available."""
        result = subprocess.run(
            ['python3', '--version'],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "Python 3 is not available. "
            "Python 3.11 must be installed for the task."
        )
        assert '3.11' in result.stdout or '3.11' in result.stderr or 'Python 3' in result.stdout, (
            f"Expected Python 3.11, got: {result.stdout.strip()}"
        )

    def test_ssh_keygen_available(self):
        """Verify ssh-keygen is available."""
        result = subprocess.run(
            ['which', 'ssh-keygen'],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "ssh-keygen is not available. "
            "ssh-keygen must be installed for manual verification."
        )

    def test_openssl_available(self):
        """Verify openssl is available."""
        result = subprocess.run(
            ['which', 'openssl'],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "openssl is not available. "
            "openssl must be installed for the task."
        )

    def test_paramiko_not_installed(self):
        """Verify paramiko is NOT installed (per task constraints)."""
        result = subprocess.run(
            ['python3', '-c', 'import paramiko'],
            capture_output=True,
            text=True
        )
        assert result.returncode != 0, (
            "paramiko is installed but should not be. "
            "Task requires using stdlib only, no paramiko."
        )

    def test_cryptography_not_installed(self):
        """Verify cryptography library is NOT installed (per task constraints)."""
        result = subprocess.run(
            ['python3', '-c', 'import cryptography'],
            capture_output=True,
            text=True
        )
        assert result.returncode != 0, (
            "cryptography library is installed but should not be. "
            "Task requires using stdlib only, no cryptography library."
        )


class TestWeakKeysExist:
    """Tests to verify the expected weak keys are present in the keystore."""

    KEYSTORE_PATH = "/home/user/keystore"
    WEAK_KEYS = ['id_007', 'id_019', 'id_023', 'id_031', 'id_044']

    def test_weak_key_files_exist(self):
        """Verify all expected weak key files exist."""
        missing = []
        for key_id in self.WEAK_KEYS:
            priv_path = os.path.join(self.KEYSTORE_PATH, key_id)
            pub_path = os.path.join(self.KEYSTORE_PATH, f"{key_id}.pub")
            if not os.path.isfile(priv_path):
                missing.append(key_id)
            if not os.path.isfile(pub_path):
                missing.append(f"{key_id}.pub")

        assert not missing, (
            f"Missing weak key files: {missing}. "
            "All expected weak keys must be present in the keystore."
        )


class TestBuggyScannerBehavior:
    """Tests to verify the scanner currently has bugs (produces wrong output)."""

    SCANNER_PATH = "/home/user/audit/scan.py"
    EXPECTED_BUGGY_OUTPUT = {'id_002', 'id_015', 'id_038'}  # False positives
    ACTUAL_WEAK_KEYS = {'id_007', 'id_019', 'id_023', 'id_031', 'id_044'}

    def test_scanner_runs_without_crash(self):
        """Verify the buggy scanner at least runs without crashing."""
        result = subprocess.run(
            ['python3', self.SCANNER_PATH],
            capture_output=True,
            text=True,
            cwd='/home/user/audit'
        )
        # It might exit non-zero due to bugs, but shouldn't crash with traceback
        # Actually, let's just verify it produces some output
        assert result.returncode == 0 or result.stdout or result.stderr, (
            "Scanner script crashes or produces no output at all. "
            "The buggy scanner should at least run and produce (incorrect) output."
        )

    def test_scanner_produces_output(self):
        """Verify the scanner produces some output (even if wrong)."""
        result = subprocess.run(
            ['python3', self.SCANNER_PATH],
            capture_output=True,
            text=True,
            cwd='/home/user/audit'
        )
        # The buggy scanner should report something
        output = result.stdout.strip()
        assert output, (
            "Scanner produces no stdout output. "
            "The buggy scanner should report some keys (even if they're false positives)."
        )

    def test_scanner_output_is_incorrect(self):
        """Verify the scanner's current output does NOT match the correct answer."""
        result = subprocess.run(
            ['python3', self.SCANNER_PATH],
            capture_output=True,
            text=True,
            cwd='/home/user/audit'
        )

        output_lines = [line.strip() for line in result.stdout.strip().split('\n') if line.strip()]
        reported_keys = set()
        for line in output_lines:
            # Extract key IDs from output (they should contain id_XXX pattern)
            for word in line.split():
                if word.startswith('id_'):
                    reported_keys.add(word.split('.')[0])  # Remove .pub if present

        # The buggy scanner should NOT produce the correct output
        assert reported_keys != self.ACTUAL_WEAK_KEYS, (
            "Scanner already produces correct output! "
            "The initial scanner should be buggy and report incorrect keys. "
            f"Got: {reported_keys}, Expected buggy output to differ from: {self.ACTUAL_WEAK_KEYS}"
        )


class TestHomeDirectory:
    """Tests for home directory setup."""

    def test_home_directory_exists(self):
        """Verify /home/user exists."""
        assert os.path.isdir('/home/user'), (
            "/home/user directory does not exist. "
            "The user home directory must be present."
        )

    def test_home_directory_writable(self):
        """Verify /home/user is writable."""
        assert os.access('/home/user', os.W_OK), (
            "/home/user is not writable. "
            "The home directory must be writable."
        )
