# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the task of fixing the build_manifest.py script.
"""

import json
import os
import subprocess
import pytest


CI_DIR = "/home/user/ci"
SCRIPT_PATH = "/home/user/ci/build_manifest.py"
ARTIFACTS_DIR = "/home/user/ci/artifacts"
OUTPUT_DIR = "/home/user/ci/output"

EXPECTED_SUBDIRS = [
    "api-service",
    "web-frontend",
    "auth-module",
    "db-migrator",
    "worker-node",
    "scheduler",
    "notifier",
    "analytics-engine",
]

EXPECTED_KEYS_NORMAL = {"name", "version", "sha256", "build_time"}
EXPECTED_KEYS_WORKER_NODE = {"name", "version", "checksum", "build_time"}


class TestCIDirectoryStructure:
    """Test that the CI directory structure exists as expected."""

    def test_ci_directory_exists(self):
        """CI directory should exist."""
        assert os.path.isdir(CI_DIR), f"CI directory {CI_DIR} does not exist"

    def test_artifacts_directory_exists(self):
        """Artifacts directory should exist."""
        assert os.path.isdir(ARTIFACTS_DIR), f"Artifacts directory {ARTIFACTS_DIR} does not exist"

    def test_output_directory_exists(self):
        """Output directory should exist."""
        assert os.path.isdir(OUTPUT_DIR), f"Output directory {OUTPUT_DIR} does not exist"


class TestBuildManifestScript:
    """Test that the build_manifest.py script exists and is properly configured."""

    def test_script_exists(self):
        """build_manifest.py should exist."""
        assert os.path.isfile(SCRIPT_PATH), f"Script {SCRIPT_PATH} does not exist"

    def test_script_is_readable(self):
        """build_manifest.py should be readable."""
        assert os.access(SCRIPT_PATH, os.R_OK), f"Script {SCRIPT_PATH} is not readable"

    def test_script_is_valid_python(self):
        """build_manifest.py should be valid Python syntax."""
        result = subprocess.run(
            ["python3", "-m", "py_compile", SCRIPT_PATH],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, f"Script {SCRIPT_PATH} has syntax errors: {result.stderr}"

    def test_script_can_be_executed_with_python3(self):
        """Python3 should be available to run the script."""
        result = subprocess.run(
            ["python3", "--version"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "Python3 is not available"


class TestArtifactSubdirectories:
    """Test that all 8 expected artifact subdirectories exist."""

    def test_correct_number_of_subdirs(self):
        """There should be exactly 8 artifact subdirectories."""
        subdirs = [d for d in os.listdir(ARTIFACTS_DIR) 
                   if os.path.isdir(os.path.join(ARTIFACTS_DIR, d))]
        assert len(subdirs) == 8, f"Expected 8 artifact subdirs, found {len(subdirs)}: {subdirs}"

    @pytest.mark.parametrize("subdir", EXPECTED_SUBDIRS)
    def test_artifact_subdir_exists(self, subdir):
        """Each expected artifact subdirectory should exist."""
        subdir_path = os.path.join(ARTIFACTS_DIR, subdir)
        assert os.path.isdir(subdir_path), f"Artifact subdirectory {subdir_path} does not exist"

    @pytest.mark.parametrize("subdir", EXPECTED_SUBDIRS)
    def test_meta_json_exists(self, subdir):
        """Each artifact subdirectory should have a meta.json file."""
        meta_path = os.path.join(ARTIFACTS_DIR, subdir, "meta.json")
        assert os.path.isfile(meta_path), f"meta.json not found at {meta_path}"

    @pytest.mark.parametrize("subdir", EXPECTED_SUBDIRS)
    def test_meta_json_is_valid_json(self, subdir):
        """Each meta.json should be valid JSON."""
        meta_path = os.path.join(ARTIFACTS_DIR, subdir, "meta.json")
        with open(meta_path, 'r') as f:
            try:
                json.load(f)
            except json.JSONDecodeError as e:
                pytest.fail(f"meta.json at {meta_path} is not valid JSON: {e}")


class TestMetaJsonSchemas:
    """Test that meta.json files have the expected schemas."""

    @pytest.mark.parametrize("subdir", [s for s in EXPECTED_SUBDIRS if s != "worker-node"])
    def test_normal_meta_json_has_sha256(self, subdir):
        """Normal meta.json files should have 'sha256' key."""
        meta_path = os.path.join(ARTIFACTS_DIR, subdir, "meta.json")
        with open(meta_path, 'r') as f:
            meta = json.load(f)
        assert "sha256" in meta, f"meta.json at {meta_path} missing 'sha256' key"
        assert "name" in meta, f"meta.json at {meta_path} missing 'name' key"
        assert "version" in meta, f"meta.json at {meta_path} missing 'version' key"
        assert "build_time" in meta, f"meta.json at {meta_path} missing 'build_time' key"

    def test_worker_node_meta_json_has_checksum_not_sha256(self):
        """worker-node meta.json should have 'checksum' instead of 'sha256'."""
        meta_path = os.path.join(ARTIFACTS_DIR, "worker-node", "meta.json")
        with open(meta_path, 'r') as f:
            meta = json.load(f)

        assert "checksum" in meta, f"worker-node meta.json missing 'checksum' key"
        assert "sha256" not in meta, f"worker-node meta.json should NOT have 'sha256' key (it should have 'checksum')"
        assert "name" in meta, f"worker-node meta.json missing 'name' key"
        assert "version" in meta, f"worker-node meta.json missing 'version' key"
        assert "build_time" in meta, f"worker-node meta.json missing 'build_time' key"

    def test_worker_node_name_is_correct(self):
        """worker-node meta.json should have name 'worker-node'."""
        meta_path = os.path.join(ARTIFACTS_DIR, "worker-node", "meta.json")
        with open(meta_path, 'r') as f:
            meta = json.load(f)
        assert meta.get("name") == "worker-node", f"worker-node meta.json has unexpected name: {meta.get('name')}"


class TestScriptFailsWithKeyError:
    """Test that running the script currently fails with KeyError."""

    def test_script_fails_when_run(self):
        """Running build_manifest.py should currently fail."""
        result = subprocess.run(
            ["python3", SCRIPT_PATH],
            capture_output=True,
            text=True,
            cwd=CI_DIR
        )
        assert result.returncode != 0, "Script should fail but it succeeded"

    def test_script_fails_with_keyerror(self):
        """Running build_manifest.py should fail with KeyError: 'sha256'."""
        result = subprocess.run(
            ["python3", SCRIPT_PATH],
            capture_output=True,
            text=True,
            cwd=CI_DIR
        )
        # Check stderr for KeyError
        assert "KeyError" in result.stderr, f"Expected KeyError in stderr, got: {result.stderr}"
        assert "sha256" in result.stderr, f"Expected 'sha256' in KeyError message, got: {result.stderr}"


class TestPythonAndToolsAvailable:
    """Test that required tools are available."""

    def test_python3_available(self):
        """Python 3 should be available."""
        result = subprocess.run(
            ["python3", "--version"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "Python3 is not available"

    def test_jq_available(self):
        """jq should be installed."""
        result = subprocess.run(
            ["jq", "--version"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "jq is not installed"


class TestPathsWritable:
    """Test that required paths are writable."""

    def test_ci_dir_writable(self):
        """CI directory should be writable."""
        assert os.access(CI_DIR, os.W_OK), f"{CI_DIR} is not writable"

    def test_output_dir_writable(self):
        """Output directory should be writable."""
        assert os.access(OUTPUT_DIR, os.W_OK), f"{OUTPUT_DIR} is not writable"

    def test_script_writable(self):
        """Script should be writable (for fixing)."""
        assert os.access(SCRIPT_PATH, os.W_OK), f"{SCRIPT_PATH} is not writable"


class TestScriptContent:
    """Test that the script has expected characteristics."""

    def test_script_reads_meta_json(self):
        """Script should contain code that reads meta.json files."""
        with open(SCRIPT_PATH, 'r') as f:
            content = f.read()
        assert "meta.json" in content, "Script should reference meta.json files"

    def test_script_accesses_sha256_key(self):
        """Script should contain code that accesses sha256 key directly."""
        with open(SCRIPT_PATH, 'r') as f:
            content = f.read()
        # The script should have direct access to sha256 without fallback
        assert "sha256" in content, "Script should reference sha256 key"

    def test_script_writes_to_output(self):
        """Script should write to output directory."""
        with open(SCRIPT_PATH, 'r') as f:
            content = f.read()
        assert "output" in content or "manifest.json" in content, \
            "Script should reference output directory or manifest.json"
