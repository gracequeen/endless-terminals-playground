# test_final_state.py
"""
Tests to validate the final state of the OS/filesystem after the student
has fixed the build_manifest.py script to handle the 'checksum' key fallback.
"""

import json
import os
import subprocess
import pytest


CI_DIR = "/home/user/ci"
SCRIPT_PATH = "/home/user/ci/build_manifest.py"
ARTIFACTS_DIR = "/home/user/ci/artifacts"
OUTPUT_DIR = "/home/user/ci/output"
MANIFEST_PATH = "/home/user/ci/output/manifest.json"

EXPECTED_SUBDIRS = [
    "api-service",
    "web-frontend",
    "auth-module",
    "db-migrator",
    "worker-node",
    "scheduler",
    "notifier",
    "analytics-engine",
]

# Store original meta.json checksums to verify they weren't modified
ORIGINAL_META_CHECKSUMS = {}


class TestScriptExecutesSuccessfully:
    """Test that the build_manifest.py script now runs without errors."""

    def test_script_exists(self):
        """build_manifest.py should still exist at the expected path."""
        assert os.path.isfile(SCRIPT_PATH), f"Script {SCRIPT_PATH} does not exist"

    def test_script_exits_zero(self):
        """Running build_manifest.py should exit with code 0."""
        result = subprocess.run(
            ["python3", SCRIPT_PATH],
            capture_output=True,
            text=True,
            cwd=CI_DIR
        )
        assert result.returncode == 0, (
            f"Script should exit 0 but exited {result.returncode}.\n"
            f"stdout: {result.stdout}\n"
            f"stderr: {result.stderr}"
        )

    def test_script_does_not_produce_keyerror(self):
        """Running build_manifest.py should not produce KeyError."""
        result = subprocess.run(
            ["python3", SCRIPT_PATH],
            capture_output=True,
            text=True,
            cwd=CI_DIR
        )
        assert "KeyError" not in result.stderr, (
            f"Script still produces KeyError:\n{result.stderr}"
        )


class TestManifestJsonExists:
    """Test that manifest.json is created in the output directory."""

    def test_manifest_json_exists(self):
        """manifest.json should exist in /home/user/ci/output/."""
        # First run the script to ensure manifest is generated
        subprocess.run(
            ["python3", SCRIPT_PATH],
            capture_output=True,
            text=True,
            cwd=CI_DIR
        )
        assert os.path.isfile(MANIFEST_PATH), (
            f"manifest.json not found at {MANIFEST_PATH}"
        )

    def test_manifest_json_is_valid_json(self):
        """manifest.json should be valid JSON."""
        subprocess.run(
            ["python3", SCRIPT_PATH],
            capture_output=True,
            text=True,
            cwd=CI_DIR
        )
        with open(MANIFEST_PATH, 'r') as f:
            try:
                json.load(f)
            except json.JSONDecodeError as e:
                pytest.fail(f"manifest.json is not valid JSON: {e}")


class TestManifestJsonContent:
    """Test that manifest.json has the correct content."""

    @pytest.fixture(autouse=True)
    def run_script_first(self):
        """Run the script before each test to ensure manifest is current."""
        subprocess.run(
            ["python3", SCRIPT_PATH],
            capture_output=True,
            text=True,
            cwd=CI_DIR
        )

    def test_manifest_contains_array(self):
        """manifest.json should contain a JSON array."""
        with open(MANIFEST_PATH, 'r') as f:
            manifest = json.load(f)
        assert isinstance(manifest, list), (
            f"manifest.json should be a JSON array, got {type(manifest).__name__}"
        )

    def test_manifest_has_8_entries(self):
        """manifest.json should contain exactly 8 entries."""
        with open(MANIFEST_PATH, 'r') as f:
            manifest = json.load(f)
        assert len(manifest) == 8, (
            f"manifest.json should have 8 entries, found {len(manifest)}"
        )

    def test_all_entries_have_required_keys(self):
        """Each entry in manifest.json should have name, version, sha256, build_time."""
        with open(MANIFEST_PATH, 'r') as f:
            manifest = json.load(f)

        required_keys = {"name", "version", "sha256", "build_time"}
        for i, entry in enumerate(manifest):
            missing_keys = required_keys - set(entry.keys())
            assert not missing_keys, (
                f"Entry {i} (name={entry.get('name', 'unknown')}) missing keys: {missing_keys}"
            )

    def test_all_artifact_names_present(self):
        """All 8 artifact names should be present in manifest.json."""
        with open(MANIFEST_PATH, 'r') as f:
            manifest = json.load(f)

        names_in_manifest = {entry.get("name") for entry in manifest}
        expected_names = set(EXPECTED_SUBDIRS)

        missing = expected_names - names_in_manifest
        assert not missing, f"Missing artifacts in manifest: {missing}"

    def test_worker_node_entry_exists(self):
        """worker-node entry should exist in manifest.json."""
        with open(MANIFEST_PATH, 'r') as f:
            manifest = json.load(f)

        worker_node_entries = [e for e in manifest if e.get("name") == "worker-node"]
        assert len(worker_node_entries) == 1, (
            f"Expected exactly 1 worker-node entry, found {len(worker_node_entries)}"
        )

    def test_worker_node_has_sha256_key(self):
        """worker-node entry should have 'sha256' key (not 'checksum')."""
        with open(MANIFEST_PATH, 'r') as f:
            manifest = json.load(f)

        worker_node = next((e for e in manifest if e.get("name") == "worker-node"), None)
        assert worker_node is not None, "worker-node entry not found"
        assert "sha256" in worker_node, (
            f"worker-node entry should have 'sha256' key, got keys: {list(worker_node.keys())}"
        )

    def test_worker_node_sha256_has_correct_value(self):
        """worker-node sha256 should contain the value from its meta.json 'checksum' field."""
        # Read the original checksum from worker-node meta.json
        worker_meta_path = os.path.join(ARTIFACTS_DIR, "worker-node", "meta.json")
        with open(worker_meta_path, 'r') as f:
            worker_meta = json.load(f)

        expected_checksum = worker_meta.get("checksum")
        assert expected_checksum is not None, "worker-node meta.json should have 'checksum' key"

        # Check manifest
        with open(MANIFEST_PATH, 'r') as f:
            manifest = json.load(f)

        worker_node = next((e for e in manifest if e.get("name") == "worker-node"), None)
        assert worker_node is not None, "worker-node entry not found in manifest"

        actual_sha256 = worker_node.get("sha256")
        assert actual_sha256 == expected_checksum, (
            f"worker-node sha256 should be '{expected_checksum}', got '{actual_sha256}'"
        )

    def test_all_sha256_values_are_non_empty(self):
        """All sha256 values in manifest should be non-empty strings."""
        with open(MANIFEST_PATH, 'r') as f:
            manifest = json.load(f)

        for entry in manifest:
            name = entry.get("name", "unknown")
            sha256 = entry.get("sha256")
            assert sha256 is not None, f"Entry '{name}' has None sha256"
            assert isinstance(sha256, str), f"Entry '{name}' sha256 should be string, got {type(sha256)}"
            assert len(sha256) > 0, f"Entry '{name}' has empty sha256"


class TestMetaJsonFilesUnmodified:
    """Test that the meta.json files in artifacts were NOT modified."""

    def test_worker_node_meta_still_has_checksum(self):
        """worker-node meta.json should still have 'checksum' key (not modified to 'sha256')."""
        meta_path = os.path.join(ARTIFACTS_DIR, "worker-node", "meta.json")
        with open(meta_path, 'r') as f:
            meta = json.load(f)

        assert "checksum" in meta, (
            "worker-node meta.json should still have 'checksum' key - "
            "the fix should be in the script, not by editing the metadata"
        )
        assert "sha256" not in meta, (
            "worker-node meta.json should NOT have 'sha256' key added - "
            "the fix should be in the script, not by editing the metadata"
        )

    @pytest.mark.parametrize("subdir", [s for s in EXPECTED_SUBDIRS if s != "worker-node"])
    def test_other_meta_files_unchanged(self, subdir):
        """Other meta.json files should still have 'sha256' key."""
        meta_path = os.path.join(ARTIFACTS_DIR, subdir, "meta.json")
        with open(meta_path, 'r') as f:
            meta = json.load(f)

        assert "sha256" in meta, (
            f"{subdir}/meta.json should still have 'sha256' key"
        )


class TestGraderVerification:
    """Test using the exact grader verification command."""

    def test_grader_verification_passes(self):
        """The grader verification command should exit 0."""
        # First run the script
        subprocess.run(
            ["python3", SCRIPT_PATH],
            capture_output=True,
            text=True,
            cwd=CI_DIR
        )

        # Run the grader verification
        grader_cmd = (
            "import json; "
            "m=json.load(open('/home/user/ci/output/manifest.json')); "
            "assert len(m)==8; "
            "assert all('sha256' in e for e in m)"
        )
        result = subprocess.run(
            ["python3", "-c", grader_cmd],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"Grader verification failed.\n"
            f"stdout: {result.stdout}\n"
            f"stderr: {result.stderr}"
        )


class TestScriptStillAtOriginalPath:
    """Test that the script is still at the original path and is a Python script."""

    def test_script_at_original_path(self):
        """Script should still be at /home/user/ci/build_manifest.py."""
        assert os.path.isfile(SCRIPT_PATH), (
            f"Script must remain at {SCRIPT_PATH}"
        )

    def test_script_is_valid_python(self):
        """Script should still be valid Python."""
        result = subprocess.run(
            ["python3", "-m", "py_compile", SCRIPT_PATH],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"Script has Python syntax errors: {result.stderr}"
        )

    def test_script_is_python_file(self):
        """Script should be a Python file (not replaced with shell script etc)."""
        with open(SCRIPT_PATH, 'r') as f:
            content = f.read()

        # Check for Python-like content
        python_indicators = ["import", "def ", "json", "open("]
        has_python_content = any(indicator in content for indicator in python_indicators)
        assert has_python_content, (
            "Script doesn't appear to be a Python script anymore"
        )


class TestManifestGeneratedByScript:
    """Test that manifest.json is actually generated by running the script."""

    def test_fresh_manifest_generated_by_script(self):
        """Deleting manifest.json and running script should recreate it."""
        # Remove existing manifest if present
        if os.path.exists(MANIFEST_PATH):
            os.remove(MANIFEST_PATH)

        assert not os.path.exists(MANIFEST_PATH), "Failed to remove manifest.json for test"

        # Run the script
        result = subprocess.run(
            ["python3", SCRIPT_PATH],
            capture_output=True,
            text=True,
            cwd=CI_DIR
        )

        assert result.returncode == 0, (
            f"Script failed to run: {result.stderr}"
        )
        assert os.path.exists(MANIFEST_PATH), (
            "Script did not create manifest.json - "
            "manifest must be generated by running the script, not created manually"
        )

        # Verify it's valid and has 8 entries
        with open(MANIFEST_PATH, 'r') as f:
            manifest = json.load(f)
        assert len(manifest) == 8, (
            f"Regenerated manifest should have 8 entries, got {len(manifest)}"
        )
