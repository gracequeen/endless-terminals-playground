# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the disaster recovery script debugging task.
"""

import os
import subprocess
import pytest


# Base paths
BACKUP_DIR = "/home/user/backup"
CHUNKS_DIR = os.path.join(BACKUP_DIR, "chunks")
MANIFESTS_DIR = os.path.join(BACKUP_DIR, "manifests")
RESTORED_DIR = os.path.join(BACKUP_DIR, "restored")
EXPECTED_DIR = os.path.join(BACKUP_DIR, "expected")
LIB_DIR = os.path.join(BACKUP_DIR, "lib")

# Expected files
DR_RESTORE_SCRIPT = os.path.join(BACKUP_DIR, "dr_restore.sh")
CHUNK_STORE_PY = os.path.join(LIB_DIR, "chunk_store.py")
MANIFEST_PY = os.path.join(LIB_DIR, "manifest.py")
COMPOSE_BUILDER_PY = os.path.join(LIB_DIR, "compose_builder.py")

EXPECTED_COMPOSE_FILES = ["api.yml", "worker.yml", "gateway.yml"]


class TestBackupDirectoryStructure:
    """Test that the backup directory structure exists."""

    def test_backup_dir_exists(self):
        assert os.path.isdir(BACKUP_DIR), \
            f"Backup directory {BACKUP_DIR} does not exist"

    def test_chunks_dir_exists(self):
        assert os.path.isdir(CHUNKS_DIR), \
            f"Chunks directory {CHUNKS_DIR} does not exist"

    def test_manifests_dir_exists(self):
        assert os.path.isdir(MANIFESTS_DIR), \
            f"Manifests directory {MANIFESTS_DIR} does not exist"

    def test_restored_dir_exists(self):
        assert os.path.isdir(RESTORED_DIR), \
            f"Restored directory {RESTORED_DIR} does not exist"

    def test_expected_dir_exists(self):
        assert os.path.isdir(EXPECTED_DIR), \
            f"Expected directory {EXPECTED_DIR} does not exist"

    def test_lib_dir_exists(self):
        assert os.path.isdir(LIB_DIR), \
            f"Lib directory {LIB_DIR} does not exist"


class TestDrRestoreScript:
    """Test that the main restore script exists and is executable."""

    def test_dr_restore_script_exists(self):
        assert os.path.isfile(DR_RESTORE_SCRIPT), \
            f"DR restore script {DR_RESTORE_SCRIPT} does not exist"

    def test_dr_restore_script_is_executable(self):
        assert os.access(DR_RESTORE_SCRIPT, os.X_OK), \
            f"DR restore script {DR_RESTORE_SCRIPT} is not executable"


class TestPythonLibraryFiles:
    """Test that the Python library files exist."""

    def test_chunk_store_py_exists(self):
        assert os.path.isfile(CHUNK_STORE_PY), \
            f"Chunk store module {CHUNK_STORE_PY} does not exist"

    def test_manifest_py_exists(self):
        assert os.path.isfile(MANIFEST_PY), \
            f"Manifest module {MANIFEST_PY} does not exist"

    def test_compose_builder_py_exists(self):
        assert os.path.isfile(COMPOSE_BUILDER_PY), \
            f"Compose builder module {COMPOSE_BUILDER_PY} does not exist"


class TestExpectedOutputFiles:
    """Test that the expected output reference files exist."""

    @pytest.mark.parametrize("compose_file", EXPECTED_COMPOSE_FILES)
    def test_expected_compose_file_exists(self, compose_file):
        filepath = os.path.join(EXPECTED_DIR, compose_file)
        assert os.path.isfile(filepath), \
            f"Expected compose file {filepath} does not exist"

    @pytest.mark.parametrize("compose_file", EXPECTED_COMPOSE_FILES)
    def test_expected_compose_file_not_empty(self, compose_file):
        filepath = os.path.join(EXPECTED_DIR, compose_file)
        assert os.path.getsize(filepath) > 0, \
            f"Expected compose file {filepath} is empty"


class TestManifestFiles:
    """Test that msgpack manifest files exist."""

    def test_manifests_dir_has_mpk_files(self):
        mpk_files = [f for f in os.listdir(MANIFESTS_DIR) if f.endswith('.mpk')]
        assert len(mpk_files) > 0, \
            f"No .mpk manifest files found in {MANIFESTS_DIR}"

    def test_manifests_count_matches_services(self):
        mpk_files = [f for f in os.listdir(MANIFESTS_DIR) if f.endswith('.mpk')]
        # Should have manifests for api, worker, gateway
        assert len(mpk_files) >= 3, \
            f"Expected at least 3 manifest files, found {len(mpk_files)}"


class TestChunkStore:
    """Test that chunk store has content."""

    def test_chunks_dir_has_files(self):
        chunk_files = os.listdir(CHUNKS_DIR)
        assert len(chunk_files) > 0, \
            f"No chunk files found in {CHUNKS_DIR}"

    def test_chunk_files_are_hex_named(self):
        """Chunk files should be named with hex-encoded sha256 hashes."""
        chunk_files = os.listdir(CHUNKS_DIR)
        for chunk_file in chunk_files:
            # Remove any extension if present
            name = chunk_file.split('.')[0]
            # Should be 64 hex characters (sha256)
            try:
                int(name, 16)
                assert len(name) == 64, \
                    f"Chunk file {chunk_file} name is not 64 hex chars (sha256)"
            except ValueError:
                pytest.fail(f"Chunk file {chunk_file} is not hex-encoded")


class TestPythonEnvironment:
    """Test that required Python packages are available."""

    def test_python3_available(self):
        result = subprocess.run(
            ["python3", "--version"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            "Python 3 is not available"

    def test_msgpack_installed(self):
        result = subprocess.run(
            ["python3", "-c", "import msgpack"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            f"msgpack module is not installed: {result.stderr}"


class TestBuggyCodePresent:
    """Test that the buggy code patterns are present (pre-fix state)."""

    def test_manifest_py_has_raw_false_bug(self):
        """The manifest.py should have raw=False which causes the bug."""
        with open(MANIFEST_PY, 'r') as f:
            content = f.read()
        # The bug is that raw=False is used, which decodes bytes as UTF-8
        # This should be present in the initial buggy state
        assert 'raw=False' in content or 'raw = False' in content or \
               ('msgpack' in content.lower() and 'unpack' in content.lower()), \
            f"manifest.py doesn't appear to use msgpack unpacking"

    def test_chunk_store_has_fuzzy_matching(self):
        """The chunk_store.py should have fuzzy/prefix matching as a bug."""
        with open(CHUNK_STORE_PY, 'r') as f:
            content = f.read().lower()
        # Look for signs of the fuzzy matching fallback
        has_prefix_logic = 'prefix' in content or 'similar' in content or \
                          'startswith' in content or 'fallback' in content
        assert has_prefix_logic, \
            "chunk_store.py doesn't appear to have the fuzzy matching bug"


class TestDirectoryWritable:
    """Test that required directories are writable."""

    def test_backup_dir_writable(self):
        assert os.access(BACKUP_DIR, os.W_OK), \
            f"Backup directory {BACKUP_DIR} is not writable"

    def test_restored_dir_writable(self):
        assert os.access(RESTORED_DIR, os.W_OK), \
            f"Restored directory {RESTORED_DIR} is not writable"

    def test_lib_dir_writable(self):
        assert os.access(LIB_DIR, os.W_OK), \
            f"Lib directory {LIB_DIR} is not writable"


class TestLibInitFile:
    """Test that lib directory is a proper Python package."""

    def test_lib_init_exists_or_namespace(self):
        init_file = os.path.join(LIB_DIR, "__init__.py")
        # Either __init__.py exists or we're using namespace packages
        # Both are valid for Python 3
        py_files = [f for f in os.listdir(LIB_DIR) if f.endswith('.py')]
        assert len(py_files) >= 3, \
            f"Expected at least 3 Python files in lib/, found {len(py_files)}"
