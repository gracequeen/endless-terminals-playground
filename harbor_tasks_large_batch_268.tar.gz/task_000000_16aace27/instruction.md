I've got a disaster recovery script at /home/user/backup/dr_restore.sh that's supposed to pull our service configs from a deduplicated backup store and rebuild the container compose files. Ran it after a mock DR drill and it completed without errors, but the restored docker-compose.yml files are garbage — services are missing, some have wrong images, port mappings are jumbled. The weird part is the checksums all pass, so the backup integrity looks fine?

The backup system uses content-addressable chunks with a manifest, pretty standard stuff. Script worked perfectly three months ago when we tested it. Only thing that changed since then is we migrated from json manifests to msgpack for space savings — maybe something got weird in the conversion but idk, the manifest loader seems to read them fine.

Need the restore script actually producing valid compose files again. There's a reference at /home/user/backup/expected/ showing what the output should look like for our test dataset.
