# test_final_state.py
"""
Tests to validate the final state of the OS/filesystem after the student
has completed the disaster recovery script debugging task.
"""

import os
import subprocess
import pytest
import shutil
import tempfile


# Base paths
BACKUP_DIR = "/home/user/backup"
CHUNKS_DIR = os.path.join(BACKUP_DIR, "chunks")
MANIFESTS_DIR = os.path.join(BACKUP_DIR, "manifests")
RESTORED_DIR = os.path.join(BACKUP_DIR, "restored")
EXPECTED_DIR = os.path.join(BACKUP_DIR, "expected")
LIB_DIR = os.path.join(BACKUP_DIR, "lib")

# Expected files
DR_RESTORE_SCRIPT = os.path.join(BACKUP_DIR, "dr_restore.sh")
CHUNK_STORE_PY = os.path.join(LIB_DIR, "chunk_store.py")
MANIFEST_PY = os.path.join(LIB_DIR, "manifest.py")
COMPOSE_BUILDER_PY = os.path.join(LIB_DIR, "compose_builder.py")

EXPECTED_COMPOSE_FILES = ["api.yml", "worker.yml", "gateway.yml"]


class TestDrRestoreScriptExecution:
    """Test that the DR restore script runs successfully."""

    def test_dr_restore_script_exits_zero(self):
        """The dr_restore.sh script must exit with code 0."""
        # First, clear the restored directory to ensure fresh run
        if os.path.isdir(RESTORED_DIR):
            for f in os.listdir(RESTORED_DIR):
                filepath = os.path.join(RESTORED_DIR, f)
                if os.path.isfile(filepath):
                    os.remove(filepath)

        result = subprocess.run(
            ["bash", DR_RESTORE_SCRIPT],
            capture_output=True,
            text=True,
            cwd=BACKUP_DIR
        )
        assert result.returncode == 0, \
            f"dr_restore.sh exited with code {result.returncode}.\n" \
            f"stdout: {result.stdout}\nstderr: {result.stderr}"


class TestRestoredFilesMatchExpected:
    """Test that restored compose files match expected output exactly."""

    @pytest.fixture(autouse=True)
    def run_restore_script(self):
        """Run the restore script before testing output."""
        # Clear restored directory
        if os.path.isdir(RESTORED_DIR):
            for f in os.listdir(RESTORED_DIR):
                filepath = os.path.join(RESTORED_DIR, f)
                if os.path.isfile(filepath):
                    os.remove(filepath)

        # Run the restore script
        result = subprocess.run(
            ["bash", DR_RESTORE_SCRIPT],
            capture_output=True,
            text=True,
            cwd=BACKUP_DIR
        )
        # Store result for potential debugging
        self._restore_result = result

    @pytest.mark.parametrize("compose_file", EXPECTED_COMPOSE_FILES)
    def test_restored_file_exists(self, compose_file):
        """Each expected compose file must exist in restored/."""
        restored_path = os.path.join(RESTORED_DIR, compose_file)
        assert os.path.isfile(restored_path), \
            f"Restored file {restored_path} does not exist after running dr_restore.sh"

    @pytest.mark.parametrize("compose_file", EXPECTED_COMPOSE_FILES)
    def test_restored_file_matches_expected(self, compose_file):
        """Each restored file must match its expected counterpart exactly."""
        restored_path = os.path.join(RESTORED_DIR, compose_file)
        expected_path = os.path.join(EXPECTED_DIR, compose_file)

        # Use diff to compare
        result = subprocess.run(
            ["diff", "-u", expected_path, restored_path],
            capture_output=True,
            text=True
        )

        assert result.returncode == 0, \
            f"Restored {compose_file} does not match expected.\n" \
            f"Diff output:\n{result.stdout}"

    def test_diff_recursive_no_differences(self):
        """diff -r between restored/ and expected/ must show no differences."""
        result = subprocess.run(
            ["diff", "-r", RESTORED_DIR, EXPECTED_DIR],
            capture_output=True,
            text=True
        )

        assert result.returncode == 0, \
            f"Differences found between restored/ and expected/:\n{result.stdout}"


class TestFuzzyMatchingRemoved:
    """Test that the fuzzy chunk matching bug has been removed."""

    def test_no_prefix_matching_in_chunk_store(self):
        """chunk_store.py must not have active prefix/similar matching logic."""
        with open(CHUNK_STORE_PY, 'r') as f:
            content = f.read()

        lines = content.split('\n')
        active_lines = []

        for line in lines:
            # Skip comments and empty lines
            stripped = line.strip()
            if stripped.startswith('#') or not stripped:
                continue
            # Check if line is inside a multi-line string (rough heuristic)
            # For simplicity, just check non-comment lines
            active_lines.append(stripped.lower())

        active_content = '\n'.join(active_lines)

        # Check for problematic patterns that indicate fuzzy matching
        problematic_patterns = []

        # Check for prefix-based matching
        if 'startswith' in active_content and ('prefix' in active_content or 'hash' in active_content or 'chunk' in active_content):
            # More specific check - look for patterns like hash.startswith or similar
            for line in active_lines:
                if 'startswith' in line and ('for ' in line or 'if ' in line or '[' in line):
                    # This looks like active prefix matching logic
                    if 'prefix' in line or 'similar' in line or 'fallback' in line:
                        problematic_patterns.append(f"Found active prefix matching: {line}")

        # Check for explicit "similar" or "fallback" logic that's not commented
        for i, line in enumerate(active_lines):
            if ('similar' in line or 'fallback' in line) and ('return' in line or '=' in line):
                if 'chunk' in line.lower() or 'hash' in line.lower() or 'ref' in line.lower():
                    problematic_patterns.append(f"Found potential fallback logic: {line}")

        # More direct check: look for the specific bug pattern
        # The bug would iterate over chunks looking for prefix matches
        if 'for ' in active_content and 'startswith' in active_content:
            for i, line in enumerate(active_lines):
                if 'for ' in line:
                    # Look at nearby lines for startswith
                    context = active_lines[max(0, i-2):min(len(active_lines), i+5)]
                    context_str = ' '.join(context)
                    if 'startswith' in context_str and ('chunk' in context_str or 'file' in context_str):
                        problematic_patterns.append(f"Found loop with startswith near: {line}")

        # If we found definite problematic patterns, fail
        # But be lenient - only fail if there's clear evidence of active fuzzy matching
        # A simple grep for keywords isn't enough - need to check context

        # Final check: just ensure the script works correctly (tested elsewhere)
        # and do a basic sanity check
        assert 'prefix' not in active_content or 'fallback' not in active_content or \
               len(problematic_patterns) == 0, \
            f"chunk_store.py appears to still have fuzzy matching logic:\n" + \
            '\n'.join(problematic_patterns)

    def test_grep_for_fuzzy_patterns(self):
        """grep for 'prefix' or 'similar' should not find active matching logic."""
        # Use grep to find lines with these patterns
        result = subprocess.run(
            ["grep", "-n", "-E", "(prefix|similar)", CHUNK_STORE_PY],
            capture_output=True,
            text=True
        )

        if result.returncode == 0 and result.stdout.strip():
            # Found matches - check if they're in comments
            lines = result.stdout.strip().split('\n')
            active_matches = []

            for line in lines:
                # Line format: "linenum:content"
                if ':' in line:
                    content = line.split(':', 1)[1].strip()
                    # Skip if it's a comment
                    if not content.startswith('#'):
                        # Skip if it's in a string (rough check)
                        if not (content.startswith('"') or content.startswith("'")):
                            active_matches.append(line)

            # Allow some matches if they're clearly not the bug
            # (e.g., variable names, error messages)
            real_problems = []
            for match in active_matches:
                content = match.split(':', 1)[1].lower() if ':' in match else match.lower()
                # Check if this looks like active fuzzy matching code
                if ('if ' in content or 'for ' in content or 'return ' in content) and \
                   ('prefix' in content or 'similar' in content):
                    real_problems.append(match)

            if real_problems:
                pytest.fail(
                    f"Found active fuzzy matching patterns in chunk_store.py:\n" +
                    '\n'.join(real_problems)
                )


class TestInvariantsPreserved:
    """Test that invariants (chunks and manifests) are unchanged."""

    def test_chunks_directory_exists(self):
        """chunks/ directory must still exist."""
        assert os.path.isdir(CHUNKS_DIR), \
            f"Chunks directory {CHUNKS_DIR} was removed or doesn't exist"

    def test_chunks_have_content(self):
        """chunks/ directory must have files."""
        chunk_files = os.listdir(CHUNKS_DIR)
        assert len(chunk_files) > 0, \
            f"Chunks directory {CHUNKS_DIR} is empty"

    def test_manifests_directory_exists(self):
        """manifests/ directory must still exist."""
        assert os.path.isdir(MANIFESTS_DIR), \
            f"Manifests directory {MANIFESTS_DIR} was removed or doesn't exist"

    def test_manifests_have_mpk_files(self):
        """manifests/ directory must have .mpk files."""
        mpk_files = [f for f in os.listdir(MANIFESTS_DIR) if f.endswith('.mpk')]
        assert len(mpk_files) >= 3, \
            f"Expected at least 3 .mpk manifest files, found {len(mpk_files)}"

    def test_expected_directory_unchanged(self):
        """expected/ directory must still exist with all files."""
        assert os.path.isdir(EXPECTED_DIR), \
            f"Expected directory {EXPECTED_DIR} was removed or doesn't exist"

        for compose_file in EXPECTED_COMPOSE_FILES:
            filepath = os.path.join(EXPECTED_DIR, compose_file)
            assert os.path.isfile(filepath), \
                f"Expected file {filepath} was removed"


class TestFixIsInPythonCode:
    """Test that the fix was made in Python code, not by cheating."""

    def test_dr_restore_script_not_just_copy(self):
        """dr_restore.sh should not just copy expected/ to restored/."""
        with open(DR_RESTORE_SCRIPT, 'r') as f:
            content = f.read()

        # Check for obvious copy commands from expected to restored
        suspicious_patterns = [
            'cp.*expected.*restored',
            'cp -r.*expected.*restored',
            'rsync.*expected.*restored',
            'mv.*expected.*restored',
        ]

        import re
        for pattern in suspicious_patterns:
            if re.search(pattern, content, re.IGNORECASE):
                pytest.fail(
                    f"dr_restore.sh appears to just copy expected/ to restored/ "
                    f"instead of fixing the Python code"
                )

    def test_python_files_were_modified(self):
        """At least one Python file in lib/ should have been modified to fix the bug."""
        # We can't easily check modification time, but we can verify
        # the fix is present by checking the code works correctly
        # This is implicitly tested by TestRestoredFilesMatchExpected
        pass


class TestFreshRestoreWorks:
    """Test that running restore on a fresh directory produces correct output."""

    def test_fresh_restore_produces_correct_output(self):
        """Clear restored/ and re-run to verify fix works from scratch."""
        # Clear restored directory completely
        if os.path.isdir(RESTORED_DIR):
            shutil.rmtree(RESTORED_DIR)
        os.makedirs(RESTORED_DIR)

        # Run restore script
        result = subprocess.run(
            ["bash", DR_RESTORE_SCRIPT],
            capture_output=True,
            text=True,
            cwd=BACKUP_DIR
        )

        assert result.returncode == 0, \
            f"dr_restore.sh failed on fresh run: {result.stderr}"

        # Verify all files match
        for compose_file in EXPECTED_COMPOSE_FILES:
            restored_path = os.path.join(RESTORED_DIR, compose_file)
            expected_path = os.path.join(EXPECTED_DIR, compose_file)

            assert os.path.isfile(restored_path), \
                f"Fresh restore did not create {compose_file}"

            diff_result = subprocess.run(
                ["diff", "-u", expected_path, restored_path],
                capture_output=True,
                text=True
            )

            assert diff_result.returncode == 0, \
                f"Fresh restore of {compose_file} doesn't match expected:\n{diff_result.stdout}"
