# test_initial_state.py
"""
Tests to validate the initial state of the system before the student performs
the permission fix task for the ETL pipeline.
"""

import os
import pwd
import stat
import subprocess
import pytest


class TestUserAndSystemSetup:
    """Verify required users and system configuration exist."""

    def test_etl_svc_user_exists(self):
        """The etl_svc user must exist in the system."""
        try:
            pwd.getpwnam('etl_svc')
        except KeyError:
            pytest.fail("User 'etl_svc' does not exist in /etc/passwd")

    def test_user_account_exists(self):
        """The user account must exist."""
        try:
            pwd.getpwnam('user')
        except KeyError:
            pytest.fail("User 'user' does not exist in /etc/passwd")

    def test_python3_available(self):
        """Python 3 must be installed and accessible."""
        result = subprocess.run(['python3', '--version'], capture_output=True)
        assert result.returncode == 0, "Python 3 is not installed or not accessible"


class TestPipelineDirectoryStructure:
    """Verify the pipeline directory structure exists."""

    def test_pipeline_directory_exists(self):
        """The main pipeline directory must exist."""
        assert os.path.isdir('/home/user/pipeline'), \
            "Pipeline directory /home/user/pipeline does not exist"

    def test_staging_directory_exists(self):
        """The staging directory must exist."""
        assert os.path.isdir('/home/user/pipeline/staging'), \
            "Staging directory /home/user/pipeline/staging does not exist"

    def test_scripts_directory_exists(self):
        """The scripts directory must exist."""
        assert os.path.isdir('/home/user/pipeline/scripts'), \
            "Scripts directory /home/user/pipeline/scripts does not exist"

    def test_work_directory_exists(self):
        """The work directory must exist."""
        assert os.path.isdir('/home/user/pipeline/work'), \
            "Work directory /home/user/pipeline/work does not exist"

    def test_output_directory_exists(self):
        """The output directory must exist."""
        assert os.path.isdir('/home/user/pipeline/output'), \
            "Output directory /home/user/pipeline/output does not exist"


class TestPipelineScripts:
    """Verify all required pipeline scripts exist and are executable."""

    def test_run_etl_script_exists(self):
        """The main ETL script must exist."""
        assert os.path.isfile('/home/user/pipeline/run_etl.sh'), \
            "Main ETL script /home/user/pipeline/run_etl.sh does not exist"

    def test_run_etl_script_executable(self):
        """The main ETL script must be executable."""
        mode = os.stat('/home/user/pipeline/run_etl.sh').st_mode
        assert mode & stat.S_IXUSR, \
            "run_etl.sh is not executable by owner"

    def test_check_as_etl_script_exists(self):
        """The check_as_etl.sh script must exist."""
        assert os.path.isfile('/home/user/pipeline/check_as_etl.sh'), \
            "Test script /home/user/pipeline/check_as_etl.sh does not exist"

    def test_check_as_etl_script_executable(self):
        """The check_as_etl.sh script must be executable."""
        mode = os.stat('/home/user/pipeline/check_as_etl.sh').st_mode
        assert mode & stat.S_IXUSR, \
            "check_as_etl.sh is not executable by owner"

    def test_validate_script_exists(self):
        """The validate.py script must exist."""
        assert os.path.isfile('/home/user/pipeline/scripts/validate.py'), \
            "Script /home/user/pipeline/scripts/validate.py does not exist"

    def test_transform_script_exists(self):
        """The transform.py script must exist."""
        assert os.path.isfile('/home/user/pipeline/scripts/transform.py'), \
            "Script /home/user/pipeline/scripts/transform.py does not exist"

    def test_aggregate_script_exists(self):
        """The aggregate.py script must exist."""
        assert os.path.isfile('/home/user/pipeline/scripts/aggregate.py'), \
            "Script /home/user/pipeline/scripts/aggregate.py does not exist"

    def test_python_scripts_executable(self):
        """All Python scripts must be executable."""
        scripts = [
            '/home/user/pipeline/scripts/validate.py',
            '/home/user/pipeline/scripts/transform.py',
            '/home/user/pipeline/scripts/aggregate.py'
        ]
        for script in scripts:
            mode = os.stat(script).st_mode
            assert mode & stat.S_IXUSR, f"{script} is not executable"


class TestStagingData:
    """Verify staging data files exist."""

    def test_input1_csv_exists(self):
        """input1.csv must exist in staging."""
        assert os.path.isfile('/home/user/pipeline/staging/input1.csv'), \
            "Input file /home/user/pipeline/staging/input1.csv does not exist"

    def test_input2_csv_exists(self):
        """input2.csv must exist in staging."""
        assert os.path.isfile('/home/user/pipeline/staging/input2.csv'), \
            "Input file /home/user/pipeline/staging/input2.csv does not exist"


class TestDirectoryPermissions:
    """Verify directory permissions match the initial buggy state."""

    def test_staging_permissions(self):
        """Staging directory should be 755 (readable by all)."""
        mode = stat.S_IMODE(os.stat('/home/user/pipeline/staging').st_mode)
        assert mode == 0o755, \
            f"Staging directory has permissions {oct(mode)}, expected 0o755"

    def test_scripts_permissions(self):
        """Scripts directory should be 755 (readable by all)."""
        mode = stat.S_IMODE(os.stat('/home/user/pipeline/scripts').st_mode)
        assert mode == 0o755, \
            f"Scripts directory has permissions {oct(mode)}, expected 0o755"

    def test_work_directory_has_restrictive_permissions(self):
        """Work directory should be 750 (the bug - etl_svc cannot write)."""
        mode = stat.S_IMODE(os.stat('/home/user/pipeline/work').st_mode)
        assert mode == 0o750, \
            f"Work directory has permissions {oct(mode)}, expected 0o750 (the bug)"

    def test_output_permissions(self):
        """Output directory should be 777 (writable by all)."""
        mode = stat.S_IMODE(os.stat('/home/user/pipeline/output').st_mode)
        assert mode == 0o777, \
            f"Output directory has permissions {oct(mode)}, expected 0o777"


class TestOwnership:
    """Verify file and directory ownership."""

    def test_pipeline_owned_by_user(self):
        """Pipeline directory should be owned by user."""
        stat_info = os.stat('/home/user/pipeline')
        owner = pwd.getpwuid(stat_info.st_uid).pw_name
        assert owner == 'user', \
            f"Pipeline directory owned by {owner}, expected 'user'"

    def test_work_directory_owned_by_user(self):
        """Work directory should be owned by user (part of the bug)."""
        stat_info = os.stat('/home/user/pipeline/work')
        owner = pwd.getpwuid(stat_info.st_uid).pw_name
        assert owner == 'user', \
            f"Work directory owned by {owner}, expected 'user'"


class TestInputFilePermissions:
    """Verify input file permissions."""

    def test_input1_csv_permissions(self):
        """input1.csv should be 644."""
        mode = stat.S_IMODE(os.stat('/home/user/pipeline/staging/input1.csv').st_mode)
        assert mode == 0o644, \
            f"input1.csv has permissions {oct(mode)}, expected 0o644"

    def test_input2_csv_permissions(self):
        """input2.csv should be 644."""
        mode = stat.S_IMODE(os.stat('/home/user/pipeline/staging/input2.csv').st_mode)
        assert mode == 0o644, \
            f"input2.csv has permissions {oct(mode)}, expected 0o644"


class TestSudoCapability:
    """Verify sudo capability for running as etl_svc."""

    def test_can_sudo_to_etl_svc(self):
        """User should be able to sudo to etl_svc without password."""
        result = subprocess.run(
            ['sudo', '-n', '-u', 'etl_svc', 'whoami'],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            "Cannot sudo to etl_svc without password"
        assert result.stdout.strip() == 'etl_svc', \
            f"sudo -u etl_svc whoami returned '{result.stdout.strip()}', expected 'etl_svc'"


class TestInitialBuggyState:
    """Verify the pipeline fails when run as etl_svc (the bug exists)."""

    def test_check_as_etl_fails(self):
        """check_as_etl.sh should fail in the initial state (confirming the bug)."""
        result = subprocess.run(
            ['/home/user/pipeline/check_as_etl.sh'],
            capture_output=True,
            text=True,
            cwd='/home/user/pipeline'
        )
        assert result.returncode != 0, \
            "check_as_etl.sh succeeded but should fail in initial buggy state"

    def test_pipeline_fails_as_etl_svc(self):
        """Running pipeline directly as etl_svc should fail (confirming the bug)."""
        result = subprocess.run(
            ['sudo', '-u', 'etl_svc', '/home/user/pipeline/run_etl.sh'],
            capture_output=True,
            text=True,
            cwd='/home/user/pipeline'
        )
        assert result.returncode != 0, \
            "Pipeline succeeded as etl_svc but should fail due to work/ permissions"
