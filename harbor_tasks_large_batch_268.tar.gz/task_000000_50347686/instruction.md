I'm auditing file permissions on a data pipeline at /home/user/pipeline and something's off — the nightly job (/home/user/pipeline/run_etl.sh) has been failing silently for a few days according to the cron logs, but when I run it manually as the `user` account it works fine. The job runs as `etl_svc` in production.

I need to figure out which file or directory has the wrong permissions that's causing `etl_svc` to fail, and fix it so the pipeline can run successfully as that user. There's a test script at /home/user/pipeline/check_as_etl.sh that simulates running the job as `etl_svc` — right now it's failing with some generic "pipeline failed" message but not saying exactly where.

The pipeline pulls from a staging area, transforms through a couple steps, and writes to an output dir. Somewhere in that chain the perms are wrong. Just need `etl_svc` to be able to run the full pipeline successfully.
