# test_final_state.py
"""
Tests to validate the final state of the system after the student has fixed
the permission issue for the ETL pipeline.
"""

import os
import pwd
import grp
import stat
import subprocess
import hashlib
import pytest


class TestUserAndSystemIntegrity:
    """Verify required users still exist and system is intact."""

    def test_etl_svc_user_still_exists(self):
        """The etl_svc user must still exist in the system."""
        try:
            pwd.getpwnam('etl_svc')
        except KeyError:
            pytest.fail("User 'etl_svc' no longer exists - this should not have been removed")

    def test_user_account_still_exists(self):
        """The user account must still exist."""
        try:
            pwd.getpwnam('user')
        except KeyError:
            pytest.fail("User 'user' no longer exists - this should not have been removed")


class TestPipelineDirectoryStructureIntact:
    """Verify the pipeline directory structure is still intact."""

    def test_pipeline_directory_exists(self):
        """The main pipeline directory must still exist."""
        assert os.path.isdir('/home/user/pipeline'), \
            "Pipeline directory /home/user/pipeline does not exist"

    def test_staging_directory_exists(self):
        """The staging directory must still exist."""
        assert os.path.isdir('/home/user/pipeline/staging'), \
            "Staging directory /home/user/pipeline/staging does not exist"

    def test_scripts_directory_exists(self):
        """The scripts directory must still exist."""
        assert os.path.isdir('/home/user/pipeline/scripts'), \
            "Scripts directory /home/user/pipeline/scripts does not exist"

    def test_work_directory_exists(self):
        """The work directory must still exist."""
        assert os.path.isdir('/home/user/pipeline/work'), \
            "Work directory /home/user/pipeline/work does not exist"

    def test_output_directory_exists(self):
        """The output directory must still exist."""
        assert os.path.isdir('/home/user/pipeline/output'), \
            "Output directory /home/user/pipeline/output does not exist"


class TestStagingDataIntact:
    """Verify staging data files were not modified."""

    def test_input1_csv_exists(self):
        """input1.csv must still exist in staging."""
        assert os.path.isfile('/home/user/pipeline/staging/input1.csv'), \
            "Input file /home/user/pipeline/staging/input1.csv was removed or renamed"

    def test_input2_csv_exists(self):
        """input2.csv must still exist in staging."""
        assert os.path.isfile('/home/user/pipeline/staging/input2.csv'), \
            "Input file /home/user/pipeline/staging/input2.csv was removed or renamed"


class TestPipelineScriptsNotModified:
    """Verify pipeline scripts were not modified (anti-shortcut guard)."""

    def test_validate_script_exists(self):
        """The validate.py script must still exist."""
        assert os.path.isfile('/home/user/pipeline/scripts/validate.py'), \
            "Script /home/user/pipeline/scripts/validate.py was removed"

    def test_transform_script_exists(self):
        """The transform.py script must still exist."""
        assert os.path.isfile('/home/user/pipeline/scripts/transform.py'), \
            "Script /home/user/pipeline/scripts/transform.py was removed"

    def test_aggregate_script_exists(self):
        """The aggregate.py script must still exist."""
        assert os.path.isfile('/home/user/pipeline/scripts/aggregate.py'), \
            "Script /home/user/pipeline/scripts/aggregate.py was removed"

    def test_run_etl_script_exists(self):
        """The main ETL script must still exist."""
        assert os.path.isfile('/home/user/pipeline/run_etl.sh'), \
            "Main ETL script /home/user/pipeline/run_etl.sh was removed"


class TestWorkDirectoryPermissionsFix:
    """Verify the work directory permissions allow etl_svc to write."""

    def test_work_directory_writable_by_etl_svc(self):
        """
        The work directory must be writable by etl_svc.
        This can be achieved via world-write permissions, group permissions,
        ownership change, or ACLs.
        """
        # Test by actually trying to write as etl_svc
        result = subprocess.run(
            ['sudo', '-n', '-u', 'etl_svc', 'touch', '/home/user/pipeline/work/.write_test'],
            capture_output=True,
            text=True
        )

        if result.returncode == 0:
            # Clean up test file
            subprocess.run(
                ['sudo', '-n', '-u', 'etl_svc', 'rm', '-f', '/home/user/pipeline/work/.write_test'],
                capture_output=True
            )
            return  # Test passed

        # If direct test failed, check permissions more thoroughly
        stat_info = os.stat('/home/user/pipeline/work')
        mode = stat.S_IMODE(stat_info.st_mode)

        # Check if world-writable
        if mode & stat.S_IWOTH:
            pytest.fail(
                f"Work directory appears world-writable (mode {oct(mode)}) but "
                f"etl_svc still cannot write. Error: {result.stderr}"
            )

        # Check if group-writable and etl_svc is in the group
        if mode & stat.S_IWGRP:
            try:
                group_info = grp.getgrgid(stat_info.st_gid)
                etl_user_info = pwd.getpwnam('etl_svc')
                if 'etl_svc' in group_info.gr_mem or etl_user_info.pw_gid == stat_info.st_gid:
                    pytest.fail(
                        f"Work directory group-writable and etl_svc appears to be in group, "
                        f"but still cannot write. Error: {result.stderr}"
                    )
            except (KeyError, AttributeError):
                pass

        # Check if owned by etl_svc
        try:
            owner = pwd.getpwuid(stat_info.st_uid).pw_name
            if owner == 'etl_svc':
                pytest.fail(
                    f"Work directory owned by etl_svc but still cannot write. "
                    f"Mode: {oct(mode)}, Error: {result.stderr}"
                )
        except KeyError:
            pass

        pytest.fail(
            f"Work directory /home/user/pipeline/work is not writable by etl_svc. "
            f"Current mode: {oct(mode)}. The permission fix was not applied correctly. "
            f"Error when trying to write: {result.stderr}"
        )


class TestPipelineRunsAsEtlSvc:
    """Verify the pipeline runs successfully as etl_svc."""

    def test_check_as_etl_succeeds(self):
        """check_as_etl.sh should now succeed."""
        result = subprocess.run(
            ['/home/user/pipeline/check_as_etl.sh'],
            capture_output=True,
            text=True,
            cwd='/home/user/pipeline'
        )
        assert result.returncode == 0, \
            f"check_as_etl.sh still fails with exit code {result.returncode}. " \
            f"stdout: {result.stdout}, stderr: {result.stderr}"

    def test_pipeline_succeeds_as_etl_svc_directly(self):
        """Running pipeline directly as etl_svc should succeed."""
        # Clean up any previous output first
        subprocess.run(
            ['sudo', '-n', '-u', 'etl_svc', 'rm', '-rf', '/home/user/pipeline/output/*'],
            capture_output=True,
            shell=False
        )
        # Also clean via shell to handle glob
        subprocess.run(
            'sudo -n -u etl_svc rm -f /home/user/pipeline/output/*',
            capture_output=True,
            shell=True
        )

        result = subprocess.run(
            ['sudo', '-n', '-u', 'etl_svc', '/home/user/pipeline/run_etl.sh'],
            capture_output=True,
            text=True,
            cwd='/home/user/pipeline'
        )
        assert result.returncode == 0, \
            f"Pipeline failed when run as etl_svc with exit code {result.returncode}. " \
            f"stdout: {result.stdout}, stderr: {result.stderr}"


class TestOutputProduced:
    """Verify the pipeline produces output files."""

    def test_output_directory_has_files(self):
        """Output directory should contain files after successful run."""
        # First run the pipeline as etl_svc to ensure output is generated
        subprocess.run(
            ['sudo', '-n', '-u', 'etl_svc', '/home/user/pipeline/run_etl.sh'],
            capture_output=True,
            cwd='/home/user/pipeline'
        )

        output_dir = '/home/user/pipeline/output'
        files = os.listdir(output_dir)
        # Filter out hidden files and empty entries
        output_files = [f for f in files if not f.startswith('.') and f]

        assert len(output_files) > 0, \
            f"Output directory /home/user/pipeline/output is empty after pipeline run. " \
            f"The pipeline should produce aggregated output files."

    def test_output_files_are_readable(self):
        """Output files should be readable."""
        output_dir = '/home/user/pipeline/output'
        files = os.listdir(output_dir)
        output_files = [f for f in files if not f.startswith('.') and f]

        for filename in output_files:
            filepath = os.path.join(output_dir, filename)
            if os.path.isfile(filepath):
                assert os.access(filepath, os.R_OK), \
                    f"Output file {filepath} is not readable"
                # Check file has content
                assert os.path.getsize(filepath) > 0, \
                    f"Output file {filepath} is empty"


class TestCompleteEndToEndValidation:
    """Complete end-to-end validation that the fix works."""

    def test_full_pipeline_cycle_as_etl_svc(self):
        """
        Run a complete pipeline cycle as etl_svc and verify all stages complete.
        This is the definitive test that the permission fix is correct.
        """
        # Clean output directory
        subprocess.run(
            'rm -f /home/user/pipeline/output/*',
            shell=True,
            capture_output=True
        )

        # Clean work directory
        subprocess.run(
            'rm -f /home/user/pipeline/work/*',
            shell=True,
            capture_output=True
        )

        # Run the full pipeline as etl_svc
        result = subprocess.run(
            ['sudo', '-n', '-u', 'etl_svc', '/home/user/pipeline/run_etl.sh'],
            capture_output=True,
            text=True,
            cwd='/home/user/pipeline'
        )

        # Check exit code
        assert result.returncode == 0, \
            f"Full pipeline cycle failed as etl_svc. Exit code: {result.returncode}. " \
            f"This indicates the permission fix is incomplete or incorrect. " \
            f"stderr: {result.stderr}"

        # Verify output was produced
        output_dir = '/home/user/pipeline/output'
        output_files = [f for f in os.listdir(output_dir) 
                       if os.path.isfile(os.path.join(output_dir, f)) and not f.startswith('.')]

        assert len(output_files) > 0, \
            "Pipeline completed but no output files were produced. " \
            "Check that aggregate.py is writing to the output directory correctly."
