# test_final_state.py
"""
Tests to validate the final state of the OS/filesystem after the student
has fixed the Japanese locale issue in the Flask webapp.
"""

import os
import subprocess
import time
import socket
import signal
import pytest


# Base paths
HOME = "/home/user"
WEBAPP = "/home/user/webapp"
TRANSLATIONS = "/home/user/webapp/translations"


def is_port_in_use(port):
    """Check if a port is in use."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        return s.connect_ex(('localhost', port)) == 0


def wait_for_port(port, timeout=10):
    """Wait for a port to become available."""
    start = time.time()
    while time.time() - start < timeout:
        if is_port_in_use(port):
            return True
        time.sleep(0.2)
    return False


def kill_process_on_port(port):
    """Kill any process listening on the given port."""
    try:
        result = subprocess.run(
            ["fuser", "-k", f"{port}/tcp"],
            capture_output=True,
            timeout=5
        )
    except Exception:
        pass
    time.sleep(0.5)


class TestWebappStructure:
    """Test that the webapp directory structure still exists."""

    def test_webapp_directory_exists(self):
        assert os.path.isdir(WEBAPP), f"Webapp directory {WEBAPP} does not exist"

    def test_app_py_exists(self):
        app_path = os.path.join(WEBAPP, "app.py")
        assert os.path.isfile(app_path), f"Main app file {app_path} does not exist"

    def test_cache_py_exists(self):
        """cache.py must still exist (not deleted as a workaround)."""
        cache_path = os.path.join(WEBAPP, "cache.py")
        assert os.path.isfile(cache_path), f"Cache module {cache_path} does not exist - it should not be deleted"


class TestTranslationsPreserved:
    """Test that translation files are preserved."""

    @pytest.mark.parametrize("locale", ["de", "fr", "ja"])
    def test_messages_po_exists(self, locale):
        po_file = os.path.join(TRANSLATIONS, locale, "LC_MESSAGES", "messages.po")
        assert os.path.isfile(po_file), f"PO file {po_file} does not exist"

    @pytest.mark.parametrize("locale", ["de", "fr", "ja"])
    def test_messages_mo_exists(self, locale):
        mo_file = os.path.join(TRANSLATIONS, locale, "LC_MESSAGES", "messages.mo")
        assert os.path.isfile(mo_file), f"MO file {mo_file} does not exist"


class TestJapanesePOFilePreserved:
    """Test that the Japanese PO file content is preserved."""

    def test_ja_po_contains_welcome_message(self):
        """Japanese PO file should still contain the user's welcome message translation."""
        po_file = os.path.join(TRANSLATIONS, "ja", "LC_MESSAGES", "messages.po")
        with open(po_file, "r", encoding="utf-8") as f:
            content = f.read()
        expected = "ようこそ、%(name)s様！"
        assert expected in content, \
            f"Japanese PO file does not contain expected welcome message: {expected} - user's translations must be preserved"


class TestJapaneseMOFileValid:
    """Test that the Japanese MO file is valid."""

    def test_ja_mo_is_valid_gnu_mo(self):
        """Japanese MO file must be a valid GNU message catalog."""
        mo_file = os.path.join(TRANSLATIONS, "ja", "LC_MESSAGES", "messages.mo")
        result = subprocess.run(
            ["file", mo_file],
            capture_output=True,
            text=True
        )
        assert "GNU message catalog" in result.stdout, \
            f"Japanese MO file is not a valid GNU message catalog: {result.stdout}"


class TestBugFixed:
    """Test that the shift_jis encoding bug has been fixed."""

    def test_no_shift_jis_encoding_in_app_py(self):
        """app.py should no longer encode to shift_jis (the bug should be fixed)."""
        app_path = os.path.join(WEBAPP, "app.py")
        with open(app_path, "r", encoding="utf-8") as f:
            content = f.read()

        # Check that the problematic encode('shift_jis') pattern is removed or commented out
        lines = content.split('\n')
        for i, line in enumerate(lines):
            # Skip comments
            stripped = line.strip()
            if stripped.startswith('#'):
                continue
            # Check for the problematic pattern in active code
            if "encode('shift_jis')" in line or 'encode("shift_jis")' in line:
                pytest.fail(
                    f"app.py still contains active shift_jis encoding on line {i+1}: {line.strip()}\n"
                    "The legacy shift_jis re-encoding bug must be fixed."
                )


class TestCachePyRetryLogicPreserved:
    """Test that cache.py still contains retry logic (not just deleted as workaround)."""

    def test_cache_py_contains_retry_structure(self):
        """cache.py must still contain retry loop structure."""
        cache_path = os.path.join(WEBAPP, "cache.py")
        with open(cache_path, "r", encoding="utf-8") as f:
            content = f.read()

        # Check for retry-related patterns - the retry logic should still exist
        has_loop = "for" in content or "while" in content
        has_sleep = "sleep" in content

        assert has_loop and has_sleep, \
            "cache.py must still contain retry loop structure with sleep - don't delete the retry logic as a workaround"


class TestNoHardcodedJapanese:
    """Test that Japanese strings are not hardcoded (must come from .mo files via flask_babel)."""

    def test_no_hardcoded_japanese_in_app_py(self):
        """app.py must not contain hardcoded Japanese welcome message."""
        app_path = os.path.join(WEBAPP, "app.py")
        with open(app_path, "r", encoding="utf-8") as f:
            content = f.read()
        assert "ようこそ" not in content, \
            "app.py contains hardcoded Japanese text - translations must come from .mo files via flask_babel"

    def test_no_hardcoded_japanese_in_cache_py(self):
        """cache.py must not contain hardcoded Japanese welcome message."""
        cache_path = os.path.join(WEBAPP, "cache.py")
        with open(cache_path, "r", encoding="utf-8") as f:
            content = f.read()
        assert "ようこそ" not in content, \
            "cache.py contains hardcoded Japanese text - translations must come from .mo files via flask_babel"


class TestAppStartsWithJapaneseLocale:
    """Test that the app starts successfully with Japanese locale."""

    def test_app_starts_within_timeout(self):
        """App must start with LANG=ja_JP.UTF-8 within 10 seconds (no hang)."""
        # Kill any existing process on port 5000
        kill_process_on_port(5000)

        env = os.environ.copy()
        env["LANG"] = "ja_JP.UTF-8"
        env["LC_ALL"] = "ja_JP.UTF-8"

        # Start the app
        proc = subprocess.Popen(
            ["python", "app.py"],
            cwd=WEBAPP,
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            start_new_session=True
        )

        try:
            # Wait for the port to become available (max 10 seconds)
            started = wait_for_port(5000, timeout=10)

            if not started:
                # Check if process died
                poll = proc.poll()
                if poll is not None:
                    stdout, stderr = proc.communicate(timeout=2)
                    pytest.fail(
                        f"App crashed during startup with exit code {poll}.\n"
                        f"Stdout: {stdout.decode('utf-8', errors='replace')}\n"
                        f"Stderr: {stderr.decode('utf-8', errors='replace')}"
                    )
                else:
                    pytest.fail(
                        "App did not start within 10 seconds - it's likely hanging due to the unfixed bug"
                    )

            # App started successfully
            assert started, "App should be listening on port 5000"

        finally:
            # Clean up
            try:
                os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
            except Exception:
                pass
            try:
                proc.terminate()
                proc.wait(timeout=2)
            except Exception:
                proc.kill()


class TestJapaneseWelcomeMessage:
    """Test that the Japanese welcome message is correctly displayed."""

    def test_welcome_endpoint_returns_japanese(self):
        """The /welcome endpoint must return the correct Japanese translation."""
        # Kill any existing process on port 5000
        kill_process_on_port(5000)

        env = os.environ.copy()
        env["LANG"] = "ja_JP.UTF-8"
        env["LC_ALL"] = "ja_JP.UTF-8"

        # Start the app
        proc = subprocess.Popen(
            ["python", "app.py"],
            cwd=WEBAPP,
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            start_new_session=True
        )

        try:
            # Wait for the app to start
            if not wait_for_port(5000, timeout=10):
                poll = proc.poll()
                if poll is not None:
                    stdout, stderr = proc.communicate(timeout=2)
                    pytest.fail(
                        f"App failed to start. Exit code: {poll}\n"
                        f"Stderr: {stderr.decode('utf-8', errors='replace')}"
                    )
                pytest.fail("App did not start in time")

            # Make request to welcome endpoint
            result = subprocess.run(
                ["curl", "-s", "http://localhost:5000/welcome?name=Test"],
                capture_output=True,
                timeout=10
            )

            response = result.stdout.decode('utf-8', errors='replace')

            # Check for the expected Japanese welcome message
            assert "ようこそ" in response, \
                f"Response does not contain Japanese welcome text 'ようこそ'. Got: {response}"
            assert "Test" in response, \
                f"Response does not contain the name 'Test'. Got: {response}"
            assert "様" in response, \
                f"Response does not contain '様' (honorific). Got: {response}"

            # More specific check for the full pattern
            expected_pattern = "ようこそ、Test様！"
            assert expected_pattern in response, \
                f"Response does not contain expected message '{expected_pattern}'. Got: {response}"

        finally:
            # Clean up
            try:
                os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
            except Exception:
                pass
            try:
                proc.terminate()
                proc.wait(timeout=2)
            except Exception:
                proc.kill()
            kill_process_on_port(5000)


class TestOtherLocalesStillWork:
    """Test that German and French locales still work correctly."""

    @pytest.mark.parametrize("locale,lang_env", [
        ("de", "de_DE.UTF-8"),
        ("fr", "fr_FR.UTF-8"),
    ])
    def test_locale_still_works(self, locale, lang_env):
        """German and French locales must still work."""
        # Kill any existing process on port 5000
        kill_process_on_port(5000)

        env = os.environ.copy()
        env["LANG"] = lang_env
        env["LC_ALL"] = lang_env

        # Start the app
        proc = subprocess.Popen(
            ["python", "app.py"],
            cwd=WEBAPP,
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            start_new_session=True
        )

        try:
            # Wait for the app to start
            if not wait_for_port(5000, timeout=10):
                poll = proc.poll()
                if poll is not None:
                    stdout, stderr = proc.communicate(timeout=2)
                    pytest.fail(
                        f"App failed to start with {lang_env}. Exit code: {poll}\n"
                        f"Stderr: {stderr.decode('utf-8', errors='replace')}"
                    )
                pytest.fail(f"App did not start in time with {lang_env}")

            # Make request to welcome endpoint
            result = subprocess.run(
                ["curl", "-s", "http://localhost:5000/welcome?name=Test"],
                capture_output=True,
                timeout=10
            )

            assert result.returncode == 0, f"curl failed for {locale} locale"

            response = result.stdout.decode('utf-8', errors='replace')

            # Just verify we get a non-empty response (locale-specific content varies)
            assert len(response) > 0, f"Empty response for {locale} locale"
            assert "Test" in response or "error" not in response.lower(), \
                f"Unexpected response for {locale} locale: {response}"

        finally:
            # Clean up
            try:
                os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
            except Exception:
                pass
            try:
                proc.terminate()
                proc.wait(timeout=2)
            except Exception:
                proc.kill()
            kill_process_on_port(5000)


class TestFlaskBabelStillUsed:
    """Test that flask_babel is still used for i18n."""

    def test_app_imports_flask_babel(self):
        """app.py must still import and use flask_babel."""
        app_path = os.path.join(WEBAPP, "app.py")
        with open(app_path, "r", encoding="utf-8") as f:
            content = f.read()

        assert "flask_babel" in content or "from flask_babel" in content or "import flask_babel" in content, \
            "app.py must still use flask_babel for i18n - don't replace it with hardcoded strings"
