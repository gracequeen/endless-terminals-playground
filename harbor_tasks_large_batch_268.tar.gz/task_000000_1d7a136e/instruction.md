I'm trying to update the Japanese translations in /home/user/webapp but the app won't even start anymore — `python app.py` just hangs for like 30 seconds then crashes with some codec error about shift_jis. Thing is, I didn't touch the code, just edited ja.po with my translations and ran msgfmt to compile it. The German and French locales still work fine if I switch to those.

The weird part is my ja.po validates clean with `msgfmt --check` and the translations themselves are correct (I triple-checked the encoding, it's UTF-8 like all the others). So I don't get why it's choking specifically on Japanese. Maybe something about the string length or a format specifier mismatch? idk.

Need the app to start with LANG=ja_JP.UTF-8 and show my updated translations. The key string I changed is the welcome message — should say "ようこそ、%(name)s様！" now.
