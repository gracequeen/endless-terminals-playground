# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the action to fix the Japanese locale issue in the Flask webapp.
"""

import os
import subprocess
import pytest


# Base paths
HOME = "/home/user"
WEBAPP = "/home/user/webapp"
TRANSLATIONS = "/home/user/webapp/translations"


class TestWebappStructure:
    """Test that the webapp directory structure exists."""

    def test_webapp_directory_exists(self):
        assert os.path.isdir(WEBAPP), f"Webapp directory {WEBAPP} does not exist"

    def test_app_py_exists(self):
        app_path = os.path.join(WEBAPP, "app.py")
        assert os.path.isfile(app_path), f"Main app file {app_path} does not exist"

    def test_cache_py_exists(self):
        cache_path = os.path.join(WEBAPP, "cache.py")
        assert os.path.isfile(cache_path), f"Cache module {cache_path} does not exist"

    def test_babel_cfg_exists(self):
        babel_cfg = os.path.join(WEBAPP, "babel.cfg")
        assert os.path.isfile(babel_cfg), f"Babel config {babel_cfg} does not exist"

    def test_setup_cfg_exists(self):
        setup_cfg = os.path.join(WEBAPP, "setup.cfg")
        assert os.path.isfile(setup_cfg), f"Setup config {setup_cfg} does not exist"


class TestTranslationsStructure:
    """Test that translation directories and files exist."""

    def test_translations_directory_exists(self):
        assert os.path.isdir(TRANSLATIONS), f"Translations directory {TRANSLATIONS} does not exist"

    @pytest.mark.parametrize("locale", ["de", "fr", "ja"])
    def test_locale_directory_exists(self, locale):
        locale_dir = os.path.join(TRANSLATIONS, locale)
        assert os.path.isdir(locale_dir), f"Locale directory {locale_dir} does not exist"

    @pytest.mark.parametrize("locale", ["de", "fr", "ja"])
    def test_lc_messages_directory_exists(self, locale):
        lc_messages = os.path.join(TRANSLATIONS, locale, "LC_MESSAGES")
        assert os.path.isdir(lc_messages), f"LC_MESSAGES directory {lc_messages} does not exist"

    @pytest.mark.parametrize("locale", ["de", "fr", "ja"])
    def test_messages_po_exists(self, locale):
        po_file = os.path.join(TRANSLATIONS, locale, "LC_MESSAGES", "messages.po")
        assert os.path.isfile(po_file), f"PO file {po_file} does not exist"

    @pytest.mark.parametrize("locale", ["de", "fr", "ja"])
    def test_messages_mo_exists(self, locale):
        mo_file = os.path.join(TRANSLATIONS, locale, "LC_MESSAGES", "messages.mo")
        assert os.path.isfile(mo_file), f"MO file {mo_file} does not exist"

    def test_japanese_mo_backup_exists(self):
        """The red herring backup file should exist."""
        backup_file = os.path.join(TRANSLATIONS, "ja", "LC_MESSAGES", "messages.mo.bak")
        assert os.path.isfile(backup_file), f"Backup file {backup_file} does not exist (red herring file)"


class TestJapanesePOFile:
    """Test the Japanese PO file content and validity."""

    def test_ja_po_is_utf8(self):
        """Japanese PO file should be valid UTF-8."""
        po_file = os.path.join(TRANSLATIONS, "ja", "LC_MESSAGES", "messages.po")
        try:
            with open(po_file, "r", encoding="utf-8") as f:
                content = f.read()
        except UnicodeDecodeError:
            pytest.fail(f"Japanese PO file {po_file} is not valid UTF-8")

    def test_ja_po_contains_welcome_message(self):
        """Japanese PO file should contain the user's welcome message translation."""
        po_file = os.path.join(TRANSLATIONS, "ja", "LC_MESSAGES", "messages.po")
        with open(po_file, "r", encoding="utf-8") as f:
            content = f.read()
        expected = "ようこそ、%(name)s様！"
        assert expected in content, f"Japanese PO file does not contain expected welcome message: {expected}"

    def test_ja_po_validates_with_msgfmt(self):
        """Japanese PO file should pass msgfmt --check validation."""
        po_file = os.path.join(TRANSLATIONS, "ja", "LC_MESSAGES", "messages.po")
        result = subprocess.run(
            ["msgfmt", "--check", po_file, "-o", "/dev/null"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, f"msgfmt --check failed for {po_file}: {result.stderr}"


class TestJapaneseMOFile:
    """Test the Japanese MO file."""

    def test_ja_mo_is_valid_gnu_mo(self):
        """Japanese MO file should be a valid GNU message catalog."""
        mo_file = os.path.join(TRANSLATIONS, "ja", "LC_MESSAGES", "messages.mo")
        result = subprocess.run(
            ["file", mo_file],
            capture_output=True,
            text=True
        )
        assert "GNU message catalog" in result.stdout, \
            f"Japanese MO file is not a valid GNU message catalog: {result.stdout}"


class TestAppPyContainsBug:
    """Test that app.py contains the buggy code that needs to be fixed."""

    def test_app_py_contains_shift_jis_encoding(self):
        """app.py should contain the legacy shift_jis encoding bug."""
        app_path = os.path.join(WEBAPP, "app.py")
        with open(app_path, "r", encoding="utf-8") as f:
            content = f.read()
        assert "shift_jis" in content, \
            "app.py does not contain 'shift_jis' - the bug may not be present"

    def test_app_py_contains_ja_locale_check(self):
        """app.py should contain the Japanese locale check."""
        app_path = os.path.join(WEBAPP, "app.py")
        with open(app_path, "r", encoding="utf-8") as f:
            content = f.read()
        assert "startswith('ja')" in content or 'startswith("ja")' in content, \
            "app.py does not contain Japanese locale check"

    def test_app_py_contains_legacy_comment(self):
        """app.py should contain the legacy Windows XP comment."""
        app_path = os.path.join(WEBAPP, "app.py")
        with open(app_path, "r", encoding="utf-8") as f:
            content = f.read()
        # Check for parts of the legacy comment
        assert "legacy" in content.lower() or "windows" in content.lower(), \
            "app.py does not contain expected legacy/Windows comments"


class TestCachePyContainsRetryLogic:
    """Test that cache.py contains the retry logic."""

    def test_cache_py_contains_retry_logic(self):
        """cache.py should contain retry loop logic."""
        cache_path = os.path.join(WEBAPP, "cache.py")
        with open(cache_path, "r", encoding="utf-8") as f:
            content = f.read()
        # Check for retry-related patterns
        has_retry = ("retry" in content.lower() or 
                     "sleep" in content or 
                     ("for" in content and "range" in content))
        assert has_retry, "cache.py does not appear to contain retry logic"

    def test_cache_py_contains_sleep(self):
        """cache.py should contain sleep calls for retry delays."""
        cache_path = os.path.join(WEBAPP, "cache.py")
        with open(cache_path, "r", encoding="utf-8") as f:
            content = f.read()
        assert "sleep" in content, "cache.py does not contain sleep calls for retry logic"


class TestPythonEnvironment:
    """Test that required Python packages are installed."""

    def test_python3_available(self):
        """Python 3 should be available."""
        result = subprocess.run(
            ["python3", "--version"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "Python 3 is not available"
        assert "3." in result.stdout or "3." in result.stderr, "Python 3 version not detected"

    def test_flask_installed(self):
        """Flask should be installed."""
        result = subprocess.run(
            ["python3", "-c", "import flask; print(flask.__version__)"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, f"Flask is not installed: {result.stderr}"

    def test_flask_babel_installed(self):
        """Flask-Babel should be installed."""
        result = subprocess.run(
            ["python3", "-c", "import flask_babel; print('ok')"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, f"Flask-Babel is not installed: {result.stderr}"


class TestWebappWritable:
    """Test that the webapp directory is writable."""

    def test_webapp_is_writable(self):
        """Webapp directory should be writable."""
        assert os.access(WEBAPP, os.W_OK), f"Webapp directory {WEBAPP} is not writable"

    def test_app_py_is_writable(self):
        """app.py should be writable (needed to fix the bug)."""
        app_path = os.path.join(WEBAPP, "app.py")
        assert os.access(app_path, os.W_OK), f"app.py at {app_path} is not writable"


class TestWorkingLocales:
    """Test that German and French locale files are properly set up."""

    @pytest.mark.parametrize("locale", ["de", "fr"])
    def test_locale_mo_is_valid_gnu_mo(self, locale):
        """German and French MO files should be valid GNU message catalogs."""
        mo_file = os.path.join(TRANSLATIONS, locale, "LC_MESSAGES", "messages.mo")
        result = subprocess.run(
            ["file", mo_file],
            capture_output=True,
            text=True
        )
        assert "GNU message catalog" in result.stdout, \
            f"{locale} MO file is not a valid GNU message catalog: {result.stdout}"


class TestNoHardcodedJapanese:
    """Test that Japanese strings are not hardcoded in source files."""

    def test_no_hardcoded_japanese_in_app_py(self):
        """app.py should not contain hardcoded Japanese welcome message."""
        app_path = os.path.join(WEBAPP, "app.py")
        with open(app_path, "r", encoding="utf-8") as f:
            content = f.read()
        assert "ようこそ" not in content, \
            "app.py contains hardcoded Japanese text - translations should come from .mo files"

    def test_no_hardcoded_japanese_in_cache_py(self):
        """cache.py should not contain hardcoded Japanese welcome message."""
        cache_path = os.path.join(WEBAPP, "cache.py")
        with open(cache_path, "r", encoding="utf-8") as f:
            content = f.read()
        assert "ようこそ" not in content, \
            "cache.py contains hardcoded Japanese text - translations should come from .mo files"
