I've got a directory of server logs at /home/user/logs/archive that I'm trying to patch with some anomaly annotations our detection system spits out. The patches are in /home/user/logs/patches — one .patch file per log file, standard unified diff format. But when I run my apply script (/home/user/logs/apply_all.sh) it fails on about half of them with "patch: **** malformed patch" or just silently produces garbage output.

Thing is, the patches look fine to me when I eyeball them? Same filenames, context lines seem to match. I diff'd a couple of the original logs against what the detection system saw and they're identical, so it's not a source mismatch.

Need the script to actually apply all the patches cleanly. The annotated logs should end up in /home/user/logs/annotated/ with the same filenames as the originals.
