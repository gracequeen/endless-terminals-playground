# test_final_state.py
"""
Tests to validate the final state of the filesystem after the student
has fixed the patch files and the apply script can run successfully.
"""

import os
import subprocess
import re
import pytest


HOME = "/home/user"
LOGS_DIR = os.path.join(HOME, "logs")
ARCHIVE_DIR = os.path.join(LOGS_DIR, "archive")
PATCHES_DIR = os.path.join(LOGS_DIR, "patches")
ANNOTATED_DIR = os.path.join(LOGS_DIR, "annotated")
APPLY_SCRIPT = os.path.join(LOGS_DIR, "apply_all.sh")

LOG_FILES = [f"access_{i:02d}.log" for i in range(1, 9)]
PATCH_FILES = [f"access_{i:02d}.log.patch" for i in range(1, 9)]


class TestAnnotatedDirectoryExists:
    """Test that the annotated directory exists with all required files."""

    def test_annotated_directory_exists(self):
        assert os.path.isdir(ANNOTATED_DIR), \
            f"Directory {ANNOTATED_DIR} does not exist. The apply script should create it."

    @pytest.mark.parametrize("log_file", LOG_FILES)
    def test_annotated_log_file_exists(self, log_file):
        annotated_path = os.path.join(ANNOTATED_DIR, log_file)
        assert os.path.isfile(annotated_path), \
            f"Annotated log file {annotated_path} does not exist"


class TestPatchFilesAreFixed:
    """Test that all patch files are now well-formed."""

    @pytest.mark.parametrize("patch_file", PATCH_FILES)
    def test_patch_file_no_crlf(self, patch_file):
        """Patch files should not have CRLF line endings."""
        patch_path = os.path.join(PATCHES_DIR, patch_file)
        result = subprocess.run(
            ['file', patch_path],
            capture_output=True,
            text=True
        )
        assert 'CRLF' not in result.stdout, \
            f"Patch file {patch_path} still has CRLF line endings: {result.stdout}"

    @pytest.mark.parametrize("patch_file", PATCH_FILES)
    def test_patch_file_is_ascii_text(self, patch_file):
        """Patch files should be reported as ASCII text."""
        patch_path = os.path.join(PATCHES_DIR, patch_file)
        result = subprocess.run(
            ['file', patch_path],
            capture_output=True,
            text=True
        )
        # Should be some form of text file
        assert 'text' in result.stdout.lower() or 'ASCII' in result.stdout, \
            f"Patch file {patch_path} is not recognized as text: {result.stdout}"

    @pytest.mark.parametrize("idx", range(1, 9))
    def test_patch_applies_cleanly_dry_run(self, idx):
        """Each patch should apply cleanly in dry-run mode."""
        log_file = f"access_{idx:02d}.log"
        patch_file = f"access_{idx:02d}.log.patch"
        log_path = os.path.join(ARCHIVE_DIR, log_file)
        patch_path = os.path.join(PATCHES_DIR, patch_file)

        result = subprocess.run(
            ['patch', '--dry-run', '-o', '/dev/null', log_path, patch_path],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            f"Patch {patch_file} does not apply cleanly: {result.stderr}"


class TestHunkLineCounts:
    """Test that hunk line counts in patches are correct."""

    @pytest.mark.parametrize("patch_file", PATCH_FILES)
    def test_hunk_line_counts_are_valid(self, patch_file):
        """Hunk headers should have correct line counts matching actual content."""
        patch_path = os.path.join(PATCHES_DIR, patch_file)

        with open(patch_path, 'r') as f:
            lines = f.readlines()

        # Parse hunks and validate
        i = 0
        while i < len(lines):
            line = lines[i]
            # Look for hunk header
            match = re.match(r'^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@', line)
            if match:
                old_count = int(match.group(2)) if match.group(2) else 1
                new_count = int(match.group(4)) if match.group(4) else 1

                # Count actual lines in hunk
                actual_old = 0
                actual_new = 0
                j = i + 1
                while j < len(lines):
                    hunk_line = lines[j]
                    if hunk_line.startswith('@@') or hunk_line.startswith('---') or hunk_line.startswith('+++'):
                        break
                    if hunk_line.startswith('-'):
                        actual_old += 1
                    elif hunk_line.startswith('+'):
                        actual_new += 1
                    elif hunk_line.startswith(' ') or hunk_line == '\n':
                        # Context line or empty context
                        actual_old += 1
                        actual_new += 1
                    elif hunk_line.startswith('\\'):
                        # "\ No newline at end of file" - doesn't count
                        pass
                    else:
                        # Treat as context line
                        actual_old += 1
                        actual_new += 1
                    j += 1

                assert actual_old == old_count, \
                    f"In {patch_file}, hunk at line {i+1} claims {old_count} old lines but has {actual_old}"
                assert actual_new == new_count, \
                    f"In {patch_file}, hunk at line {i+1} claims {new_count} new lines but has {actual_new}"
            i += 1


class TestApplyScriptSucceeds:
    """Test that the apply script runs successfully."""

    def test_apply_script_exits_zero(self):
        """Running apply_all.sh should exit with code 0."""
        # Clean up annotated directory first
        if os.path.exists(ANNOTATED_DIR):
            import shutil
            shutil.rmtree(ANNOTATED_DIR)

        result = subprocess.run(
            [APPLY_SCRIPT],
            capture_output=True,
            text=True,
            cwd=LOGS_DIR
        )

        assert result.returncode == 0, \
            f"apply_all.sh failed with exit code {result.returncode}. stderr: {result.stderr}"

    def test_apply_script_no_error_output(self):
        """Running apply_all.sh should not produce error messages."""
        # Clean up annotated directory first
        if os.path.exists(ANNOTATED_DIR):
            import shutil
            shutil.rmtree(ANNOTATED_DIR)

        result = subprocess.run(
            [APPLY_SCRIPT],
            capture_output=True,
            text=True,
            cwd=LOGS_DIR
        )

        # Check for common error patterns
        error_patterns = ['malformed', 'failed', 'error', 'FAILED', 'reject']
        stderr_lower = result.stderr.lower()
        stdout_lower = result.stdout.lower()

        for pattern in error_patterns:
            assert pattern not in stderr_lower, \
                f"apply_all.sh produced error containing '{pattern}': {result.stderr}"
            # Also check stdout as patch sometimes outputs there
            if pattern in stdout_lower and 'hunk' in stdout_lower:
                pytest.fail(f"apply_all.sh produced error containing '{pattern}': {result.stdout}")


class TestAnnotationsPresent:
    """Test that annotations are present in the annotated files."""

    @pytest.mark.parametrize("log_file", LOG_FILES)
    def test_annotated_file_contains_anomaly_comments(self, log_file):
        """Each annotated file should contain ANOMALY comments."""
        annotated_path = os.path.join(ANNOTATED_DIR, log_file)
        if not os.path.exists(annotated_path):
            pytest.skip(f"Annotated file {annotated_path} does not exist")

        with open(annotated_path, 'r') as f:
            content = f.read()

        # At least some files should have annotations
        # We'll check total count separately
        pass  # Individual file check is optional

    def test_total_annotation_count(self):
        """Total ANOMALY annotations across all files should be 15."""
        result = subprocess.run(
            ['grep', '-c', '# ANOMALY:', *[os.path.join(ANNOTATED_DIR, f) for f in LOG_FILES]],
            capture_output=True,
            text=True
        )

        # Parse the output - format is "filename:count" per line
        total = 0
        for line in result.stdout.strip().split('\n'):
            if ':' in line:
                parts = line.rsplit(':', 1)
                if len(parts) == 2:
                    try:
                        total += int(parts[1])
                    except ValueError:
                        pass

        assert total == 15, \
            f"Expected 15 total ANOMALY annotations, found {total}"


class TestOriginalLogsUnchanged:
    """Test that original log files in archive are unchanged."""

    @pytest.mark.parametrize("log_file", LOG_FILES)
    def test_archive_log_has_no_anomaly_comments(self, log_file):
        """Original archive logs should not contain ANOMALY comments."""
        log_path = os.path.join(ARCHIVE_DIR, log_file)
        with open(log_path, 'r') as f:
            content = f.read()

        assert '# ANOMALY:' not in content, \
            f"Original log {log_path} was modified - contains ANOMALY comments"

    @pytest.mark.parametrize("log_file", LOG_FILES)
    def test_archive_log_still_uses_lf(self, log_file):
        """Original archive logs should still use LF line endings."""
        log_path = os.path.join(ARCHIVE_DIR, log_file)
        with open(log_path, 'rb') as f:
            content = f.read()

        assert b'\r\n' not in content, \
            f"Original log {log_path} was modified - now has CRLF line endings"


class TestAnnotatedFilesHaveOriginalContent:
    """Test that annotated files contain all original log content plus annotations."""

    @pytest.mark.parametrize("log_file", LOG_FILES)
    def test_annotated_file_is_larger_than_original(self, log_file):
        """Annotated files should be larger than originals (due to added annotations)."""
        original_path = os.path.join(ARCHIVE_DIR, log_file)
        annotated_path = os.path.join(ANNOTATED_DIR, log_file)

        if not os.path.exists(annotated_path):
            pytest.skip(f"Annotated file {annotated_path} does not exist")

        original_size = os.path.getsize(original_path)
        annotated_size = os.path.getsize(annotated_path)

        # Annotated should be at least as large (could be equal if no annotations for that file,
        # but based on task description each patch adds 1-3 annotations)
        assert annotated_size >= original_size, \
            f"Annotated file {annotated_path} ({annotated_size} bytes) is smaller than " \
            f"original ({original_size} bytes)"


class TestNoMalformedMarkers:
    """Test that malformed markers have been fixed."""

    def test_patch_06_no_malformed_newline_marker(self):
        """access_06.log.patch should not have the malformed newline marker."""
        patch_path = os.path.join(PATCHES_DIR, 'access_06.log.patch')
        with open(patch_path, 'r') as f:
            content = f.read()

        # The malformed marker was "\ No newline at end of the file" (extra "the")
        assert 'No newline at end of the file' not in content, \
            f"Patch {patch_path} still has malformed newline marker"

        # If there's a newline marker, it should be correct
        if 'No newline at end of' in content:
            assert 'No newline at end of file' in content, \
                f"Patch {patch_path} has incorrect newline marker format"


class TestPatchSemanticPreservation:
    """Test that the semantic content of patches is preserved."""

    @pytest.mark.parametrize("patch_file", PATCH_FILES)
    def test_patch_still_contains_anomaly_additions(self, patch_file):
        """Each patch should still contain ANOMALY lines to add."""
        patch_path = os.path.join(PATCHES_DIR, patch_file)
        with open(patch_path, 'r') as f:
            content = f.read()

        # Patches should contain lines starting with + that add ANOMALY comments
        assert '+# ANOMALY:' in content or '+ # ANOMALY:' in content or '+#ANOMALY:' in content, \
            f"Patch {patch_path} does not contain ANOMALY additions - semantic content may have been lost"
