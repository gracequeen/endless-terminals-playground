# test_initial_state.py
"""
Tests to validate the initial state of the filesystem before the student
performs the patch-fixing task.
"""

import os
import subprocess
import pytest


HOME = "/home/user"
LOGS_DIR = os.path.join(HOME, "logs")
ARCHIVE_DIR = os.path.join(LOGS_DIR, "archive")
PATCHES_DIR = os.path.join(LOGS_DIR, "patches")
ANNOTATED_DIR = os.path.join(LOGS_DIR, "annotated")
APPLY_SCRIPT = os.path.join(LOGS_DIR, "apply_all.sh")

LOG_FILES = [f"access_{i:02d}.log" for i in range(1, 9)]
PATCH_FILES = [f"access_{i:02d}.log.patch" for i in range(1, 9)]


class TestDirectoryStructure:
    """Test that required directories exist."""

    def test_logs_directory_exists(self):
        assert os.path.isdir(LOGS_DIR), f"Directory {LOGS_DIR} does not exist"

    def test_archive_directory_exists(self):
        assert os.path.isdir(ARCHIVE_DIR), f"Directory {ARCHIVE_DIR} does not exist"

    def test_patches_directory_exists(self):
        assert os.path.isdir(PATCHES_DIR), f"Directory {PATCHES_DIR} does not exist"

    def test_annotated_directory_does_not_exist(self):
        """The annotated directory should NOT exist initially."""
        assert not os.path.exists(ANNOTATED_DIR), \
            f"Directory {ANNOTATED_DIR} should not exist initially"


class TestLogFiles:
    """Test that all log files exist in the archive directory."""

    @pytest.mark.parametrize("log_file", LOG_FILES)
    def test_log_file_exists(self, log_file):
        log_path = os.path.join(ARCHIVE_DIR, log_file)
        assert os.path.isfile(log_path), f"Log file {log_path} does not exist"

    @pytest.mark.parametrize("log_file", LOG_FILES)
    def test_log_file_is_readable(self, log_file):
        log_path = os.path.join(ARCHIVE_DIR, log_file)
        assert os.access(log_path, os.R_OK), f"Log file {log_path} is not readable"

    @pytest.mark.parametrize("log_file", LOG_FILES)
    def test_log_file_has_content(self, log_file):
        log_path = os.path.join(ARCHIVE_DIR, log_file)
        size = os.path.getsize(log_path)
        assert size > 0, f"Log file {log_path} is empty"

    @pytest.mark.parametrize("log_file", LOG_FILES)
    def test_log_file_uses_lf_line_endings(self, log_file):
        """Log files should use LF line endings (not CRLF)."""
        log_path = os.path.join(ARCHIVE_DIR, log_file)
        with open(log_path, 'rb') as f:
            content = f.read()
        # Check for CRLF
        assert b'\r\n' not in content, \
            f"Log file {log_path} contains CRLF line endings, expected LF only"

    @pytest.mark.parametrize("log_file", LOG_FILES)
    def test_log_file_has_reasonable_line_count(self, log_file):
        """Log files should have 50-200 lines."""
        log_path = os.path.join(ARCHIVE_DIR, log_file)
        with open(log_path, 'r') as f:
            line_count = sum(1 for _ in f)
        assert 50 <= line_count <= 200, \
            f"Log file {log_path} has {line_count} lines, expected 50-200"


class TestPatchFiles:
    """Test that all patch files exist in the patches directory."""

    @pytest.mark.parametrize("patch_file", PATCH_FILES)
    def test_patch_file_exists(self, patch_file):
        patch_path = os.path.join(PATCHES_DIR, patch_file)
        assert os.path.isfile(patch_path), f"Patch file {patch_path} does not exist"

    @pytest.mark.parametrize("patch_file", PATCH_FILES)
    def test_patch_file_is_readable(self, patch_file):
        patch_path = os.path.join(PATCHES_DIR, patch_file)
        assert os.access(patch_path, os.R_OK), f"Patch file {patch_path} is not readable"

    @pytest.mark.parametrize("patch_file", PATCH_FILES)
    def test_patch_file_has_content(self, patch_file):
        patch_path = os.path.join(PATCHES_DIR, patch_file)
        size = os.path.getsize(patch_path)
        assert size > 0, f"Patch file {patch_path} is empty"

    @pytest.mark.parametrize("patch_file", PATCH_FILES)
    def test_patch_file_contains_unified_diff_markers(self, patch_file):
        """Patch files should contain unified diff format markers."""
        patch_path = os.path.join(PATCHES_DIR, patch_file)
        with open(patch_path, 'rb') as f:
            content = f.read()
        # Check for @@ markers (hunk headers) - allowing for CRLF
        assert b'@@' in content, \
            f"Patch file {patch_path} does not contain unified diff hunk markers (@@)"


class TestApplyScript:
    """Test that the apply script exists and has correct content."""

    def test_apply_script_exists(self):
        assert os.path.isfile(APPLY_SCRIPT), f"Apply script {APPLY_SCRIPT} does not exist"

    def test_apply_script_is_executable(self):
        assert os.access(APPLY_SCRIPT, os.X_OK), \
            f"Apply script {APPLY_SCRIPT} is not executable"

    def test_apply_script_is_bash_script(self):
        with open(APPLY_SCRIPT, 'r') as f:
            first_line = f.readline()
        assert first_line.strip().startswith('#!/bin/bash'), \
            f"Apply script {APPLY_SCRIPT} does not start with bash shebang"

    def test_apply_script_creates_annotated_dir(self):
        """Script should contain mkdir for annotated directory."""
        with open(APPLY_SCRIPT, 'r') as f:
            content = f.read()
        assert 'mkdir' in content and 'annotated' in content, \
            f"Apply script {APPLY_SCRIPT} does not create annotated directory"

    def test_apply_script_uses_patch_command(self):
        """Script should use the patch command."""
        with open(APPLY_SCRIPT, 'r') as f:
            content = f.read()
        assert 'patch' in content, \
            f"Apply script {APPLY_SCRIPT} does not use patch command"


class TestPatchCorruption:
    """Test that patches have the expected corruption patterns."""

    def test_some_patches_have_crlf(self):
        """Some patches should have CRLF line endings (the corruption)."""
        crlf_patches = ['access_01.log.patch', 'access_03.log.patch', 
                        'access_05.log.patch', 'access_07.log.patch']
        crlf_count = 0
        for patch_file in crlf_patches:
            patch_path = os.path.join(PATCHES_DIR, patch_file)
            with open(patch_path, 'rb') as f:
                content = f.read()
            if b'\r\n' in content:
                crlf_count += 1
        assert crlf_count > 0, \
            "Expected some patches to have CRLF line endings as corruption"

    def test_patch_08_is_correct(self):
        """access_08.log.patch should be the correct one that applies cleanly."""
        patch_path = os.path.join(PATCHES_DIR, 'access_08.log.patch')
        log_path = os.path.join(ARCHIVE_DIR, 'access_08.log')

        # Try a dry-run of the patch
        result = subprocess.run(
            ['patch', '--dry-run', '-o', '/dev/null', log_path, patch_path],
            capture_output=True,
            text=True
        )
        # This one should succeed
        assert result.returncode == 0, \
            f"access_08.log.patch should apply cleanly but failed: {result.stderr}"


class TestRequiredTools:
    """Test that required tools are available."""

    @pytest.mark.parametrize("tool", [
        'patch', 'diff', 'dos2unix', 'sed', 'awk', 'grep', 
        'file', 'xxd', 'cat', 'head', 'tail', 'wc'
    ])
    def test_tool_available(self, tool):
        result = subprocess.run(['which', tool], capture_output=True)
        assert result.returncode == 0, f"Required tool '{tool}' is not available"

    def test_python3_available(self):
        result = subprocess.run(['which', 'python3'], capture_output=True)
        assert result.returncode == 0, "Python3 is not available"


class TestWritePermissions:
    """Test that required paths are writable."""

    def test_logs_dir_is_writable(self):
        assert os.access(LOGS_DIR, os.W_OK), f"{LOGS_DIR} is not writable"

    def test_patches_dir_is_writable(self):
        assert os.access(PATCHES_DIR, os.W_OK), f"{PATCHES_DIR} is not writable"

    def test_archive_dir_is_writable(self):
        assert os.access(ARCHIVE_DIR, os.W_OK), f"{ARCHIVE_DIR} is not writable"


class TestApplyScriptFails:
    """Verify that the apply script currently fails (patches are corrupted)."""

    def test_apply_script_produces_errors(self):
        """Running the apply script should produce errors due to corrupted patches."""
        # First clean up any existing annotated directory
        if os.path.exists(ANNOTATED_DIR):
            import shutil
            shutil.rmtree(ANNOTATED_DIR)

        result = subprocess.run(
            [APPLY_SCRIPT],
            capture_output=True,
            text=True,
            cwd=LOGS_DIR
        )

        # The script should either return non-zero or have error messages
        has_errors = (
            result.returncode != 0 or
            'malformed' in result.stderr.lower() or
            'malformed' in result.stdout.lower() or
            'hunk' in result.stderr.lower() or
            'failed' in result.stderr.lower()
        )

        # Clean up
        if os.path.exists(ANNOTATED_DIR):
            import shutil
            shutil.rmtree(ANNOTATED_DIR)

        assert has_errors, \
            "Apply script should fail or produce errors due to corrupted patches"
