# test_initial_state.py
"""
Tests to validate the initial state of the system before the student performs the task.
This verifies the log aggregator setup with the buggy max_records configuration.
"""

import os
import subprocess
import sqlite3
import configparser
import glob
import pytest


class TestLogpipeDirectoryStructure:
    """Test that the logpipe directory and files exist."""

    def test_logpipe_directory_exists(self):
        """Verify /home/user/logpipe directory exists."""
        assert os.path.isdir("/home/user/logpipe"), \
            "Directory /home/user/logpipe does not exist"

    def test_ingest_script_exists(self):
        """Verify ingest.py script exists."""
        assert os.path.isfile("/home/user/logpipe/ingest.py"), \
            "File /home/user/logpipe/ingest.py does not exist"

    def test_ingest_script_is_readable(self):
        """Verify ingest.py is readable."""
        assert os.access("/home/user/logpipe/ingest.py", os.R_OK), \
            "File /home/user/logpipe/ingest.py is not readable"

    def test_config_ini_exists(self):
        """Verify config.ini exists."""
        assert os.path.isfile("/home/user/logpipe/config.ini"), \
            "File /home/user/logpipe/config.ini does not exist"

    def test_events_db_exists(self):
        """Verify events.db exists."""
        assert os.path.isfile("/home/user/logpipe/events.db"), \
            "File /home/user/logpipe/events.db does not exist"

    def test_logpipe_directory_is_writable(self):
        """Verify /home/user/logpipe is writable."""
        assert os.access("/home/user/logpipe", os.W_OK), \
            "Directory /home/user/logpipe is not writable"


class TestLogFilesExist:
    """Test that the log files in /var/log/app/ exist and are readable."""

    def test_var_log_app_directory_exists(self):
        """Verify /var/log/app directory exists."""
        assert os.path.isdir("/var/log/app"), \
            "Directory /var/log/app does not exist"

    def test_var_log_app_is_readable(self):
        """Verify /var/log/app is readable."""
        assert os.access("/var/log/app", os.R_OK), \
            "Directory /var/log/app is not readable"

    def test_access_log_exists(self):
        """Verify access.log exists."""
        assert os.path.isfile("/var/log/app/access.log"), \
            "File /var/log/app/access.log does not exist"

    def test_error_log_exists(self):
        """Verify error.log exists."""
        assert os.path.isfile("/var/log/app/error.log"), \
            "File /var/log/app/error.log does not exist"

    def test_debug_log_exists(self):
        """Verify debug.log exists."""
        assert os.path.isfile("/var/log/app/debug.log"), \
            "File /var/log/app/debug.log does not exist"

    def test_log_files_are_readable(self):
        """Verify all log files are readable."""
        for logfile in ["/var/log/app/access.log", "/var/log/app/error.log", "/var/log/app/debug.log"]:
            assert os.access(logfile, os.R_OK), \
                f"File {logfile} is not readable"

    def test_access_log_has_content(self):
        """Verify access.log has approximately 800 lines."""
        with open("/var/log/app/access.log", "r") as f:
            line_count = sum(1 for _ in f)
        assert line_count >= 700, \
            f"access.log has only {line_count} lines, expected ~800"

    def test_error_log_has_content(self):
        """Verify error.log has approximately 400 lines."""
        with open("/var/log/app/error.log", "r") as f:
            line_count = sum(1 for _ in f)
        assert line_count >= 300, \
            f"error.log has only {line_count} lines, expected ~400"

    def test_debug_log_has_content(self):
        """Verify debug.log has approximately 1500 lines."""
        with open("/var/log/app/debug.log", "r") as f:
            line_count = sum(1 for _ in f)
        assert line_count >= 1400, \
            f"debug.log has only {line_count} lines, expected ~1500"


class TestConfigFile:
    """Test the configuration file has the buggy max_records setting."""

    def test_config_ini_is_valid(self):
        """Verify config.ini is a valid INI file."""
        config = configparser.ConfigParser()
        try:
            config.read("/home/user/logpipe/config.ini")
        except Exception as e:
            pytest.fail(f"config.ini is not a valid INI file: {e}")

    def test_config_has_ingest_section(self):
        """Verify config.ini has [ingest] section."""
        config = configparser.ConfigParser()
        config.read("/home/user/logpipe/config.ini")
        assert "ingest" in config.sections(), \
            "config.ini does not have [ingest] section"

    def test_config_has_log_pattern(self):
        """Verify config.ini has log_pattern setting."""
        config = configparser.ConfigParser()
        config.read("/home/user/logpipe/config.ini")
        assert config.has_option("ingest", "log_pattern"), \
            "config.ini [ingest] section does not have log_pattern"

    def test_config_has_batch_size(self):
        """Verify config.ini has batch_size setting."""
        config = configparser.ConfigParser()
        config.read("/home/user/logpipe/config.ini")
        assert config.has_option("ingest", "batch_size"), \
            "config.ini [ingest] section does not have batch_size"

    def test_config_has_max_records_bug(self):
        """Verify config.ini has the buggy max_records = 5 setting."""
        config = configparser.ConfigParser()
        config.read("/home/user/logpipe/config.ini")
        assert config.has_option("ingest", "max_records"), \
            "config.ini [ingest] section does not have max_records (the bug)"
        max_records = config.getint("ingest", "max_records")
        assert max_records == 5, \
            f"max_records is {max_records}, expected 5 (the buggy debug value)"


class TestDatabase:
    """Test the database structure and initial state."""

    def test_events_db_is_valid_sqlite(self):
        """Verify events.db is a valid SQLite database."""
        try:
            conn = sqlite3.connect("/home/user/logpipe/events.db")
            cursor = conn.cursor()
            cursor.execute("SELECT sqlite_version();")
            conn.close()
        except sqlite3.Error as e:
            pytest.fail(f"events.db is not a valid SQLite database: {e}")

    def test_events_table_exists(self):
        """Verify events table exists in the database."""
        conn = sqlite3.connect("/home/user/logpipe/events.db")
        cursor = conn.cursor()
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='events';")
        result = cursor.fetchone()
        conn.close()
        assert result is not None, \
            "Table 'events' does not exist in events.db"

    def test_events_table_has_correct_schema(self):
        """Verify events table has the expected columns."""
        conn = sqlite3.connect("/home/user/logpipe/events.db")
        cursor = conn.cursor()
        cursor.execute("PRAGMA table_info(events);")
        columns = {row[1] for row in cursor.fetchall()}
        conn.close()
        expected_columns = {"id", "timestamp", "level", "service", "message"}
        assert expected_columns.issubset(columns), \
            f"events table is missing columns. Found: {columns}, Expected: {expected_columns}"

    def test_events_table_has_limited_rows(self):
        """Verify events table has very few rows (due to max_records bug)."""
        conn = sqlite3.connect("/home/user/logpipe/events.db")
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM events;")
        count = cursor.fetchone()[0]
        conn.close()
        # Should have around 5 rows due to the max_records = 5 bug
        assert count <= 10, \
            f"events table has {count} rows, expected <= 10 (due to max_records bug)"
        assert count >= 1, \
            f"events table has {count} rows, expected at least 1 row from previous run"


class TestPythonEnvironment:
    """Test that Python 3 and sqlite3 CLI are available."""

    def test_python3_available(self):
        """Verify Python 3 is available."""
        result = subprocess.run(
            ["python3", "--version"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            "Python 3 is not available"
        assert "Python 3" in result.stdout, \
            f"Unexpected Python version: {result.stdout}"

    def test_sqlite3_cli_available(self):
        """Verify sqlite3 CLI tool is available."""
        result = subprocess.run(
            ["sqlite3", "--version"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            "sqlite3 CLI tool is not available"


class TestIngestScriptStructure:
    """Test that the ingest.py script has expected characteristics."""

    def test_ingest_script_is_python(self):
        """Verify ingest.py appears to be a Python script."""
        with open("/home/user/logpipe/ingest.py", "r") as f:
            content = f.read()
        # Check for common Python patterns
        assert "import" in content or "def " in content or "class " in content, \
            "ingest.py does not appear to be a Python script"

    def test_ingest_script_reasonable_size(self):
        """Verify ingest.py is approximately 80 lines."""
        with open("/home/user/logpipe/ingest.py", "r") as f:
            line_count = sum(1 for _ in f)
        assert 50 <= line_count <= 150, \
            f"ingest.py has {line_count} lines, expected ~80 lines"

    def test_ingest_script_uses_config(self):
        """Verify ingest.py references config.ini."""
        with open("/home/user/logpipe/ingest.py", "r") as f:
            content = f.read()
        assert "config" in content.lower(), \
            "ingest.py does not appear to reference configuration"

    def test_ingest_script_uses_sqlite(self):
        """Verify ingest.py uses sqlite3."""
        with open("/home/user/logpipe/ingest.py", "r") as f:
            content = f.read()
        assert "sqlite" in content.lower(), \
            "ingest.py does not appear to use sqlite"
