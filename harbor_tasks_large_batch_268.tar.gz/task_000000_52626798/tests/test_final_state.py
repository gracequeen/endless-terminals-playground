# test_final_state.py
"""
Tests to validate the final state of the system after the student has fixed the log aggregator.
The fix should be in config.ini: max_records removed or set to a value >= 3000.
"""

import os
import subprocess
import sqlite3
import configparser
import re
import pytest


class TestLogpipeDirectoryStructure:
    """Test that the logpipe directory and files still exist."""

    def test_logpipe_directory_exists(self):
        """Verify /home/user/logpipe directory exists."""
        assert os.path.isdir("/home/user/logpipe"), \
            "Directory /home/user/logpipe does not exist"

    def test_ingest_script_exists(self):
        """Verify ingest.py script exists."""
        assert os.path.isfile("/home/user/logpipe/ingest.py"), \
            "File /home/user/logpipe/ingest.py does not exist"

    def test_config_ini_exists(self):
        """Verify config.ini exists (required by the script)."""
        assert os.path.isfile("/home/user/logpipe/config.ini"), \
            "File /home/user/logpipe/config.ini does not exist - the script requires it"

    def test_events_db_exists(self):
        """Verify events.db exists."""
        assert os.path.isfile("/home/user/logpipe/events.db"), \
            "File /home/user/logpipe/events.db does not exist"


class TestLogFilesUnchanged:
    """Test that the log files in /var/log/app/ are unchanged."""

    def test_access_log_exists(self):
        """Verify access.log still exists."""
        assert os.path.isfile("/var/log/app/access.log"), \
            "File /var/log/app/access.log does not exist"

    def test_error_log_exists(self):
        """Verify error.log still exists."""
        assert os.path.isfile("/var/log/app/error.log"), \
            "File /var/log/app/error.log does not exist"

    def test_debug_log_exists(self):
        """Verify debug.log still exists."""
        assert os.path.isfile("/var/log/app/debug.log"), \
            "File /var/log/app/debug.log does not exist"

    def test_access_log_has_content(self):
        """Verify access.log still has approximately 800 lines."""
        with open("/var/log/app/access.log", "r") as f:
            line_count = sum(1 for _ in f)
        assert line_count >= 700, \
            f"access.log has only {line_count} lines, expected ~800 - log files should not be modified"

    def test_error_log_has_content(self):
        """Verify error.log still has approximately 400 lines."""
        with open("/var/log/app/error.log", "r") as f:
            line_count = sum(1 for _ in f)
        assert line_count >= 300, \
            f"error.log has only {line_count} lines, expected ~400 - log files should not be modified"

    def test_debug_log_has_content(self):
        """Verify debug.log still has approximately 1500 lines."""
        with open("/var/log/app/debug.log", "r") as f:
            line_count = sum(1 for _ in f)
        assert line_count >= 1400, \
            f"debug.log has only {line_count} lines, expected ~1500 - log files should not be modified"


class TestConfigFileFix:
    """Test that the configuration file has been fixed."""

    def test_config_ini_is_valid(self):
        """Verify config.ini is still a valid INI file."""
        config = configparser.ConfigParser()
        try:
            config.read("/home/user/logpipe/config.ini")
        except Exception as e:
            pytest.fail(f"config.ini is not a valid INI file: {e}")

    def test_config_has_ingest_section(self):
        """Verify config.ini still has [ingest] section."""
        config = configparser.ConfigParser()
        config.read("/home/user/logpipe/config.ini")
        assert "ingest" in config.sections(), \
            "config.ini does not have [ingest] section"

    def test_config_has_log_pattern(self):
        """Verify config.ini still has log_pattern setting."""
        config = configparser.ConfigParser()
        config.read("/home/user/logpipe/config.ini")
        assert config.has_option("ingest", "log_pattern"), \
            "config.ini [ingest] section does not have log_pattern"

    def test_max_records_not_low(self):
        """Verify max_records is either removed or set to a high/unlimited value."""
        # Check using grep that the buggy low value is gone
        result = subprocess.run(
            ["grep", "-E", r"max_records\s*=\s*[0-5]$", "/home/user/logpipe/config.ini"],
            capture_output=True,
            text=True
        )
        assert result.returncode != 0, \
            f"config.ini still has a low max_records value (0-5): {result.stdout.strip()}"

    def test_max_records_value_if_present(self):
        """If max_records is present, verify it's set high enough or indicates unlimited."""
        config = configparser.ConfigParser()
        config.read("/home/user/logpipe/config.ini")

        if config.has_option("ingest", "max_records"):
            max_records = config.getint("ingest", "max_records")
            # Allow high values (>= 3000) or special "unlimited" values (0, -1)
            is_unlimited = max_records <= 0
            is_high_enough = max_records >= 3000
            assert is_unlimited or is_high_enough, \
                f"max_records is {max_records}, expected >= 3000 or 0/-1 for unlimited"


class TestDatabaseSchema:
    """Test that the database schema is unchanged."""

    def test_events_db_is_valid_sqlite(self):
        """Verify events.db is still a valid SQLite database."""
        try:
            conn = sqlite3.connect("/home/user/logpipe/events.db")
            cursor = conn.cursor()
            cursor.execute("SELECT sqlite_version();")
            conn.close()
        except sqlite3.Error as e:
            pytest.fail(f"events.db is not a valid SQLite database: {e}")

    def test_events_table_exists(self):
        """Verify events table still exists in the database."""
        conn = sqlite3.connect("/home/user/logpipe/events.db")
        cursor = conn.cursor()
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='events';")
        result = cursor.fetchone()
        conn.close()
        assert result is not None, \
            "Table 'events' does not exist in events.db"

    def test_events_table_has_correct_schema(self):
        """Verify events table still has the expected columns."""
        conn = sqlite3.connect("/home/user/logpipe/events.db")
        cursor = conn.cursor()
        cursor.execute("PRAGMA table_info(events);")
        columns = {row[1] for row in cursor.fetchall()}
        conn.close()
        expected_columns = {"id", "timestamp", "level", "service", "message"}
        assert expected_columns.issubset(columns), \
            f"events table schema changed. Found: {columns}, Expected: {expected_columns}"


class TestIngestScriptRuns:
    """Test that the ingest script runs successfully and ingests all records."""

    def test_ingest_script_exits_zero(self):
        """Verify ingest.py runs to completion with exit code 0."""
        result = subprocess.run(
            ["python3", "/home/user/logpipe/ingest.py"],
            capture_output=True,
            text=True,
            timeout=60
        )
        assert result.returncode == 0, \
            f"ingest.py exited with code {result.returncode}. Stderr: {result.stderr}"

    def test_events_table_has_sufficient_rows(self):
        """Verify events table has at least 2500 rows after ingestion."""
        # First run the ingest script to ensure data is loaded
        subprocess.run(
            ["python3", "/home/user/logpipe/ingest.py"],
            capture_output=True,
            text=True,
            timeout=60
        )

        # Now check the count
        conn = sqlite3.connect("/home/user/logpipe/events.db")
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM events;")
        count = cursor.fetchone()[0]
        conn.close()

        assert count >= 2500, \
            f"events table has only {count} rows, expected at least 2500. " \
            f"The max_records limit may still be too low or the script is not ingesting properly."

    def test_events_table_count_via_sqlite3_cli(self):
        """Verify row count using sqlite3 CLI as specified in requirements."""
        result = subprocess.run(
            ["sqlite3", "/home/user/logpipe/events.db", "SELECT COUNT(*) FROM events;"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            f"sqlite3 command failed: {result.stderr}"

        count = int(result.stdout.strip())
        assert count >= 2500, \
            f"sqlite3 reports events table has only {count} rows, expected at least 2500"


class TestDataIntegrity:
    """Test that the ingested data has proper structure."""

    def test_events_have_timestamps(self):
        """Verify ingested events have non-null timestamps."""
        conn = sqlite3.connect("/home/user/logpipe/events.db")
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM events WHERE timestamp IS NULL OR timestamp = '';")
        null_count = cursor.fetchone()[0]
        cursor.execute("SELECT COUNT(*) FROM events;")
        total_count = cursor.fetchone()[0]
        conn.close()

        # Allow some parse failures but most should have timestamps
        assert null_count < total_count * 0.1, \
            f"{null_count} out of {total_count} events have null/empty timestamps"

    def test_events_have_levels(self):
        """Verify ingested events have non-null levels."""
        conn = sqlite3.connect("/home/user/logpipe/events.db")
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM events WHERE level IS NULL OR level = '';")
        null_count = cursor.fetchone()[0]
        cursor.execute("SELECT COUNT(*) FROM events;")
        total_count = cursor.fetchone()[0]
        conn.close()

        assert null_count < total_count * 0.1, \
            f"{null_count} out of {total_count} events have null/empty levels"

    def test_events_have_services(self):
        """Verify ingested events have non-null services."""
        conn = sqlite3.connect("/home/user/logpipe/events.db")
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM events WHERE service IS NULL OR service = '';")
        null_count = cursor.fetchone()[0]
        cursor.execute("SELECT COUNT(*) FROM events;")
        total_count = cursor.fetchone()[0]
        conn.close()

        assert null_count < total_count * 0.1, \
            f"{null_count} out of {total_count} events have null/empty services"


class TestAntiShortcuts:
    """Test that shortcuts were not used to fake the solution."""

    def test_config_file_not_deleted(self):
        """Verify config.ini was not deleted (script requires it)."""
        assert os.path.isfile("/home/user/logpipe/config.ini"), \
            "config.ini was deleted - this is not a valid fix as the script requires it"

    def test_script_actually_works(self):
        """Verify the script can run fresh and ingest data."""
        # Clear the table
        conn = sqlite3.connect("/home/user/logpipe/events.db")
        cursor = conn.cursor()
        cursor.execute("DELETE FROM events;")
        conn.commit()
        conn.close()

        # Run the ingest script
        result = subprocess.run(
            ["python3", "/home/user/logpipe/ingest.py"],
            capture_output=True,
            text=True,
            timeout=60
        )

        assert result.returncode == 0, \
            f"ingest.py failed after clearing table. Exit code: {result.returncode}, Stderr: {result.stderr}"

        # Check that data was actually ingested
        conn = sqlite3.connect("/home/user/logpipe/events.db")
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM events;")
        count = cursor.fetchone()[0]
        conn.close()

        assert count >= 2500, \
            f"After clearing and re-running, only {count} rows were ingested. " \
            f"Expected at least 2500. The fix must allow the script to ingest all log data."
