# test_initial_state.py
"""
Pre-action validation tests for the database.yml permissions fix task.
Validates that the initial state matches expected conditions before the student performs the action.
"""

import os
import stat
import pwd
import grp
import pytest


TARGET_FILE = "/home/user/webapp/config/database.yml"
TARGET_DIR = "/home/user/webapp/config"


class TestTargetFileExists:
    """Verify the target file exists and is a regular file."""

    def test_file_exists(self):
        """The target file must exist."""
        assert os.path.exists(TARGET_FILE), (
            f"Target file {TARGET_FILE} does not exist. "
            "The file must be present for the permissions fix task."
        )

    def test_is_regular_file(self):
        """The target must be a regular file, not a directory or symlink."""
        assert os.path.isfile(TARGET_FILE), (
            f"{TARGET_FILE} exists but is not a regular file. "
            "It may be a directory or special file."
        )
        assert not os.path.islink(TARGET_FILE), (
            f"{TARGET_FILE} is a symbolic link, expected a regular file."
        )


class TestInitialPermissions:
    """Verify the file has the expected initial permissions (644)."""

    def test_permissions_are_644(self):
        """File should have permissions 644 (rw-r--r--) initially."""
        file_stat = os.stat(TARGET_FILE)
        mode = stat.S_IMODE(file_stat.st_mode)
        expected_mode = 0o644

        assert mode == expected_mode, (
            f"Expected {TARGET_FILE} to have permissions 644 (0o644), "
            f"but found {oct(mode)} ({stat.filemode(file_stat.st_mode)}). "
            "Initial state requires world-readable permissions for the security audit scenario."
        )

    def test_file_is_world_readable(self):
        """File should be world-readable (others have read permission)."""
        file_stat = os.stat(TARGET_FILE)
        mode = stat.S_IMODE(file_stat.st_mode)

        assert mode & stat.S_IROTH, (
            f"{TARGET_FILE} is not world-readable. "
            "The security audit scenario requires the file to be world-readable initially."
        )


class TestFileOwnership:
    """Verify the file is owned by user:user."""

    def test_owner_is_user(self):
        """File should be owned by 'user'."""
        file_stat = os.stat(TARGET_FILE)
        try:
            owner_name = pwd.getpwuid(file_stat.st_uid).pw_name
        except KeyError:
            owner_name = str(file_stat.st_uid)

        assert owner_name == "user", (
            f"Expected {TARGET_FILE} to be owned by 'user', "
            f"but found owner '{owner_name}'."
        )

    def test_group_is_user(self):
        """File should have group 'user'."""
        file_stat = os.stat(TARGET_FILE)
        try:
            group_name = grp.getgrgid(file_stat.st_gid).gr_name
        except KeyError:
            group_name = str(file_stat.st_gid)

        assert group_name == "user", (
            f"Expected {TARGET_FILE} to have group 'user', "
            f"but found group '{group_name}'."
        )


class TestFileContents:
    """Verify the file contains the expected YAML content with plaintext password."""

    def test_file_is_readable(self):
        """File should be readable."""
        assert os.access(TARGET_FILE, os.R_OK), (
            f"Cannot read {TARGET_FILE}. File must be readable to verify contents."
        )

    def test_contains_production_block(self):
        """File should contain a production configuration block."""
        with open(TARGET_FILE, 'r') as f:
            content = f.read()

        assert 'production' in content.lower(), (
            f"{TARGET_FILE} does not contain a 'production' block. "
            "The file should have YAML with a production configuration."
        )

    def test_contains_plaintext_password(self):
        """File should contain the plaintext password in the production block."""
        with open(TARGET_FILE, 'r') as f:
            content = f.read()

        assert 's3cr3t_pr0d_pw!' in content, (
            f"{TARGET_FILE} does not contain the expected plaintext password 's3cr3t_pr0d_pw!'. "
            "The security audit scenario requires the password to be visible in plaintext."
        )

    def test_contains_password_key(self):
        """File should have a password key in the YAML."""
        with open(TARGET_FILE, 'r') as f:
            content = f.read()

        assert 'password:' in content or 'password :' in content, (
            f"{TARGET_FILE} does not contain a 'password:' key. "
            "The file should be valid YAML with a password field."
        )


class TestDirectoryState:
    """Verify the parent directory exists and is writable."""

    def test_config_directory_exists(self):
        """The config directory must exist."""
        assert os.path.exists(TARGET_DIR), (
            f"Config directory {TARGET_DIR} does not exist."
        )

    def test_config_directory_is_directory(self):
        """The config path must be a directory."""
        assert os.path.isdir(TARGET_DIR), (
            f"{TARGET_DIR} exists but is not a directory."
        )

    def test_config_directory_is_writable(self):
        """The config directory should be writable by the agent."""
        assert os.access(TARGET_DIR, os.W_OK), (
            f"Config directory {TARGET_DIR} is not writable. "
            "The agent needs write access to modify file permissions."
        )


class TestWebappStructure:
    """Verify the webapp directory structure exists."""

    def test_webapp_directory_exists(self):
        """The webapp directory must exist."""
        webapp_dir = "/home/user/webapp"
        assert os.path.exists(webapp_dir), (
            f"Webapp directory {webapp_dir} does not exist."
        )

    def test_webapp_is_directory(self):
        """The webapp path must be a directory."""
        webapp_dir = "/home/user/webapp"
        assert os.path.isdir(webapp_dir), (
            f"{webapp_dir} exists but is not a directory."
        )
