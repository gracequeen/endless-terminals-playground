# test_final_state.py
"""
Post-action validation tests for the database.yml permissions fix task.
Validates that the final state matches expected conditions after the student performs the action.
"""

import os
import stat
import pwd
import grp
import hashlib
import pytest


TARGET_FILE = "/home/user/webapp/config/database.yml"
TARGET_DIR = "/home/user/webapp/config"


class TestTargetFileExists:
    """Verify the target file still exists and is a regular file."""

    def test_file_exists(self):
        """The target file must still exist at the original path."""
        assert os.path.exists(TARGET_FILE), (
            f"Target file {TARGET_FILE} does not exist. "
            "The file must remain at its original path - it should not be moved, deleted, or recreated elsewhere."
        )

    def test_is_regular_file(self):
        """The target must be a regular file, not a directory or symlink."""
        assert os.path.isfile(TARGET_FILE), (
            f"{TARGET_FILE} exists but is not a regular file. "
            "It may have been replaced with a directory or special file."
        )
        assert not os.path.islink(TARGET_FILE), (
            f"{TARGET_FILE} is a symbolic link. "
            "The original file should remain, not be replaced with a symlink."
        )


class TestFinalPermissions:
    """Verify the file has the expected final permissions (600)."""

    def test_permissions_are_600(self):
        """File should have permissions 600 (rw-------) after the fix."""
        file_stat = os.stat(TARGET_FILE)
        mode = stat.S_IMODE(file_stat.st_mode)
        expected_mode = 0o600

        assert mode == expected_mode, (
            f"Expected {TARGET_FILE} to have permissions 600 (0o600), "
            f"but found {oct(mode)} ({stat.filemode(file_stat.st_mode)}). "
            "The file should be chmod'd to 600 so only the owner can access it."
        )

    def test_file_is_not_world_readable(self):
        """File should NOT be world-readable after the fix."""
        file_stat = os.stat(TARGET_FILE)
        mode = stat.S_IMODE(file_stat.st_mode)

        assert not (mode & stat.S_IROTH), (
            f"{TARGET_FILE} is still world-readable (others have read permission). "
            "The security fix requires removing read access for others."
        )

    def test_file_is_not_group_readable(self):
        """File should NOT be group-readable after the fix."""
        file_stat = os.stat(TARGET_FILE)
        mode = stat.S_IMODE(file_stat.st_mode)

        assert not (mode & stat.S_IRGRP), (
            f"{TARGET_FILE} is still group-readable. "
            "Permissions 600 means no group read access."
        )

    def test_owner_has_read_write(self):
        """Owner should still have read and write permissions."""
        file_stat = os.stat(TARGET_FILE)
        mode = stat.S_IMODE(file_stat.st_mode)

        assert mode & stat.S_IRUSR, (
            f"Owner lost read permission on {TARGET_FILE}. "
            "Permissions 600 should allow owner to read."
        )
        assert mode & stat.S_IWUSR, (
            f"Owner lost write permission on {TARGET_FILE}. "
            "Permissions 600 should allow owner to write."
        )

    def test_no_execute_permissions(self):
        """File should not have any execute permissions."""
        file_stat = os.stat(TARGET_FILE)
        mode = stat.S_IMODE(file_stat.st_mode)

        assert not (mode & stat.S_IXUSR), (
            f"{TARGET_FILE} has owner execute permission, which is unexpected for a YAML config file."
        )
        assert not (mode & stat.S_IXGRP), (
            f"{TARGET_FILE} has group execute permission, which is unexpected."
        )
        assert not (mode & stat.S_IXOTH), (
            f"{TARGET_FILE} has other execute permission, which is unexpected."
        )


class TestFileOwnershipUnchanged:
    """Verify the file ownership is unchanged (still user:user)."""

    def test_owner_is_still_user(self):
        """File should still be owned by 'user'."""
        file_stat = os.stat(TARGET_FILE)
        try:
            owner_name = pwd.getpwuid(file_stat.st_uid).pw_name
        except KeyError:
            owner_name = str(file_stat.st_uid)

        assert owner_name == "user", (
            f"Expected {TARGET_FILE} to still be owned by 'user', "
            f"but found owner '{owner_name}'. "
            "Only permissions should change, not ownership."
        )

    def test_group_is_still_user(self):
        """File should still have group 'user'."""
        file_stat = os.stat(TARGET_FILE)
        try:
            group_name = grp.getgrgid(file_stat.st_gid).gr_name
        except KeyError:
            group_name = str(file_stat.st_gid)

        assert group_name == "user", (
            f"Expected {TARGET_FILE} to still have group 'user', "
            f"but found group '{group_name}'. "
            "Only permissions should change, not group ownership."
        )


class TestFileContentsPreserved:
    """Verify the file contents are unchanged (only permissions modified)."""

    def test_contains_production_block(self):
        """File should still contain a production configuration block."""
        with open(TARGET_FILE, 'r') as f:
            content = f.read()

        assert 'production' in content.lower(), (
            f"{TARGET_FILE} no longer contains a 'production' block. "
            "File contents should be preserved - only permissions should change."
        )

    def test_contains_plaintext_password(self):
        """File should still contain the plaintext password (content unchanged)."""
        with open(TARGET_FILE, 'r') as f:
            content = f.read()

        assert 's3cr3t_pr0d_pw!' in content, (
            f"{TARGET_FILE} no longer contains the expected password 's3cr3t_pr0d_pw!'. "
            "File contents should be byte-identical to the initial state - only permissions should change."
        )

    def test_contains_password_key(self):
        """File should still have a password key in the YAML."""
        with open(TARGET_FILE, 'r') as f:
            content = f.read()

        assert 'password:' in content or 'password :' in content, (
            f"{TARGET_FILE} no longer contains a 'password:' key. "
            "File contents should be preserved."
        )

    def test_file_is_not_empty(self):
        """File should not be empty."""
        file_stat = os.stat(TARGET_FILE)
        assert file_stat.st_size > 0, (
            f"{TARGET_FILE} is empty. "
            "File contents should be preserved - the file should not be truncated."
        )


class TestNoOtherFilesModified:
    """Verify no other files in the config directory had permissions changed."""

    def test_directory_permissions_unchanged(self):
        """The config directory permissions should be reasonable (not overly restrictive)."""
        dir_stat = os.stat(TARGET_DIR)
        mode = stat.S_IMODE(dir_stat.st_mode)

        # Directory should at least be accessible by owner
        assert mode & stat.S_IRUSR, (
            f"Config directory {TARGET_DIR} lost owner read permission."
        )
        assert mode & stat.S_IXUSR, (
            f"Config directory {TARGET_DIR} lost owner execute permission (needed to access directory)."
        )


class TestStatCommandOutput:
    """Verify stat command returns expected output."""

    def test_stat_shows_600(self):
        """stat -c '%a' should output exactly '600'."""
        import subprocess

        result = subprocess.run(
            ['stat', '-c', '%a', TARGET_FILE],
            capture_output=True,
            text=True
        )

        assert result.returncode == 0, (
            f"stat command failed with return code {result.returncode}. "
            f"stderr: {result.stderr}"
        )

        actual_perms = result.stdout.strip()
        assert actual_perms == "600", (
            f"Expected `stat -c '%a' {TARGET_FILE}` to output '600', "
            f"but got '{actual_perms}'."
        )
