# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the task of fixing the Makefile bug.
"""

import os
import subprocess
import json
import pytest

MLOPS_DIR = "/home/user/mlops"


class TestDirectoryStructure:
    """Test that required directories exist."""

    def test_mlops_directory_exists(self):
        """The /home/user/mlops directory must exist."""
        assert os.path.isdir(MLOPS_DIR), f"Directory {MLOPS_DIR} does not exist"

    def test_scripts_directory_exists(self):
        """The scripts subdirectory must exist."""
        scripts_dir = os.path.join(MLOPS_DIR, "scripts")
        assert os.path.isdir(scripts_dir), f"Directory {scripts_dir} does not exist"

    def test_artifacts_directory_exists(self):
        """The artifacts subdirectory must exist."""
        artifacts_dir = os.path.join(MLOPS_DIR, "artifacts")
        assert os.path.isdir(artifacts_dir), f"Directory {artifacts_dir} does not exist"


class TestRequiredFiles:
    """Test that all required files exist."""

    def test_makefile_exists(self):
        """The Makefile must exist."""
        makefile_path = os.path.join(MLOPS_DIR, "Makefile")
        assert os.path.isfile(makefile_path), f"Makefile not found at {makefile_path}"

    def test_train_py_exists(self):
        """train.py must exist."""
        train_path = os.path.join(MLOPS_DIR, "train.py")
        assert os.path.isfile(train_path), f"train.py not found at {train_path}"

    def test_register_py_exists(self):
        """register.py must exist."""
        register_path = os.path.join(MLOPS_DIR, "register.py")
        assert os.path.isfile(register_path), f"register.py not found at {register_path}"

    def test_setup_dirs_script_exists(self):
        """scripts/setup_dirs.sh must exist."""
        setup_script = os.path.join(MLOPS_DIR, "scripts", "setup_dirs.sh")
        assert os.path.isfile(setup_script), f"setup_dirs.sh not found at {setup_script}"

    def test_manifest_json_exists(self):
        """manifest.json must exist."""
        manifest_path = os.path.join(MLOPS_DIR, "manifest.json")
        assert os.path.isfile(manifest_path), f"manifest.json not found at {manifest_path}"

    def test_train_py_orig_exists(self):
        """train.py.orig must exist for anti-shortcut verification."""
        orig_path = os.path.join(MLOPS_DIR, "train.py.orig")
        assert os.path.isfile(orig_path), f"train.py.orig not found at {orig_path} (needed for anti-shortcut check)"

    def test_register_py_orig_exists(self):
        """register.py.orig must exist for anti-shortcut verification."""
        orig_path = os.path.join(MLOPS_DIR, "register.py.orig")
        assert os.path.isfile(orig_path), f"register.py.orig not found at {orig_path} (needed for anti-shortcut check)"


class TestMakefileContent:
    """Test that the Makefile has the expected buggy structure."""

    def test_makefile_has_run_target(self):
        """Makefile must have a 'run' target."""
        makefile_path = os.path.join(MLOPS_DIR, "Makefile")
        with open(makefile_path, "r") as f:
            content = f.read()
        assert "run:" in content or "run :" in content, "Makefile missing 'run' target"

    def test_makefile_has_experiment_variable(self):
        """Makefile must use EXPERIMENT variable."""
        makefile_path = os.path.join(MLOPS_DIR, "Makefile")
        with open(makefile_path, "r") as f:
            content = f.read()
        assert "EXPERIMENT" in content, "Makefile missing EXPERIMENT variable"

    def test_makefile_has_model_path(self):
        """Makefile must define MODEL_PATH."""
        makefile_path = os.path.join(MLOPS_DIR, "Makefile")
        with open(makefile_path, "r") as f:
            content = f.read()
        assert "MODEL_PATH" in content, "Makefile missing MODEL_PATH variable"

    def test_makefile_has_register_target(self):
        """Makefile must have a 'register' target."""
        makefile_path = os.path.join(MLOPS_DIR, "Makefile")
        with open(makefile_path, "r") as f:
            content = f.read()
        assert "register:" in content or "register :" in content, "Makefile missing 'register' target"


class TestManifestJson:
    """Test that manifest.json is valid JSON."""

    def test_manifest_is_valid_json(self):
        """manifest.json must be valid JSON."""
        manifest_path = os.path.join(MLOPS_DIR, "manifest.json")
        with open(manifest_path, "r") as f:
            try:
                data = json.load(f)
            except json.JSONDecodeError as e:
                pytest.fail(f"manifest.json is not valid JSON: {e}")
        assert isinstance(data, dict), "manifest.json must be a JSON object/dict"


class TestScriptsExecutable:
    """Test that scripts are executable or can be executed."""

    def test_setup_dirs_is_readable(self):
        """setup_dirs.sh must be readable."""
        setup_script = os.path.join(MLOPS_DIR, "scripts", "setup_dirs.sh")
        assert os.access(setup_script, os.R_OK), f"{setup_script} is not readable"

    def test_train_py_is_readable(self):
        """train.py must be readable."""
        train_path = os.path.join(MLOPS_DIR, "train.py")
        assert os.access(train_path, os.R_OK), f"{train_path} is not readable"

    def test_register_py_is_readable(self):
        """register.py must be readable."""
        register_path = os.path.join(MLOPS_DIR, "register.py")
        assert os.access(register_path, os.R_OK), f"{register_path} is not readable"


class TestPythonAvailable:
    """Test that Python is available."""

    def test_python3_available(self):
        """Python 3 must be available."""
        result = subprocess.run(
            ["python3", "--version"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "python3 is not available"

    def test_python_available(self):
        """Python must be available (could be python or python3)."""
        result = subprocess.run(
            ["which", "python"],
            capture_output=True,
            text=True
        )
        if result.returncode != 0:
            result = subprocess.run(
                ["which", "python3"],
                capture_output=True,
                text=True
            )
        assert result.returncode == 0, "Neither python nor python3 is available in PATH"


class TestMakeAvailable:
    """Test that make is available."""

    def test_make_available(self):
        """GNU make must be available."""
        result = subprocess.run(
            ["make", "--version"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "make is not available"


class TestDirectoryWritable:
    """Test that the mlops directory is writable."""

    def test_mlops_dir_writable(self):
        """The /home/user/mlops directory must be writable."""
        assert os.access(MLOPS_DIR, os.W_OK), f"{MLOPS_DIR} is not writable"

    def test_artifacts_dir_writable(self):
        """The artifacts directory must be writable."""
        artifacts_dir = os.path.join(MLOPS_DIR, "artifacts")
        assert os.access(artifacts_dir, os.W_OK), f"{artifacts_dir} is not writable"


class TestPythonScriptsValid:
    """Test that Python scripts have valid syntax."""

    def test_train_py_syntax(self):
        """train.py must have valid Python syntax."""
        train_path = os.path.join(MLOPS_DIR, "train.py")
        result = subprocess.run(
            ["python3", "-m", "py_compile", train_path],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, f"train.py has syntax errors: {result.stderr}"

    def test_register_py_syntax(self):
        """register.py must have valid Python syntax."""
        register_path = os.path.join(MLOPS_DIR, "register.py")
        result = subprocess.run(
            ["python3", "-m", "py_compile", register_path],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, f"register.py has syntax errors: {result.stderr}"
