# test_final_state.py
"""
Tests to validate the final state after the student has fixed the Makefile bug.
The fix should ensure that running `make run EXPERIMENT=name` twice produces
different hashes in manifest.json (because train.py generates different output each time).
"""

import os
import subprocess
import json
import time
import pytest

MLOPS_DIR = "/home/user/mlops"


class TestFilesUnchanged:
    """Verify that train.py and register.py were not modified (anti-shortcut)."""

    def test_train_py_unchanged(self):
        """train.py must be identical to train.py.orig."""
        train_path = os.path.join(MLOPS_DIR, "train.py")
        orig_path = os.path.join(MLOPS_DIR, "train.py.orig")

        assert os.path.isfile(train_path), f"train.py not found at {train_path}"
        assert os.path.isfile(orig_path), f"train.py.orig not found at {orig_path}"

        result = subprocess.run(
            ["diff", train_path, orig_path],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"train.py has been modified (anti-shortcut violation). "
            f"The fix must be in the Makefile, not in train.py.\n"
            f"Diff output:\n{result.stdout}"
        )

    def test_register_py_unchanged(self):
        """register.py must be identical to register.py.orig."""
        register_path = os.path.join(MLOPS_DIR, "register.py")
        orig_path = os.path.join(MLOPS_DIR, "register.py.orig")

        assert os.path.isfile(register_path), f"register.py not found at {register_path}"
        assert os.path.isfile(orig_path), f"register.py.orig not found at {orig_path}"

        result = subprocess.run(
            ["diff", register_path, orig_path],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"register.py has been modified (anti-shortcut violation). "
            f"The fix must be in the Makefile, not in register.py.\n"
            f"Diff output:\n{result.stdout}"
        )


class TestSetupDirsUnchanged:
    """Verify that setup_dirs.sh was not modified."""

    def test_setup_dirs_exists(self):
        """scripts/setup_dirs.sh must still exist."""
        setup_script = os.path.join(MLOPS_DIR, "scripts", "setup_dirs.sh")
        assert os.path.isfile(setup_script), f"setup_dirs.sh not found at {setup_script}"


class TestMakefileInterfacePreserved:
    """Verify that the Makefile interface is preserved."""

    def test_makefile_exists(self):
        """Makefile must still exist."""
        makefile_path = os.path.join(MLOPS_DIR, "Makefile")
        assert os.path.isfile(makefile_path), f"Makefile not found at {makefile_path}"

    def test_makefile_has_run_target(self):
        """Makefile must still have a 'run' target."""
        makefile_path = os.path.join(MLOPS_DIR, "Makefile")
        with open(makefile_path, "r") as f:
            content = f.read()
        # Check for run target - could be "run:" or "run :" or part of .PHONY
        assert "run" in content, "Makefile missing 'run' target"

    def test_makefile_supports_experiment_variable(self):
        """Makefile must still support EXPERIMENT variable."""
        makefile_path = os.path.join(MLOPS_DIR, "Makefile")
        with open(makefile_path, "r") as f:
            content = f.read()
        assert "EXPERIMENT" in content, "Makefile missing EXPERIMENT variable support"


class TestMakeRunWorks:
    """Test that make run EXPERIMENT=name still works."""

    def test_make_run_executes_successfully(self):
        """make run EXPERIMENT=testrun should execute without errors."""
        # First clean up
        subprocess.run(
            ["make", "clean"],
            cwd=MLOPS_DIR,
            capture_output=True,
            text=True
        )

        # Run make
        result = subprocess.run(
            ["make", "run", "EXPERIMENT=testrun"],
            cwd=MLOPS_DIR,
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"make run EXPERIMENT=testrun failed with return code {result.returncode}.\n"
            f"stdout: {result.stdout}\n"
            f"stderr: {result.stderr}"
        )

    def test_make_run_creates_model_file(self):
        """make run should create the model file."""
        # Clean and run
        subprocess.run(["make", "clean"], cwd=MLOPS_DIR, capture_output=True)
        subprocess.run(["make", "run", "EXPERIMENT=modeltest"], cwd=MLOPS_DIR, capture_output=True)

        model_path = os.path.join(MLOPS_DIR, "artifacts", "modeltest", "model.bin")
        assert os.path.isfile(model_path), (
            f"Model file not created at {model_path}. "
            f"make run should create artifacts/EXPERIMENT/model.bin"
        )

    def test_make_run_updates_manifest(self):
        """make run should update manifest.json with the experiment."""
        # Clean and run
        subprocess.run(["make", "clean"], cwd=MLOPS_DIR, capture_output=True)
        subprocess.run(["make", "run", "EXPERIMENT=manifesttest"], cwd=MLOPS_DIR, capture_output=True)

        manifest_path = os.path.join(MLOPS_DIR, "manifest.json")
        assert os.path.isfile(manifest_path), f"manifest.json not found at {manifest_path}"

        with open(manifest_path, "r") as f:
            data = json.load(f)

        assert "manifesttest" in data, (
            f"Experiment 'manifesttest' not found in manifest.json. "
            f"Contents: {data}"
        )
        assert "hash" in data["manifesttest"], (
            f"'hash' key missing for experiment 'manifesttest' in manifest.json"
        )


class TestBugFixed:
    """The main test: verify that the stale hash bug is fixed."""

    def test_consecutive_runs_produce_different_hashes(self):
        """
        Running make run EXPERIMENT=X twice should produce different hashes
        in manifest.json (because train.py includes timestamp, so model changes).
        This is the core test that verifies the bug is fixed.
        """
        experiment_name = "verify_exp"
        manifest_path = os.path.join(MLOPS_DIR, "manifest.json")

        # Step 1: Clean
        result = subprocess.run(
            ["make", "clean"],
            cwd=MLOPS_DIR,
            capture_output=True,
            text=True
        )
        # Clean might fail if manifest doesn't exist, that's ok

        # Step 2: First run
        result = subprocess.run(
            ["make", "run", f"EXPERIMENT={experiment_name}"],
            cwd=MLOPS_DIR,
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"First make run failed: {result.stderr}"
        )

        # Step 3: Get first hash
        assert os.path.isfile(manifest_path), "manifest.json not created after first run"
        with open(manifest_path, "r") as f:
            data1 = json.load(f)

        assert experiment_name in data1, (
            f"Experiment '{experiment_name}' not in manifest after first run"
        )
        hash1 = data1[experiment_name]["hash"]

        # Step 4: Wait to ensure timestamp difference
        time.sleep(2)

        # Step 5: Second run
        result = subprocess.run(
            ["make", "run", f"EXPERIMENT={experiment_name}"],
            cwd=MLOPS_DIR,
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"Second make run failed: {result.stderr}"
        )

        # Step 6: Get second hash
        with open(manifest_path, "r") as f:
            data2 = json.load(f)

        assert experiment_name in data2, (
            f"Experiment '{experiment_name}' not in manifest after second run"
        )
        hash2 = data2[experiment_name]["hash"]

        # Step 7: Verify hashes are different
        assert hash1 != hash2, (
            f"BUG NOT FIXED: Hash after second run ({hash2}) is identical to "
            f"hash after first run ({hash1}). The Makefile should force "
            f"re-training on each 'make run' so that the new model hash "
            f"is registered in manifest.json."
        )

    def test_multiple_experiments_tracked_correctly(self):
        """Different experiments should be tracked independently."""
        manifest_path = os.path.join(MLOPS_DIR, "manifest.json")

        # Clean
        subprocess.run(["make", "clean"], cwd=MLOPS_DIR, capture_output=True)

        # Run experiment A
        result = subprocess.run(
            ["make", "run", "EXPERIMENT=exp_a"],
            cwd=MLOPS_DIR,
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, f"make run EXPERIMENT=exp_a failed: {result.stderr}"

        # Run experiment B
        result = subprocess.run(
            ["make", "run", "EXPERIMENT=exp_b"],
            cwd=MLOPS_DIR,
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, f"make run EXPERIMENT=exp_b failed: {result.stderr}"

        # Check manifest has both
        with open(manifest_path, "r") as f:
            data = json.load(f)

        assert "exp_a" in data, "Experiment 'exp_a' missing from manifest"
        assert "exp_b" in data, "Experiment 'exp_b' missing from manifest"
        assert data["exp_a"]["hash"] != data["exp_b"]["hash"], (
            "Different experiments should have different hashes"
        )


class TestNoWrapperScriptShortcut:
    """Ensure the fix is in the Makefile, not a wrapper script."""

    def test_make_invoked_directly_works(self):
        """
        The fix should work when make is invoked directly, not through
        a wrapper script that does 'make clean' first.
        """
        # This is implicitly tested by test_consecutive_runs_produce_different_hashes
        # but we add an explicit check that we're testing make directly
        manifest_path = os.path.join(MLOPS_DIR, "manifest.json")

        # Clean once at the start
        subprocess.run(["make", "clean"], cwd=MLOPS_DIR, capture_output=True)

        # First run
        subprocess.run(
            ["make", "run", "EXPERIMENT=direct_test"],
            cwd=MLOPS_DIR,
            capture_output=True
        )

        with open(manifest_path, "r") as f:
            hash1 = json.load(f)["direct_test"]["hash"]

        time.sleep(2)

        # Second run - NO clean in between
        subprocess.run(
            ["make", "run", "EXPERIMENT=direct_test"],
            cwd=MLOPS_DIR,
            capture_output=True
        )

        with open(manifest_path, "r") as f:
            hash2 = json.load(f)["direct_test"]["hash"]

        assert hash1 != hash2, (
            "Consecutive make runs without 'make clean' in between must produce "
            "different hashes. If they're the same, the Makefile bug is not fixed."
        )
