# test_final_state.py
"""
Tests to validate the final state of the OS/filesystem after the student
has completed the task of fixing the Flask inventory-api service.

The app should:
- Start without errors on port 5000
- Have /health endpoint returning {"status": "ok"}
- Have /api/items endpoint returning items data
- Still use ProxyFix middleware (not just deleted)
"""

import json
import os
import signal
import socket
import subprocess
import time
import pytest


PROJECT_DIR = "/home/user/inventory-api"
APP_FILE = os.path.join(PROJECT_DIR, "app.py")
REQUIREMENTS_FILE = os.path.join(PROJECT_DIR, "requirements.txt")
HOST = "localhost"
PORT = 5000


class TestAppPyFixed:
    """Test that app.py has been properly fixed."""

    def test_app_py_exists(self):
        """app.py must still exist."""
        assert os.path.isfile(APP_FILE), (
            f"app.py not found at {APP_FILE}. "
            "The Flask application file must exist."
        )

    def test_app_py_still_uses_proxyfix(self):
        """app.py must still use ProxyFix middleware (not just deleted to avoid import error)."""
        with open(APP_FILE, 'r') as f:
            content = f.read()
        assert "ProxyFix" in content, (
            "app.py no longer contains 'ProxyFix'. "
            "The middleware must still be used, not simply deleted to fix the import error."
        )

    def test_app_py_no_legacy_import(self):
        """app.py must not have the broken werkzeug.contrib.fixers import."""
        with open(APP_FILE, 'r') as f:
            content = f.read()
        assert "werkzeug.contrib.fixers" not in content, (
            "app.py still contains the legacy 'werkzeug.contrib.fixers' import. "
            "This import is broken in modern Werkzeug and must be updated to "
            "'werkzeug.middleware.proxy_fix'."
        )

    def test_app_py_has_modern_proxyfix_import(self):
        """app.py should import ProxyFix from the correct modern location."""
        with open(APP_FILE, 'r') as f:
            content = f.read()
        # Check for the modern import path
        has_modern_import = (
            "werkzeug.middleware.proxy_fix" in content or
            "from werkzeug.middleware import" in content
        )
        assert has_modern_import, (
            "app.py does not contain the modern ProxyFix import. "
            "Expected import from 'werkzeug.middleware.proxy_fix'."
        )

    def test_app_py_contains_health_endpoint(self):
        """app.py must still define a /health endpoint."""
        with open(APP_FILE, 'r') as f:
            content = f.read()
        assert "/health" in content, (
            "app.py no longer contains '/health' route. "
            "The health endpoint must be preserved."
        )

    def test_app_py_contains_items_endpoint(self):
        """app.py must still define a /api/items endpoint."""
        with open(APP_FILE, 'r') as f:
            content = f.read()
        assert "/api/items" in content, (
            "app.py no longer contains '/api/items' route. "
            "The items endpoint must be preserved."
        )


class TestAppCanImport:
    """Test that app.py can be imported without errors."""

    def test_app_py_syntax_valid(self):
        """app.py must have valid Python syntax."""
        result = subprocess.run(
            ["python3", "-m", "py_compile", APP_FILE],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"app.py has syntax errors: {result.stderr}"
        )

    def test_app_py_imports_successfully(self):
        """app.py must import without ImportError."""
        # Try to import the module to check for import errors
        result = subprocess.run(
            ["python3", "-c", f"import sys; sys.path.insert(0, '{PROJECT_DIR}'); import app"],
            capture_output=True,
            text=True,
            cwd=PROJECT_DIR,
            timeout=30
        )
        assert result.returncode == 0, (
            f"app.py failed to import. "
            f"Error: {result.stderr}\n"
            "The import error (likely werkzeug.contrib.fixers) must be fixed."
        )


class TestAppStartsAndResponds:
    """Test that the Flask app starts and responds to requests."""

    @pytest.fixture(scope="class")
    def running_app(self):
        """Start the Flask app and yield, then clean up."""
        # First, kill any existing process on port 5000
        subprocess.run(
            ["fuser", "-k", "5000/tcp"],
            capture_output=True,
            stderr=subprocess.DEVNULL
        )
        time.sleep(1)

        # Start the app
        proc = subprocess.Popen(
            ["python3", "app.py"],
            cwd=PROJECT_DIR,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            preexec_fn=os.setsid
        )

        # Wait for the app to start (up to 10 seconds)
        started = False
        for _ in range(20):
            time.sleep(0.5)
            # Check if process is still running
            if proc.poll() is not None:
                stdout, stderr = proc.communicate()
                pytest.fail(
                    f"Flask app crashed on startup.\n"
                    f"stdout: {stdout.decode()}\n"
                    f"stderr: {stderr.decode()}"
                )
            # Try to connect to the port
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(1)
                result = sock.connect_ex((HOST, PORT))
                sock.close()
                if result == 0:
                    started = True
                    break
            except:
                pass

        if not started:
            # Try to get any error output
            proc.terminate()
            try:
                stdout, stderr = proc.communicate(timeout=5)
                error_info = f"stdout: {stdout.decode()}\nstderr: {stderr.decode()}"
            except:
                error_info = "Could not retrieve process output"
            pytest.fail(
                f"Flask app did not start listening on port {PORT} within 10 seconds.\n"
                f"{error_info}"
            )

        yield proc

        # Cleanup: terminate the process group
        try:
            os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
        except:
            pass
        try:
            proc.wait(timeout=5)
        except:
            try:
                os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
            except:
                pass

    def test_app_starts_successfully(self, running_app):
        """The Flask app must start without crashing."""
        # If we got here, the app started (fixture didn't fail)
        assert running_app.poll() is None, (
            "Flask app process terminated unexpectedly after starting."
        )

    def test_port_5000_listening(self, running_app):
        """Port 5000 must be listening."""
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(5)
        try:
            result = sock.connect_ex((HOST, PORT))
            assert result == 0, (
                f"Port {PORT} is not listening. "
                "The Flask app must be running on port 5000."
            )
        finally:
            sock.close()

    def test_health_endpoint_returns_ok(self, running_app):
        """GET /health must return {"status": "ok"}."""
        result = subprocess.run(
            ["curl", "-s", f"http://{HOST}:{PORT}/health"],
            capture_output=True,
            text=True,
            timeout=10
        )
        assert result.returncode == 0, (
            f"curl to /health failed: {result.stderr}"
        )

        response_text = result.stdout.strip()
        assert response_text, (
            "Empty response from /health endpoint."
        )

        try:
            data = json.loads(response_text)
        except json.JSONDecodeError as e:
            pytest.fail(
                f"/health did not return valid JSON. "
                f"Response: {response_text}\n"
                f"Error: {e}"
            )

        assert "status" in data, (
            f"/health response missing 'status' key. "
            f"Got: {data}"
        )
        assert data["status"] == "ok", (
            f"/health status is not 'ok'. "
            f"Expected: 'ok', Got: {data['status']}"
        )

    def test_items_endpoint_returns_items(self, running_app):
        """GET /api/items must return valid JSON with items."""
        result = subprocess.run(
            ["curl", "-s", f"http://{HOST}:{PORT}/api/items"],
            capture_output=True,
            text=True,
            timeout=10
        )
        assert result.returncode == 0, (
            f"curl to /api/items failed: {result.stderr}"
        )

        response_text = result.stdout.strip()
        assert response_text, (
            "Empty response from /api/items endpoint."
        )

        try:
            data = json.loads(response_text)
        except json.JSONDecodeError as e:
            pytest.fail(
                f"/api/items did not return valid JSON. "
                f"Response: {response_text}\n"
                f"Error: {e}"
            )

        assert "items" in data, (
            f"/api/items response missing 'items' key. "
            f"Got: {data}"
        )

        items = data["items"]
        assert isinstance(items, list), (
            f"/api/items 'items' should be a list. "
            f"Got type: {type(items)}"
        )

        assert len(items) == 2, (
            f"/api/items should return 2 items. "
            f"Got {len(items)} items."
        )

        # Check that items have expected structure
        for item in items:
            assert "id" in item, (
                f"Item missing 'id' key: {item}"
            )
            assert "name" in item, (
                f"Item missing 'name' key: {item}"
            )

        # Check for expected item names
        names = [item["name"] for item in items]
        assert "widget" in names, (
            f"Expected 'widget' in items. Got names: {names}"
        )
        assert "gadget" in names, (
            f"Expected 'gadget' in items. Got names: {names}"
        )

    def test_health_endpoint_http_status(self, running_app):
        """GET /health must return HTTP 200."""
        result = subprocess.run(
            ["curl", "-s", "-o", "/dev/null", "-w", "%{http_code}",
             f"http://{HOST}:{PORT}/health"],
            capture_output=True,
            text=True,
            timeout=10
        )
        assert result.returncode == 0, (
            f"curl failed: {result.stderr}"
        )
        status_code = result.stdout.strip()
        assert status_code == "200", (
            f"/health returned HTTP {status_code}, expected 200."
        )

    def test_items_endpoint_http_status(self, running_app):
        """GET /api/items must return HTTP 200."""
        result = subprocess.run(
            ["curl", "-s", "-o", "/dev/null", "-w", "%{http_code}",
             f"http://{HOST}:{PORT}/api/items"],
            capture_output=True,
            text=True,
            timeout=10
        )
        assert result.returncode == 0, (
            f"curl failed: {result.stderr}"
        )
        status_code = result.stdout.strip()
        assert status_code == "200", (
            f"/api/items returned HTTP {status_code}, expected 200."
        )


class TestProxyFixGrep:
    """Anti-shortcut guard: verify ProxyFix wasn't just deleted."""

    def test_grep_proxyfix_matches(self):
        """grep -i proxyfix must match in app.py."""
        result = subprocess.run(
            ["grep", "-i", "proxyfix", APP_FILE],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "grep -i proxyfix did not match in app.py. "
            "The ProxyFix middleware must still be used, not deleted."
        )
        assert result.stdout.strip(), (
            "grep -i proxyfix returned empty output. "
            "ProxyFix must still be present in the code."
        )
