# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the task of fixing the Flask inventory-api service.
"""

import os
import subprocess
import pytest


HOME_DIR = "/home/user"
PROJECT_DIR = "/home/user/inventory-api"
APP_FILE = os.path.join(PROJECT_DIR, "app.py")
REQUIREMENTS_FILE = os.path.join(PROJECT_DIR, "requirements.txt")
TEMPLATES_DIR = os.path.join(PROJECT_DIR, "templates")
INDEX_TEMPLATE = os.path.join(TEMPLATES_DIR, "index.html")


class TestProjectStructure:
    """Test that the project directory and files exist."""

    def test_project_directory_exists(self):
        """The inventory-api project directory must exist."""
        assert os.path.isdir(PROJECT_DIR), (
            f"Project directory {PROJECT_DIR} does not exist. "
            "The inventory-api project should be present."
        )

    def test_app_py_exists(self):
        """The app.py file must exist in the project directory."""
        assert os.path.isfile(APP_FILE), (
            f"app.py not found at {APP_FILE}. "
            "The Flask application file should be present."
        )

    def test_requirements_txt_exists(self):
        """The requirements.txt file must exist in the project directory."""
        assert os.path.isfile(REQUIREMENTS_FILE), (
            f"requirements.txt not found at {REQUIREMENTS_FILE}. "
            "The requirements file should be present."
        )

    def test_templates_directory_exists(self):
        """The templates directory must exist."""
        assert os.path.isdir(TEMPLATES_DIR), (
            f"Templates directory {TEMPLATES_DIR} does not exist. "
            "The templates folder should be present."
        )

    def test_index_template_exists(self):
        """The index.html template must exist."""
        assert os.path.isfile(INDEX_TEMPLATE), (
            f"index.html not found at {INDEX_TEMPLATE}. "
            "The index template should be present."
        )


class TestAppPyContents:
    """Test that app.py has the expected legacy code structure."""

    def test_app_py_contains_flask_import(self):
        """app.py must import Flask."""
        with open(APP_FILE, 'r') as f:
            content = f.read()
        assert "from flask import" in content or "import flask" in content.lower(), (
            "app.py does not contain Flask import. "
            "The file should be a Flask application."
        )

    def test_app_py_contains_legacy_proxyfix_import(self):
        """app.py must contain the legacy werkzeug.contrib.fixers import (the bug)."""
        with open(APP_FILE, 'r') as f:
            content = f.read()
        assert "werkzeug.contrib.fixers" in content, (
            "app.py does not contain the legacy import 'werkzeug.contrib.fixers'. "
            "The initial state should have the buggy import that needs to be fixed."
        )

    def test_app_py_contains_proxyfix_usage(self):
        """app.py must use ProxyFix middleware."""
        with open(APP_FILE, 'r') as f:
            content = f.read()
        assert "ProxyFix" in content, (
            "app.py does not contain 'ProxyFix'. "
            "The application should use ProxyFix middleware."
        )

    def test_app_py_contains_health_endpoint(self):
        """app.py must define a /health endpoint."""
        with open(APP_FILE, 'r') as f:
            content = f.read()
        assert "/health" in content, (
            "app.py does not contain '/health' route. "
            "The health endpoint should be defined."
        )

    def test_app_py_contains_items_endpoint(self):
        """app.py must define a /api/items endpoint."""
        with open(APP_FILE, 'r') as f:
            content = f.read()
        assert "/api/items" in content, (
            "app.py does not contain '/api/items' route. "
            "The items endpoint should be defined."
        )

    def test_app_py_contains_port_5000(self):
        """app.py must be configured to run on port 5000."""
        with open(APP_FILE, 'r') as f:
            content = f.read()
        assert "5000" in content, (
            "app.py does not contain port 5000 configuration. "
            "The application should be set to run on port 5000."
        )


class TestRequirementsTxtContents:
    """Test that requirements.txt has the expected legacy dependencies."""

    def test_requirements_contains_flask(self):
        """requirements.txt must contain Flask dependency."""
        with open(REQUIREMENTS_FILE, 'r') as f:
            content = f.read()
        assert "Flask" in content or "flask" in content.lower(), (
            "requirements.txt does not contain Flask. "
            "Flask should be listed as a dependency."
        )

    def test_requirements_contains_werkzeug(self):
        """requirements.txt must contain Werkzeug dependency."""
        with open(REQUIREMENTS_FILE, 'r') as f:
            content = f.read()
        assert "Werkzeug" in content or "werkzeug" in content.lower(), (
            "requirements.txt does not contain Werkzeug. "
            "Werkzeug should be listed as a dependency."
        )


class TestPythonEnvironment:
    """Test that Python and pip are available."""

    def test_python3_available(self):
        """Python 3 must be available."""
        result = subprocess.run(
            ["python3", "--version"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "Python 3 is not available. "
            f"Error: {result.stderr}"
        )
        assert "Python 3" in result.stdout, (
            f"Expected Python 3, got: {result.stdout}"
        )

    def test_pip_available(self):
        """pip must be available."""
        result = subprocess.run(
            ["pip3", "--version"],
            capture_output=True,
            text=True
        )
        if result.returncode != 0:
            # Try alternative pip command
            result = subprocess.run(
                ["pip", "--version"],
                capture_output=True,
                text=True
            )
        assert result.returncode == 0, (
            "pip is not available. "
            f"Error: {result.stderr}"
        )


class TestCurlAvailable:
    """Test that curl is available for testing endpoints."""

    def test_curl_available(self):
        """curl must be available for testing."""
        result = subprocess.run(
            ["which", "curl"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "curl is not available. "
            "curl is needed to test the API endpoints."
        )


class TestAppCrashesWithLegacyImport:
    """Test that the app crashes with the legacy import (the bug to fix)."""

    def test_app_fails_to_start(self):
        """Running app.py should fail due to the werkzeug.contrib import error."""
        result = subprocess.run(
            ["python3", APP_FILE],
            capture_output=True,
            text=True,
            cwd=PROJECT_DIR,
            timeout=10
        )
        # The app should fail to start
        assert result.returncode != 0, (
            "app.py started successfully but should have failed. "
            "The legacy werkzeug.contrib.fixers import should cause an ImportError."
        )
        # Check for the expected import error
        error_output = result.stderr + result.stdout
        assert "ImportError" in error_output or "ModuleNotFoundError" in error_output or "cannot import" in error_output.lower(), (
            f"Expected an ImportError related to werkzeug.contrib, but got: {error_output}"
        )


class TestPort5000NotInUse:
    """Test that port 5000 is not currently in use."""

    def test_port_5000_available(self):
        """Port 5000 should not be in use before the task."""
        result = subprocess.run(
            ["ss", "-tlnp"],
            capture_output=True,
            text=True
        )
        if result.returncode == 0:
            # Check if port 5000 is listening
            assert ":5000" not in result.stdout, (
                "Port 5000 is already in use. "
                "The port should be available for the Flask application."
            )
        else:
            # ss might not be available, try netstat
            result = subprocess.run(
                ["netstat", "-tlnp"],
                capture_output=True,
                text=True
            )
            if result.returncode == 0:
                assert ":5000" not in result.stdout, (
                    "Port 5000 is already in use. "
                    "The port should be available for the Flask application."
                )
            # If neither command works, skip this check
            # (the test will still catch issues when the app tries to bind)


class TestDirectoryWritable:
    """Test that the project directory is writable."""

    def test_project_directory_writable(self):
        """The project directory must be writable."""
        assert os.access(PROJECT_DIR, os.W_OK), (
            f"Project directory {PROJECT_DIR} is not writable. "
            "The agent needs to be able to modify files."
        )

    def test_app_py_writable(self):
        """app.py must be writable."""
        assert os.access(APP_FILE, os.W_OK), (
            f"app.py at {APP_FILE} is not writable. "
            "The agent needs to be able to modify this file."
        )

    def test_requirements_txt_writable(self):
        """requirements.txt must be writable."""
        assert os.access(REQUIREMENTS_FILE, os.W_OK), (
            f"requirements.txt at {REQUIREMENTS_FILE} is not writable. "
            "The agent may need to modify this file."
        )
