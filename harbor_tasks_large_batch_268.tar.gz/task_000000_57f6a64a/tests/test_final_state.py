# test_final_state.py
"""
Tests to validate the final state of the OS/filesystem after the student
has fixed the aggregate.py script to correctly process all 912 input records.
"""

import os
import json
import csv
import subprocess
import re
import pytest


HOME = "/home/user"
INGEST_DIR = os.path.join(HOME, "ingest")
INPUT_DIR = os.path.join(INGEST_DIR, "input")
OUTPUT_DIR = os.path.join(INGEST_DIR, "output")
AGGREGATE_SCRIPT = os.path.join(INGEST_DIR, "aggregate.py")
OUTPUT_CSV = os.path.join(OUTPUT_DIR, "fleet.csv")


class TestScriptExistsAndRuns:
    """Test that the aggregate.py script exists and runs successfully."""

    def test_aggregate_script_exists(self):
        assert os.path.isfile(AGGREGATE_SCRIPT), f"Script {AGGREGATE_SCRIPT} does not exist"

    def test_aggregate_script_runs_successfully(self):
        """Script should exit with code 0."""
        result = subprocess.run(
            ['python3', AGGREGATE_SCRIPT],
            capture_output=True,
            text=True,
            cwd=INGEST_DIR
        )
        assert result.returncode == 0, (
            f"Script failed with return code {result.returncode}.\n"
            f"stdout: {result.stdout}\n"
            f"stderr: {result.stderr}"
        )

    def test_script_is_still_python_based(self):
        """Script should still be a Python script, not replaced with shell/jq."""
        with open(AGGREGATE_SCRIPT, 'r') as f:
            content = f.read()

        # Should contain Python imports
        assert 'import' in content, "Script should contain Python import statements"
        # Should not be primarily a shell script
        assert not content.strip().startswith('#!/bin/bash'), "Script should not be a bash script"
        assert not content.strip().startswith('#!/bin/sh'), "Script should not be a shell script"


class TestInputFilesUnmodified:
    """Test that input JSON files were not modified."""

    def test_input_directory_still_has_912_files(self):
        json_files = [f for f in os.listdir(INPUT_DIR) if f.endswith('.json')]
        assert len(json_files) == 912, (
            f"Expected 912 JSON files in {INPUT_DIR}, found {len(json_files)}. "
            "Input files should not be modified or deleted."
        )

    def test_input_files_still_valid_json(self):
        """Input files should still be valid JSON (not corrupted)."""
        json_files = [f for f in os.listdir(INPUT_DIR) if f.endswith('.json')]
        for fname in json_files[:50]:  # Sample check
            fpath = os.path.join(INPUT_DIR, fname)
            with open(fpath, 'rb') as f:
                content = f.read()
            # Handle potential BOM
            if content.startswith(b'\xef\xbb\xbf'):
                content = content[3:]
            try:
                json.loads(content.decode('utf-8'))
            except json.JSONDecodeError as e:
                pytest.fail(f"Input file {fname} is no longer valid JSON: {e}")


class TestOutputCSVStructure:
    """Test that the output CSV has correct structure."""

    def test_output_csv_exists(self):
        assert os.path.isfile(OUTPUT_CSV), f"Output file {OUTPUT_CSV} does not exist"

    def test_output_csv_has_expected_columns(self):
        """Verify CSV has the expected column headers."""
        expected_columns = {'device_id', 'timestamp', 'temp', 'humidity', 'voltage', 'firmware', 'location'}

        with open(OUTPUT_CSV, 'r') as f:
            reader = csv.reader(f)
            header = next(reader)

        header_set = set(header)
        assert header_set == expected_columns, (
            f"Expected columns {expected_columns}, found {header_set}"
        )

    def test_output_csv_is_valid_parseable_csv(self):
        """Verify the output is a valid, parseable CSV."""
        with open(OUTPUT_CSV, 'r') as f:
            reader = csv.DictReader(f)
            try:
                rows = list(reader)
                assert len(rows) > 0, "CSV should have data rows"
            except csv.Error as e:
                pytest.fail(f"Output CSV is not valid: {e}")

    def test_output_csv_parseable_by_pandas(self):
        """Verify pandas can read the CSV without errors."""
        result = subprocess.run(
            ['python3', '-c', f"import pandas; df = pandas.read_csv('{OUTPUT_CSV}'); print(len(df))"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"pandas.read_csv() failed on output CSV: {result.stderr}"
        )


class TestOutputRowCount:
    """Test that the output CSV has exactly 912 data rows."""

    def test_output_has_exactly_912_data_rows(self):
        """The fixed script should produce exactly 912 data rows."""
        # First, run the script to ensure output is current
        subprocess.run(['python3', AGGREGATE_SCRIPT], cwd=INGEST_DIR, capture_output=True)

        with open(OUTPUT_CSV, 'r') as f:
            reader = csv.reader(f)
            rows = list(reader)

        # First row should be header
        assert len(rows) > 1, "Output CSV should have header and data rows"
        data_rows = len(rows) - 1  # Subtract header
        assert data_rows == 912, (
            f"Expected exactly 912 data rows in output CSV, found {data_rows}. "
            f"Missing {912 - data_rows} records." if data_rows < 912 else
            f"Expected exactly 912 data rows in output CSV, found {data_rows}. "
            f"Extra {data_rows - 912} records."
        )

    def test_row_count_via_pandas(self):
        """Double-check row count using pandas."""
        result = subprocess.run(
            ['python3', '-c', f"import pandas; df = pandas.read_csv('{OUTPUT_CSV}'); print(len(df))"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, f"Failed to read CSV with pandas: {result.stderr}"
        row_count = int(result.stdout.strip())
        assert row_count == 912, (
            f"pandas reports {row_count} data rows, expected 912"
        )


class TestAllInputsRepresentedInOutput:
    """Test that all 912 input JSON files are represented in the output."""

    def test_all_input_records_in_output(self):
        """Every input JSON file should have a corresponding row in output."""
        # Run the script first
        subprocess.run(['python3', AGGREGATE_SCRIPT], cwd=INGEST_DIR, capture_output=True)

        # Collect all input records
        input_records = []
        json_files = [f for f in os.listdir(INPUT_DIR) if f.endswith('.json')]

        for fname in json_files:
            fpath = os.path.join(INPUT_DIR, fname)
            with open(fpath, 'rb') as f:
                content = f.read()
            # Handle BOM
            if content.startswith(b'\xef\xbb\xbf'):
                content = content[3:]
            data = json.loads(content.decode('utf-8'))
            # Strip BOM from firmware if present
            firmware = data['firmware'].lstrip('\ufeff')
            input_records.append({
                'device_id': data['device_id'],
                'timestamp': data['timestamp'],
                'firmware': firmware
            })

        # Collect all output records
        with open(OUTPUT_CSV, 'r') as f:
            reader = csv.DictReader(f)
            output_rows = list(reader)

        # Create a set of (device_id, timestamp) tuples from output for lookup
        # Normalize timestamps for comparison (output might have different format)
        output_keys = set()
        for row in output_rows:
            # The timestamp in output might be in ISO format
            ts = row['timestamp']
            device_id = row['device_id']
            output_keys.add((device_id, ts))
            # Also try with original input format variations
            # Handle potential format differences

        # Check that we have 912 unique records in output
        assert len(output_rows) == 912, (
            f"Output has {len(output_rows)} rows, expected 912"
        )

    def test_device_id_timestamp_combinations_unique(self):
        """Each (device_id, timestamp) combination should appear exactly once."""
        with open(OUTPUT_CSV, 'r') as f:
            reader = csv.DictReader(f)
            output_rows = list(reader)

        seen = {}
        duplicates = []
        for row in output_rows:
            key = (row['device_id'], row['timestamp'])
            if key in seen:
                duplicates.append(key)
            seen[key] = True

        assert len(duplicates) == 0, (
            f"Found {len(duplicates)} duplicate (device_id, timestamp) combinations: {duplicates[:5]}"
        )


class TestDataIntegrity:
    """Test that data values in output match source JSON files."""

    def test_sample_records_match_input(self):
        """Verify a sample of output records match their input JSON files."""
        # Run the script first
        subprocess.run(['python3', AGGREGATE_SCRIPT], cwd=INGEST_DIR, capture_output=True)

        # Read output
        with open(OUTPUT_CSV, 'r') as f:
            reader = csv.DictReader(f)
            output_rows = list(reader)

        # Build a lookup from input files
        input_data = {}
        json_files = [f for f in os.listdir(INPUT_DIR) if f.endswith('.json')]

        for fname in json_files:
            fpath = os.path.join(INPUT_DIR, fname)
            with open(fpath, 'rb') as f:
                content = f.read()
            if content.startswith(b'\xef\xbb\xbf'):
                content = content[3:]
            data = json.loads(content.decode('utf-8'))
            # Store with device_id as part of key
            device_id = data['device_id']
            timestamp = data['timestamp']
            input_data[(device_id, timestamp)] = data

        # Check a sample of output rows
        errors = []
        for row in output_rows[:100]:  # Check first 100
            device_id = row['device_id']
            output_ts = row['timestamp']

            # Find matching input (may need to handle timestamp format differences)
            matched = False
            for (inp_dev, inp_ts), inp_data in input_data.items():
                if inp_dev == device_id:
                    # Check if timestamps match (accounting for format differences)
                    # Input might have milliseconds, output might not
                    inp_ts_normalized = inp_ts.split('.')[0]  # Remove milliseconds
                    out_ts_normalized = output_ts.split('.')[0]

                    if inp_ts_normalized == out_ts_normalized or inp_ts == output_ts:
                        matched = True
                        # Verify data values
                        try:
                            assert abs(float(row['temp']) - inp_data['readings']['temp']) < 0.001
                            assert abs(float(row['humidity']) - inp_data['readings']['humidity']) < 0.001
                            assert abs(float(row['voltage']) - inp_data['readings']['voltage']) < 0.001
                            assert row['location'] == inp_data['location']
                        except AssertionError as e:
                            errors.append(f"Data mismatch for {device_id}: {e}")
                        break

            if not matched:
                # This is okay - we're sampling, not all will match due to timestamp format
                pass

        assert len(errors) == 0, f"Data integrity errors: {errors}"


class TestBugFixesApplied:
    """Test that the script no longer has the original bugs."""

    def test_no_bare_except_with_continue(self):
        """Script should not have bare 'except: continue' that silently drops errors."""
        with open(AGGREGATE_SCRIPT, 'r') as f:
            content = f.read()

        # Look for patterns like "except:" followed by "continue" (with possible whitespace)
        # This is a heuristic check
        lines = content.split('\n')
        for i, line in enumerate(lines):
            stripped = line.strip()
            if stripped == 'except:':
                # Check if next non-empty line is just 'continue'
                for j in range(i + 1, min(i + 3, len(lines))):
                    next_stripped = lines[j].strip()
                    if next_stripped == 'continue':
                        pytest.fail(
                            f"Found bare 'except: continue' pattern at line {i+1}. "
                            "This silently drops errors. Use specific exception handling."
                        )
                    elif next_stripped and not next_stripped.startswith('#'):
                        break  # Found other code, not just continue

    def test_script_handles_multiple_records_per_device(self):
        """Script should not overwrite records from same device."""
        with open(AGGREGATE_SCRIPT, 'r') as f:
            content = f.read()

        # The original bug used records[data["device_id"]] = ...
        # Fixed version should use a list or key by (device_id, timestamp)

        # Check that output has 912 rows (which proves multiple records per device are kept)
        with open(OUTPUT_CSV, 'r') as f:
            reader = csv.reader(f)
            rows = list(reader)

        data_rows = len(rows) - 1
        assert data_rows == 912, (
            f"Only {data_rows} rows in output. If less than 912, the script may still be "
            "overwriting records from devices with multiple reports."
        )

    def test_millisecond_timestamps_handled(self):
        """Script should handle timestamps with milliseconds."""
        # Find input files with millisecond timestamps
        json_files = [f for f in os.listdir(INPUT_DIR) if f.endswith('.json')]
        ms_timestamp_devices = []

        for fname in json_files:
            fpath = os.path.join(INPUT_DIR, fname)
            with open(fpath, 'rb') as f:
                content = f.read()
            if content.startswith(b'\xef\xbb\xbf'):
                content = content[3:]
            data = json.loads(content.decode('utf-8'))
            ts = data.get('timestamp', '')
            if '.' in ts:
                ms_timestamp_devices.append(data['device_id'])

        # Check that these devices appear in output
        with open(OUTPUT_CSV, 'r') as f:
            reader = csv.DictReader(f)
            output_device_ids = [row['device_id'] for row in reader]

        missing = [d for d in ms_timestamp_devices if d not in output_device_ids]
        # Note: device might appear multiple times, so we check if it appears at all
        assert len(missing) == 0, (
            f"Devices with millisecond timestamps missing from output: {missing[:5]}... "
            "The script may not be handling millisecond timestamps correctly."
        )

    def test_bom_files_handled(self):
        """Script should handle files with UTF-8 BOM correctly."""
        # Find input files with BOM
        json_files = [f for f in os.listdir(INPUT_DIR) if f.endswith('.json')]
        bom_devices = []

        for fname in json_files:
            fpath = os.path.join(INPUT_DIR, fname)
            with open(fpath, 'rb') as f:
                first_bytes = f.read(3)
            if first_bytes == b'\xef\xbb\xbf':
                with open(fpath, 'rb') as f:
                    content = f.read()[3:]  # Skip BOM
                data = json.loads(content.decode('utf-8'))
                bom_devices.append(data['device_id'])

        # Check that these devices appear in output
        with open(OUTPUT_CSV, 'r') as f:
            reader = csv.DictReader(f)
            output_device_ids = [row['device_id'] for row in reader]

        missing = [d for d in bom_devices if d not in output_device_ids]
        assert len(missing) == 0, (
            f"Devices from BOM files missing from output: {missing}. "
            "The script may not be handling UTF-8 BOM correctly in firmware field comparison."
        )


class TestRerunProducesSameResult:
    """Test that running the script again produces consistent results."""

    def test_rerun_produces_912_rows(self):
        """Running the script again should still produce 912 rows."""
        # Run twice
        subprocess.run(['python3', AGGREGATE_SCRIPT], cwd=INGEST_DIR, capture_output=True)
        subprocess.run(['python3', AGGREGATE_SCRIPT], cwd=INGEST_DIR, capture_output=True)

        with open(OUTPUT_CSV, 'r') as f:
            reader = csv.reader(f)
            rows = list(reader)

        data_rows = len(rows) - 1
        assert data_rows == 912, (
            f"After re-running script, output has {data_rows} rows instead of 912"
        )
