# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the task of fixing the aggregate.py script.
"""

import os
import json
import csv
import subprocess
import pytest


HOME = "/home/user"
INGEST_DIR = os.path.join(HOME, "ingest")
INPUT_DIR = os.path.join(INGEST_DIR, "input")
OUTPUT_DIR = os.path.join(INGEST_DIR, "output")
AGGREGATE_SCRIPT = os.path.join(INGEST_DIR, "aggregate.py")
OUTPUT_CSV = os.path.join(OUTPUT_DIR, "fleet.csv")


class TestDirectoryStructure:
    """Test that required directories exist."""

    def test_ingest_directory_exists(self):
        assert os.path.isdir(INGEST_DIR), f"Directory {INGEST_DIR} does not exist"

    def test_input_directory_exists(self):
        assert os.path.isdir(INPUT_DIR), f"Directory {INPUT_DIR} does not exist"

    def test_output_directory_exists(self):
        assert os.path.isdir(OUTPUT_DIR), f"Directory {OUTPUT_DIR} does not exist"

    def test_ingest_directory_is_writable(self):
        assert os.access(INGEST_DIR, os.W_OK), f"Directory {INGEST_DIR} is not writable"


class TestAggregateScript:
    """Test that the aggregate.py script exists and has expected structure."""

    def test_aggregate_script_exists(self):
        assert os.path.isfile(AGGREGATE_SCRIPT), f"Script {AGGREGATE_SCRIPT} does not exist"

    def test_aggregate_script_is_readable(self):
        assert os.access(AGGREGATE_SCRIPT, os.R_OK), f"Script {AGGREGATE_SCRIPT} is not readable"

    def test_aggregate_script_is_python(self):
        with open(AGGREGATE_SCRIPT, 'r') as f:
            content = f.read()
        # Check for basic Python constructs expected in the script
        assert 'import json' in content, "Script should import json module"
        assert 'import csv' in content or 'csv' in content, "Script should use csv module"
        assert 'def aggregate' in content or 'aggregate' in content, "Script should have aggregate function"


class TestInputFiles:
    """Test that input JSON files exist and have expected structure."""

    def test_input_directory_has_json_files(self):
        json_files = [f for f in os.listdir(INPUT_DIR) if f.endswith('.json')]
        assert len(json_files) > 0, f"No JSON files found in {INPUT_DIR}"

    def test_input_has_exactly_912_json_files(self):
        json_files = [f for f in os.listdir(INPUT_DIR) if f.endswith('.json')]
        assert len(json_files) == 912, f"Expected 912 JSON files in {INPUT_DIR}, found {len(json_files)}"

    def test_input_files_follow_naming_convention(self):
        """Check that files follow {device_id}_{timestamp}.json pattern."""
        json_files = [f for f in os.listdir(INPUT_DIR) if f.endswith('.json')]
        # At least check that files have underscore separating device_id and timestamp
        for fname in json_files[:10]:  # Sample first 10
            name_without_ext = fname[:-5]  # Remove .json
            assert '_' in name_without_ext, f"File {fname} doesn't follow expected naming pattern"

    def test_sample_input_files_have_valid_json(self):
        """Verify that input files contain valid JSON."""
        json_files = [f for f in os.listdir(INPUT_DIR) if f.endswith('.json')]
        # Test a sample of files
        sample_size = min(20, len(json_files))
        for fname in json_files[:sample_size]:
            fpath = os.path.join(INPUT_DIR, fname)
            try:
                with open(fpath, 'rb') as f:
                    content = f.read()
                # Handle potential BOM
                if content.startswith(b'\xef\xbb\xbf'):
                    content = content[3:]
                json.loads(content.decode('utf-8'))
            except json.JSONDecodeError as e:
                pytest.fail(f"File {fname} contains invalid JSON: {e}")

    def test_sample_input_files_have_expected_schema(self):
        """Verify that input files have the expected JSON schema."""
        json_files = [f for f in os.listdir(INPUT_DIR) if f.endswith('.json')]
        required_fields = {'device_id', 'timestamp', 'readings', 'firmware', 'location'}
        required_readings = {'temp', 'humidity', 'voltage'}

        sample_size = min(20, len(json_files))
        for fname in json_files[:sample_size]:
            fpath = os.path.join(INPUT_DIR, fname)
            with open(fpath, 'rb') as f:
                content = f.read()
            # Handle potential BOM
            if content.startswith(b'\xef\xbb\xbf'):
                content = content[3:]
            data = json.loads(content.decode('utf-8'))

            # Check top-level fields
            for field in required_fields:
                assert field in data, f"File {fname} missing required field: {field}"

            # Check readings sub-fields
            assert isinstance(data['readings'], dict), f"File {fname}: 'readings' should be a dict"
            for reading in required_readings:
                assert reading in data['readings'], f"File {fname} missing reading: {reading}"


class TestOutputFile:
    """Test that the output CSV exists with expected characteristics."""

    def test_output_csv_exists(self):
        assert os.path.isfile(OUTPUT_CSV), f"Output file {OUTPUT_CSV} does not exist"

    def test_output_csv_is_readable(self):
        assert os.access(OUTPUT_CSV, os.R_OK), f"Output file {OUTPUT_CSV} is not readable"

    def test_output_csv_has_847_data_rows(self):
        """The buggy script produces 847 data rows."""
        with open(OUTPUT_CSV, 'r') as f:
            reader = csv.reader(f)
            rows = list(reader)

        # First row should be header
        assert len(rows) > 1, "Output CSV should have header and data rows"
        data_rows = len(rows) - 1  # Subtract header
        assert data_rows == 847, f"Expected 847 data rows in output CSV, found {data_rows}"

    def test_output_csv_has_expected_columns(self):
        """Verify CSV has the expected column headers."""
        expected_columns = {'device_id', 'timestamp', 'temp', 'humidity', 'voltage', 'firmware', 'location'}

        with open(OUTPUT_CSV, 'r') as f:
            reader = csv.reader(f)
            header = next(reader)

        header_set = set(header)
        assert header_set == expected_columns, f"Expected columns {expected_columns}, found {header_set}"

    def test_output_csv_is_valid_csv(self):
        """Verify the output is a valid, parseable CSV."""
        with open(OUTPUT_CSV, 'r') as f:
            reader = csv.DictReader(f)
            try:
                rows = list(reader)
                assert len(rows) > 0, "CSV should have data rows"
            except csv.Error as e:
                pytest.fail(f"Output CSV is not valid: {e}")


class TestPythonEnvironment:
    """Test that required Python environment is available."""

    def test_python3_available(self):
        result = subprocess.run(['python3', '--version'], capture_output=True, text=True)
        assert result.returncode == 0, "Python 3 is not available"
        assert 'Python 3' in result.stdout, f"Expected Python 3, got: {result.stdout}"

    def test_python_version_is_3_11_or_higher(self):
        result = subprocess.run(['python3', '-c', 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")'], 
                              capture_output=True, text=True)
        assert result.returncode == 0, "Failed to get Python version"
        version = result.stdout.strip()
        major, minor = map(int, version.split('.'))
        assert (major, minor) >= (3, 11), f"Expected Python 3.11+, got {version}"

    def test_pandas_available(self):
        result = subprocess.run(['python3', '-c', 'import pandas'], capture_output=True, text=True)
        assert result.returncode == 0, f"pandas module not available: {result.stderr}"

    def test_json_stdlib_available(self):
        result = subprocess.run(['python3', '-c', 'import json'], capture_output=True, text=True)
        assert result.returncode == 0, f"json module not available: {result.stderr}"

    def test_csv_stdlib_available(self):
        result = subprocess.run(['python3', '-c', 'import csv'], capture_output=True, text=True)
        assert result.returncode == 0, f"csv module not available: {result.stderr}"


class TestBugConditionsPresent:
    """Test that the conditions for the three bugs are present in the input data."""

    def test_some_devices_have_multiple_reports(self):
        """Verify that some devices sent multiple reports (condition for bug 1)."""
        json_files = [f for f in os.listdir(INPUT_DIR) if f.endswith('.json')]
        device_counts = {}

        for fname in json_files:
            # Extract device_id from filename pattern {device_id}_{timestamp}.json
            parts = fname[:-5].rsplit('_', 1)  # Remove .json and split on last underscore
            if len(parts) >= 1:
                device_id = parts[0]
                device_counts[device_id] = device_counts.get(device_id, 0) + 1

        # Check if any device has multiple reports
        multi_report_devices = [d for d, c in device_counts.items() if c > 1]
        assert len(multi_report_devices) > 0, "Expected some devices to have multiple reports"

    def test_some_files_have_millisecond_timestamps(self):
        """Verify that some files have timestamps with milliseconds (condition for bug 2)."""
        json_files = [f for f in os.listdir(INPUT_DIR) if f.endswith('.json')]
        files_with_ms = 0

        for fname in json_files:
            fpath = os.path.join(INPUT_DIR, fname)
            try:
                with open(fpath, 'rb') as f:
                    content = f.read()
                if content.startswith(b'\xef\xbb\xbf'):
                    content = content[3:]
                data = json.loads(content.decode('utf-8'))
                ts = data.get('timestamp', '')
                # Check for milliseconds pattern (has a dot followed by digits before end or timezone)
                if '.' in ts and ts.split('.')[1][:1].isdigit():
                    files_with_ms += 1
            except (json.JSONDecodeError, KeyError):
                continue

        assert files_with_ms > 0, "Expected some files to have millisecond timestamps"

    def test_some_files_have_bom(self):
        """Verify that some files have UTF-8 BOM (condition for bug 3)."""
        json_files = [f for f in os.listdir(INPUT_DIR) if f.endswith('.json')]
        files_with_bom = 0

        for fname in json_files:
            fpath = os.path.join(INPUT_DIR, fname)
            with open(fpath, 'rb') as f:
                first_bytes = f.read(3)
            if first_bytes == b'\xef\xbb\xbf':
                files_with_bom += 1

        assert files_with_bom > 0, "Expected some files to have UTF-8 BOM"


class TestScriptCanRun:
    """Test that the aggregate script can be executed."""

    def test_script_runs_without_crash(self):
        """Verify the script runs and exits cleanly (even with bugs)."""
        result = subprocess.run(
            ['python3', AGGREGATE_SCRIPT],
            capture_output=True,
            text=True,
            cwd=INGEST_DIR
        )
        assert result.returncode == 0, f"Script failed with return code {result.returncode}: {result.stderr}"
