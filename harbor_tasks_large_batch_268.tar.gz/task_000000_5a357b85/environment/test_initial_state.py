# test_initial_state.py
"""
Tests to validate the initial state of the operating system/filesystem
before the student performs the task of adding Turkish locale to the dashboard.
"""

import json
import os
import stat
import subprocess
import pytest


class TestDashboardDirectoryStructure:
    """Test that the dashboard directory structure exists."""

    def test_dashboard_directory_exists(self):
        """The /home/user/dashboard directory must exist."""
        path = "/home/user/dashboard"
        assert os.path.isdir(path), f"Directory {path} does not exist"

    def test_locales_directory_exists(self):
        """The /home/user/dashboard/locales directory must exist."""
        path = "/home/user/dashboard/locales"
        assert os.path.isdir(path), f"Directory {path} does not exist"

    def test_locales_directory_is_writable(self):
        """The /home/user/dashboard/locales directory must be writable."""
        path = "/home/user/dashboard/locales"
        assert os.access(path, os.W_OK), f"Directory {path} is not writable"


class TestCheckServicesScript:
    """Test that the check_services.py script exists and is executable."""

    def test_check_services_script_exists(self):
        """The check_services.py script must exist."""
        path = "/home/user/dashboard/check_services.py"
        assert os.path.isfile(path), f"Script {path} does not exist"

    def test_check_services_script_is_executable(self):
        """The check_services.py script must be executable."""
        path = "/home/user/dashboard/check_services.py"
        assert os.access(path, os.X_OK), f"Script {path} is not executable"

    def test_check_services_script_is_readable(self):
        """The check_services.py script must be readable."""
        path = "/home/user/dashboard/check_services.py"
        assert os.access(path, os.R_OK), f"Script {path} is not readable"


class TestExistingLocaleFiles:
    """Test that the existing locale files (en, de, es) exist and are valid."""

    @pytest.mark.parametrize("locale", ["en", "de", "es"])
    def test_locale_file_exists(self, locale):
        """Each existing locale file must exist."""
        path = f"/home/user/dashboard/locales/{locale}.json"
        assert os.path.isfile(path), f"Locale file {path} does not exist"

    @pytest.mark.parametrize("locale", ["en", "de", "es"])
    def test_locale_file_is_valid_json(self, locale):
        """Each existing locale file must be valid JSON."""
        path = f"/home/user/dashboard/locales/{locale}.json"
        try:
            with open(path, 'r', encoding='utf-8') as f:
                json.load(f)
        except json.JSONDecodeError as e:
            pytest.fail(f"Locale file {path} is not valid JSON: {e}")

    @pytest.mark.parametrize("locale", ["en", "de", "es"])
    def test_locale_file_has_required_keys(self, locale):
        """Each existing locale file must have all required keys."""
        path = f"/home/user/dashboard/locales/{locale}.json"
        required_keys = {"status_ok", "status_warn", "status_crit", "last_check"}
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        actual_keys = set(data.keys())
        assert actual_keys == required_keys, (
            f"Locale file {path} has keys {actual_keys}, expected {required_keys}"
        )


class TestEnglishLocaleContent:
    """Test the specific content of the English locale file."""

    def test_en_json_content(self):
        """The en.json file must have the expected content."""
        path = "/home/user/dashboard/locales/en.json"
        expected = {
            "status_ok": "All services operational",
            "status_warn": "Some services degraded",
            "status_crit": "Critical services down",
            "last_check": "Last checked"
        }
        with open(path, 'r', encoding='utf-8') as f:
            actual = json.load(f)
        assert actual == expected, f"en.json content mismatch. Expected: {expected}, Got: {actual}"


class TestGermanLocaleContent:
    """Test the specific content of the German locale file."""

    def test_de_json_content(self):
        """The de.json file must have the expected content."""
        path = "/home/user/dashboard/locales/de.json"
        expected = {
            "status_ok": "Alle Dienste betriebsbereit",
            "status_warn": "Einige Dienste beeinträchtigt",
            "status_crit": "Kritische Dienste ausgefallen",
            "last_check": "Zuletzt geprüft"
        }
        with open(path, 'r', encoding='utf-8') as f:
            actual = json.load(f)
        assert actual == expected, f"de.json content mismatch. Expected: {expected}, Got: {actual}"


class TestSpanishLocaleContent:
    """Test the specific content of the Spanish locale file."""

    def test_es_json_content(self):
        """The es.json file must have the expected content."""
        path = "/home/user/dashboard/locales/es.json"
        expected = {
            "status_ok": "Todos los servicios operativos",
            "status_warn": "Algunos servicios degradados",
            "status_crit": "Servicios críticos caídos",
            "last_check": "Última comprobación"
        }
        with open(path, 'r', encoding='utf-8') as f:
            actual = json.load(f)
        assert actual == expected, f"es.json content mismatch. Expected: {expected}, Got: {actual}"


class TestTurkishLocaleDoesNotExist:
    """Test that the Turkish locale file does not exist yet (initial state)."""

    def test_tr_json_does_not_exist(self):
        """The tr.json file should NOT exist in the initial state."""
        path = "/home/user/dashboard/locales/tr.json"
        assert not os.path.exists(path), (
            f"Turkish locale file {path} already exists - this is the initial state test, "
            "the file should not exist yet"
        )


class TestPythonAvailability:
    """Test that Python 3.11+ is available."""

    def test_python3_available(self):
        """Python 3 must be available."""
        result = subprocess.run(
            ["python3", "--version"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "Python 3 is not available"

    def test_python3_version_sufficient(self):
        """Python version must be 3.11 or higher."""
        result = subprocess.run(
            ["python3", "-c", "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "Could not determine Python version"
        version = result.stdout.strip()
        major, minor = map(int, version.split('.'))
        assert (major, minor) >= (3, 11), f"Python version {version} is less than 3.11"


class TestScriptFunctionality:
    """Test that the check_services.py script works with existing locales."""

    @pytest.mark.parametrize("locale", ["en", "de", "es"])
    def test_script_works_with_existing_locale(self, locale):
        """The script should work with existing locale files."""
        result = subprocess.run(
            ["python3", "/home/user/dashboard/check_services.py", "--lang", locale],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"Script failed with --lang {locale}. "
            f"stdout: {result.stdout}, stderr: {result.stderr}"
        )
