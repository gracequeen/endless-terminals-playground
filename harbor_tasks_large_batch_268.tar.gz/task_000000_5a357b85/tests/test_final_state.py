# test_final_state.py
"""
Tests to validate the final state of the operating system/filesystem
after the student has completed the task of adding Turkish locale to the dashboard.
"""

import json
import os
import subprocess
import pytest


class TestTurkishLocaleFileExists:
    """Test that the Turkish locale file exists and is valid."""

    def test_tr_json_exists(self):
        """The tr.json file must exist."""
        path = "/home/user/dashboard/locales/tr.json"
        assert os.path.isfile(path), f"Turkish locale file {path} does not exist"

    def test_tr_json_is_readable(self):
        """The tr.json file must be readable."""
        path = "/home/user/dashboard/locales/tr.json"
        assert os.access(path, os.R_OK), f"Turkish locale file {path} is not readable"


class TestTurkishLocaleIsValidJson:
    """Test that tr.json is valid JSON."""

    def test_tr_json_parseable(self):
        """The tr.json file must be parseable as valid JSON."""
        path = "/home/user/dashboard/locales/tr.json"
        try:
            with open(path, 'r', encoding='utf-8') as f:
                json.load(f)
        except json.JSONDecodeError as e:
            pytest.fail(f"Turkish locale file {path} is not valid JSON: {e}")

    def test_tr_json_parseable_via_subprocess(self):
        """Anti-shortcut: tr.json must be parseable via subprocess call."""
        result = subprocess.run(
            ["python3", "-c", "import json; json.load(open('/home/user/dashboard/locales/tr.json'))"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"tr.json is not parseable as JSON via subprocess. stderr: {result.stderr}"
        )


class TestTurkishLocaleHasRequiredKeys:
    """Test that tr.json has exactly the required keys."""

    def test_tr_json_has_all_required_keys(self):
        """The tr.json file must have all four required keys."""
        path = "/home/user/dashboard/locales/tr.json"
        required_keys = {"status_ok", "status_warn", "status_crit", "last_check"}
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        actual_keys = set(data.keys())
        missing_keys = required_keys - actual_keys
        assert not missing_keys, f"tr.json is missing required keys: {missing_keys}"

    def test_tr_json_has_exactly_required_keys(self):
        """The tr.json file must have exactly the four required keys (no extra keys)."""
        path = "/home/user/dashboard/locales/tr.json"
        required_keys = {"status_ok", "status_warn", "status_crit", "last_check"}
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        actual_keys = set(data.keys())
        assert actual_keys == required_keys, (
            f"tr.json has keys {actual_keys}, expected exactly {required_keys}"
        )

    def test_tr_json_keys_via_subprocess(self):
        """Anti-shortcut: verify keys via subprocess call."""
        result = subprocess.run(
            ["python3", "-c", 
             "import json; d=json.load(open('/home/user/dashboard/locales/tr.json')); "
             "assert set(d.keys()) == {'status_ok','status_warn','status_crit','last_check'}"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"tr.json does not have exactly the required keys. stderr: {result.stderr}"
        )


class TestTurkishLocaleValuesAreTurkish:
    """Test that tr.json values are Turkish translations."""

    def test_tr_json_values_are_strings(self):
        """All values in tr.json must be strings."""
        path = "/home/user/dashboard/locales/tr.json"
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        for key, value in data.items():
            assert isinstance(value, str), f"Value for key '{key}' is not a string: {type(value)}"

    def test_tr_json_values_are_non_empty(self):
        """All values in tr.json must be non-empty strings."""
        path = "/home/user/dashboard/locales/tr.json"
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        for key, value in data.items():
            assert value.strip(), f"Value for key '{key}' is empty or whitespace-only"

    def test_status_ok_is_turkish(self):
        """The status_ok value should be a Turkish translation."""
        path = "/home/user/dashboard/locales/tr.json"
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        value = data["status_ok"].lower()
        # Check for common Turkish words/patterns for "all services operational"
        turkish_indicators = ["tüm", "hizmet", "servis", "çalış", "operasyonel", "aktif"]
        has_turkish = any(indicator in value for indicator in turkish_indicators)
        assert has_turkish, (
            f"status_ok value '{data['status_ok']}' does not appear to be Turkish. "
            "Expected something like 'Tüm hizmetler çalışıyor' or 'Tüm servisler operasyonel'"
        )

    def test_status_warn_is_turkish(self):
        """The status_warn value should be a Turkish translation."""
        path = "/home/user/dashboard/locales/tr.json"
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        value = data["status_warn"].lower()
        # Check for common Turkish words/patterns for "some services degraded"
        turkish_indicators = ["bazı", "hizmet", "servis", "düşük", "sorunlu", "performans", "bozuk"]
        has_turkish = any(indicator in value for indicator in turkish_indicators)
        assert has_turkish, (
            f"status_warn value '{data['status_warn']}' does not appear to be Turkish. "
            "Expected something like 'Bazı hizmetler düşük performansta' or 'Bazı servisler sorunlu'"
        )

    def test_status_crit_is_turkish(self):
        """The status_crit value should be a Turkish translation."""
        path = "/home/user/dashboard/locales/tr.json"
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        value = data["status_crit"].lower()
        # Check for common Turkish words/patterns for "critical services down"
        turkish_indicators = ["kritik", "hizmet", "servis", "çalışmıyor", "çöktü", "kapalı", "down"]
        has_turkish = any(indicator in value for indicator in turkish_indicators)
        assert has_turkish, (
            f"status_crit value '{data['status_crit']}' does not appear to be Turkish. "
            "Expected something like 'Kritik hizmetler çalışmıyor' or 'Kritik servisler çöktü'"
        )

    def test_last_check_is_turkish(self):
        """The last_check value should be a Turkish translation."""
        path = "/home/user/dashboard/locales/tr.json"
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        value = data["last_check"].lower()
        # Check for common Turkish words/patterns for "last checked"
        turkish_indicators = ["son", "kontrol", "denetim", "kontrol edildi"]
        has_turkish = any(indicator in value for indicator in turkish_indicators)
        assert has_turkish, (
            f"last_check value '{data['last_check']}' does not appear to be Turkish. "
            "Expected something like 'Son kontrol'"
        )


class TestScriptWorksWithTurkishLocale:
    """Test that the check_services.py script works with the Turkish locale."""

    def test_script_exits_zero_with_turkish(self):
        """The script should exit with code 0 when using --lang tr."""
        result = subprocess.run(
            ["python3", "/home/user/dashboard/check_services.py", "--lang", "tr"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"Script failed with --lang tr (exit code {result.returncode}). "
            f"stdout: {result.stdout}, stderr: {result.stderr}"
        )

    def test_script_output_contains_turkish_string(self):
        """The script output should contain at least one Turkish string from tr.json."""
        # First, get the Turkish strings from tr.json
        with open("/home/user/dashboard/locales/tr.json", 'r', encoding='utf-8') as f:
            tr_data = json.load(f)

        # Run the script
        result = subprocess.run(
            ["python3", "/home/user/dashboard/check_services.py", "--lang", "tr"],
            capture_output=True,
            text=True
        )

        output = result.stdout + result.stderr

        # Check if any of the Turkish strings appear in the output
        found_turkish = any(value in output for value in tr_data.values())
        assert found_turkish, (
            f"Script output does not contain any Turkish strings from tr.json. "
            f"Expected one of: {list(tr_data.values())}. "
            f"Got output: {output}"
        )


class TestExistingLocalesUnchanged:
    """Test that existing locale files (en, de, es) are unchanged."""

    def test_en_json_unchanged(self):
        """The en.json file must be unchanged."""
        path = "/home/user/dashboard/locales/en.json"
        expected = {
            "status_ok": "All services operational",
            "status_warn": "Some services degraded",
            "status_crit": "Critical services down",
            "last_check": "Last checked"
        }
        with open(path, 'r', encoding='utf-8') as f:
            actual = json.load(f)
        assert actual == expected, f"en.json has been modified. Expected: {expected}, Got: {actual}"

    def test_de_json_unchanged(self):
        """The de.json file must be unchanged."""
        path = "/home/user/dashboard/locales/de.json"
        expected = {
            "status_ok": "Alle Dienste betriebsbereit",
            "status_warn": "Einige Dienste beeinträchtigt",
            "status_crit": "Kritische Dienste ausgefallen",
            "last_check": "Zuletzt geprüft"
        }
        with open(path, 'r', encoding='utf-8') as f:
            actual = json.load(f)
        assert actual == expected, f"de.json has been modified. Expected: {expected}, Got: {actual}"

    def test_es_json_unchanged(self):
        """The es.json file must be unchanged."""
        path = "/home/user/dashboard/locales/es.json"
        expected = {
            "status_ok": "Todos los servicios operativos",
            "status_warn": "Algunos servicios degradados",
            "status_crit": "Servicios críticos caídos",
            "last_check": "Última comprobación"
        }
        with open(path, 'r', encoding='utf-8') as f:
            actual = json.load(f)
        assert actual == expected, f"es.json has been modified. Expected: {expected}, Got: {actual}"


class TestCheckServicesScriptUnchanged:
    """Test that check_services.py script still exists and is executable."""

    def test_check_services_script_exists(self):
        """The check_services.py script must still exist."""
        path = "/home/user/dashboard/check_services.py"
        assert os.path.isfile(path), f"Script {path} does not exist"

    def test_check_services_script_is_executable(self):
        """The check_services.py script must still be executable."""
        path = "/home/user/dashboard/check_services.py"
        assert os.access(path, os.X_OK), f"Script {path} is not executable"

    @pytest.mark.parametrize("locale", ["en", "de", "es"])
    def test_script_still_works_with_existing_locales(self, locale):
        """The script should still work with existing locale files."""
        result = subprocess.run(
            ["python3", "/home/user/dashboard/check_services.py", "--lang", locale],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"Script no longer works with --lang {locale}. "
            f"stdout: {result.stdout}, stderr: {result.stderr}"
        )
