# test_initial_state.py
"""
Tests to validate the initial state of the system before the student fixes the healthcheck issue.
"""

import os
import subprocess
import pytest
import re


HOME = "/home/user"
BIN_DIR = f"{HOME}/bin"
CONFIG_DIR = f"{HOME}/.config"
MONITORS_DIR = f"{HOME}/monitors"
HEALTHCHECK_SCRIPT = f"{BIN_DIR}/healthcheck.sh"
MONITOR_CONF = f"{CONFIG_DIR}/monitor.conf"
OVERRIDE_CONF = f"{CONFIG_DIR}/monitor.conf.d/override.conf"
HEARTBEAT_FILE = f"{MONITORS_DIR}/heartbeat.touch"
LOG_FILE = "/var/log/healthcheck.log"


class TestHealthcheckScriptExists:
    """Test that the healthcheck script exists and is properly configured."""

    def test_healthcheck_script_exists(self):
        """Verify /home/user/bin/healthcheck.sh exists."""
        assert os.path.isfile(HEALTHCHECK_SCRIPT), \
            f"Healthcheck script not found at {HEALTHCHECK_SCRIPT}"

    def test_healthcheck_script_is_executable(self):
        """Verify the healthcheck script is executable."""
        assert os.access(HEALTHCHECK_SCRIPT, os.X_OK), \
            f"Healthcheck script at {HEALTHCHECK_SCRIPT} is not executable"

    def test_healthcheck_script_is_bash(self):
        """Verify the healthcheck script is a bash script."""
        with open(HEALTHCHECK_SCRIPT, 'r') as f:
            content = f.read()
        assert content.startswith('#!/bin/bash') or content.startswith('#!/usr/bin/env bash'), \
            f"Healthcheck script does not appear to be a bash script"

    def test_healthcheck_sources_config(self):
        """Verify the healthcheck script sources monitor.conf."""
        with open(HEALTHCHECK_SCRIPT, 'r') as f:
            content = f.read()
        # Check for sourcing of monitor.conf
        assert 'monitor.conf' in content or '.config/monitor.conf' in content, \
            "Healthcheck script does not appear to source monitor.conf"


class TestMonitorConfigExists:
    """Test that the monitor configuration files exist."""

    def test_config_dir_exists(self):
        """Verify /home/user/.config directory exists."""
        assert os.path.isdir(CONFIG_DIR), \
            f"Config directory not found at {CONFIG_DIR}"

    def test_monitor_conf_exists(self):
        """Verify /home/user/.config/monitor.conf exists."""
        assert os.path.isfile(MONITOR_CONF), \
            f"Monitor config not found at {MONITOR_CONF}"

    def test_monitor_conf_contains_monitor_dir(self):
        """Verify monitor.conf contains MONITOR_DIR setting."""
        with open(MONITOR_CONF, 'r') as f:
            content = f.read()
        assert 'MONITOR_DIR=' in content, \
            "monitor.conf does not contain MONITOR_DIR setting"
        assert '/home/user/monitors' in content, \
            "monitor.conf MONITOR_DIR does not point to /home/user/monitors"

    def test_monitor_conf_contains_heartbeat_file(self):
        """Verify monitor.conf contains HEARTBEAT_FILE setting."""
        with open(MONITOR_CONF, 'r') as f:
            content = f.read()
        assert 'HEARTBEAT_FILE=' in content, \
            "monitor.conf does not contain HEARTBEAT_FILE setting"

    def test_monitor_conf_sources_override(self):
        """Verify monitor.conf has the override sourcing mechanism."""
        with open(MONITOR_CONF, 'r') as f:
            content = f.read()
        assert 'override.conf' in content, \
            "monitor.conf does not contain override.conf sourcing mechanism"


class TestOverrideConfigExists:
    """Test that the problematic override config exists."""

    def test_override_conf_dir_exists(self):
        """Verify /home/user/.config/monitor.conf.d directory exists."""
        override_dir = f"{CONFIG_DIR}/monitor.conf.d"
        assert os.path.isdir(override_dir), \
            f"Override config directory not found at {override_dir}"

    def test_override_conf_exists(self):
        """Verify /home/user/.config/monitor.conf.d/override.conf exists."""
        assert os.path.isfile(OVERRIDE_CONF), \
            f"Override config not found at {OVERRIDE_CONF}"

    def test_override_conf_contains_bug(self):
        """Verify override.conf contains the problematic date-based MONITOR_DIR."""
        with open(OVERRIDE_CONF, 'r') as f:
            content = f.read()
        # The bug is that MONITOR_DIR uses $(date +%S) making it time-dependent
        assert 'MONITOR_DIR=' in content, \
            "override.conf does not contain MONITOR_DIR setting"
        assert 'date' in content or '%S' in content, \
            "override.conf does not contain the expected date-based bug pattern"


class TestMonitorsDirectory:
    """Test that the monitors directory structure exists."""

    def test_monitors_dir_exists(self):
        """Verify /home/user/monitors directory exists."""
        assert os.path.isdir(MONITORS_DIR), \
            f"Monitors directory not found at {MONITORS_DIR}"

    def test_monitors_dir_is_writable(self):
        """Verify /home/user/monitors is writable."""
        assert os.access(MONITORS_DIR, os.W_OK), \
            f"Monitors directory at {MONITORS_DIR} is not writable"

    def test_heartbeat_file_exists(self):
        """Verify /home/user/monitors/heartbeat.touch exists."""
        assert os.path.isfile(HEARTBEAT_FILE), \
            f"Heartbeat file not found at {HEARTBEAT_FILE}"

    def test_leftover_monitors_dirs_exist(self):
        """Verify some leftover monitors-XX directories exist from previous runs."""
        parent_dir = HOME
        pattern = re.compile(r'^monitors-\d{2}$')
        leftover_dirs = [d for d in os.listdir(parent_dir) 
                        if pattern.match(d) and os.path.isdir(os.path.join(parent_dir, d))]
        assert len(leftover_dirs) > 0, \
            "No leftover monitors-XX directories found - expected some from previous failed runs"


class TestLogFile:
    """Test that the log file exists and shows the flapping behavior."""

    def test_log_file_exists(self):
        """Verify /var/log/healthcheck.log exists."""
        assert os.path.isfile(LOG_FILE), \
            f"Log file not found at {LOG_FILE}"

    def test_log_file_is_readable(self):
        """Verify the log file is readable."""
        assert os.access(LOG_FILE, os.R_OK), \
            f"Log file at {LOG_FILE} is not readable"

    def test_log_shows_failures(self):
        """Verify the log shows failure messages about non-existent directories."""
        with open(LOG_FILE, 'r') as f:
            content = f.read()
        # Check for error messages about missing directories
        assert 'does not exist' in content.lower() or 'monitors-' in content, \
            "Log file does not show expected failure messages about missing directories"


class TestRequiredTools:
    """Test that required tools are available."""

    def test_bash_available(self):
        """Verify bash is available."""
        result = subprocess.run(['which', 'bash'], capture_output=True)
        assert result.returncode == 0, "bash is not available"

    def test_touch_available(self):
        """Verify touch command is available."""
        result = subprocess.run(['which', 'touch'], capture_output=True)
        assert result.returncode == 0, "touch command is not available"

    def test_date_available(self):
        """Verify date command is available."""
        result = subprocess.run(['which', 'date'], capture_output=True)
        assert result.returncode == 0, "date command is not available"

    def test_grep_available(self):
        """Verify grep is available."""
        result = subprocess.run(['which', 'grep'], capture_output=True)
        assert result.returncode == 0, "grep is not available"

    def test_cat_available(self):
        """Verify cat is available."""
        result = subprocess.run(['which', 'cat'], capture_output=True)
        assert result.returncode == 0, "cat is not available"


class TestHealthcheckBehavior:
    """Test that the healthcheck exhibits the flapping behavior."""

    def test_healthcheck_is_flapping(self):
        """Verify that running healthcheck multiple times shows inconsistent results."""
        results = []
        for _ in range(5):
            result = subprocess.run([HEALTHCHECK_SCRIPT], capture_output=True)
            results.append(result.returncode)

        # We expect at least some variation - not all 0s and not all 1s
        # But since timing is involved, we just verify the script runs
        # The flapping nature is evidenced by the log file and leftover directories
        assert len(results) == 5, "Could not run healthcheck script 5 times"


class TestWritePermissions:
    """Test that the user has proper write permissions."""

    def test_home_writable(self):
        """Verify /home/user is writable."""
        assert os.access(HOME, os.W_OK), \
            f"Home directory {HOME} is not writable"

    def test_config_dir_writable(self):
        """Verify /home/user/.config is writable."""
        assert os.access(CONFIG_DIR, os.W_OK), \
            f"Config directory {CONFIG_DIR} is not writable"

    def test_override_conf_writable(self):
        """Verify override.conf is writable (so it can be fixed)."""
        assert os.access(OVERRIDE_CONF, os.W_OK), \
            f"Override config {OVERRIDE_CONF} is not writable"
