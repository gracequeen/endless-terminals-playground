# test_final_state.py
"""
Tests to validate the final state of the system after the student fixes the healthcheck issue.
"""

import os
import subprocess
import pytest
import re
import time


HOME = "/home/user"
BIN_DIR = f"{HOME}/bin"
CONFIG_DIR = f"{HOME}/.config"
MONITORS_DIR = f"{HOME}/monitors"
HEALTHCHECK_SCRIPT = f"{BIN_DIR}/healthcheck.sh"
MONITOR_CONF = f"{CONFIG_DIR}/monitor.conf"
OVERRIDE_CONF = f"{CONFIG_DIR}/monitor.conf.d/override.conf"
HEARTBEAT_FILE = f"{MONITORS_DIR}/heartbeat.touch"


class TestHealthcheckReliability:
    """Test that the healthcheck script now runs reliably."""

    def test_healthcheck_exits_zero_ten_times(self):
        """Verify that running healthcheck 10 consecutive times all exit 0."""
        failures = []
        for i in range(10):
            result = subprocess.run(
                [HEALTHCHECK_SCRIPT],
                capture_output=True,
                text=True
            )
            if result.returncode != 0:
                failures.append({
                    'run': i + 1,
                    'returncode': result.returncode,
                    'stdout': result.stdout,
                    'stderr': result.stderr
                })
            # Small delay to ensure we cross second boundaries
            time.sleep(0.15)

        assert len(failures) == 0, \
            f"Healthcheck failed {len(failures)} out of 10 runs. Failures: {failures}"

    def test_healthcheck_with_sleep_exits_zero(self):
        """Verify healthcheck exits 0 reliably with 1 second delays (as per task requirement)."""
        results = []
        for i in range(10):
            result = subprocess.run(
                [HEALTHCHECK_SCRIPT],
                capture_output=True,
                text=True
            )
            results.append(result.returncode)
            if i < 9:  # Don't sleep after the last iteration
                time.sleep(1)

        non_zero = [r for r in results if r != 0]
        assert len(non_zero) == 0, \
            f"Expected all 10 runs to exit 0, but got exit codes: {results}"


class TestHeartbeatFileUpdated:
    """Test that the heartbeat file gets updated on each run."""

    def test_heartbeat_file_exists(self):
        """Verify /home/user/monitors/heartbeat.touch exists."""
        assert os.path.isfile(HEARTBEAT_FILE), \
            f"Heartbeat file not found at {HEARTBEAT_FILE}"

    def test_heartbeat_mtime_updates(self):
        """Verify heartbeat.touch mtime changes on each healthcheck run."""
        # Get initial mtime
        initial_mtime = os.path.getmtime(HEARTBEAT_FILE)

        # Wait a moment to ensure time difference is detectable
        time.sleep(0.1)

        # Run healthcheck
        result = subprocess.run([HEALTHCHECK_SCRIPT], capture_output=True)
        assert result.returncode == 0, \
            f"Healthcheck failed with return code {result.returncode}"

        # Check mtime changed
        new_mtime = os.path.getmtime(HEARTBEAT_FILE)
        assert new_mtime >= initial_mtime, \
            f"Heartbeat file mtime did not update. Initial: {initial_mtime}, After: {new_mtime}"

    def test_heartbeat_in_correct_directory(self):
        """Verify heartbeat file is in /home/user/monitors/, not monitors-XX."""
        # Run healthcheck
        result = subprocess.run([HEALTHCHECK_SCRIPT], capture_output=True)
        assert result.returncode == 0, "Healthcheck should exit 0"

        # Verify the correct heartbeat file exists and was recently modified
        assert os.path.isfile(HEARTBEAT_FILE), \
            f"Heartbeat file should be at {HEARTBEAT_FILE}"

        # Check it was modified within the last 5 seconds
        mtime = os.path.getmtime(HEARTBEAT_FILE)
        current_time = time.time()
        assert current_time - mtime < 5, \
            "Heartbeat file in /home/user/monitors/ was not recently updated"


class TestScriptIntegrity:
    """Test that the healthcheck script core logic remains unchanged."""

    def test_healthcheck_script_exists(self):
        """Verify /home/user/bin/healthcheck.sh still exists."""
        assert os.path.isfile(HEALTHCHECK_SCRIPT), \
            f"Healthcheck script not found at {HEALTHCHECK_SCRIPT}"

    def test_healthcheck_still_sources_config(self):
        """Verify the healthcheck script still sources monitor.conf."""
        with open(HEALTHCHECK_SCRIPT, 'r') as f:
            content = f.read()
        assert 'monitor.conf' in content, \
            "Healthcheck script should still source monitor.conf"

    def test_healthcheck_still_checks_directory(self):
        """Verify the healthcheck script still checks if directory exists."""
        with open(HEALTHCHECK_SCRIPT, 'r') as f:
            content = f.read()
        # Should still have directory existence check logic
        assert 'MONITOR_DIR' in content or '-d' in content or 'exist' in content.lower(), \
            "Healthcheck script should still check directory existence"

    def test_healthcheck_still_touches_file(self):
        """Verify the healthcheck script still touches the heartbeat file."""
        with open(HEALTHCHECK_SCRIPT, 'r') as f:
            content = f.read()
        assert 'touch' in content, \
            "Healthcheck script should still touch the heartbeat file"


class TestConfigIntegrity:
    """Test that the base config file remains unchanged."""

    def test_monitor_conf_exists(self):
        """Verify /home/user/.config/monitor.conf still exists."""
        assert os.path.isfile(MONITOR_CONF), \
            f"Monitor config not found at {MONITOR_CONF}"

    def test_monitor_conf_still_has_override_sourcing(self):
        """Verify monitor.conf still has the override sourcing mechanism."""
        with open(MONITOR_CONF, 'r') as f:
            content = f.read()
        assert 'override.conf' in content, \
            "monitor.conf must still contain the override.conf sourcing mechanism"

    def test_monitor_conf_has_base_settings(self):
        """Verify monitor.conf still has the base MONITOR_DIR and HEARTBEAT_FILE settings."""
        with open(MONITOR_CONF, 'r') as f:
            content = f.read()
        assert 'MONITOR_DIR=' in content, \
            "monitor.conf should still have MONITOR_DIR setting"
        assert 'HEARTBEAT_FILE=' in content, \
            "monitor.conf should still have HEARTBEAT_FILE setting"


class TestMonitorsDirectory:
    """Test that the monitors directory still exists."""

    def test_monitors_dir_exists(self):
        """Verify /home/user/monitors directory still exists."""
        assert os.path.isdir(MONITORS_DIR), \
            f"Monitors directory not found at {MONITORS_DIR}"

    def test_monitors_dir_is_writable(self):
        """Verify /home/user/monitors is still writable."""
        assert os.access(MONITORS_DIR, os.W_OK), \
            f"Monitors directory at {MONITORS_DIR} is not writable"


class TestAntiShortcutGuards:
    """Test that the fix was done properly, not via shortcuts."""

    def test_no_new_monitors_xx_directories_created(self):
        """Verify no new monitors-XX directories were created as part of the fix."""
        # This test checks that the fix didn't involve creating all 60 possible directories
        # We allow the pre-existing leftover directories but check that the fix
        # addresses the root cause in the config

        # The real test is that the override.conf no longer has the date-based bug
        if os.path.isfile(OVERRIDE_CONF):
            with open(OVERRIDE_CONF, 'r') as f:
                content = f.read()
            # Check that the problematic date +%S pattern is not present
            assert 'date +%S' not in content and '$(date' not in content.replace(' ', ''), \
                "override.conf should not contain date-based MONITOR_DIR anymore"

    def test_fix_not_in_script_ignoring_errors(self):
        """Verify the fix wasn't done by making the script ignore errors."""
        with open(HEALTHCHECK_SCRIPT, 'r') as f:
            content = f.read()

        # Check script doesn't have "exit 0" at the very end unconditionally
        # or "|| true" patterns that would mask errors
        lines = content.strip().split('\n')

        # The script should still have proper error handling, not just "exit 0" everywhere
        # This is a heuristic check - the script should still check conditions
        assert any('-d' in line or 'exist' in line.lower() or 'if' in line.lower() 
                  for line in lines), \
            "Script should still have directory checking logic"

    def test_override_conf_fixed_properly(self):
        """Verify the override.conf was fixed by removing/fixing the problematic line."""
        if os.path.isfile(OVERRIDE_CONF):
            with open(OVERRIDE_CONF, 'r') as f:
                content = f.read()

            # The fix should either:
            # 1. Remove the MONITOR_DIR line entirely
            # 2. Comment it out
            # 3. Fix it to point to the correct static path
            # 4. Remove the date command usage

            # Check that if MONITOR_DIR is set, it doesn't use date
            if 'MONITOR_DIR=' in content:
                # Find lines with MONITOR_DIR that aren't commented
                for line in content.split('\n'):
                    stripped = line.strip()
                    if stripped.startswith('#'):
                        continue
                    if 'MONITOR_DIR=' in stripped:
                        assert 'date' not in stripped and '%S' not in stripped, \
                            f"MONITOR_DIR in override.conf still contains date-based value: {stripped}"

    def test_no_monitors_pattern_in_modified_files(self):
        """Verify the fix doesn't involve hardcoding monitors-XX patterns."""
        files_to_check = [HEALTHCHECK_SCRIPT, MONITOR_CONF]
        if os.path.isfile(OVERRIDE_CONF):
            files_to_check.append(OVERRIDE_CONF)

        pattern = re.compile(r'monitors-\d{2}')

        for filepath in files_to_check:
            if os.path.isfile(filepath):
                with open(filepath, 'r') as f:
                    content = f.read()
                matches = pattern.findall(content)
                assert len(matches) == 0, \
                    f"File {filepath} contains hardcoded monitors-XX pattern: {matches}"


class TestRootCauseFix:
    """Test that the root cause was properly addressed."""

    def test_effective_monitor_dir_is_correct(self):
        """Verify that after sourcing configs, MONITOR_DIR resolves to /home/user/monitors."""
        # Create a test script that sources the config and echoes MONITOR_DIR
        test_script = """#!/bin/bash
source /home/user/.config/monitor.conf
echo "$MONITOR_DIR"
"""
        # Run multiple times to ensure it's consistent
        results = set()
        for _ in range(5):
            result = subprocess.run(
                ['bash', '-c', test_script],
                capture_output=True,
                text=True
            )
            results.add(result.stdout.strip())
            time.sleep(0.3)  # Cross second boundaries

        # Should only have one unique result
        assert len(results) == 1, \
            f"MONITOR_DIR resolves to different values at different times: {results}"

        # And that result should be the correct path
        assert MONITORS_DIR in results, \
            f"MONITOR_DIR should resolve to {MONITORS_DIR}, but got: {results}"
