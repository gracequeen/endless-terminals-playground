# test_final_state.py
"""
Tests to validate the final state of the ETL environment after the student
has fixed the permission denied issue and the ETL job runs successfully.
"""

import os
import stat
import grp
import pwd
import subprocess
import pytest


HOME = "/home/user"
ETL_BASE = f"{HOME}/etl"
SCRIPT_PATH = f"{ETL_BASE}/daily_load.sh"
TRANSFORM_PATH = f"{ETL_BASE}/transform.py"
SOURCES_DIR = f"{ETL_BASE}/sources"
STAGING_DIR = f"{ETL_BASE}/staging"
OUTPUT_DIR = f"{ETL_BASE}/output"
WAREHOUSE_DIR = f"{ETL_BASE}/warehouse"
LOGS_DIR = f"{ETL_BASE}/logs"
LOG_FILE = f"{LOGS_DIR}/daily_load.log"
WAREHOUSE_OUTPUT = f"{WAREHOUSE_DIR}/daily_combined.csv"
OUTPUT_COMBINED = f"{OUTPUT_DIR}/combined.csv"


class TestETLScriptRunsSuccessfully:
    """Test that the ETL script now runs successfully."""

    def test_etl_script_exits_zero(self):
        """Running the ETL script should now succeed with exit code 0."""
        result = subprocess.run(
            [SCRIPT_PATH],
            capture_output=True,
            text=True,
            cwd=ETL_BASE
        )
        assert result.returncode == 0, \
            f"ETL script failed with exit code {result.returncode}.\nStdout: {result.stdout}\nStderr: {result.stderr}"


class TestWarehouseOutput:
    """Test the warehouse output file exists and has correct properties."""

    def test_warehouse_output_exists(self):
        """The daily_combined.csv should exist in warehouse after successful run."""
        # First run the script to ensure it's been executed
        subprocess.run([SCRIPT_PATH], capture_output=True, cwd=ETL_BASE)
        assert os.path.isfile(WAREHOUSE_OUTPUT), \
            f"Warehouse output file {WAREHOUSE_OUTPUT} does not exist after ETL run"

    def test_warehouse_output_is_writable_by_user(self):
        """User should be able to write to the warehouse output file for future runs."""
        # Run script first
        subprocess.run([SCRIPT_PATH], capture_output=True, cwd=ETL_BASE)
        assert os.access(WAREHOUSE_OUTPUT, os.W_OK), \
            f"Warehouse output file {WAREHOUSE_OUTPUT} is not writable by user - future runs will fail"

    def test_warehouse_output_not_empty(self):
        """The warehouse output file should not be empty."""
        subprocess.run([SCRIPT_PATH], capture_output=True, cwd=ETL_BASE)
        assert os.path.getsize(WAREHOUSE_OUTPUT) > 0, \
            f"Warehouse output file {WAREHOUSE_OUTPUT} is empty"

    def test_warehouse_output_has_header(self):
        """The warehouse output should contain the expected header row."""
        subprocess.run([SCRIPT_PATH], capture_output=True, cwd=ETL_BASE)
        with open(WAREHOUSE_OUTPUT, 'r') as f:
            first_line = f.readline().strip()
        # Check that header contains expected columns (semantic check)
        assert "customer_id" in first_line, \
            f"Warehouse output missing 'customer_id' in header. Got: {first_line}"
        assert "order_count" in first_line, \
            f"Warehouse output missing 'order_count' in header. Got: {first_line}"
        assert "total_amount" in first_line, \
            f"Warehouse output missing 'total_amount' in header. Got: {first_line}"


class TestOutputMatchesWarehouse:
    """Test that output/combined.csv matches warehouse/daily_combined.csv."""

    def test_output_combined_exists(self):
        """The combined.csv should exist in output directory."""
        subprocess.run([SCRIPT_PATH], capture_output=True, cwd=ETL_BASE)
        assert os.path.isfile(OUTPUT_COMBINED), \
            f"Output file {OUTPUT_COMBINED} does not exist"

    def test_output_matches_warehouse(self):
        """Content of output/combined.csv should match warehouse/daily_combined.csv."""
        subprocess.run([SCRIPT_PATH], capture_output=True, cwd=ETL_BASE)

        with open(OUTPUT_COMBINED, 'r') as f:
            output_content = f.read()
        with open(WAREHOUSE_OUTPUT, 'r') as f:
            warehouse_content = f.read()

        assert output_content == warehouse_content, \
            "Content of output/combined.csv does not match warehouse/daily_combined.csv"


class TestLogShowsSuccess:
    """Test that the log shows all stages completing successfully."""

    def test_log_shows_all_stages_ok(self):
        """Log should show all four stages completing with OK."""
        # Run the script to generate fresh log entries
        subprocess.run([SCRIPT_PATH], capture_output=True, cwd=ETL_BASE)

        with open(LOG_FILE, 'r') as f:
            content = f.read()

        # Check for successful completion indicators
        # We look for the pattern of stages completing - the log should have OK for all stages
        lines = content.split('\n')

        # Find the most recent run's entries (look from the end)
        # We need to see Stage 4 completing successfully
        stage4_ok_found = False
        for line in reversed(lines):
            if "Stage 4" in line and "OK" in line:
                stage4_ok_found = True
                break
            # If we hit a FAILED for stage 4 before finding OK, the fix didn't work
            if "Stage 4" in line and "FAILED" in line:
                # Keep looking - there might be a successful run after the failed one
                continue

        assert stage4_ok_found, \
            "Log does not show Stage 4 completing with OK - the ETL job did not fully succeed"


class TestInvariantsPreserved:
    """Test that invariants are preserved - script and source files unchanged."""

    def test_daily_load_script_exists(self):
        """ETL script should still exist."""
        assert os.path.isfile(SCRIPT_PATH), \
            f"ETL script {SCRIPT_PATH} no longer exists"

    def test_daily_load_script_permissions_unchanged(self):
        """ETL script should still be mode 750."""
        st = os.stat(SCRIPT_PATH)
        mode = stat.S_IMODE(st.st_mode)
        assert mode == 0o750, \
            f"ETL script permissions changed from 0o750 to {oct(mode)}"

    def test_daily_load_script_ownership_unchanged(self):
        """ETL script should still be owned by user:etl-writers."""
        st = os.stat(SCRIPT_PATH)
        owner = pwd.getpwuid(st.st_uid).pw_name
        group = grp.getgrgid(st.st_gid).gr_name
        assert owner == "user", \
            f"ETL script owner changed from 'user' to '{owner}'"
        assert group == "etl-writers", \
            f"ETL script group changed from 'etl-writers' to '{group}'"

    def test_transform_script_exists(self):
        """Transform script should still exist."""
        assert os.path.isfile(TRANSFORM_PATH), \
            f"Transform script {TRANSFORM_PATH} no longer exists"

    def test_source_files_exist(self):
        """Source CSV files should still exist."""
        customers = f"{SOURCES_DIR}/customers.csv"
        orders = f"{SOURCES_DIR}/orders.csv"
        assert os.path.isfile(customers), \
            f"Source file {customers} no longer exists"
        assert os.path.isfile(orders), \
            f"Source file {orders} no longer exists"

    def test_user_still_in_etl_writers_group(self):
        """User should still be in etl-writers group."""
        try:
            etl_group = grp.getgrnam("etl-writers")
            user_info = pwd.getpwnam("user")
            user_primary_gid = user_info.pw_gid

            in_group = ("user" in etl_group.gr_mem) or (user_primary_gid == etl_group.gr_gid)
            assert in_group, \
                "User 'user' is no longer a member of etl-writers group"
        except KeyError as e:
            pytest.fail(f"Required user or group does not exist: {e}")


class TestDirectoryPermissionsUnchanged:
    """Test that directory permissions remain unchanged."""

    def test_sources_directory_permissions(self):
        """Sources directory should still be mode 755."""
        st = os.stat(SOURCES_DIR)
        mode = stat.S_IMODE(st.st_mode)
        assert mode == 0o755, \
            f"Sources directory permissions changed from 0o755 to {oct(mode)}"

    def test_staging_directory_permissions(self):
        """Staging directory should still be mode 770."""
        st = os.stat(STAGING_DIR)
        mode = stat.S_IMODE(st.st_mode)
        assert mode == 0o770, \
            f"Staging directory permissions changed from 0o770 to {oct(mode)}"

    def test_output_directory_permissions(self):
        """Output directory should still be mode 770."""
        st = os.stat(OUTPUT_DIR)
        mode = stat.S_IMODE(st.st_mode)
        assert mode == 0o770, \
            f"Output directory permissions changed from 0o770 to {oct(mode)}"

    def test_warehouse_directory_permissions(self):
        """Warehouse directory should still be mode 770."""
        st = os.stat(WAREHOUSE_DIR)
        mode = stat.S_IMODE(st.st_mode)
        assert mode == 0o770, \
            f"Warehouse directory permissions changed from 0o770 to {oct(mode)}"

    def test_warehouse_directory_group(self):
        """Warehouse directory should still have group etl-writers."""
        st = os.stat(WAREHOUSE_DIR)
        group = grp.getgrgid(st.st_gid).gr_name
        assert group == "etl-writers", \
            f"Warehouse directory group changed from 'etl-writers' to '{group}'"


class TestRepeatedRunsWork:
    """Test that the ETL job can run multiple times successfully."""

    def test_second_run_succeeds(self):
        """Running the ETL script twice should both succeed."""
        # First run
        result1 = subprocess.run(
            [SCRIPT_PATH],
            capture_output=True,
            text=True,
            cwd=ETL_BASE
        )
        assert result1.returncode == 0, \
            f"First ETL run failed with exit code {result1.returncode}"

        # Second run
        result2 = subprocess.run(
            [SCRIPT_PATH],
            capture_output=True,
            text=True,
            cwd=ETL_BASE
        )
        assert result2.returncode == 0, \
            f"Second ETL run failed with exit code {result2.returncode} - the fix doesn't allow repeated runs"
