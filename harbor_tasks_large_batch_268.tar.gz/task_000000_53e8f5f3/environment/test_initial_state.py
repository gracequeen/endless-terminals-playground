# test_initial_state.py
"""
Tests to validate the initial state of the ETL environment before the student
performs any actions to fix the permission denied issue.
"""

import os
import stat
import grp
import pwd
import subprocess
import pytest


HOME = "/home/user"
ETL_BASE = f"{HOME}/etl"
SCRIPT_PATH = f"{ETL_BASE}/daily_load.sh"
TRANSFORM_PATH = f"{ETL_BASE}/transform.py"
SOURCES_DIR = f"{ETL_BASE}/sources"
STAGING_DIR = f"{ETL_BASE}/staging"
OUTPUT_DIR = f"{ETL_BASE}/output"
WAREHOUSE_DIR = f"{ETL_BASE}/warehouse"
LOGS_DIR = f"{ETL_BASE}/logs"
LOG_FILE = f"{LOGS_DIR}/daily_load.log"
BLOCKING_FILE = f"{WAREHOUSE_DIR}/daily_combined.csv"


class TestETLDirectoryStructure:
    """Test that the ETL directory structure exists."""

    def test_etl_base_directory_exists(self):
        assert os.path.isdir(ETL_BASE), f"ETL base directory {ETL_BASE} does not exist"

    def test_sources_directory_exists(self):
        assert os.path.isdir(SOURCES_DIR), f"Sources directory {SOURCES_DIR} does not exist"

    def test_staging_directory_exists(self):
        assert os.path.isdir(STAGING_DIR), f"Staging directory {STAGING_DIR} does not exist"

    def test_output_directory_exists(self):
        assert os.path.isdir(OUTPUT_DIR), f"Output directory {OUTPUT_DIR} does not exist"

    def test_warehouse_directory_exists(self):
        assert os.path.isdir(WAREHOUSE_DIR), f"Warehouse directory {WAREHOUSE_DIR} does not exist"

    def test_logs_directory_exists(self):
        assert os.path.isdir(LOGS_DIR), f"Logs directory {LOGS_DIR} does not exist"


class TestETLScript:
    """Test the main ETL script exists and has correct permissions."""

    def test_daily_load_script_exists(self):
        assert os.path.isfile(SCRIPT_PATH), f"ETL script {SCRIPT_PATH} does not exist"

    def test_daily_load_script_is_executable(self):
        assert os.access(SCRIPT_PATH, os.X_OK), f"ETL script {SCRIPT_PATH} is not executable"

    def test_daily_load_script_permissions(self):
        """Script should be mode 750 (rwxr-x---)."""
        st = os.stat(SCRIPT_PATH)
        mode = stat.S_IMODE(st.st_mode)
        assert mode == 0o750, f"ETL script has mode {oct(mode)}, expected 0o750"

    def test_daily_load_script_owner(self):
        """Script should be owned by user."""
        st = os.stat(SCRIPT_PATH)
        owner = pwd.getpwuid(st.st_uid).pw_name
        assert owner == "user", f"ETL script owned by {owner}, expected 'user'"

    def test_daily_load_script_group(self):
        """Script should have group etl-writers."""
        st = os.stat(SCRIPT_PATH)
        group = grp.getgrgid(st.st_gid).gr_name
        assert group == "etl-writers", f"ETL script has group {group}, expected 'etl-writers'"


class TestTransformScript:
    """Test the Python transform script exists."""

    def test_transform_script_exists(self):
        assert os.path.isfile(TRANSFORM_PATH), f"Transform script {TRANSFORM_PATH} does not exist"


class TestSourceFiles:
    """Test source CSV files exist and are readable."""

    def test_customers_csv_exists(self):
        path = f"{SOURCES_DIR}/customers.csv"
        assert os.path.isfile(path), f"Source file {path} does not exist"

    def test_orders_csv_exists(self):
        path = f"{SOURCES_DIR}/orders.csv"
        assert os.path.isfile(path), f"Source file {path} does not exist"

    def test_sources_directory_permissions(self):
        """Sources directory should be mode 755."""
        st = os.stat(SOURCES_DIR)
        mode = stat.S_IMODE(st.st_mode)
        assert mode == 0o755, f"Sources directory has mode {oct(mode)}, expected 0o755"

    def test_customers_csv_permissions(self):
        """Source files should be mode 644."""
        path = f"{SOURCES_DIR}/customers.csv"
        st = os.stat(path)
        mode = stat.S_IMODE(st.st_mode)
        assert mode == 0o644, f"customers.csv has mode {oct(mode)}, expected 0o644"

    def test_orders_csv_permissions(self):
        """Source files should be mode 644."""
        path = f"{SOURCES_DIR}/orders.csv"
        st = os.stat(path)
        mode = stat.S_IMODE(st.st_mode)
        assert mode == 0o644, f"orders.csv has mode {oct(mode)}, expected 0o644"


class TestDirectoryPermissions:
    """Test directory permissions for ETL workflow directories."""

    def test_staging_directory_permissions(self):
        """Staging directory should be mode 770."""
        st = os.stat(STAGING_DIR)
        mode = stat.S_IMODE(st.st_mode)
        assert mode == 0o770, f"Staging directory has mode {oct(mode)}, expected 0o770"

    def test_staging_directory_group(self):
        """Staging directory should have group etl-writers."""
        st = os.stat(STAGING_DIR)
        group = grp.getgrgid(st.st_gid).gr_name
        assert group == "etl-writers", f"Staging directory has group {group}, expected 'etl-writers'"

    def test_output_directory_permissions(self):
        """Output directory should be mode 770."""
        st = os.stat(OUTPUT_DIR)
        mode = stat.S_IMODE(st.st_mode)
        assert mode == 0o770, f"Output directory has mode {oct(mode)}, expected 0o770"

    def test_output_directory_group(self):
        """Output directory should have group etl-writers."""
        st = os.stat(OUTPUT_DIR)
        group = grp.getgrgid(st.st_gid).gr_name
        assert group == "etl-writers", f"Output directory has group {group}, expected 'etl-writers'"

    def test_warehouse_directory_permissions(self):
        """Warehouse directory should be mode 770."""
        st = os.stat(WAREHOUSE_DIR)
        mode = stat.S_IMODE(st.st_mode)
        assert mode == 0o770, f"Warehouse directory has mode {oct(mode)}, expected 0o770"

    def test_warehouse_directory_group(self):
        """Warehouse directory should have group etl-writers."""
        st = os.stat(WAREHOUSE_DIR)
        group = grp.getgrgid(st.st_gid).gr_name
        assert group == "etl-writers", f"Warehouse directory has group {group}, expected 'etl-writers'"


class TestUserGroupMembership:
    """Test that user is in the etl-writers group."""

    def test_user_in_etl_writers_group(self):
        """User 'user' should be a member of etl-writers group."""
        try:
            etl_group = grp.getgrnam("etl-writers")
            # Check if user is in the group's member list or if it's their primary group
            user_info = pwd.getpwnam("user")
            user_primary_gid = user_info.pw_gid

            in_group = ("user" in etl_group.gr_mem) or (user_primary_gid == etl_group.gr_gid)
            assert in_group, "User 'user' is not a member of etl-writers group"
        except KeyError as e:
            pytest.fail(f"Required user or group does not exist: {e}")


class TestBlockingFile:
    """Test the blocking file that causes the permission denied error."""

    def test_blocking_file_exists(self):
        """The problematic daily_combined.csv should exist in warehouse."""
        assert os.path.isfile(BLOCKING_FILE), \
            f"Blocking file {BLOCKING_FILE} does not exist - this is the file causing the issue"

    def test_blocking_file_owned_by_root(self):
        """The blocking file should be owned by root (the cause of the problem)."""
        st = os.stat(BLOCKING_FILE)
        owner = pwd.getpwuid(st.st_uid).pw_name
        assert owner == "root", \
            f"Blocking file owned by {owner}, expected 'root' (this is the root cause of the issue)"

    def test_blocking_file_group_is_root(self):
        """The blocking file should have group root."""
        st = os.stat(BLOCKING_FILE)
        group = grp.getgrgid(st.st_gid).gr_name
        assert group == "root", \
            f"Blocking file has group {group}, expected 'root'"

    def test_blocking_file_permissions(self):
        """The blocking file should be mode 644 (not writable by others)."""
        st = os.stat(BLOCKING_FILE)
        mode = stat.S_IMODE(st.st_mode)
        assert mode == 0o644, \
            f"Blocking file has mode {oct(mode)}, expected 0o644"

    def test_blocking_file_not_writable_by_user(self):
        """User should NOT be able to write to the blocking file (this is the bug)."""
        # Since file is owned by root:root with 644, user cannot write to it
        assert not os.access(BLOCKING_FILE, os.W_OK), \
            "User CAN write to blocking file - the permission issue doesn't exist"


class TestLogFile:
    """Test the log file exists and shows the error."""

    def test_log_file_exists(self):
        assert os.path.isfile(LOG_FILE), f"Log file {LOG_FILE} does not exist"

    def test_log_shows_permission_denied(self):
        """Log should contain the permission denied error."""
        with open(LOG_FILE, 'r') as f:
            content = f.read()
        assert "Permission denied" in content, \
            "Log file does not contain 'Permission denied' error message"

    def test_log_shows_stages_1_and_2_ok(self):
        """Log should show first stages completed successfully."""
        with open(LOG_FILE, 'r') as f:
            content = f.read()
        assert "Stage 1" in content and "OK" in content, \
            "Log does not show Stage 1 completing"
        assert "Stage 2" in content, \
            "Log does not show Stage 2"

    def test_log_shows_stage_4_failure(self):
        """Log should show Stage 4 failing."""
        with open(LOG_FILE, 'r') as f:
            content = f.read()
        assert "Stage 4" in content, \
            "Log does not show Stage 4"
        assert "FAILED" in content, \
            "Log does not show FAILED status"


class TestETLScriptCurrentlyFails:
    """Verify that running the ETL script currently fails."""

    def test_etl_script_fails_with_permission_error(self):
        """Running the ETL script should currently fail."""
        result = subprocess.run(
            [SCRIPT_PATH],
            capture_output=True,
            text=True,
            cwd=ETL_BASE
        )
        # The script should fail (non-zero exit code)
        assert result.returncode != 0, \
            f"ETL script unexpectedly succeeded - it should fail due to permission denied"


class TestSudoNotAvailable:
    """Verify sudo is not available for the user."""

    def test_sudo_not_available(self):
        """Sudo should not be available or should require password."""
        result = subprocess.run(
            ["sudo", "-n", "true"],
            capture_output=True,
            text=True
        )
        # -n flag means non-interactive, should fail if sudo requires password or isn't available
        assert result.returncode != 0, \
            "Sudo is available without password - this shouldn't be the case"
