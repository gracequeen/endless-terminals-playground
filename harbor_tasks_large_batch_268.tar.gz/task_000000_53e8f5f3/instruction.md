ETL job at /home/user/etl/daily_load.sh has been failing since yesterday with permission denied somewhere in the middle — it gets through the first couple extracts fine then dies. I added myself to the `etl-writers` group last week so I could run it manually, but something's still off. The cron runs it as my user (checked that already).

Logs are in /home/user/etl/logs/ if that helps. Need this working before tonight's run.
