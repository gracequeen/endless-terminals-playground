# test_final_state.py
"""
Tests to validate the final state after the student fixes the broken symlink issue.
The build script should now complete successfully.
"""

import os
import subprocess
import pytest


class TestSymlinkFixed:
    """Test that the symlink has been properly fixed."""

    def test_node_modules_exists_and_accessible(self):
        """The node_modules path should now be accessible."""
        node_modules_path = "/home/user/app/node_modules"
        assert os.path.exists(node_modules_path), \
            f"{node_modules_path} does not exist or is a broken symlink - the symlink needs to be fixed"

    def test_node_modules_resolves_to_shared_deps(self):
        """The node_modules should resolve to the shared-deps location."""
        node_modules_path = "/home/user/app/node_modules"
        # Get the real path (resolving all symlinks)
        real_path = os.path.realpath(node_modules_path)
        expected_real_path = os.path.realpath("/home/user/shared-deps/node_modules")
        assert real_path == expected_real_path, \
            f"node_modules should resolve to /home/user/shared-deps/node_modules, but resolves to {real_path}"

    def test_esbuild_accessible_via_app_node_modules(self):
        """The esbuild binary should be accessible via /home/user/app/node_modules."""
        esbuild_path = "/home/user/app/node_modules/.bin/esbuild"
        assert os.path.exists(esbuild_path), \
            f"esbuild binary not accessible at {esbuild_path} - symlink may still be broken"

    def test_esbuild_is_executable_via_symlink(self):
        """The esbuild binary should be executable via the symlink path."""
        esbuild_path = "/home/user/app/node_modules/.bin/esbuild"
        assert os.access(esbuild_path, os.X_OK), \
            f"esbuild at {esbuild_path} is not executable"

    def test_bin_directory_accessible(self):
        """The .bin directory should be accessible via the symlink."""
        bin_path = "/home/user/app/node_modules/.bin"
        assert os.path.isdir(bin_path), \
            f".bin directory not accessible at {bin_path}"


class TestSymlinkNotDuplicated:
    """Ensure the fix uses the symlink approach, not duplicating node_modules."""

    def test_shared_deps_still_has_packages(self):
        """The shared-deps/node_modules should still contain the actual packages."""
        assert os.path.isdir("/home/user/shared-deps/node_modules"), \
            "shared-deps/node_modules should still exist with actual packages"

    def test_shared_deps_has_esbuild(self):
        """The esbuild should still be in shared-deps."""
        esbuild_path = "/home/user/shared-deps/node_modules/.bin/esbuild"
        assert os.path.exists(esbuild_path), \
            f"esbuild should still exist at {esbuild_path}"

    def test_app_node_modules_is_symlink_or_resolves_correctly(self):
        """
        The app's node_modules should either be a symlink to shared-deps
        or otherwise resolve to the shared-deps location (not a copy).
        """
        app_nm = "/home/user/app/node_modules"
        shared_nm = "/home/user/shared-deps/node_modules"

        # Check that they resolve to the same real path
        app_real = os.path.realpath(app_nm)
        shared_real = os.path.realpath(shared_nm)

        assert app_real == shared_real, \
            f"app's node_modules should resolve to shared-deps/node_modules. " \
            f"Got {app_real}, expected {shared_real}. " \
            f"Don't copy node_modules - fix the symlink instead."


class TestBuildScriptIntegrity:
    """Ensure the build script wasn't modified inappropriately."""

    def test_build_script_exists(self):
        """The build script should still exist."""
        assert os.path.isfile("/home/user/app/scripts/build.sh"), \
            "Build script /home/user/app/scripts/build.sh should exist"

    def test_build_script_still_uses_relative_esbuild_path(self):
        """The build script should still use relative path to esbuild, not hardcoded absolute."""
        with open("/home/user/app/scripts/build.sh", "r") as f:
            content = f.read()

        # Should still reference node_modules relatively
        assert "node_modules" in content, \
            "Build script should still reference node_modules (don't hardcode absolute paths)"

        # Should NOT have hardcoded absolute path to shared-deps esbuild
        assert "/home/user/shared-deps/node_modules/.bin/esbuild" not in content, \
            "Build script should not hardcode absolute path to esbuild - fix the symlink instead"


class TestSourceFileIntegrity:
    """Ensure source files weren't modified."""

    def test_index_js_exists(self):
        """The source file should still exist."""
        assert os.path.isfile("/home/user/app/src/index.js"), \
            "Source file /home/user/app/src/index.js should exist"

    def test_index_js_has_content(self):
        """The source file should have content."""
        with open("/home/user/app/src/index.js", "r") as f:
            content = f.read()
        assert len(content.strip()) > 0, \
            "Source file should have content"


class TestBuildSucceeds:
    """Test that the build now succeeds."""

    def test_build_script_exits_zero(self):
        """The build script should now exit with code 0."""
        result = subprocess.run(
            ["bash", "/home/user/app/scripts/build.sh"],
            capture_output=True,
            text=True,
            cwd="/home/user/app"
        )
        assert result.returncode == 0, \
            f"Build script should succeed (exit 0), but got exit code {result.returncode}.\n" \
            f"stdout: {result.stdout}\n" \
            f"stderr: {result.stderr}"

    def test_bundle_file_created(self):
        """The build should create the bundle file."""
        # Run the build first to ensure it's been executed
        subprocess.run(
            ["bash", "/home/user/app/scripts/build.sh"],
            capture_output=True,
            cwd="/home/user/app"
        )

        bundle_path = "/home/user/app/dist/bundle.js"
        assert os.path.isfile(bundle_path), \
            f"Bundle file should be created at {bundle_path}"

    def test_bundle_has_content(self):
        """The bundle file should have content (valid esbuild output)."""
        # Run the build first
        subprocess.run(
            ["bash", "/home/user/app/scripts/build.sh"],
            capture_output=True,
            cwd="/home/user/app"
        )

        bundle_path = "/home/user/app/dist/bundle.js"
        assert os.path.isfile(bundle_path), \
            f"Bundle file should exist at {bundle_path}"

        with open(bundle_path, "r") as f:
            content = f.read()

        assert len(content.strip()) > 0, \
            "Bundle file should have content"

    def test_bundle_is_valid_javascript(self):
        """The bundle should be valid JavaScript (can be parsed by node)."""
        # Run the build first
        subprocess.run(
            ["bash", "/home/user/app/scripts/build.sh"],
            capture_output=True,
            cwd="/home/user/app"
        )

        bundle_path = "/home/user/app/dist/bundle.js"

        # Use node to check syntax
        result = subprocess.run(
            ["node", "--check", bundle_path],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            f"Bundle should be valid JavaScript. Node syntax check failed: {result.stderr}"


class TestSymlinkResolution:
    """Test that the symlink properly resolves."""

    def test_readlink_returns_valid_path(self):
        """If node_modules is a symlink, readlink should return a path that resolves correctly."""
        node_modules_path = "/home/user/app/node_modules"

        if os.path.islink(node_modules_path):
            target = os.readlink(node_modules_path)

            # Resolve the target relative to the symlink's directory
            if not os.path.isabs(target):
                symlink_dir = os.path.dirname(node_modules_path)
                resolved = os.path.normpath(os.path.join(symlink_dir, target))
            else:
                resolved = target

            assert os.path.exists(resolved), \
                f"Symlink target '{target}' resolves to '{resolved}' which does not exist. " \
                f"The symlink needs to point to a valid path."

            # Verify it points to shared-deps/node_modules
            real_resolved = os.path.realpath(resolved)
            real_shared = os.path.realpath("/home/user/shared-deps/node_modules")
            assert real_resolved == real_shared, \
                f"Symlink should resolve to /home/user/shared-deps/node_modules, " \
                f"but resolves to {real_resolved}"

    def test_ls_node_modules_bin_esbuild_succeeds(self):
        """ls /home/user/app/node_modules/.bin/esbuild should succeed."""
        result = subprocess.run(
            ["ls", "/home/user/app/node_modules/.bin/esbuild"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            f"'ls /home/user/app/node_modules/.bin/esbuild' should succeed. " \
            f"stderr: {result.stderr}"
