CI build on /home/user/app keeps failing at the asset compilation step — says it can't find `node_modules/.bin/esbuild` even though npm install runs clean right before. The weird thing is it worked fine until last week when we reorganized the repo to share deps across services. I'm pretty sure node_modules is there, I can see it, but something about how the build script resolves the binary is off. Might be a path thing? Or maybe the symlinks got weird during the reorg, idk.

Build script is at /home/user/app/scripts/build.sh — just need it to actually complete without that "not found" error.
