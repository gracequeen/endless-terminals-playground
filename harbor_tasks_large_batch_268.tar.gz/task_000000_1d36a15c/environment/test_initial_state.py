# test_initial_state.py
"""
Tests to validate the initial state before the student fixes the broken symlink issue.
"""

import os
import subprocess
import pytest


class TestDirectoryStructure:
    """Test that the required directory structure exists."""

    def test_app_directory_exists(self):
        """The /home/user/app directory must exist."""
        assert os.path.isdir("/home/user/app"), \
            "Directory /home/user/app does not exist"

    def test_shared_deps_directory_exists(self):
        """The /home/user/shared-deps directory must exist."""
        assert os.path.isdir("/home/user/shared-deps"), \
            "Directory /home/user/shared-deps does not exist"

    def test_shared_deps_node_modules_exists(self):
        """The /home/user/shared-deps/node_modules directory must exist with actual packages."""
        assert os.path.isdir("/home/user/shared-deps/node_modules"), \
            "Directory /home/user/shared-deps/node_modules does not exist"

    def test_shared_deps_bin_directory_exists(self):
        """The /home/user/shared-deps/node_modules/.bin directory must exist."""
        assert os.path.isdir("/home/user/shared-deps/node_modules/.bin"), \
            "Directory /home/user/shared-deps/node_modules/.bin does not exist"

    def test_esbuild_binary_exists_in_shared_deps(self):
        """The esbuild binary must exist in shared-deps."""
        esbuild_path = "/home/user/shared-deps/node_modules/.bin/esbuild"
        assert os.path.exists(esbuild_path), \
            f"esbuild binary not found at {esbuild_path}"

    def test_esbuild_binary_is_executable(self):
        """The esbuild binary must be executable."""
        esbuild_path = "/home/user/shared-deps/node_modules/.bin/esbuild"
        assert os.access(esbuild_path, os.X_OK), \
            f"esbuild binary at {esbuild_path} is not executable"

    def test_scripts_directory_exists(self):
        """The /home/user/app/scripts directory must exist."""
        assert os.path.isdir("/home/user/app/scripts"), \
            "Directory /home/user/app/scripts does not exist"

    def test_src_directory_exists(self):
        """The /home/user/app/src directory must exist."""
        assert os.path.isdir("/home/user/app/src"), \
            "Directory /home/user/app/src does not exist"

    def test_dist_directory_exists(self):
        """The /home/user/app/dist directory must exist."""
        assert os.path.isdir("/home/user/app/dist"), \
            "Directory /home/user/app/dist does not exist"


class TestRequiredFiles:
    """Test that required files exist."""

    def test_package_json_exists(self):
        """The package.json file must exist."""
        assert os.path.isfile("/home/user/app/package.json"), \
            "File /home/user/app/package.json does not exist"

    def test_build_script_exists(self):
        """The build.sh script must exist."""
        assert os.path.isfile("/home/user/app/scripts/build.sh"), \
            "File /home/user/app/scripts/build.sh does not exist"

    def test_build_script_is_executable(self):
        """The build.sh script must be executable."""
        assert os.access("/home/user/app/scripts/build.sh", os.X_OK), \
            "File /home/user/app/scripts/build.sh is not executable"

    def test_index_js_exists(self):
        """The src/index.js file must exist."""
        assert os.path.isfile("/home/user/app/src/index.js"), \
            "File /home/user/app/src/index.js does not exist"


class TestSymlinkState:
    """Test the symlink configuration (the broken state)."""

    def test_node_modules_is_symlink(self):
        """The node_modules in /home/user/app must be a symlink."""
        node_modules_path = "/home/user/app/node_modules"
        assert os.path.islink(node_modules_path), \
            f"{node_modules_path} is not a symlink - it should be a symlink to shared-deps"

    def test_symlink_target_is_incorrect(self):
        """The symlink should point to an incorrect relative path (the bug)."""
        node_modules_path = "/home/user/app/node_modules"
        target = os.readlink(node_modules_path)
        # The bug is that it points to 'shared-deps/node_modules' instead of '../shared-deps/node_modules'
        assert target == "shared-deps/node_modules", \
            f"Expected symlink to point to 'shared-deps/node_modules' (the broken path), but got '{target}'"

    def test_symlink_is_broken(self):
        """The symlink should be broken (target doesn't exist)."""
        node_modules_path = "/home/user/app/node_modules"
        # os.path.exists follows symlinks, so it returns False for broken symlinks
        assert os.path.islink(node_modules_path) and not os.path.exists(node_modules_path), \
            f"Symlink at {node_modules_path} should be broken but it appears to be valid"


class TestBuildScriptContent:
    """Test that the build script has expected content."""

    def test_build_script_has_cd_dirname(self):
        """The build script should contain cd to dirname."""
        with open("/home/user/app/scripts/build.sh", "r") as f:
            content = f.read()
        assert 'cd "$(dirname "$0")"' in content or "cd \"$(dirname \"$0\")\"" in content, \
            "Build script should contain 'cd \"$(dirname \"$0\")\"'"

    def test_build_script_references_node_modules(self):
        """The build script should reference ../node_modules/.bin/esbuild."""
        with open("/home/user/app/scripts/build.sh", "r") as f:
            content = f.read()
        assert "../node_modules/.bin/esbuild" in content, \
            "Build script should reference '../node_modules/.bin/esbuild'"


class TestBuildCurrentlyFails:
    """Test that the build currently fails (confirming the bug)."""

    def test_build_script_fails(self):
        """The build script should currently fail due to the broken symlink."""
        result = subprocess.run(
            ["bash", "/home/user/app/scripts/build.sh"],
            capture_output=True,
            text=True,
            cwd="/home/user/app"
        )
        assert result.returncode != 0, \
            "Build script should fail due to broken symlink, but it succeeded"

    def test_cannot_access_esbuild_via_symlink(self):
        """Cannot access esbuild through the broken symlink."""
        esbuild_via_symlink = "/home/user/app/node_modules/.bin/esbuild"
        assert not os.path.exists(esbuild_via_symlink), \
            f"Should not be able to access {esbuild_via_symlink} through broken symlink"


class TestToolsAvailable:
    """Test that required tools are available."""

    def test_node_available(self):
        """Node.js must be available."""
        result = subprocess.run(["node", "--version"], capture_output=True, text=True)
        assert result.returncode == 0, "Node.js is not available"
        # Check for Node 20.x
        version = result.stdout.strip()
        assert version.startswith("v20") or version.startswith("v21") or version.startswith("v22"), \
            f"Expected Node 20.x or higher, got {version}"

    def test_npm_available(self):
        """npm must be available."""
        result = subprocess.run(["npm", "--version"], capture_output=True, text=True)
        assert result.returncode == 0, "npm is not available"

    def test_bash_available(self):
        """bash must be available."""
        result = subprocess.run(["bash", "--version"], capture_output=True, text=True)
        assert result.returncode == 0, "bash is not available"


class TestPackageJson:
    """Test package.json content."""

    def test_package_json_has_esbuild_dependency(self):
        """package.json should have esbuild as a devDependency."""
        import json
        with open("/home/user/app/package.json", "r") as f:
            pkg = json.load(f)

        has_esbuild = (
            ("devDependencies" in pkg and "esbuild" in pkg["devDependencies"]) or
            ("dependencies" in pkg and "esbuild" in pkg["dependencies"])
        )
        assert has_esbuild, \
            "package.json should have esbuild as a dependency or devDependency"
