# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the bidirectional rsync sync fix task.
"""

import os
import stat
import subprocess
import pytest
from pathlib import Path


HOME = Path("/home/user")
MANIFESTS_DIR = HOME / "manifests"
REMOTE_MIRROR_DIR = HOME / "remote-mirror"
SYNC_SCRIPT = HOME / "sync.sh"


class TestDirectoriesExist:
    """Verify required directories exist."""

    def test_home_directory_exists(self):
        assert HOME.exists(), f"Home directory {HOME} does not exist"
        assert HOME.is_dir(), f"{HOME} is not a directory"

    def test_manifests_directory_exists(self):
        assert MANIFESTS_DIR.exists(), f"Manifests directory {MANIFESTS_DIR} does not exist"
        assert MANIFESTS_DIR.is_dir(), f"{MANIFESTS_DIR} is not a directory"

    def test_remote_mirror_directory_exists(self):
        assert REMOTE_MIRROR_DIR.exists(), f"Remote mirror directory {REMOTE_MIRROR_DIR} does not exist"
        assert REMOTE_MIRROR_DIR.is_dir(), f"{REMOTE_MIRROR_DIR} is not a directory"


class TestManifestsDirectoryContents:
    """Verify contents of /home/user/manifests/."""

    def test_deployment_yaml_exists(self):
        deployment = MANIFESTS_DIR / "deployment.yaml"
        assert deployment.exists(), f"{deployment} does not exist in manifests directory"
        assert deployment.is_file(), f"{deployment} is not a file"

    def test_deployment_yaml_content(self):
        deployment = MANIFESTS_DIR / "deployment.yaml"
        expected_content = "apiVersion: apps/v1\nkind: Deployment\nmetadata:\n  name: web\nspec:\n  replicas: 3\n"
        actual_content = deployment.read_text()
        assert actual_content == expected_content, (
            f"deployment.yaml in manifests has unexpected content.\n"
            f"Expected:\n{expected_content}\n"
            f"Actual:\n{actual_content}"
        )

    def test_service_yaml_exists(self):
        service = MANIFESTS_DIR / "service.yaml"
        assert service.exists(), f"{service} does not exist in manifests directory"
        assert service.is_file(), f"{service} is not a file"

    def test_service_yaml_content(self):
        service = MANIFESTS_DIR / "service.yaml"
        expected_content = "apiVersion: v1\nkind: Service\nmetadata:\n  name: web-svc\n"
        actual_content = service.read_text()
        assert actual_content == expected_content, (
            f"service.yaml in manifests has unexpected content.\n"
            f"Expected:\n{expected_content}\n"
            f"Actual:\n{actual_content}"
        )

    def test_configmap_yaml_not_in_manifests(self):
        """configmap.yaml should NOT exist in manifests initially (it's only in remote-mirror)."""
        configmap = MANIFESTS_DIR / "configmap.yaml"
        assert not configmap.exists(), (
            f"{configmap} should NOT exist in manifests directory initially. "
            "It should only exist in remote-mirror."
        )


class TestRemoteMirrorDirectoryContents:
    """Verify contents of /home/user/remote-mirror/."""

    def test_deployment_yaml_exists(self):
        deployment = REMOTE_MIRROR_DIR / "deployment.yaml"
        assert deployment.exists(), f"{deployment} does not exist in remote-mirror directory"
        assert deployment.is_file(), f"{deployment} is not a file"

    def test_deployment_yaml_content(self):
        deployment = REMOTE_MIRROR_DIR / "deployment.yaml"
        expected_content = "apiVersion: apps/v1\nkind: Deployment\nmetadata:\n  name: web\nspec:\n  replicas: 5\n  # scaled up for load test\n"
        actual_content = deployment.read_text()
        assert actual_content == expected_content, (
            f"deployment.yaml in remote-mirror has unexpected content.\n"
            f"Expected:\n{expected_content}\n"
            f"Actual:\n{actual_content}"
        )

    def test_service_yaml_exists(self):
        service = REMOTE_MIRROR_DIR / "service.yaml"
        assert service.exists(), f"{service} does not exist in remote-mirror directory"
        assert service.is_file(), f"{service} is not a file"

    def test_service_yaml_content(self):
        service = REMOTE_MIRROR_DIR / "service.yaml"
        expected_content = "apiVersion: v1\nkind: Service\nmetadata:\n  name: web-svc\n"
        actual_content = service.read_text()
        assert actual_content == expected_content, (
            f"service.yaml in remote-mirror has unexpected content.\n"
            f"Expected:\n{expected_content}\n"
            f"Actual:\n{actual_content}"
        )

    def test_configmap_yaml_exists(self):
        configmap = REMOTE_MIRROR_DIR / "configmap.yaml"
        assert configmap.exists(), f"{configmap} does not exist in remote-mirror directory"
        assert configmap.is_file(), f"{configmap} is not a file"

    def test_configmap_yaml_content(self):
        configmap = REMOTE_MIRROR_DIR / "configmap.yaml"
        expected_content = "apiVersion: v1\nkind: ConfigMap\nmetadata:\n  name: app-config\ndata:\n  ENV: production\n"
        actual_content = configmap.read_text()
        assert actual_content == expected_content, (
            f"configmap.yaml in remote-mirror has unexpected content.\n"
            f"Expected:\n{expected_content}\n"
            f"Actual:\n{actual_content}"
        )


class TestFileMtimes:
    """Verify the modification times are set correctly for conflict resolution testing."""

    def test_remote_deployment_newer_than_local(self):
        """remote-mirror/deployment.yaml should be newer than manifests/deployment.yaml."""
        local_deployment = MANIFESTS_DIR / "deployment.yaml"
        remote_deployment = REMOTE_MIRROR_DIR / "deployment.yaml"

        local_mtime = local_deployment.stat().st_mtime
        remote_mtime = remote_deployment.stat().st_mtime

        assert remote_mtime > local_mtime, (
            f"remote-mirror/deployment.yaml (mtime: {remote_mtime}) should be newer than "
            f"manifests/deployment.yaml (mtime: {local_mtime})"
        )

    def test_service_yaml_mtimes_equal_or_close(self):
        """service.yaml should have similar mtimes on both sides (both 2 days old)."""
        local_service = MANIFESTS_DIR / "service.yaml"
        remote_service = REMOTE_MIRROR_DIR / "service.yaml"

        # Both should exist
        assert local_service.exists()
        assert remote_service.exists()


class TestSyncScript:
    """Verify the sync.sh script exists and has the expected properties."""

    def test_sync_script_exists(self):
        assert SYNC_SCRIPT.exists(), f"Sync script {SYNC_SCRIPT} does not exist"
        assert SYNC_SCRIPT.is_file(), f"{SYNC_SCRIPT} is not a file"

    def test_sync_script_is_executable(self):
        mode = SYNC_SCRIPT.stat().st_mode
        assert mode & stat.S_IXUSR, f"{SYNC_SCRIPT} is not executable by owner"

    def test_sync_script_is_bash_script(self):
        content = SYNC_SCRIPT.read_text()
        assert content.startswith("#!/bin/bash"), (
            f"{SYNC_SCRIPT} does not start with #!/bin/bash shebang"
        )

    def test_sync_script_uses_rsync(self):
        content = SYNC_SCRIPT.read_text()
        assert "rsync" in content, (
            f"{SYNC_SCRIPT} does not contain rsync command"
        )

    def test_sync_script_defines_local_and_remote(self):
        content = SYNC_SCRIPT.read_text()
        assert 'LOCAL="/home/user/manifests/"' in content, (
            f"{SYNC_SCRIPT} does not define LOCAL variable correctly"
        )
        assert 'REMOTE="/home/user/remote-mirror/"' in content, (
            f"{SYNC_SCRIPT} does not define REMOTE variable correctly"
        )

    def test_sync_script_has_staging_dir(self):
        content = SYNC_SCRIPT.read_text()
        assert ".sync-staging" in content, (
            f"{SYNC_SCRIPT} does not reference .sync-staging directory"
        )

    def test_sync_script_has_the_bug(self):
        """Verify the script has the trailing slash bug that needs to be fixed."""
        content = SYNC_SCRIPT.read_text()
        # The bug is: rsync -av --update "$REMOTE" "$STAGING" 
        # instead of: rsync -av --update "$REMOTE" "$STAGING/"
        # or the REMOTE variable missing trailing slash in the rsync call
        assert 'rsync -av --update "$REMOTE" "$STAGING"' in content, (
            f"{SYNC_SCRIPT} does not have the expected buggy rsync line. "
            "The script should have the trailing slash bug for the student to fix."
        )


class TestRequiredTools:
    """Verify required tools are available."""

    def test_rsync_available(self):
        result = subprocess.run(["which", "rsync"], capture_output=True)
        assert result.returncode == 0, "rsync is not available on the system"

    def test_bash_available(self):
        result = subprocess.run(["which", "bash"], capture_output=True)
        assert result.returncode == 0, "bash is not available on the system"

    def test_touch_available(self):
        result = subprocess.run(["which", "touch"], capture_output=True)
        assert result.returncode == 0, "touch is not available on the system"


class TestDirectoryWritable:
    """Verify directories are writable."""

    def test_home_writable(self):
        assert os.access(HOME, os.W_OK), f"{HOME} is not writable"

    def test_manifests_writable(self):
        assert os.access(MANIFESTS_DIR, os.W_OK), f"{MANIFESTS_DIR} is not writable"

    def test_remote_mirror_writable(self):
        assert os.access(REMOTE_MIRROR_DIR, os.W_OK), f"{REMOTE_MIRROR_DIR} is not writable"


class TestNoExtraFiles:
    """Verify there are no unexpected files that could interfere with testing."""

    def test_manifests_has_only_expected_files(self):
        expected_files = {"deployment.yaml", "service.yaml"}
        actual_files = {f.name for f in MANIFESTS_DIR.iterdir() if f.is_file()}
        assert actual_files == expected_files, (
            f"manifests directory has unexpected files.\n"
            f"Expected: {expected_files}\n"
            f"Actual: {actual_files}"
        )

    def test_remote_mirror_has_only_expected_files(self):
        expected_files = {"deployment.yaml", "service.yaml", "configmap.yaml"}
        actual_files = {f.name for f in REMOTE_MIRROR_DIR.iterdir() if f.is_file()}
        assert actual_files == expected_files, (
            f"remote-mirror directory has unexpected files.\n"
            f"Expected: {expected_files}\n"
            f"Actual: {actual_files}"
        )
