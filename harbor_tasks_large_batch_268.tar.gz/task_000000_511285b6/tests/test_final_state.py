# test_final_state.py
"""
Tests to validate the final state of the OS/filesystem after the student
has fixed the bidirectional rsync sync script.
"""

import os
import stat
import subprocess
import time
import pytest
from pathlib import Path


HOME = Path("/home/user")
MANIFESTS_DIR = HOME / "manifests"
REMOTE_MIRROR_DIR = HOME / "remote-mirror"
SYNC_SCRIPT = HOME / "sync.sh"


class TestSyncScriptExists:
    """Verify the sync script still exists and is valid."""

    def test_sync_script_exists(self):
        assert SYNC_SCRIPT.exists(), f"Sync script {SYNC_SCRIPT} does not exist"
        assert SYNC_SCRIPT.is_file(), f"{SYNC_SCRIPT} is not a file"

    def test_sync_script_is_executable(self):
        mode = SYNC_SCRIPT.stat().st_mode
        assert mode & stat.S_IXUSR, f"{SYNC_SCRIPT} is not executable by owner"

    def test_sync_script_is_bash_script(self):
        content = SYNC_SCRIPT.read_text()
        assert content.startswith("#!/bin/bash"), (
            f"{SYNC_SCRIPT} does not start with #!/bin/bash shebang"
        )

    def test_sync_script_uses_rsync(self):
        """Script must use rsync, not be replaced with a different tool."""
        content = SYNC_SCRIPT.read_text()
        assert "rsync" in content, (
            f"{SYNC_SCRIPT} must use rsync for synchronization"
        )


class TestDirectoriesInSync:
    """Verify both directories are now in sync after the fix."""

    def test_manifests_directory_exists(self):
        assert MANIFESTS_DIR.exists(), f"{MANIFESTS_DIR} does not exist"
        assert MANIFESTS_DIR.is_dir(), f"{MANIFESTS_DIR} is not a directory"

    def test_remote_mirror_directory_exists(self):
        assert REMOTE_MIRROR_DIR.exists(), f"{REMOTE_MIRROR_DIR} does not exist"
        assert REMOTE_MIRROR_DIR.is_dir(), f"{REMOTE_MIRROR_DIR} is not a directory"

    def test_configmap_exists_in_manifests(self):
        """configmap.yaml from remote-mirror should now exist in manifests."""
        configmap = MANIFESTS_DIR / "configmap.yaml"
        assert configmap.exists(), (
            f"configmap.yaml should have been synced from remote-mirror to manifests. "
            f"File {configmap} does not exist."
        )

    def test_configmap_exists_in_remote_mirror(self):
        """configmap.yaml should still exist in remote-mirror (not deleted)."""
        configmap = REMOTE_MIRROR_DIR / "configmap.yaml"
        assert configmap.exists(), (
            f"configmap.yaml should NOT have been deleted from remote-mirror. "
            f"File {configmap} does not exist."
        )

    def test_configmap_content_correct(self):
        """configmap.yaml should have the production config content."""
        configmap_local = MANIFESTS_DIR / "configmap.yaml"
        configmap_remote = REMOTE_MIRROR_DIR / "configmap.yaml"

        expected_content = "apiVersion: v1\nkind: ConfigMap\nmetadata:\n  name: app-config\ndata:\n  ENV: production\n"

        local_content = configmap_local.read_text()
        remote_content = configmap_remote.read_text()

        assert "ENV: production" in local_content, (
            f"configmap.yaml in manifests should contain 'ENV: production'"
        )
        assert "ENV: production" in remote_content, (
            f"configmap.yaml in remote-mirror should contain 'ENV: production'"
        )

    def test_deployment_yaml_has_newer_version(self):
        """deployment.yaml should have the remote-mirror version (replicas: 5) since it was newer."""
        deployment_local = MANIFESTS_DIR / "deployment.yaml"
        deployment_remote = REMOTE_MIRROR_DIR / "deployment.yaml"

        local_content = deployment_local.read_text()
        remote_content = deployment_remote.read_text()

        # Check for replicas: 5 (the newer remote version)
        assert "replicas: 5" in local_content, (
            f"deployment.yaml in manifests should have 'replicas: 5' from the newer remote version.\n"
            f"Actual content:\n{local_content}"
        )
        assert "replicas: 5" in remote_content, (
            f"deployment.yaml in remote-mirror should have 'replicas: 5'.\n"
            f"Actual content:\n{remote_content}"
        )

        # Should also have the comment from the remote version
        assert "scaled up for load test" in local_content or "replicas: 5" in local_content, (
            f"deployment.yaml should reflect the remote-mirror version"
        )

    def test_service_yaml_exists_both_sides(self):
        """service.yaml should exist in both directories."""
        service_local = MANIFESTS_DIR / "service.yaml"
        service_remote = REMOTE_MIRROR_DIR / "service.yaml"

        assert service_local.exists(), f"{service_local} does not exist"
        assert service_remote.exists(), f"{service_remote} does not exist"

    def test_service_yaml_content(self):
        """service.yaml should have the expected content."""
        service_local = MANIFESTS_DIR / "service.yaml"
        service_remote = REMOTE_MIRROR_DIR / "service.yaml"

        local_content = service_local.read_text()
        remote_content = service_remote.read_text()

        assert "name: web-svc" in local_content, (
            f"service.yaml in manifests should contain 'name: web-svc'"
        )
        assert "name: web-svc" in remote_content, (
            f"service.yaml in remote-mirror should contain 'name: web-svc'"
        )

    def test_directories_have_same_files(self):
        """Both directories should have the same set of files."""
        local_files = {f.name for f in MANIFESTS_DIR.iterdir() if f.is_file()}
        remote_files = {f.name for f in REMOTE_MIRROR_DIR.iterdir() if f.is_file()}

        assert local_files == remote_files, (
            f"Directories should have the same files after sync.\n"
            f"manifests files: {local_files}\n"
            f"remote-mirror files: {remote_files}"
        )


class TestBidirectionalSyncFromRemote:
    """Test that new files from remote-mirror are synced to manifests."""

    def test_new_remote_file_syncs_to_local(self):
        """Creating a new file in remote-mirror and running sync should copy it to manifests."""
        test_file_remote = REMOTE_MIRROR_DIR / "test-remote-new.txt"
        test_file_local = MANIFESTS_DIR / "test-remote-new.txt"

        try:
            # Create a new file in remote-mirror
            test_file_remote.write_text("created in remote-mirror\n")

            # Run the sync script
            result = subprocess.run(
                [str(SYNC_SCRIPT)],
                capture_output=True,
                text=True,
                cwd=str(HOME)
            )

            assert result.returncode == 0, (
                f"sync.sh failed with return code {result.returncode}.\n"
                f"stdout: {result.stdout}\n"
                f"stderr: {result.stderr}"
            )

            # Verify the file was synced to manifests
            assert test_file_local.exists(), (
                f"New file created in remote-mirror was not synced to manifests. "
                f"The bidirectional sync from remote to local is not working."
            )

            # Verify content
            assert "created in remote-mirror" in test_file_local.read_text(), (
                f"File content was not correctly synced"
            )

        finally:
            # Cleanup
            if test_file_remote.exists():
                test_file_remote.unlink()
            if test_file_local.exists():
                test_file_local.unlink()
            # Run sync again to clean up both sides
            subprocess.run([str(SYNC_SCRIPT)], capture_output=True, cwd=str(HOME))


class TestBidirectionalSyncFromLocal:
    """Test that new files from manifests are synced to remote-mirror."""

    def test_new_local_file_syncs_to_remote(self):
        """Creating a new file in manifests and running sync should copy it to remote-mirror."""
        test_file_local = MANIFESTS_DIR / "test-local-new.txt"
        test_file_remote = REMOTE_MIRROR_DIR / "test-local-new.txt"

        try:
            # Create a new file in manifests
            test_file_local.write_text("created in manifests\n")

            # Run the sync script
            result = subprocess.run(
                [str(SYNC_SCRIPT)],
                capture_output=True,
                text=True,
                cwd=str(HOME)
            )

            assert result.returncode == 0, (
                f"sync.sh failed with return code {result.returncode}.\n"
                f"stdout: {result.stdout}\n"
                f"stderr: {result.stderr}"
            )

            # Verify the file was synced to remote-mirror
            assert test_file_remote.exists(), (
                f"New file created in manifests was not synced to remote-mirror. "
                f"The bidirectional sync from local to remote is not working."
            )

            # Verify content
            assert "created in manifests" in test_file_remote.read_text(), (
                f"File content was not correctly synced"
            )

        finally:
            # Cleanup
            if test_file_local.exists():
                test_file_local.unlink()
            if test_file_remote.exists():
                test_file_remote.unlink()
            # Run sync again to clean up both sides
            subprocess.run([str(SYNC_SCRIPT)], capture_output=True, cwd=str(HOME))


class TestConflictResolution:
    """Test that mtime-based conflict resolution works correctly."""

    def test_newer_remote_wins_conflict(self):
        """When same file exists on both sides, newer mtime should win."""
        conflict_file_local = MANIFESTS_DIR / "conflict-test.txt"
        conflict_file_remote = REMOTE_MIRROR_DIR / "conflict-test.txt"

        try:
            # Create file in local with older mtime
            conflict_file_local.write_text("local version - older\n")
            old_time = time.time() - 3600  # 1 hour ago
            os.utime(conflict_file_local, (old_time, old_time))

            # Create file in remote with newer mtime
            conflict_file_remote.write_text("remote version - newer\n")
            new_time = time.time() - 60  # 1 minute ago
            os.utime(conflict_file_remote, (new_time, new_time))

            # Run the sync script
            result = subprocess.run(
                [str(SYNC_SCRIPT)],
                capture_output=True,
                text=True,
                cwd=str(HOME)
            )

            assert result.returncode == 0, (
                f"sync.sh failed with return code {result.returncode}.\n"
                f"stdout: {result.stdout}\n"
                f"stderr: {result.stderr}"
            )

            # Both files should have the newer (remote) content
            local_content = conflict_file_local.read_text()
            remote_content = conflict_file_remote.read_text()

            assert "remote version - newer" in local_content, (
                f"Conflict resolution failed: local file should have remote's content (newer mtime wins).\n"
                f"Local content: {local_content}"
            )
            assert "remote version - newer" in remote_content, (
                f"Remote file content was unexpectedly changed.\n"
                f"Remote content: {remote_content}"
            )

        finally:
            # Cleanup
            if conflict_file_local.exists():
                conflict_file_local.unlink()
            if conflict_file_remote.exists():
                conflict_file_remote.unlink()
            # Run sync again to clean up both sides
            subprocess.run([str(SYNC_SCRIPT)], capture_output=True, cwd=str(HOME))

    def test_newer_local_wins_conflict(self):
        """When local file is newer, it should win the conflict."""
        conflict_file_local = MANIFESTS_DIR / "conflict-test2.txt"
        conflict_file_remote = REMOTE_MIRROR_DIR / "conflict-test2.txt"

        try:
            # Create file in remote with older mtime
            conflict_file_remote.write_text("remote version - older\n")
            old_time = time.time() - 3600  # 1 hour ago
            os.utime(conflict_file_remote, (old_time, old_time))

            # Create file in local with newer mtime
            conflict_file_local.write_text("local version - newer\n")
            new_time = time.time() - 60  # 1 minute ago
            os.utime(conflict_file_local, (new_time, new_time))

            # Run the sync script
            result = subprocess.run(
                [str(SYNC_SCRIPT)],
                capture_output=True,
                text=True,
                cwd=str(HOME)
            )

            assert result.returncode == 0, (
                f"sync.sh failed with return code {result.returncode}.\n"
                f"stdout: {result.stdout}\n"
                f"stderr: {result.stderr}"
            )

            # Both files should have the newer (local) content
            local_content = conflict_file_local.read_text()
            remote_content = conflict_file_remote.read_text()

            assert "local version - newer" in local_content, (
                f"Local file content was unexpectedly changed.\n"
                f"Local content: {local_content}"
            )
            assert "local version - newer" in remote_content, (
                f"Conflict resolution failed: remote file should have local's content (newer mtime wins).\n"
                f"Remote content: {remote_content}"
            )

        finally:
            # Cleanup
            if conflict_file_local.exists():
                conflict_file_local.unlink()
            if conflict_file_remote.exists():
                conflict_file_remote.unlink()
            # Run sync again to clean up both sides
            subprocess.run([str(SYNC_SCRIPT)], capture_output=True, cwd=str(HOME))


class TestIdempotency:
    """Test that running sync multiple times produces consistent results."""

    def test_sync_is_idempotent(self):
        """Running sync twice with no changes should not modify files."""
        # First, get the current state
        local_files_before = {f.name: f.read_text() for f in MANIFESTS_DIR.iterdir() if f.is_file()}
        remote_files_before = {f.name: f.read_text() for f in REMOTE_MIRROR_DIR.iterdir() if f.is_file()}

        # Run sync
        result1 = subprocess.run(
            [str(SYNC_SCRIPT)],
            capture_output=True,
            text=True,
            cwd=str(HOME)
        )
        assert result1.returncode == 0, f"First sync failed: {result1.stderr}"

        # Run sync again
        result2 = subprocess.run(
            [str(SYNC_SCRIPT)],
            capture_output=True,
            text=True,
            cwd=str(HOME)
        )
        assert result2.returncode == 0, f"Second sync failed: {result2.stderr}"

        # Get state after
        local_files_after = {f.name: f.read_text() for f in MANIFESTS_DIR.iterdir() if f.is_file()}
        remote_files_after = {f.name: f.read_text() for f in REMOTE_MIRROR_DIR.iterdir() if f.is_file()}

        # Both directories should have the same files
        assert set(local_files_after.keys()) == set(remote_files_after.keys()), (
            f"Directories have different files after sync.\n"
            f"Local: {set(local_files_after.keys())}\n"
            f"Remote: {set(remote_files_after.keys())}"
        )


class TestSyncScriptRuns:
    """Test that the sync script runs without errors."""

    def test_sync_script_executes_successfully(self):
        """The sync script should execute without errors."""
        result = subprocess.run(
            [str(SYNC_SCRIPT)],
            capture_output=True,
            text=True,
            cwd=str(HOME)
        )

        assert result.returncode == 0, (
            f"sync.sh failed with return code {result.returncode}.\n"
            f"stdout: {result.stdout}\n"
            f"stderr: {result.stderr}"
        )

    def test_staging_directory_cleaned_up(self):
        """The .sync-staging directory should be cleaned up after sync."""
        staging_dir = HOME / ".sync-staging"

        # Run sync
        subprocess.run([str(SYNC_SCRIPT)], capture_output=True, cwd=str(HOME))

        # Staging should not exist or be empty after sync
        if staging_dir.exists():
            contents = list(staging_dir.iterdir())
            assert len(contents) == 0, (
                f".sync-staging directory should be cleaned up after sync. "
                f"Found: {contents}"
            )
