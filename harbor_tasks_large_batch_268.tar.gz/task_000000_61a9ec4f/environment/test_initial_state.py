# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the filtering configuration fix task.
"""

import os
import subprocess
import pytest

BUILDBOT_DIR = "/home/user/buildbot"
FILTER_SCRIPT = os.path.join(BUILDBOT_DIR, "filter.sh")
RULES_CONF = os.path.join(BUILDBOT_DIR, "rules.conf")
SAMPLE_LOG = os.path.join(BUILDBOT_DIR, "sample.log")
OUTPUT_DIR = os.path.join(BUILDBOT_DIR, "output")


class TestBuildBotDirectoryExists:
    """Test that the buildbot directory and its structure exist."""

    def test_buildbot_directory_exists(self):
        """The /home/user/buildbot directory must exist."""
        assert os.path.isdir(BUILDBOT_DIR), (
            f"Directory {BUILDBOT_DIR} does not exist. "
            "The buildbot pipeline directory is required for this task."
        )

    def test_output_directory_exists(self):
        """The output directory must exist."""
        assert os.path.isdir(OUTPUT_DIR), (
            f"Directory {OUTPUT_DIR} does not exist. "
            "The output directory is required for filtered log output."
        )


class TestFilterScriptExists:
    """Test that filter.sh exists and is properly configured."""

    def test_filter_script_exists(self):
        """filter.sh must exist in the buildbot directory."""
        assert os.path.isfile(FILTER_SCRIPT), (
            f"File {FILTER_SCRIPT} does not exist. "
            "The filter script is required for the CI pipeline filtering."
        )

    def test_filter_script_is_executable(self):
        """filter.sh must be executable."""
        assert os.access(FILTER_SCRIPT, os.X_OK), (
            f"File {FILTER_SCRIPT} is not executable. "
            "The filter script must have execute permissions."
        )

    def test_filter_script_is_bash_script(self):
        """filter.sh should be a bash script."""
        with open(FILTER_SCRIPT, 'r') as f:
            first_line = f.readline()
        assert first_line.startswith("#!/bin/bash"), (
            f"File {FILTER_SCRIPT} does not start with #!/bin/bash shebang. "
            "Expected a bash script."
        )

    def test_filter_script_uses_rules_conf(self):
        """filter.sh must reference rules.conf for its filtering patterns."""
        with open(FILTER_SCRIPT, 'r') as f:
            content = f.read()
        assert "rules.conf" in content, (
            f"File {FILTER_SCRIPT} does not reference rules.conf. "
            "The filter script should use rules.conf for regex patterns."
        )

    def test_filter_script_uses_grep_f(self):
        """filter.sh must use grep -f for pattern matching."""
        with open(FILTER_SCRIPT, 'r') as f:
            content = f.read()
        assert "grep -f" in content, (
            f"File {FILTER_SCRIPT} does not use 'grep -f'. "
            "The filter script should use grep -f with the rules file."
        )


class TestRulesConfExists:
    """Test that rules.conf exists and contains patterns."""

    def test_rules_conf_exists(self):
        """rules.conf must exist in the buildbot directory."""
        assert os.path.isfile(RULES_CONF), (
            f"File {RULES_CONF} does not exist. "
            "The rules configuration file is required for filtering patterns."
        )

    def test_rules_conf_is_readable(self):
        """rules.conf must be readable."""
        assert os.access(RULES_CONF, os.R_OK), (
            f"File {RULES_CONF} is not readable. "
            "The rules configuration file must be readable."
        )

    def test_rules_conf_is_writable(self):
        """rules.conf must be writable (so the agent can fix it)."""
        assert os.access(RULES_CONF, os.W_OK), (
            f"File {RULES_CONF} is not writable. "
            "The rules configuration file must be writable to fix the filtering."
        )

    def test_rules_conf_has_content(self):
        """rules.conf must have some patterns defined."""
        with open(RULES_CONF, 'r') as f:
            content = f.read().strip()
        assert len(content) > 0, (
            f"File {RULES_CONF} is empty. "
            "The rules configuration file should contain regex patterns."
        )

    def test_rules_conf_contains_error_pattern(self):
        """rules.conf should contain the ERROR pattern."""
        with open(RULES_CONF, 'r') as f:
            content = f.read()
        assert "ERROR" in content, (
            f"File {RULES_CONF} does not contain ERROR pattern. "
            "Expected ERROR pattern to be present."
        )

    def test_rules_conf_contains_noise_patterns(self):
        """rules.conf should contain noise patterns (the bug to fix)."""
        with open(RULES_CONF, 'r') as f:
            content = f.read()
        # Check for at least one noise pattern that needs to be removed
        has_warning = "WARNING" in content
        has_note = "Note:" in content
        has_w_pattern = "^w:" in content

        assert has_warning or has_note or has_w_pattern, (
            f"File {RULES_CONF} does not contain the expected noise patterns "
            "(WARNING, Note:, or w:). The initial state should have these "
            "patterns that cause the filtering problem."
        )


class TestSampleLogExists:
    """Test that sample.log exists and has expected content."""

    def test_sample_log_exists(self):
        """sample.log must exist in the buildbot directory."""
        assert os.path.isfile(SAMPLE_LOG), (
            f"File {SAMPLE_LOG} does not exist. "
            "The sample log file is required for testing the filter."
        )

    def test_sample_log_is_readable(self):
        """sample.log must be readable."""
        assert os.access(SAMPLE_LOG, os.R_OK), (
            f"File {SAMPLE_LOG} is not readable. "
            "The sample log file must be readable."
        )

    def test_sample_log_has_substantial_content(self):
        """sample.log should have around 50+ lines (the 'noise' problem)."""
        with open(SAMPLE_LOG, 'r') as f:
            lines = f.readlines()
        assert len(lines) >= 40, (
            f"File {SAMPLE_LOG} has only {len(lines)} lines. "
            "Expected at least 40 lines to represent the noisy log problem."
        )

    def test_sample_log_contains_error_lines(self):
        """sample.log should contain ERROR: lines."""
        with open(SAMPLE_LOG, 'r') as f:
            content = f.read()
        assert "ERROR:" in content, (
            f"File {SAMPLE_LOG} does not contain any ERROR: lines. "
            "The sample log should have error lines to filter."
        )

    def test_sample_log_contains_failure_line(self):
        """sample.log should contain a FAILURE: line."""
        with open(SAMPLE_LOG, 'r') as f:
            content = f.read()
        assert "FAILURE:" in content, (
            f"File {SAMPLE_LOG} does not contain a FAILURE: line. "
            "The sample log should have a failure line to filter."
        )

    def test_sample_log_contains_build_line(self):
        """sample.log should contain a BUILD line."""
        with open(SAMPLE_LOG, 'r') as f:
            lines = f.readlines()
        build_lines = [l for l in lines if l.startswith("BUILD")]
        assert len(build_lines) > 0, (
            f"File {SAMPLE_LOG} does not contain any lines starting with BUILD. "
            "The sample log should have a build summary line."
        )

    def test_sample_log_contains_warning_noise(self):
        """sample.log should contain WARNING lines (noise to filter out)."""
        with open(SAMPLE_LOG, 'r') as f:
            content = f.read()
        assert "WARNING:" in content, (
            f"File {SAMPLE_LOG} does not contain WARNING: lines. "
            "The sample log should have warning noise to demonstrate the problem."
        )

    def test_sample_log_contains_note_noise(self):
        """sample.log should contain Note: lines (noise to filter out)."""
        with open(SAMPLE_LOG, 'r') as f:
            content = f.read()
        assert "Note:" in content, (
            f"File {SAMPLE_LOG} does not contain Note: lines. "
            "The sample log should have note noise to demonstrate the problem."
        )


class TestRequiredToolsAvailable:
    """Test that required command-line tools are available."""

    def test_grep_available(self):
        """grep must be available for the filtering."""
        result = subprocess.run(
            ["which", "grep"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "grep command is not available. "
            "grep is required for the filtering mechanism."
        )

    def test_bash_available(self):
        """bash must be available for running filter.sh."""
        result = subprocess.run(
            ["which", "bash"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "bash is not available. "
            "bash is required to run the filter script."
        )

    def test_cat_available(self):
        """cat must be available (used in filter.sh)."""
        result = subprocess.run(
            ["which", "cat"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "cat command is not available. "
            "cat is used in the filter script."
        )


class TestFilterCurrentlyProducesTooMuchOutput:
    """Test that the current filter configuration lets through too much (the bug)."""

    def test_current_filter_produces_more_than_4_lines(self):
        """Running the current filter should produce more than 4 lines (the bug)."""
        test_output = "/tmp/test_filter_output.log"

        result = subprocess.run(
            [FILTER_SCRIPT, SAMPLE_LOG, test_output],
            capture_output=True,
            text=True,
            cwd=BUILDBOT_DIR
        )

        assert result.returncode == 0, (
            f"filter.sh failed to run: {result.stderr}. "
            "The filter script should be functional."
        )

        assert os.path.isfile(test_output), (
            f"filter.sh did not create output file {test_output}. "
            "The filter script should create an output file."
        )

        with open(test_output, 'r') as f:
            lines = f.readlines()

        # Clean up
        os.remove(test_output)

        # The bug is that it produces too many lines - should be more than 4
        assert len(lines) > 4, (
            f"Current filter produces only {len(lines)} lines. "
            "Expected more than 4 lines to demonstrate the noise problem. "
            "The initial state should have the buggy configuration."
        )
