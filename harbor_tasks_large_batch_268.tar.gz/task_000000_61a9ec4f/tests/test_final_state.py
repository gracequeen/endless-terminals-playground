# test_final_state.py
"""
Tests to validate the final state of the OS/filesystem after the student
has fixed the filtering configuration to only allow through genuine errors
and the build summary line.
"""

import os
import subprocess
import pytest

BUILDBOT_DIR = "/home/user/buildbot"
FILTER_SCRIPT = os.path.join(BUILDBOT_DIR, "filter.sh")
RULES_CONF = os.path.join(BUILDBOT_DIR, "rules.conf")
SAMPLE_LOG = os.path.join(BUILDBOT_DIR, "sample.log")
OUTPUT_DIR = os.path.join(BUILDBOT_DIR, "output")
FILTERED_OUTPUT = os.path.join(OUTPUT_DIR, "filtered.log")


class TestFilterScriptIntegrity:
    """Test that filter.sh still uses the correct mechanism."""

    def test_filter_script_exists(self):
        """filter.sh must still exist."""
        assert os.path.isfile(FILTER_SCRIPT), (
            f"File {FILTER_SCRIPT} does not exist. "
            "The filter script should not be deleted."
        )

    def test_filter_script_is_executable(self):
        """filter.sh must still be executable."""
        assert os.access(FILTER_SCRIPT, os.X_OK), (
            f"File {FILTER_SCRIPT} is not executable. "
            "The filter script must retain execute permissions."
        )

    def test_filter_script_still_uses_rules_conf(self):
        """filter.sh must still reference rules.conf (no hardcoding patterns)."""
        with open(FILTER_SCRIPT, 'r') as f:
            content = f.read()
        assert "rules.conf" in content, (
            f"File {FILTER_SCRIPT} no longer references rules.conf. "
            "The filter script must use rules.conf for regex patterns, "
            "not hardcode patterns directly."
        )

    def test_filter_script_still_uses_grep_f(self):
        """filter.sh must still use grep -f for pattern matching."""
        with open(FILTER_SCRIPT, 'r') as f:
            content = f.read()
        assert "grep -f" in content, (
            f"File {FILTER_SCRIPT} no longer uses 'grep -f'. "
            "The filter script must use grep -f with the rules file, "
            "not replace the mechanism with something else."
        )


class TestRulesConfExists:
    """Test that rules.conf still exists and is properly configured."""

    def test_rules_conf_exists(self):
        """rules.conf must still exist."""
        assert os.path.isfile(RULES_CONF), (
            f"File {RULES_CONF} does not exist. "
            "The rules configuration file should not be deleted."
        )

    def test_rules_conf_has_content(self):
        """rules.conf must have some patterns defined."""
        with open(RULES_CONF, 'r') as f:
            content = f.read().strip()
        assert len(content) > 0, (
            f"File {RULES_CONF} is empty. "
            "The rules configuration file should contain regex patterns."
        )

    def test_rules_conf_contains_error_pattern(self):
        """rules.conf should contain a pattern to match ERROR: lines."""
        with open(RULES_CONF, 'r') as f:
            lines = [l.strip() for l in f.readlines() if l.strip()]

        # Check that there's a pattern that would match lines starting with ERROR:
        has_error_pattern = any("ERROR" in line for line in lines)
        assert has_error_pattern, (
            f"File {RULES_CONF} does not contain a pattern for ERROR lines. "
            "The rules should include a pattern to match ERROR: lines."
        )

    def test_rules_conf_contains_failure_pattern(self):
        """rules.conf should contain a pattern to match FAILURE: lines."""
        with open(RULES_CONF, 'r') as f:
            lines = [l.strip() for l in f.readlines() if l.strip()]

        has_failure_pattern = any("FAILURE" in line for line in lines)
        assert has_failure_pattern, (
            f"File {RULES_CONF} does not contain a pattern for FAILURE lines. "
            "The rules should include a pattern to match FAILURE: lines."
        )

    def test_rules_conf_contains_build_pattern(self):
        """rules.conf should contain a pattern to match BUILD lines."""
        with open(RULES_CONF, 'r') as f:
            lines = [l.strip() for l in f.readlines() if l.strip()]

        has_build_pattern = any("BUILD" in line for line in lines)
        assert has_build_pattern, (
            f"File {RULES_CONF} does not contain a pattern for BUILD lines. "
            "The rules should include a pattern to match the BUILD summary line."
        )


class TestSampleLogUnmodified:
    """Test that sample.log was not modified."""

    def test_sample_log_exists(self):
        """sample.log must still exist."""
        assert os.path.isfile(SAMPLE_LOG), (
            f"File {SAMPLE_LOG} does not exist. "
            "The sample log file should not be deleted."
        )

    def test_sample_log_has_substantial_content(self):
        """sample.log should still have around 50+ lines."""
        with open(SAMPLE_LOG, 'r') as f:
            lines = f.readlines()
        assert len(lines) >= 40, (
            f"File {SAMPLE_LOG} has only {len(lines)} lines. "
            "The sample log should not have been modified/truncated. "
            "Expected at least 40 lines."
        )

    def test_sample_log_still_contains_noise(self):
        """sample.log should still contain the noise lines (not filtered in place)."""
        with open(SAMPLE_LOG, 'r') as f:
            content = f.read()

        # The sample log should still have WARNING lines - it shouldn't be modified
        assert "WARNING:" in content, (
            f"File {SAMPLE_LOG} no longer contains WARNING: lines. "
            "The sample log should not be modified - only the rules.conf "
            "should be changed to fix the filtering."
        )


class TestFilterProducesCorrectOutput:
    """Test that running the filter produces the correct output."""

    def test_filter_script_runs_successfully(self):
        """Running filter.sh should succeed."""
        result = subprocess.run(
            [FILTER_SCRIPT, SAMPLE_LOG, FILTERED_OUTPUT],
            capture_output=True,
            text=True,
            cwd=BUILDBOT_DIR
        )
        assert result.returncode == 0, (
            f"filter.sh failed with return code {result.returncode}. "
            f"stderr: {result.stderr}"
        )

    def test_filtered_output_exists(self):
        """The filtered output file should be created."""
        # Run the filter first to ensure output exists
        subprocess.run(
            [FILTER_SCRIPT, SAMPLE_LOG, FILTERED_OUTPUT],
            capture_output=True,
            text=True,
            cwd=BUILDBOT_DIR
        )

        assert os.path.isfile(FILTERED_OUTPUT), (
            f"File {FILTERED_OUTPUT} was not created. "
            "The filter script should create the output file."
        )

    def test_filtered_output_has_exactly_4_lines(self):
        """The filtered output should have exactly 4 lines."""
        # Run the filter
        subprocess.run(
            [FILTER_SCRIPT, SAMPLE_LOG, FILTERED_OUTPUT],
            capture_output=True,
            text=True,
            cwd=BUILDBOT_DIR
        )

        with open(FILTERED_OUTPUT, 'r') as f:
            lines = [l for l in f.readlines() if l.strip()]

        assert len(lines) == 4, (
            f"Filtered output has {len(lines)} lines, expected exactly 4. "
            "The filter should produce exactly 4 lines: "
            "2 ERROR lines, 1 FAILURE line, and 1 BUILD line."
        )

    def test_filtered_output_contains_error_lines(self):
        """The filtered output should contain the ERROR: lines."""
        # Run the filter
        subprocess.run(
            [FILTER_SCRIPT, SAMPLE_LOG, FILTERED_OUTPUT],
            capture_output=True,
            text=True,
            cwd=BUILDBOT_DIR
        )

        with open(FILTERED_OUTPUT, 'r') as f:
            content = f.read()

        assert "ERROR:" in content, (
            "Filtered output does not contain ERROR: lines. "
            "The filter should include lines starting with ERROR:"
        )

        # Check for the specific error messages
        assert "resource color/primary not found" in content, (
            "Filtered output missing the resource not found error. "
            "Expected: ERROR: /res/layout/activity_main.xml:23: error: resource color/primary not found"
        )

        assert "AAPT2" in content, (
            "Filtered output missing the AAPT2 error. "
            "Expected: ERROR: AAPT2 aapt2-8.1.0 Daemon: Unexpected error during linking"
        )

    def test_filtered_output_contains_failure_line(self):
        """The filtered output should contain the FAILURE: line."""
        # Run the filter
        subprocess.run(
            [FILTER_SCRIPT, SAMPLE_LOG, FILTERED_OUTPUT],
            capture_output=True,
            text=True,
            cwd=BUILDBOT_DIR
        )

        with open(FILTERED_OUTPUT, 'r') as f:
            lines = f.readlines()

        failure_lines = [l for l in lines if l.startswith("FAILURE:")]
        assert len(failure_lines) == 1, (
            f"Filtered output has {len(failure_lines)} FAILURE: lines, expected 1. "
            "The filter should include exactly one line starting with FAILURE:"
        )

        assert "Build failed with an exception" in failure_lines[0], (
            "FAILURE line doesn't contain expected content. "
            "Expected: FAILURE: Build failed with an exception."
        )

    def test_filtered_output_contains_build_line(self):
        """The filtered output should contain the BUILD summary line."""
        # Run the filter
        subprocess.run(
            [FILTER_SCRIPT, SAMPLE_LOG, FILTERED_OUTPUT],
            capture_output=True,
            text=True,
            cwd=BUILDBOT_DIR
        )

        with open(FILTERED_OUTPUT, 'r') as f:
            lines = f.readlines()

        build_lines = [l for l in lines if l.startswith("BUILD")]
        assert len(build_lines) == 1, (
            f"Filtered output has {len(build_lines)} BUILD lines, expected 1. "
            "The filter should include exactly one line starting with BUILD"
        )

        assert "FAILED" in build_lines[0], (
            "BUILD line doesn't contain expected content. "
            "Expected: BUILD FAILED in 2m 34s"
        )


class TestNoNoiseInOutput:
    """Test that the filtered output does NOT contain noise lines."""

    def test_no_warning_lines_in_output(self):
        """The filtered output should NOT contain WARNING: lines."""
        # Run the filter
        subprocess.run(
            [FILTER_SCRIPT, SAMPLE_LOG, FILTERED_OUTPUT],
            capture_output=True,
            text=True,
            cwd=BUILDBOT_DIR
        )

        with open(FILTERED_OUTPUT, 'r') as f:
            lines = f.readlines()

        warning_lines = [l for l in lines if "WARNING:" in l]
        assert len(warning_lines) == 0, (
            f"Filtered output contains {len(warning_lines)} WARNING: lines. "
            "The filter should NOT include WARNING: lines - they are noise."
        )

    def test_no_note_lines_in_output(self):
        """The filtered output should NOT contain Note: lines."""
        # Run the filter
        subprocess.run(
            [FILTER_SCRIPT, SAMPLE_LOG, FILTERED_OUTPUT],
            capture_output=True,
            text=True,
            cwd=BUILDBOT_DIR
        )

        with open(FILTERED_OUTPUT, 'r') as f:
            lines = f.readlines()

        note_lines = [l for l in lines if "Note:" in l]
        assert len(note_lines) == 0, (
            f"Filtered output contains {len(note_lines)} Note: lines. "
            "The filter should NOT include Note: lines - they are noise."
        )

    def test_no_kotlin_warning_lines_in_output(self):
        """The filtered output should NOT contain w: (Kotlin warning) lines."""
        # Run the filter
        subprocess.run(
            [FILTER_SCRIPT, SAMPLE_LOG, FILTERED_OUTPUT],
            capture_output=True,
            text=True,
            cwd=BUILDBOT_DIR
        )

        with open(FILTERED_OUTPUT, 'r') as f:
            lines = f.readlines()

        w_lines = [l for l in lines if l.startswith("w:")]
        assert len(w_lines) == 0, (
            f"Filtered output contains {len(w_lines)} w: lines. "
            "The filter should NOT include w: (Kotlin warning) lines - they are noise."
        )

    def test_no_task_lines_in_output(self):
        """The filtered output should NOT contain '> Task' lines."""
        # Run the filter
        subprocess.run(
            [FILTER_SCRIPT, SAMPLE_LOG, FILTERED_OUTPUT],
            capture_output=True,
            text=True,
            cwd=BUILDBOT_DIR
        )

        with open(FILTERED_OUTPUT, 'r') as f:
            lines = f.readlines()

        task_lines = [l for l in lines if "> Task" in l]
        assert len(task_lines) == 0, (
            f"Filtered output contains {len(task_lines)} '> Task' lines. "
            "The filter should NOT include task progress lines - they are noise."
        )

    def test_grep_confirms_no_noise(self):
        """Use grep to confirm no noise patterns in output."""
        # Run the filter
        subprocess.run(
            [FILTER_SCRIPT, SAMPLE_LOG, FILTERED_OUTPUT],
            capture_output=True,
            text=True,
            cwd=BUILDBOT_DIR
        )

        # grep -c returns the count of matching lines
        result = subprocess.run(
            ["grep", "-c", "-E", "WARNING:|Note:|^w:"],
            stdin=open(FILTERED_OUTPUT, 'r'),
            capture_output=True,
            text=True
        )

        # grep -c returns 1 if no matches (and outputs "0")
        # We want 0 matches
        count = int(result.stdout.strip()) if result.stdout.strip() else 0
        assert count == 0, (
            f"Found {count} noise lines (WARNING:, Note:, or w:) in filtered output. "
            "The filter should not include any of these noise patterns."
        )


class TestLineCountVerification:
    """Additional verification using wc -l."""

    def test_wc_confirms_4_lines(self):
        """Use wc -l to confirm exactly 4 lines in output."""
        # Run the filter
        subprocess.run(
            [FILTER_SCRIPT, SAMPLE_LOG, FILTERED_OUTPUT],
            capture_output=True,
            text=True,
            cwd=BUILDBOT_DIR
        )

        result = subprocess.run(
            ["wc", "-l"],
            stdin=open(FILTERED_OUTPUT, 'r'),
            capture_output=True,
            text=True
        )

        line_count = int(result.stdout.strip().split()[0])
        assert line_count == 4, (
            f"wc -l reports {line_count} lines in filtered output, expected 4. "
            "The filter should produce exactly 4 lines: "
            "2 ERROR lines, 1 FAILURE line, and 1 BUILD line."
        )
