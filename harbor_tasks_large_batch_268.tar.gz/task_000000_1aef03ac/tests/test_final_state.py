# test_final_state.py
"""
Tests to validate the final state of the OS/filesystem after the student
has fixed the broken config file that was causing the audit script to fail.
"""

import os
import subprocess
import json
import hashlib
import pytest


# Base paths
HOME = "/home/user"
SERVICES_DIR = os.path.join(HOME, "services")
AUDIT_DIR = os.path.join(HOME, "audit")

# Expected config files
CONFIG_FILES = [
    os.path.join(SERVICES_DIR, "api", "config.yml"),
    os.path.join(SERVICES_DIR, "api", "routes.toml"),
    os.path.join(SERVICES_DIR, "worker", "config.yml"),
    os.path.join(SERVICES_DIR, "worker", "queues.toml"),
    os.path.join(SERVICES_DIR, "gateway", "config.yml"),
    os.path.join(SERVICES_DIR, "gateway", "upstream.toml"),
    os.path.join(SERVICES_DIR, "storage", "config.yml"),
    os.path.join(SERVICES_DIR, "storage", "buckets.toml"),
]

# Audit files
CHECK_PERMS_SCRIPT = os.path.join(AUDIT_DIR, "check_perms.py")
SCHEMA_FILE = os.path.join(AUDIT_DIR, "schema.json")

# The fixed config file
WORKER_CONFIG = os.path.join(SERVICES_DIR, "worker", "config.yml")


class TestAllConfigFilesStillExist:
    """Test that all 8 config files still exist after the fix."""

    @pytest.mark.parametrize("config_file", CONFIG_FILES)
    def test_config_file_exists(self, config_file):
        assert os.path.isfile(config_file), (
            f"Config file {config_file} no longer exists. "
            "All 8 config files must be preserved."
        )


class TestConfigFileCount:
    """Test that we still have exactly 8 config files."""

    def test_exactly_eight_config_files(self):
        """There should still be exactly 8 config files."""
        found_files = []
        for root, dirs, files in os.walk(SERVICES_DIR):
            for f in files:
                if f.endswith('.yml') or f.endswith('.toml'):
                    found_files.append(os.path.join(root, f))

        assert len(found_files) == 8, (
            f"Expected exactly 8 config files (.yml and .toml), "
            f"but found {len(found_files)}: {found_files}"
        )


class TestAuditScriptSucceeds:
    """Test that the audit script now runs successfully."""

    def test_check_perms_script_exits_zero(self):
        """The audit script should now exit with code 0."""
        result = subprocess.run(
            ["python3", CHECK_PERMS_SCRIPT],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"Expected audit script to exit with code 0 after fix, "
            f"but got exit code {result.returncode}. "
            f"stdout: {result.stdout}\nstderr: {result.stderr}"
        )

    def test_audit_complete_message_printed(self):
        """The audit script should print 'Audit complete' message."""
        result = subprocess.run(
            ["python3", CHECK_PERMS_SCRIPT],
            capture_output=True,
            text=True
        )
        combined_output = result.stdout + result.stderr
        assert "audit complete" in combined_output.lower(), (
            f"Expected audit script to print 'Audit complete: X issues found', "
            f"but got: {combined_output}"
        )

    def test_no_unexpected_key_error(self):
        """The audit script should no longer report unexpected key error."""
        result = subprocess.run(
            ["python3", CHECK_PERMS_SCRIPT],
            capture_output=True,
            text=True
        )
        combined_output = result.stdout + result.stderr
        assert "unexpected key" not in combined_output.lower(), (
            f"Audit script still reports 'unexpected key' error: {combined_output}"
        )


class TestMetadataKeyRemoved:
    """Test that the metadata key has been removed from worker config."""

    def test_metadata_key_not_in_worker_config(self):
        """The 'metadata' key should be removed from worker/config.yml."""
        with open(WORKER_CONFIG, 'r') as f:
            content = f.read()
        assert "metadata" not in content, (
            f"The 'metadata' key should be removed from {WORKER_CONFIG}, "
            "but it's still present."
        )

    def test_grep_metadata_returns_nonzero(self):
        """grep for 'metadata' in worker config should return exit code 1."""
        result = subprocess.run(
            ["grep", "-q", "metadata", WORKER_CONFIG],
            capture_output=True
        )
        assert result.returncode == 1, (
            f"Expected 'grep -q metadata {WORKER_CONFIG}' to return 1 (not found), "
            f"but got {result.returncode}. The metadata key should be removed."
        )


class TestPermissionsPreserved:
    """Test that permission rules in worker config are preserved."""

    def test_permissions_block_exists(self):
        """The permissions block should still exist."""
        with open(WORKER_CONFIG, 'r') as f:
            content = f.read()
        assert "permissions" in content, (
            f"The 'permissions' block is missing from {WORKER_CONFIG}. "
            "Permission rules must be preserved."
        )

    def test_admin_role_preserved(self):
        """The admin role should still be in permissions."""
        with open(WORKER_CONFIG, 'r') as f:
            content = f.read()
        assert "admin" in content, (
            f"The 'admin' role is missing from {WORKER_CONFIG}. "
            "Permission rules must be preserved."
        )

    def test_operator_role_preserved(self):
        """The operator role should still be in permissions."""
        with open(WORKER_CONFIG, 'r') as f:
            content = f.read()
        assert "operator" in content, (
            f"The 'operator' role is missing from {WORKER_CONFIG}. "
            "Permission rules must be preserved."
        )

    def test_grep_operator_returns_zero(self):
        """grep for 'operator' in worker config should return exit code 0."""
        result = subprocess.run(
            ["grep", "-q", "operator", WORKER_CONFIG],
            capture_output=True
        )
        assert result.returncode == 0, (
            f"Expected 'grep -q operator {WORKER_CONFIG}' to return 0 (found), "
            f"but got {result.returncode}. The operator role must be preserved."
        )

    def test_sensitive_paths_preserved(self):
        """The sensitive paths should still be in permissions."""
        with open(WORKER_CONFIG, 'r') as f:
            content = f.read()
        assert "/etc/worker" in content, (
            f"Path '/etc/worker' is missing from {WORKER_CONFIG}. "
            "Permission paths must be preserved."
        )
        assert "/var/secrets/worker" in content, (
            f"Path '/var/secrets/worker' is missing from {WORKER_CONFIG}. "
            "Permission paths must be preserved."
        )
        assert "/var/log/worker" in content, (
            f"Path '/var/log/worker' is missing from {WORKER_CONFIG}. "
            "Permission paths must be preserved."
        )

    def test_access_levels_preserved(self):
        """The access levels (read/write) should be preserved."""
        with open(WORKER_CONFIG, 'r') as f:
            content = f.read()
        assert "write" in content, (
            f"Access level 'write' is missing from {WORKER_CONFIG}. "
            "Permission access levels must be preserved."
        )
        assert "read" in content, (
            f"Access level 'read' is missing from {WORKER_CONFIG}. "
            "Permission access levels must be preserved."
        )

    def test_worker_config_parseable_yaml(self):
        """The worker config should still be valid YAML."""
        result = subprocess.run(
            ["python3", "-c", f"import yaml; yaml.safe_load(open('{WORKER_CONFIG}'))"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"Worker config {WORKER_CONFIG} is not valid YAML: {result.stderr}"
        )


class TestWorkerConfigStructure:
    """Test the structure of the fixed worker config."""

    def test_name_field_preserved(self):
        """The name field should be preserved."""
        with open(WORKER_CONFIG, 'r') as f:
            content = f.read()
        assert "worker-service" in content, (
            f"Service name 'worker-service' is missing from {WORKER_CONFIG}."
        )

    def test_version_field_preserved(self):
        """The version field should be preserved."""
        with open(WORKER_CONFIG, 'r') as f:
            content = f.read()
        assert "2.1.0" in content, (
            f"Version '2.1.0' is missing from {WORKER_CONFIG}."
        )

    def test_worker_config_has_valid_structure(self):
        """Parse the worker config and verify its structure."""
        import subprocess
        result = subprocess.run(
            ["python3", "-c", f"""
import yaml
with open('{WORKER_CONFIG}') as f:
    config = yaml.safe_load(f)
assert 'name' in config, "Missing 'name' key"
assert 'version' in config, "Missing 'version' key"
assert 'permissions' in config, "Missing 'permissions' key"
assert isinstance(config['permissions'], list), "'permissions' should be a list"
assert len(config['permissions']) >= 2, "Should have at least 2 permission entries"
print("Structure OK")
"""],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"Worker config structure validation failed: {result.stderr}"
        )


class TestAuditFilesUnmodified:
    """Test that audit script and schema were not modified."""

    def test_check_perms_script_exists(self):
        """The audit script should still exist."""
        assert os.path.isfile(CHECK_PERMS_SCRIPT), (
            f"Audit script {CHECK_PERMS_SCRIPT} no longer exists."
        )

    def test_schema_file_exists(self):
        """The schema file should still exist."""
        assert os.path.isfile(SCHEMA_FILE), (
            f"Schema file {SCHEMA_FILE} no longer exists."
        )

    def test_check_perms_script_is_python(self):
        """The audit script should still be a valid Python file."""
        result = subprocess.run(
            ["python3", "-m", "py_compile", CHECK_PERMS_SCRIPT],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"Audit script {CHECK_PERMS_SCRIPT} is not valid Python: {result.stderr}"
        )

    def test_schema_is_valid_json(self):
        """The schema file should still be valid JSON."""
        with open(SCHEMA_FILE, 'r') as f:
            try:
                schema = json.load(f)
            except json.JSONDecodeError as e:
                pytest.fail(f"Schema file {SCHEMA_FILE} is not valid JSON: {e}")
        assert isinstance(schema, dict), "Schema should be a JSON object"


class TestNoPermissionRulesAltered:
    """Test that no permission rules in any config were altered."""

    def test_worker_permissions_yaml_structure(self):
        """Verify the exact permission structure in worker config."""
        result = subprocess.run(
            ["python3", "-c", f"""
import yaml
with open('{WORKER_CONFIG}') as f:
    config = yaml.safe_load(f)

perms = config.get('permissions', [])
roles_found = set()
for p in perms:
    roles_found.add(p.get('role'))
    if p.get('role') == 'admin':
        assert p.get('access') == 'write', "admin should have write access"
        paths = p.get('paths', [])
        assert '/etc/worker' in paths, "admin should have /etc/worker path"
        assert '/var/secrets/worker' in paths, "admin should have /var/secrets/worker path"
    elif p.get('role') == 'operator':
        assert p.get('access') == 'read', "operator should have read access"
        paths = p.get('paths', [])
        assert '/var/log/worker' in paths, "operator should have /var/log/worker path"

assert 'admin' in roles_found, "admin role missing"
assert 'operator' in roles_found, "operator role missing"
print("Permissions structure verified")
"""],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"Permission structure verification failed: {result.stderr}\n{result.stdout}"
        )


class TestOnlyWorkerConfigChanged:
    """Test that only the worker config was changed (metadata removed)."""

    def test_worker_config_only_has_expected_top_level_keys(self):
        """Worker config should only have name, version, permissions at top level."""
        result = subprocess.run(
            ["python3", "-c", f"""
import yaml
with open('{WORKER_CONFIG}') as f:
    config = yaml.safe_load(f)

allowed_keys = {{'name', 'version', 'permissions'}}
actual_keys = set(config.keys())
unexpected = actual_keys - allowed_keys
if unexpected:
    print(f"Unexpected keys found: {{unexpected}}")
    exit(1)
print("Only expected keys present")
"""],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"Worker config has unexpected keys: {result.stdout}\n{result.stderr}"
        )
