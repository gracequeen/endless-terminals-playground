# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the task of fixing the broken config file.
"""

import os
import subprocess
import json
import pytest


# Base paths
HOME = "/home/user"
SERVICES_DIR = os.path.join(HOME, "services")
AUDIT_DIR = os.path.join(HOME, "audit")

# Expected config files
CONFIG_FILES = [
    os.path.join(SERVICES_DIR, "api", "config.yml"),
    os.path.join(SERVICES_DIR, "api", "routes.toml"),
    os.path.join(SERVICES_DIR, "worker", "config.yml"),
    os.path.join(SERVICES_DIR, "worker", "queues.toml"),
    os.path.join(SERVICES_DIR, "gateway", "config.yml"),
    os.path.join(SERVICES_DIR, "gateway", "upstream.toml"),
    os.path.join(SERVICES_DIR, "storage", "config.yml"),
    os.path.join(SERVICES_DIR, "storage", "buckets.toml"),
]

# Audit files
CHECK_PERMS_SCRIPT = os.path.join(AUDIT_DIR, "check_perms.py")
SCHEMA_FILE = os.path.join(AUDIT_DIR, "schema.json")

# The broken config file
BROKEN_CONFIG = os.path.join(SERVICES_DIR, "worker", "config.yml")


class TestDirectoryStructure:
    """Test that required directories exist."""

    def test_home_directory_exists(self):
        assert os.path.isdir(HOME), f"Home directory {HOME} does not exist"

    def test_services_directory_exists(self):
        assert os.path.isdir(SERVICES_DIR), f"Services directory {SERVICES_DIR} does not exist"

    def test_audit_directory_exists(self):
        assert os.path.isdir(AUDIT_DIR), f"Audit directory {AUDIT_DIR} does not exist"

    def test_api_subdirectory_exists(self):
        api_dir = os.path.join(SERVICES_DIR, "api")
        assert os.path.isdir(api_dir), f"API subdirectory {api_dir} does not exist"

    def test_worker_subdirectory_exists(self):
        worker_dir = os.path.join(SERVICES_DIR, "worker")
        assert os.path.isdir(worker_dir), f"Worker subdirectory {worker_dir} does not exist"

    def test_gateway_subdirectory_exists(self):
        gateway_dir = os.path.join(SERVICES_DIR, "gateway")
        assert os.path.isdir(gateway_dir), f"Gateway subdirectory {gateway_dir} does not exist"

    def test_storage_subdirectory_exists(self):
        storage_dir = os.path.join(SERVICES_DIR, "storage")
        assert os.path.isdir(storage_dir), f"Storage subdirectory {storage_dir} does not exist"


class TestConfigFilesExist:
    """Test that all 8 config files exist."""

    @pytest.mark.parametrize("config_file", CONFIG_FILES)
    def test_config_file_exists(self, config_file):
        assert os.path.isfile(config_file), f"Config file {config_file} does not exist"


class TestAuditFilesExist:
    """Test that audit script and schema exist."""

    def test_check_perms_script_exists(self):
        assert os.path.isfile(CHECK_PERMS_SCRIPT), f"Audit script {CHECK_PERMS_SCRIPT} does not exist"

    def test_schema_file_exists(self):
        assert os.path.isfile(SCHEMA_FILE), f"Schema file {SCHEMA_FILE} does not exist"

    def test_check_perms_script_is_readable(self):
        assert os.access(CHECK_PERMS_SCRIPT, os.R_OK), f"Audit script {CHECK_PERMS_SCRIPT} is not readable"

    def test_schema_file_is_readable(self):
        assert os.access(SCHEMA_FILE, os.R_OK), f"Schema file {SCHEMA_FILE} is not readable"


class TestBrokenConfigFile:
    """Test that the broken config file has the expected bug."""

    def test_worker_config_contains_metadata_key(self):
        """The worker config should contain the unexpected 'metadata' key that causes the bug."""
        with open(BROKEN_CONFIG, 'r') as f:
            content = f.read()
        assert "metadata" in content, (
            f"Expected {BROKEN_CONFIG} to contain 'metadata' key (the bug), but it doesn't. "
            "The initial state should have the broken config."
        )

    def test_worker_config_contains_permissions(self):
        """The worker config should have permissions that need to be preserved."""
        with open(BROKEN_CONFIG, 'r') as f:
            content = f.read()
        assert "permissions" in content, (
            f"Expected {BROKEN_CONFIG} to contain 'permissions' block"
        )
        assert "admin" in content, (
            f"Expected {BROKEN_CONFIG} to contain 'admin' role in permissions"
        )
        assert "operator" in content, (
            f"Expected {BROKEN_CONFIG} to contain 'operator' role in permissions"
        )

    def test_worker_config_has_expected_structure(self):
        """Verify the worker config has the expected YAML structure."""
        with open(BROKEN_CONFIG, 'r') as f:
            content = f.read()
        # Check for key elements that should be present
        assert "name:" in content or "name :" in content, "Missing 'name' field"
        assert "version:" in content or "version :" in content, "Missing 'version' field"
        assert "worker-service" in content, "Missing expected service name 'worker-service'"


class TestAuditScriptFailsInitially:
    """Test that the audit script currently fails (exit code 1)."""

    def test_check_perms_script_exits_with_error(self):
        """The audit script should exit with code 1 due to the unexpected key."""
        result = subprocess.run(
            ["python3", CHECK_PERMS_SCRIPT],
            capture_output=True,
            text=True
        )
        assert result.returncode == 1, (
            f"Expected audit script to exit with code 1 (due to bug), "
            f"but got exit code {result.returncode}. "
            f"stdout: {result.stdout}\nstderr: {result.stderr}"
        )

    def test_error_mentions_unexpected_key(self):
        """The error message should mention 'unexpected key'."""
        result = subprocess.run(
            ["python3", CHECK_PERMS_SCRIPT],
            capture_output=True,
            text=True
        )
        combined_output = result.stdout + result.stderr
        assert "unexpected key" in combined_output.lower(), (
            f"Expected error message to mention 'unexpected key', "
            f"but got: {combined_output}"
        )

    def test_error_mentions_metadata(self):
        """The error message should mention the 'metadata' key."""
        result = subprocess.run(
            ["python3", CHECK_PERMS_SCRIPT],
            capture_output=True,
            text=True
        )
        combined_output = result.stdout + result.stderr
        assert "metadata" in combined_output.lower(), (
            f"Expected error message to mention 'metadata', "
            f"but got: {combined_output}"
        )


class TestSchemaFileValid:
    """Test that the schema file is valid JSON."""

    def test_schema_is_valid_json(self):
        """The schema file should be valid JSON."""
        with open(SCHEMA_FILE, 'r') as f:
            try:
                schema = json.load(f)
            except json.JSONDecodeError as e:
                pytest.fail(f"Schema file {SCHEMA_FILE} is not valid JSON: {e}")
        assert isinstance(schema, dict), "Schema should be a JSON object"


class TestFilesAreWritable:
    """Test that config files are writable (so student can fix them)."""

    @pytest.mark.parametrize("config_file", CONFIG_FILES)
    def test_config_file_is_writable(self, config_file):
        assert os.access(config_file, os.W_OK), f"Config file {config_file} is not writable"


class TestPythonEnvironment:
    """Test that required Python packages are available."""

    def test_python3_available(self):
        """Python 3 should be available."""
        result = subprocess.run(
            ["python3", "--version"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "Python 3 is not available"

    def test_pyyaml_installed(self):
        """PyYAML package should be installed."""
        result = subprocess.run(
            ["python3", "-c", "import yaml"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"PyYAML is not installed. Error: {result.stderr}"
        )

    def test_toml_installed(self):
        """toml package should be installed."""
        result = subprocess.run(
            ["python3", "-c", "import toml"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"toml package is not installed. Error: {result.stderr}"
        )


class TestConfigFileCount:
    """Test that we have exactly 8 config files."""

    def test_exactly_eight_config_files(self):
        """There should be exactly 8 config files across the services directory."""
        found_files = []
        for root, dirs, files in os.walk(SERVICES_DIR):
            for f in files:
                if f.endswith('.yml') or f.endswith('.toml'):
                    found_files.append(os.path.join(root, f))

        assert len(found_files) == 8, (
            f"Expected exactly 8 config files (.yml and .toml), "
            f"but found {len(found_files)}: {found_files}"
        )
