# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the JSON to CSV conversion task.
"""

import json
import os
import shutil
import subprocess
import pytest


class TestInitialState:
    """Tests to verify the system is in the correct initial state."""

    def test_data_directory_exists(self):
        """Verify /home/user/data/ directory exists."""
        data_dir = "/home/user/data"
        assert os.path.isdir(data_dir), (
            f"Directory {data_dir} does not exist. "
            "The data directory must exist before the task can be performed."
        )

    def test_data_directory_is_writable(self):
        """Verify /home/user/data/ directory is writable."""
        data_dir = "/home/user/data"
        assert os.access(data_dir, os.W_OK), (
            f"Directory {data_dir} is not writable. "
            "The data directory must be writable to create the output CSV file."
        )

    def test_users_json_exists(self):
        """Verify /home/user/data/users.json exists."""
        json_file = "/home/user/data/users.json"
        assert os.path.isfile(json_file), (
            f"File {json_file} does not exist. "
            "The source JSON file must exist before the task can be performed."
        )

    def test_users_json_is_readable(self):
        """Verify /home/user/data/users.json is readable."""
        json_file = "/home/user/data/users.json"
        assert os.access(json_file, os.R_OK), (
            f"File {json_file} is not readable. "
            "The source JSON file must be readable to extract data from it."
        )

    def test_users_json_is_valid_json(self):
        """Verify /home/user/data/users.json contains valid JSON."""
        json_file = "/home/user/data/users.json"
        try:
            with open(json_file, 'r') as f:
                data = json.load(f)
        except json.JSONDecodeError as e:
            pytest.fail(
                f"File {json_file} contains invalid JSON: {e}. "
                "The source file must contain valid JSON data."
            )

    def test_users_json_is_array(self):
        """Verify /home/user/data/users.json contains a JSON array."""
        json_file = "/home/user/data/users.json"
        with open(json_file, 'r') as f:
            data = json.load(f)
        assert isinstance(data, list), (
            f"File {json_file} does not contain a JSON array. "
            f"Expected a list, got {type(data).__name__}."
        )

    def test_users_json_has_correct_number_of_records(self):
        """Verify /home/user/data/users.json contains exactly 4 user records."""
        json_file = "/home/user/data/users.json"
        with open(json_file, 'r') as f:
            data = json.load(f)
        assert len(data) == 4, (
            f"File {json_file} should contain 4 user records, "
            f"but contains {len(data)} records."
        )

    def test_users_json_has_required_fields(self):
        """Verify each user object has id, email, and created_at fields."""
        json_file = "/home/user/data/users.json"
        required_fields = ['id', 'email', 'created_at']
        with open(json_file, 'r') as f:
            data = json.load(f)

        for i, user in enumerate(data):
            for field in required_fields:
                assert field in user, (
                    f"User record at index {i} is missing required field '{field}'. "
                    f"Each user object must have: {required_fields}"
                )

    def test_users_json_has_expected_content(self):
        """Verify /home/user/data/users.json has the expected user data."""
        json_file = "/home/user/data/users.json"
        expected_data = [
            {"id": 1, "email": "alice@example.com", "name": "Alice Chen", "created_at": "2024-01-15", "role": "admin"},
            {"id": 2, "email": "bob@example.com", "name": "Bob Smith", "created_at": "2024-02-20", "role": "user"},
            {"id": 3, "email": "carol@example.com", "name": "Carol Jones", "created_at": "2024-03-08", "role": "user"},
            {"id": 4, "email": "dan@example.com", "name": "Dan Lee", "created_at": "2024-03-22", "role": "moderator"}
        ]

        with open(json_file, 'r') as f:
            data = json.load(f)

        assert data == expected_data, (
            f"File {json_file} does not contain the expected user data. "
            "The JSON content must match the expected initial state."
        )

    def test_users_csv_does_not_exist(self):
        """Verify /home/user/data/users.csv does not exist initially."""
        csv_file = "/home/user/data/users.csv"
        assert not os.path.exists(csv_file), (
            f"File {csv_file} already exists. "
            "The output CSV file should not exist before the task is performed."
        )

    def test_python3_available(self):
        """Verify Python 3 is available."""
        result = subprocess.run(
            ['python3', '--version'],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "Python 3 is not available. "
            "Python 3 must be installed to perform this task."
        )
        assert 'Python 3' in result.stdout, (
            f"Expected Python 3, but got: {result.stdout}. "
            "Python 3 must be available."
        )

    def test_jq_installed(self):
        """Verify jq is installed."""
        result = subprocess.run(
            ['which', 'jq'],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "jq is not installed. "
            "jq must be available as an alternative tool for JSON processing."
        )
