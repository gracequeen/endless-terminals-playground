# test_final_state.py
"""
Tests to validate the final state of the OS/filesystem after the student
has completed the JSON to CSV conversion task.
"""

import csv
import json
import os
import pytest


class TestFinalState:
    """Tests to verify the system is in the correct final state after task completion."""

    def test_users_csv_exists(self):
        """Verify /home/user/data/users.csv exists."""
        csv_file = "/home/user/data/users.csv"
        assert os.path.isfile(csv_file), (
            f"File {csv_file} does not exist. "
            "The CSV output file must be created by the task."
        )

    def test_users_csv_is_readable(self):
        """Verify /home/user/data/users.csv is readable."""
        csv_file = "/home/user/data/users.csv"
        assert os.access(csv_file, os.R_OK), (
            f"File {csv_file} is not readable. "
            "The CSV output file must be readable."
        )

    def test_users_csv_has_correct_header(self):
        """Verify /home/user/data/users.csv has the correct header row."""
        csv_file = "/home/user/data/users.csv"
        with open(csv_file, 'r', newline='') as f:
            reader = csv.reader(f)
            header = next(reader, None)

        assert header is not None, (
            f"File {csv_file} is empty or has no header row."
        )
        expected_header = ['id', 'email', 'created_at']
        assert header == expected_header, (
            f"CSV header is incorrect. Expected {expected_header}, got {header}. "
            "The header must be 'id,email,created_at' in that exact order."
        )

    def test_users_csv_has_correct_number_of_data_rows(self):
        """Verify /home/user/data/users.csv has exactly 4 data rows."""
        csv_file = "/home/user/data/users.csv"
        with open(csv_file, 'r', newline='') as f:
            reader = csv.reader(f)
            rows = list(reader)

        # Subtract 1 for header row
        data_row_count = len(rows) - 1
        assert data_row_count == 4, (
            f"CSV should have 4 data rows, but has {data_row_count}. "
            "There should be one row for each user in the JSON file."
        )

    def test_users_csv_has_correct_data(self):
        """Verify /home/user/data/users.csv contains the correct data values."""
        csv_file = "/home/user/data/users.csv"
        expected_data = [
            ['1', 'alice@example.com', '2024-01-15'],
            ['2', 'bob@example.com', '2024-02-20'],
            ['3', 'carol@example.com', '2024-03-08'],
            ['4', 'dan@example.com', '2024-03-22'],
        ]

        with open(csv_file, 'r', newline='') as f:
            reader = csv.reader(f)
            next(reader)  # Skip header
            data_rows = list(reader)

        assert len(data_rows) == len(expected_data), (
            f"Expected {len(expected_data)} data rows, got {len(data_rows)}."
        )

        for i, (actual, expected) in enumerate(zip(data_rows, expected_data)):
            assert actual == expected, (
                f"Data row {i + 1} is incorrect. Expected {expected}, got {actual}. "
                "Each row must have id, email, and created_at in the correct order."
            )

    def test_users_csv_contains_emails_from_json(self):
        """
        Anti-shortcut guard: Verify CSV contains the exact emails from the JSON source.
        This ensures the CSV was generated from the JSON file, not hardcoded.
        """
        json_file = "/home/user/data/users.json"
        csv_file = "/home/user/data/users.csv"

        # Get emails from JSON
        with open(json_file, 'r') as f:
            json_data = json.load(f)
        json_emails = {user['email'] for user in json_data}

        # Get emails from CSV
        with open(csv_file, 'r', newline='') as f:
            reader = csv.DictReader(f)
            csv_emails = {row['email'] for row in reader}

        assert json_emails == csv_emails, (
            f"CSV emails do not match JSON emails. "
            f"JSON emails: {json_emails}, CSV emails: {csv_emails}. "
            "The CSV must be generated from the JSON file."
        )

    def test_users_csv_column_order(self):
        """Verify columns are in the correct order: id, email, created_at."""
        csv_file = "/home/user/data/users.csv"

        with open(csv_file, 'r', newline='') as f:
            reader = csv.reader(f)
            header = next(reader)
            first_data_row = next(reader, None)

        assert first_data_row is not None, "CSV has no data rows."

        # Check that first column is numeric (id)
        assert first_data_row[0].isdigit(), (
            f"First column should be id (numeric), got '{first_data_row[0]}'. "
            "Column order must be: id, email, created_at"
        )

        # Check that second column contains @ (email)
        assert '@' in first_data_row[1], (
            f"Second column should be email (contains @), got '{first_data_row[1]}'. "
            "Column order must be: id, email, created_at"
        )

        # Check that third column is a date format (created_at)
        assert '-' in first_data_row[2] and len(first_data_row[2]) == 10, (
            f"Third column should be created_at (date format), got '{first_data_row[2]}'. "
            "Column order must be: id, email, created_at"
        )

    def test_users_json_unchanged(self):
        """Invariant: Verify /home/user/data/users.json is unchanged."""
        json_file = "/home/user/data/users.json"
        expected_data = [
            {"id": 1, "email": "alice@example.com", "name": "Alice Chen", "created_at": "2024-01-15", "role": "admin"},
            {"id": 2, "email": "bob@example.com", "name": "Bob Smith", "created_at": "2024-02-20", "role": "user"},
            {"id": 3, "email": "carol@example.com", "name": "Carol Jones", "created_at": "2024-03-08", "role": "user"},
            {"id": 4, "email": "dan@example.com", "name": "Dan Lee", "created_at": "2024-03-22", "role": "moderator"}
        ]

        assert os.path.isfile(json_file), (
            f"File {json_file} no longer exists. "
            "The source JSON file must remain unchanged."
        )

        with open(json_file, 'r') as f:
            actual_data = json.load(f)

        assert actual_data == expected_data, (
            f"File {json_file} has been modified. "
            "The source JSON file must remain unchanged after the task."
        )

    def test_csv_is_comma_separated(self):
        """Verify the CSV uses commas as field separators."""
        csv_file = "/home/user/data/users.csv"

        with open(csv_file, 'r') as f:
            first_line = f.readline().strip()

        # Header should have exactly 2 commas (3 fields)
        comma_count = first_line.count(',')
        assert comma_count == 2, (
            f"CSV header should have 2 commas (3 fields), but has {comma_count}. "
            f"Header line: '{first_line}'. Fields must be comma-separated."
        )

    def test_csv_rows_are_newline_separated(self):
        """Verify the CSV uses newlines to separate rows."""
        csv_file = "/home/user/data/users.csv"

        with open(csv_file, 'r') as f:
            content = f.read()

        # Should have at least 4 newlines (header + 4 data rows, possibly trailing)
        lines = content.strip().split('\n')
        assert len(lines) == 5, (
            f"CSV should have 5 lines (1 header + 4 data rows), but has {len(lines)}. "
            "Rows must be newline-separated."
        )
