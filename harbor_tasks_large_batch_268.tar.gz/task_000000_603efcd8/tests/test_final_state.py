# test_final_state.py
"""
Tests to validate the final state of the OS/filesystem after the student
has fixed the build pipeline bug.
"""

import os
import subprocess
import tarfile
import hashlib
import pytest

# Base paths
ARTIFACTS_DIR = "/home/user/artifacts"
CONFIG_DIR = os.path.join(ARTIFACTS_DIR, "config")
KEYS_DIR = os.path.join(ARTIFACTS_DIR, "keys")
SRC_DIR = os.path.join(ARTIFACTS_DIR, "src")
DIST_DIR = os.path.join(ARTIFACTS_DIR, "dist")


class TestPipelineSucceeds:
    """Test that the pipeline now runs successfully."""

    def test_pipeline_exits_zero(self):
        result = subprocess.run(
            ["python3", "pipeline.py"],
            cwd=ARTIFACTS_DIR,
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            f"pipeline.py should exit 0 after fix. Exit code: {result.returncode}\n" \
            f"stdout: {result.stdout}\nstderr: {result.stderr}"


class TestTarballCreated:
    """Test that the expected tarball is created in dist/."""

    def test_tarball_exists_with_correct_version(self):
        tarball_path = os.path.join(DIST_DIR, "myartifact-2.1.1.tar.gz")
        assert os.path.isfile(tarball_path), \
            f"Expected tarball {tarball_path} does not exist. " \
            f"Contents of {DIST_DIR}: {os.listdir(DIST_DIR) if os.path.isdir(DIST_DIR) else 'dir not found'}"

    def test_tarball_contains_data_txt(self):
        tarball_path = os.path.join(DIST_DIR, "myartifact-2.1.1.tar.gz")
        if not os.path.isfile(tarball_path):
            pytest.skip(f"Tarball {tarball_path} does not exist")

        with tarfile.open(tarball_path, "r:gz") as tar:
            names = tar.getnames()
            # Check that data.txt is in the tarball (may have path prefix)
            has_data_txt = any("data.txt" in name for name in names)
            assert has_data_txt, \
                f"Tarball should contain data.txt. Contents: {names}"

    def test_tarball_is_valid_gzip(self):
        tarball_path = os.path.join(DIST_DIR, "myartifact-2.1.1.tar.gz")
        if not os.path.isfile(tarball_path):
            pytest.skip(f"Tarball {tarball_path} does not exist")

        try:
            with tarfile.open(tarball_path, "r:gz") as tar:
                # Just try to list contents to verify it's valid
                tar.getnames()
        except Exception as e:
            pytest.fail(f"Tarball is not a valid gzip tar archive: {e}")


class TestConfigFilesPreserved:
    """Test that config files maintain required structure."""

    def test_base_toml_exists(self):
        base_toml_path = os.path.join(CONFIG_DIR, "base.toml")
        assert os.path.isfile(base_toml_path), \
            f"base.toml should still exist at {base_toml_path}"

    def test_base_toml_has_checksums_section(self):
        base_toml_path = os.path.join(CONFIG_DIR, "base.toml")
        with open(base_toml_path, 'r') as f:
            content = f.read()
        assert "[checksums]" in content, \
            "base.toml should still contain [checksums] section (structure must be preserved)"

    def test_signing_toml_unchanged(self):
        """signing.toml should not be modified as it's not the problem."""
        signing_toml_path = os.path.join(CONFIG_DIR, "signing.toml")
        assert os.path.isfile(signing_toml_path), \
            f"signing.toml should still exist at {signing_toml_path}"

        with open(signing_toml_path, 'r') as f:
            content = f.read()

        # Check key elements are still present
        assert "[signing]" in content, \
            "signing.toml should still contain [signing] section"
        assert "enabled = true" in content, \
            "signing.toml should still have enabled = true"
        assert "release.pem" in content, \
            "signing.toml should still reference release.pem"

    def test_env_yaml_exists(self):
        env_yaml_path = os.path.join(CONFIG_DIR, "env.yaml")
        assert os.path.isfile(env_yaml_path), \
            f"env.yaml should still exist at {env_yaml_path} (cannot be deleted)"

    def test_env_yaml_still_has_version_bump(self):
        """env.yaml must still contain version 2.1.1 for the tarball name to be correct."""
        env_yaml_path = os.path.join(CONFIG_DIR, "env.yaml")
        with open(env_yaml_path, 'r') as f:
            content = f.read()
        assert "2.1.1" in content, \
            "env.yaml must still contain version 2.1.1"

    def test_env_yaml_typo_fixed(self):
        """The typo 'algoritm' should be fixed to 'algorithm'."""
        env_yaml_path = os.path.join(CONFIG_DIR, "env.yaml")
        with open(env_yaml_path, 'r') as f:
            content = f.read()

        # The typo should no longer be present
        # Check for the misspelled key (without the 'h')
        assert "algoritm:" not in content, \
            "env.yaml should no longer contain the typo 'algoritm:' - it should be fixed to 'algorithm:'"


class TestOtherFilesUnchanged:
    """Test that files that shouldn't be modified remain intact."""

    def test_release_pem_exists(self):
        pem_path = os.path.join(KEYS_DIR, "release.pem")
        assert os.path.isfile(pem_path), \
            f"release.pem should still exist at {pem_path}"

    def test_data_txt_exists(self):
        data_path = os.path.join(SRC_DIR, "data.txt")
        assert os.path.isfile(data_path), \
            f"data.txt should still exist at {data_path}"

    def test_pipeline_py_exists(self):
        pipeline_path = os.path.join(ARTIFACTS_DIR, "pipeline.py")
        assert os.path.isfile(pipeline_path), \
            f"pipeline.py should still exist at {pipeline_path}"


class TestPipelineNotModified:
    """Test that pipeline.py was not modified (fix should be in config files)."""

    def test_pipeline_py_not_modified(self):
        """
        The fix should be in the config files, not in pipeline.py.
        We check that pipeline.py still contains the expected validation logic.
        """
        pipeline_path = os.path.join(ARTIFACTS_DIR, "pipeline.py")
        with open(pipeline_path, 'r') as f:
            content = f.read()

        # Check that key elements of the pipeline are still present
        # This ensures the agent didn't just gut the validation
        assert "deep_merge" in content or "merge" in content, \
            "pipeline.py should still contain merge functionality"
        assert "tomllib" in content or "toml" in content.lower(), \
            "pipeline.py should still use TOML parsing"
        assert "yaml" in content.lower(), \
            "pipeline.py should still use YAML parsing"

        # Check that validation logic is still present
        assert "checksums" in content.lower(), \
            "pipeline.py should still reference checksums in its logic"


class TestMergedConfigValid:
    """Test that the merged configuration is now valid."""

    def test_no_algoritm_typo_in_merged_config(self):
        """
        Run a check to ensure the merged config doesn't have the typo key.
        We do this by running the pipeline and checking it succeeds.
        """
        result = subprocess.run(
            ["python3", "pipeline.py"],
            cwd=ARTIFACTS_DIR,
            capture_output=True,
            text=True
        )

        # Should not contain the error about 'algoritm'
        combined_output = (result.stdout + result.stderr).lower()
        assert "algoritm" not in combined_output or result.returncode == 0, \
            f"The 'algoritm' typo error should be fixed. Output: {result.stdout + result.stderr}"


class TestDirectoryStructureIntact:
    """Test that directory structure is maintained."""

    def test_artifacts_directory_exists(self):
        assert os.path.isdir(ARTIFACTS_DIR), \
            f"Directory {ARTIFACTS_DIR} should exist"

    def test_config_directory_exists(self):
        assert os.path.isdir(CONFIG_DIR), \
            f"Directory {CONFIG_DIR} should exist"

    def test_keys_directory_exists(self):
        assert os.path.isdir(KEYS_DIR), \
            f"Directory {KEYS_DIR} should exist"

    def test_src_directory_exists(self):
        assert os.path.isdir(SRC_DIR), \
            f"Directory {SRC_DIR} should exist"

    def test_dist_directory_exists(self):
        assert os.path.isdir(DIST_DIR), \
            f"Directory {DIST_DIR} should exist"
