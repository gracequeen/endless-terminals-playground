# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the task of fixing the build pipeline.
"""

import os
import subprocess
import pytest

# Base paths
ARTIFACTS_DIR = "/home/user/artifacts"
CONFIG_DIR = os.path.join(ARTIFACTS_DIR, "config")
KEYS_DIR = os.path.join(ARTIFACTS_DIR, "keys")
SRC_DIR = os.path.join(ARTIFACTS_DIR, "src")
DIST_DIR = os.path.join(ARTIFACTS_DIR, "dist")


class TestDirectoryStructure:
    """Test that required directories exist."""

    def test_artifacts_directory_exists(self):
        assert os.path.isdir(ARTIFACTS_DIR), \
            f"Directory {ARTIFACTS_DIR} does not exist"

    def test_config_directory_exists(self):
        assert os.path.isdir(CONFIG_DIR), \
            f"Directory {CONFIG_DIR} does not exist"

    def test_keys_directory_exists(self):
        assert os.path.isdir(KEYS_DIR), \
            f"Directory {KEYS_DIR} does not exist"

    def test_src_directory_exists(self):
        assert os.path.isdir(SRC_DIR), \
            f"Directory {SRC_DIR} does not exist"

    def test_dist_directory_exists(self):
        assert os.path.isdir(DIST_DIR), \
            f"Directory {DIST_DIR} does not exist"

    def test_dist_directory_is_empty(self):
        contents = os.listdir(DIST_DIR)
        assert len(contents) == 0, \
            f"Directory {DIST_DIR} should be empty but contains: {contents}"


class TestRequiredFiles:
    """Test that required files exist."""

    def test_pipeline_py_exists(self):
        pipeline_path = os.path.join(ARTIFACTS_DIR, "pipeline.py")
        assert os.path.isfile(pipeline_path), \
            f"File {pipeline_path} does not exist"

    def test_base_toml_exists(self):
        base_toml_path = os.path.join(CONFIG_DIR, "base.toml")
        assert os.path.isfile(base_toml_path), \
            f"File {base_toml_path} does not exist"

    def test_env_yaml_exists(self):
        env_yaml_path = os.path.join(CONFIG_DIR, "env.yaml")
        assert os.path.isfile(env_yaml_path), \
            f"File {env_yaml_path} does not exist"

    def test_signing_toml_exists(self):
        signing_toml_path = os.path.join(CONFIG_DIR, "signing.toml")
        assert os.path.isfile(signing_toml_path), \
            f"File {signing_toml_path} does not exist"

    def test_release_pem_exists(self):
        pem_path = os.path.join(KEYS_DIR, "release.pem")
        assert os.path.isfile(pem_path), \
            f"File {pem_path} does not exist"

    def test_data_txt_exists(self):
        data_path = os.path.join(SRC_DIR, "data.txt")
        assert os.path.isfile(data_path), \
            f"File {data_path} does not exist"


class TestBaseTomlContent:
    """Test that base.toml has expected content."""

    def test_base_toml_has_package_section(self):
        base_toml_path = os.path.join(CONFIG_DIR, "base.toml")
        with open(base_toml_path, 'r') as f:
            content = f.read()
        assert "[package]" in content, \
            "base.toml should contain [package] section"

    def test_base_toml_has_checksums_section(self):
        base_toml_path = os.path.join(CONFIG_DIR, "base.toml")
        with open(base_toml_path, 'r') as f:
            content = f.read()
        assert "[checksums]" in content, \
            "base.toml should contain [checksums] section"

    def test_base_toml_has_algorithm_sha256(self):
        base_toml_path = os.path.join(CONFIG_DIR, "base.toml")
        with open(base_toml_path, 'r') as f:
            content = f.read()
        assert 'algorithm = "sha256"' in content, \
            "base.toml should contain algorithm = \"sha256\""


class TestEnvYamlContent:
    """Test that env.yaml has the typo that causes the bug."""

    def test_env_yaml_has_typo_algoritm(self):
        env_yaml_path = os.path.join(CONFIG_DIR, "env.yaml")
        with open(env_yaml_path, 'r') as f:
            content = f.read()
        assert "algoritm:" in content, \
            "env.yaml should contain the typo 'algoritm:' (missing 'h')"

    def test_env_yaml_has_version_bump(self):
        env_yaml_path = os.path.join(CONFIG_DIR, "env.yaml")
        with open(env_yaml_path, 'r') as f:
            content = f.read()
        assert "2.1.1" in content, \
            "env.yaml should contain version 2.1.1"

    def test_env_yaml_has_package_section(self):
        env_yaml_path = os.path.join(CONFIG_DIR, "env.yaml")
        with open(env_yaml_path, 'r') as f:
            content = f.read()
        assert "package:" in content, \
            "env.yaml should contain package: section"


class TestSigningTomlContent:
    """Test that signing.toml has expected content."""

    def test_signing_toml_has_signing_section(self):
        signing_toml_path = os.path.join(CONFIG_DIR, "signing.toml")
        with open(signing_toml_path, 'r') as f:
            content = f.read()
        assert "[signing]" in content, \
            "signing.toml should contain [signing] section"

    def test_signing_toml_has_key_path(self):
        signing_toml_path = os.path.join(CONFIG_DIR, "signing.toml")
        with open(signing_toml_path, 'r') as f:
            content = f.read()
        assert "release.pem" in content, \
            "signing.toml should reference release.pem"


class TestPythonEnvironment:
    """Test that required Python environment is available."""

    def test_python3_available(self):
        result = subprocess.run(
            ["python3", "--version"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            "python3 should be available"

    def test_python3_version_311_or_higher(self):
        result = subprocess.run(
            ["python3", "-c", "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "Failed to get Python version"
        version = result.stdout.strip()
        major, minor = map(int, version.split('.'))
        assert (major, minor) >= (3, 11), \
            f"Python 3.11+ required, but found {version}"

    def test_pyyaml_installed(self):
        result = subprocess.run(
            ["python3", "-c", "import yaml"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            "PyYAML should be installed (import yaml failed)"

    def test_tomllib_available(self):
        result = subprocess.run(
            ["python3", "-c", "import tomllib"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            "tomllib should be available (Python 3.11+ stdlib)"


class TestPipelineCurrentlyFails:
    """Test that the pipeline currently fails with the expected error."""

    def test_pipeline_exits_nonzero(self):
        result = subprocess.run(
            ["python3", "pipeline.py"],
            cwd=ARTIFACTS_DIR,
            capture_output=True,
            text=True
        )
        assert result.returncode != 0, \
            "pipeline.py should currently fail (exit non-zero) due to the bug"

    def test_pipeline_error_mentions_algoritm_or_checksum(self):
        result = subprocess.run(
            ["python3", "pipeline.py"],
            cwd=ARTIFACTS_DIR,
            capture_output=True,
            text=True
        )
        combined_output = result.stdout + result.stderr
        # The error should mention the invalid key or checksum issue
        assert ("algoritm" in combined_output.lower() or 
                "checksum" in combined_output.lower() or
                "invalid" in combined_output.lower()), \
            f"Error output should mention the checksum/algoritm issue. Got: {combined_output}"


class TestFilePermissions:
    """Test that files and directories have appropriate permissions."""

    def test_artifacts_dir_writable(self):
        assert os.access(ARTIFACTS_DIR, os.W_OK), \
            f"{ARTIFACTS_DIR} should be writable"

    def test_dist_dir_writable(self):
        assert os.access(DIST_DIR, os.W_OK), \
            f"{DIST_DIR} should be writable"

    def test_config_dir_writable(self):
        assert os.access(CONFIG_DIR, os.W_OK), \
            f"{CONFIG_DIR} should be writable"

    def test_env_yaml_writable(self):
        env_yaml_path = os.path.join(CONFIG_DIR, "env.yaml")
        assert os.access(env_yaml_path, os.W_OK), \
            f"{env_yaml_path} should be writable"

    def test_pipeline_py_readable(self):
        pipeline_path = os.path.join(ARTIFACTS_DIR, "pipeline.py")
        assert os.access(pipeline_path, os.R_OK), \
            f"{pipeline_path} should be readable"
