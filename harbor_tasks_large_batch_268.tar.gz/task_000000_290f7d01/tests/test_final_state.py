# test_final_state.py
"""
Tests to validate the final state of the operating system/filesystem
after the student has completed the tar extraction task.
"""

import os
import tarfile
import json
import hashlib
import pytest


class TestFinalState:
    """Test suite to verify the final state after tar extraction."""

    def test_destination_directory_exists(self):
        """Verify /home/user/datasets/neuroimaging_v3/ exists as a directory."""
        dest_dir = "/home/user/datasets/neuroimaging_v3"
        assert os.path.exists(dest_dir), (
            f"Directory {dest_dir} does not exist. "
            "The extraction destination directory must be created."
        )
        assert os.path.isdir(dest_dir), (
            f"{dest_dir} exists but is not a directory. "
            "The extraction should create a directory, not a file."
        )

    def test_readme_file_exists(self):
        """Verify README.txt exists in the extracted directory."""
        readme_path = "/home/user/datasets/neuroimaging_v3/README.txt"
        assert os.path.isfile(readme_path), (
            f"File {readme_path} does not exist. "
            "README.txt must be extracted from the archive."
        )

    def test_readme_file_contents(self):
        """Verify README.txt has correct contents."""
        readme_path = "/home/user/datasets/neuroimaging_v3/README.txt"
        expected_content = "NeuroImaging Dataset v3\nCollected 2024-01\n"

        with open(readme_path, 'r') as f:
            actual_content = f.read()

        assert actual_content == expected_content, (
            f"README.txt contents do not match expected. "
            f"Expected: {repr(expected_content)}, Got: {repr(actual_content)}"
        )

    def test_scans_directory_exists(self):
        """Verify scans/ subdirectory exists."""
        scans_dir = "/home/user/datasets/neuroimaging_v3/scans"
        assert os.path.isdir(scans_dir), (
            f"Directory {scans_dir} does not exist. "
            "The scans subdirectory must be extracted from the archive."
        )

    def test_subject_001_scan_exists(self):
        """Verify subject_001.nii.gz exists."""
        scan_path = "/home/user/datasets/neuroimaging_v3/scans/subject_001.nii.gz"
        assert os.path.isfile(scan_path), (
            f"File {scan_path} does not exist. "
            "subject_001.nii.gz must be extracted from the archive."
        )

    def test_subject_002_scan_exists(self):
        """Verify subject_002.nii.gz exists."""
        scan_path = "/home/user/datasets/neuroimaging_v3/scans/subject_002.nii.gz"
        assert os.path.isfile(scan_path), (
            f"File {scan_path} does not exist. "
            "subject_002.nii.gz must be extracted from the archive."
        )

    def test_subject_001_scan_size(self):
        """Verify subject_001.nii.gz has correct size (128 bytes)."""
        scan_path = "/home/user/datasets/neuroimaging_v3/scans/subject_001.nii.gz"
        actual_size = os.path.getsize(scan_path)
        assert actual_size == 128, (
            f"File {scan_path} has incorrect size. "
            f"Expected 128 bytes, got {actual_size} bytes."
        )

    def test_subject_002_scan_size(self):
        """Verify subject_002.nii.gz has correct size (128 bytes)."""
        scan_path = "/home/user/datasets/neuroimaging_v3/scans/subject_002.nii.gz"
        actual_size = os.path.getsize(scan_path)
        assert actual_size == 128, (
            f"File {scan_path} has incorrect size. "
            f"Expected 128 bytes, got {actual_size} bytes."
        )

    def test_metadata_json_exists(self):
        """Verify metadata.json exists in the extracted directory."""
        metadata_path = "/home/user/datasets/neuroimaging_v3/metadata.json"
        assert os.path.isfile(metadata_path), (
            f"File {metadata_path} does not exist. "
            "metadata.json must be extracted from the archive."
        )

    def test_metadata_json_contents(self):
        """Verify metadata.json has correct contents."""
        metadata_path = "/home/user/datasets/neuroimaging_v3/metadata.json"
        expected_data = {"version": "3.0", "subjects": 2}

        with open(metadata_path, 'r') as f:
            actual_data = json.load(f)

        assert actual_data == expected_data, (
            f"metadata.json contents do not match expected. "
            f"Expected: {expected_data}, Got: {actual_data}"
        )

    def test_tarball_still_exists(self):
        """Verify the original tarball still exists (archive preserved)."""
        tarball_path = "/home/user/datasets/neuroimaging_v3.tar.gz"
        assert os.path.isfile(tarball_path), (
            f"Tarball {tarball_path} no longer exists. "
            "The original archive must be preserved after extraction."
        )

    def test_tarball_is_still_valid(self):
        """Verify the tarball is still a valid tar.gz archive."""
        tarball_path = "/home/user/datasets/neuroimaging_v3.tar.gz"

        # Check gzip magic number
        with open(tarball_path, 'rb') as f:
            magic = f.read(2)
        assert magic == b'\x1f\x8b', (
            f"File {tarball_path} is no longer a valid gzip-compressed file. "
            "The archive may have been corrupted."
        )

        # Check it's still a valid tarfile
        assert tarfile.is_tarfile(tarball_path), (
            f"File {tarball_path} is no longer a valid tar archive. "
            "The archive may have been corrupted."
        )

    def test_tarball_contents_intact(self):
        """Verify the tarball still contains the expected structure."""
        tarball_path = "/home/user/datasets/neuroimaging_v3.tar.gz"
        expected_members = {
            "neuroimaging_v3/",
            "neuroimaging_v3/README.txt",
            "neuroimaging_v3/scans/",
            "neuroimaging_v3/scans/subject_001.nii.gz",
            "neuroimaging_v3/scans/subject_002.nii.gz",
            "neuroimaging_v3/metadata.json",
        }

        with tarfile.open(tarball_path, 'r:gz') as tar:
            actual_members = set()
            for member in tar.getmembers():
                name = member.name
                if member.isdir() and not name.endswith('/'):
                    name += '/'
                actual_members.add(name)

        missing = expected_members - actual_members
        assert not missing, (
            f"Archive is missing expected members: {missing}. "
            "The archive contents may have been corrupted."
        )

    def test_extracted_files_match_archive(self):
        """Verify extracted files match what's in the archive."""
        tarball_path = "/home/user/datasets/neuroimaging_v3.tar.gz"
        base_path = "/home/user/datasets"

        with tarfile.open(tarball_path, 'r:gz') as tar:
            for member in tar.getmembers():
                if member.isfile():
                    extracted_path = os.path.join(base_path, member.name)
                    assert os.path.isfile(extracted_path), (
                        f"Expected extracted file {extracted_path} does not exist."
                    )

                    # Compare file contents
                    archive_file = tar.extractfile(member)
                    archive_content = archive_file.read()

                    with open(extracted_path, 'rb') as f:
                        extracted_content = f.read()

                    assert extracted_content == archive_content, (
                        f"Extracted file {extracted_path} does not match archive contents. "
                        "The extraction may have been incomplete or corrupted."
                    )
