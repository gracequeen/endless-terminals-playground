# test_initial_state.py
"""
Tests to validate the initial state of the operating system/filesystem
before the student performs the tar extraction task.
"""

import os
import tarfile
import gzip
import json
import subprocess
import pytest


class TestInitialState:
    """Test suite to verify the initial state before tar extraction."""

    def test_datasets_directory_exists(self):
        """Verify /home/user/datasets/ directory exists."""
        datasets_dir = "/home/user/datasets"
        assert os.path.isdir(datasets_dir), (
            f"Directory {datasets_dir} does not exist. "
            "The datasets directory must exist before extraction."
        )

    def test_datasets_directory_is_writable(self):
        """Verify /home/user/datasets/ is writable."""
        datasets_dir = "/home/user/datasets"
        assert os.access(datasets_dir, os.W_OK), (
            f"Directory {datasets_dir} is not writable. "
            "The datasets directory must be writable for extraction."
        )

    def test_tarball_exists(self):
        """Verify the tarball /home/user/datasets/neuroimaging_v3.tar.gz exists."""
        tarball_path = "/home/user/datasets/neuroimaging_v3.tar.gz"
        assert os.path.isfile(tarball_path), (
            f"Tarball {tarball_path} does not exist. "
            "The source archive must exist before extraction."
        )

    def test_tarball_is_gzip_compressed(self):
        """Verify the tarball is a valid gzip-compressed file."""
        tarball_path = "/home/user/datasets/neuroimaging_v3.tar.gz"
        # Check gzip magic number
        with open(tarball_path, 'rb') as f:
            magic = f.read(2)
        assert magic == b'\x1f\x8b', (
            f"File {tarball_path} is not a valid gzip-compressed file. "
            "Expected gzip magic number (1f 8b)."
        )

    def test_tarball_is_valid_tar_archive(self):
        """Verify the tarball is a valid tar archive."""
        tarball_path = "/home/user/datasets/neuroimaging_v3.tar.gz"
        assert tarfile.is_tarfile(tarball_path), (
            f"File {tarball_path} is not a valid tar archive. "
            "The file must be a valid tar.gz archive."
        )

    def test_archive_contains_expected_structure(self):
        """Verify the archive contains the expected directory structure."""
        tarball_path = "/home/user/datasets/neuroimaging_v3.tar.gz"
        expected_members = {
            "neuroimaging_v3/",
            "neuroimaging_v3/README.txt",
            "neuroimaging_v3/scans/",
            "neuroimaging_v3/scans/subject_001.nii.gz",
            "neuroimaging_v3/scans/subject_002.nii.gz",
            "neuroimaging_v3/metadata.json",
        }

        with tarfile.open(tarball_path, 'r:gz') as tar:
            actual_members = set()
            for member in tar.getmembers():
                name = member.name
                if member.isdir() and not name.endswith('/'):
                    name += '/'
                actual_members.add(name)

        missing = expected_members - actual_members
        assert not missing, (
            f"Archive is missing expected members: {missing}. "
            "The archive must contain the complete neuroimaging_v3 structure."
        )

    def test_archive_readme_contents(self):
        """Verify README.txt in archive has correct contents."""
        tarball_path = "/home/user/datasets/neuroimaging_v3.tar.gz"
        expected_content = "NeuroImaging Dataset v3\nCollected 2024-01\n"

        with tarfile.open(tarball_path, 'r:gz') as tar:
            readme_member = tar.getmember("neuroimaging_v3/README.txt")
            readme_file = tar.extractfile(readme_member)
            actual_content = readme_file.read().decode('utf-8')

        assert actual_content == expected_content, (
            f"README.txt contents do not match expected. "
            f"Expected: {repr(expected_content)}, Got: {repr(actual_content)}"
        )

    def test_archive_metadata_json_contents(self):
        """Verify metadata.json in archive has correct contents."""
        tarball_path = "/home/user/datasets/neuroimaging_v3.tar.gz"
        expected_data = {"version": "3.0", "subjects": 2}

        with tarfile.open(tarball_path, 'r:gz') as tar:
            metadata_member = tar.getmember("neuroimaging_v3/metadata.json")
            metadata_file = tar.extractfile(metadata_member)
            actual_data = json.load(metadata_file)

        assert actual_data == expected_data, (
            f"metadata.json contents do not match expected. "
            f"Expected: {expected_data}, Got: {actual_data}"
        )

    def test_archive_scan_files_exist_and_have_correct_size(self):
        """Verify scan files in archive exist and are 128 bytes."""
        tarball_path = "/home/user/datasets/neuroimaging_v3.tar.gz"
        scan_files = [
            "neuroimaging_v3/scans/subject_001.nii.gz",
            "neuroimaging_v3/scans/subject_002.nii.gz",
        ]

        with tarfile.open(tarball_path, 'r:gz') as tar:
            for scan_file in scan_files:
                member = tar.getmember(scan_file)
                assert member.size == 128, (
                    f"Scan file {scan_file} has incorrect size. "
                    f"Expected 128 bytes, got {member.size} bytes."
                )

    def test_destination_directory_does_not_exist(self):
        """Verify /home/user/datasets/neuroimaging_v3/ does not exist yet."""
        dest_dir = "/home/user/datasets/neuroimaging_v3"
        assert not os.path.exists(dest_dir), (
            f"Directory {dest_dir} already exists. "
            "The destination directory should not exist before extraction."
        )

    def test_tar_command_available(self):
        """Verify tar command is available."""
        result = subprocess.run(
            ["which", "tar"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "tar command is not available. "
            "tar must be installed for this task."
        )

    def test_gzip_command_available(self):
        """Verify gzip command is available."""
        result = subprocess.run(
            ["which", "gzip"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "gzip command is not available. "
            "gzip must be installed for this task."
        )
