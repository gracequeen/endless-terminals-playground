# test_initial_state.py
"""
Tests to validate the initial state before the student converts Python 2 print statements to Python 3.
"""

import os
import subprocess
import pytest


class TestInitialState:
    """Validate the OS/filesystem state before the task is performed."""

    def test_legacy_directory_exists(self):
        """Verify /home/user/legacy/ directory exists."""
        legacy_dir = "/home/user/legacy"
        assert os.path.isdir(legacy_dir), f"Directory {legacy_dir} does not exist"

    def test_legacy_directory_is_writable(self):
        """Verify /home/user/legacy/ directory is writable."""
        legacy_dir = "/home/user/legacy"
        assert os.access(legacy_dir, os.W_OK), f"Directory {legacy_dir} is not writable"

    def test_report_script_exists(self):
        """Verify /home/user/legacy/report.py exists."""
        script_path = "/home/user/legacy/report.py"
        assert os.path.isfile(script_path), f"Script {script_path} does not exist"

    def test_report_script_is_readable(self):
        """Verify /home/user/legacy/report.py is readable."""
        script_path = "/home/user/legacy/report.py"
        assert os.access(script_path, os.R_OK), f"Script {script_path} is not readable"

    def test_report_script_is_writable(self):
        """Verify /home/user/legacy/report.py is writable."""
        script_path = "/home/user/legacy/report.py"
        assert os.access(script_path, os.W_OK), f"Script {script_path} is not writable"

    def test_python3_is_installed(self):
        """Verify python3 is installed and accessible."""
        result = subprocess.run(
            ["which", "python3"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "python3 is not installed or not in PATH"

    def test_python3_version_is_3_10_or_higher(self):
        """Verify python3 version is 3.10+."""
        result = subprocess.run(
            ["python3", "--version"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "Failed to get python3 version"
        # Output is like "Python 3.10.x"
        version_str = result.stdout.strip()
        parts = version_str.split()[1].split(".")
        major = int(parts[0])
        minor = int(parts[1])
        assert major == 3 and minor >= 10, f"python3 version should be 3.10+, got {version_str}"

    def test_python2_is_not_installed(self):
        """Verify python2 is NOT installed."""
        result = subprocess.run(
            ["which", "python2"],
            capture_output=True,
            text=True
        )
        assert result.returncode != 0, "python2 should NOT be installed"

    def test_script_contains_old_style_print_statements(self):
        """Verify the script contains Python 2 style print statements."""
        script_path = "/home/user/legacy/report.py"
        with open(script_path, "r") as f:
            content = f.read()

        # Check for old-style print statements (print followed by space and string/variable)
        result = subprocess.run(
            ["grep", "-E", r'print\s+"', script_path],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "Script should contain old-style Python 2 print statements like 'print \"...\"'"
        )

    def test_script_contains_expected_content(self):
        """Verify the script contains expected Python 2 code structure."""
        script_path = "/home/user/legacy/report.py"
        with open(script_path, "r") as f:
            content = f.read()

        # Check for key elements of the script
        assert "data = [1, 2, 3, 4, 5]" in content, "Script should contain 'data = [1, 2, 3, 4, 5]'"
        assert "Starting report generation" in content, "Script should contain 'Starting report generation'"
        assert "Report complete" in content, "Script should contain 'Report complete'"
        assert "for item in data:" in content, "Script should contain a for loop over data"
        assert "total" in content, "Script should contain 'total' variable"

    def test_script_fails_with_python3(self):
        """Verify that running the script with python3 currently fails with SyntaxError."""
        script_path = "/home/user/legacy/report.py"
        result = subprocess.run(
            ["python3", script_path],
            capture_output=True,
            text=True
        )
        assert result.returncode != 0, (
            "Script should fail when run with python3 (it has Python 2 syntax)"
        )
        # Check that it's a syntax error
        assert "SyntaxError" in result.stderr, (
            f"Script should fail with SyntaxError, got: {result.stderr}"
        )

    def test_script_is_approximately_correct_size(self):
        """Verify the script is approximately 25 lines as described."""
        script_path = "/home/user/legacy/report.py"
        with open(script_path, "r") as f:
            lines = f.readlines()

        # Allow some flexibility - between 10 and 40 lines
        assert 10 <= len(lines) <= 40, (
            f"Script should be approximately 25 lines, got {len(lines)} lines"
        )

    def test_script_has_multiple_print_statements(self):
        """Verify the script has 3-4 print statements as described."""
        script_path = "/home/user/legacy/report.py"
        with open(script_path, "r") as f:
            content = f.read()

        # Count lines starting with 'print ' (Python 2 style)
        print_count = content.count("\nprint ") + (1 if content.startswith("print ") else 0)
        # Also count if there's a print at the start after shebang
        lines = content.split("\n")
        print_lines = [line for line in lines if line.strip().startswith("print ")]

        assert len(print_lines) >= 3, (
            f"Script should have at least 3 print statements, found {len(print_lines)}"
        )
