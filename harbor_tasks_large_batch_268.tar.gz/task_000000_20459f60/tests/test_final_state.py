# test_final_state.py
"""
Tests to validate the final state after the student converts Python 2 print statements to Python 3.
"""

import os
import subprocess
import pytest


class TestFinalState:
    """Validate the OS/filesystem state after the task is completed."""

    def test_script_file_still_exists(self):
        """Verify /home/user/legacy/report.py still exists."""
        script_path = "/home/user/legacy/report.py"
        assert os.path.isfile(script_path), f"Script {script_path} should still exist"

    def test_script_runs_successfully_with_python3(self):
        """Verify that python3 /home/user/legacy/report.py exits with code 0."""
        script_path = "/home/user/legacy/report.py"
        result = subprocess.run(
            ["python3", script_path],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"Script should exit with code 0 when run with python3.\n"
            f"Exit code: {result.returncode}\n"
            f"Stdout: {result.stdout}\n"
            f"Stderr: {result.stderr}"
        )

    def test_output_contains_starting_message(self):
        """Verify output contains 'Starting report generation'."""
        script_path = "/home/user/legacy/report.py"
        result = subprocess.run(
            ["python3", script_path],
            capture_output=True,
            text=True
        )
        assert "Starting report generation" in result.stdout, (
            f"Output should contain 'Starting report generation'.\n"
            f"Actual output: {result.stdout}"
        )

    def test_output_contains_total_15(self):
        """Verify output contains 'Total: 15' (sum of 1+2+3+4+5)."""
        script_path = "/home/user/legacy/report.py"
        result = subprocess.run(
            ["python3", script_path],
            capture_output=True,
            text=True
        )
        # Check for Total: 15 with some flexibility for spacing
        assert "Total:" in result.stdout and "15" in result.stdout, (
            f"Output should contain 'Total: 15'.\n"
            f"Actual output: {result.stdout}"
        )

    def test_output_contains_report_complete(self):
        """Verify output contains 'Report complete'."""
        script_path = "/home/user/legacy/report.py"
        result = subprocess.run(
            ["python3", script_path],
            capture_output=True,
            text=True
        )
        assert "Report complete" in result.stdout, (
            f"Output should contain 'Report complete'.\n"
            f"Actual output: {result.stdout}"
        )

    def test_no_old_style_print_statements_remain(self):
        """Verify no old-style Python 2 print statements remain in the script."""
        script_path = "/home/user/legacy/report.py"
        result = subprocess.run(
            ["grep", "-E", r'print\s+"', script_path],
            capture_output=True,
            text=True
        )
        assert result.returncode != 0, (
            f"Old-style print statements (print \"...\") should not remain in the script.\n"
            f"Found: {result.stdout}"
        )

    def test_script_contains_print_function_calls(self):
        """Verify the script contains print function calls (not removed entirely)."""
        script_path = "/home/user/legacy/report.py"
        with open(script_path, "r") as f:
            content = f.read()

        # Check for print( which indicates function call syntax
        assert "print(" in content, (
            "Script should contain print function calls (print(...)) to produce output.\n"
            "The script should not have all prints removed or replaced with a stub."
        )

    def test_script_logic_preserved_data_list(self):
        """Verify the script still contains the original data list."""
        script_path = "/home/user/legacy/report.py"
        with open(script_path, "r") as f:
            content = f.read()

        assert "data" in content and "[1, 2, 3, 4, 5]" in content.replace(" ", "").replace("\n", "") or \
               "data = [1, 2, 3, 4, 5]" in content or \
               "[1,2,3,4,5]" in content.replace(" ", ""), (
            "Script should still contain the original data list [1, 2, 3, 4, 5].\n"
            "The script logic should remain unchanged."
        )

    def test_script_logic_preserved_loop(self):
        """Verify the script still contains a for loop."""
        script_path = "/home/user/legacy/report.py"
        with open(script_path, "r") as f:
            content = f.read()

        assert "for" in content and "in" in content, (
            "Script should still contain a for loop.\n"
            "The script logic should remain unchanged."
        )

    def test_script_logic_preserved_total_variable(self):
        """Verify the script still uses a total variable for calculation."""
        script_path = "/home/user/legacy/report.py"
        with open(script_path, "r") as f:
            content = f.read()

        assert "total" in content, (
            "Script should still contain 'total' variable.\n"
            "The script logic should remain unchanged."
        )

    def test_output_contains_processed_items(self):
        """Verify output shows processed items from the loop."""
        script_path = "/home/user/legacy/report.py"
        result = subprocess.run(
            ["python3", script_path],
            capture_output=True,
            text=True
        )
        # The original script prints "Processed item:" for each item
        # Check that at least some processing output exists
        output = result.stdout
        assert "Processed" in output or "item" in output.lower(), (
            f"Output should show processed items from the loop.\n"
            f"Actual output: {output}"
        )

    def test_multiple_print_function_calls_exist(self):
        """Verify the script has multiple print function calls (3+)."""
        script_path = "/home/user/legacy/report.py"
        with open(script_path, "r") as f:
            content = f.read()

        # Count print( occurrences
        print_count = content.count("print(")
        assert print_count >= 3, (
            f"Script should have at least 3 print function calls, found {print_count}.\n"
            "The original script had 4 print statements that should be converted."
        )

    def test_script_is_valid_python3_syntax(self):
        """Verify the script has valid Python 3 syntax by compiling it."""
        script_path = "/home/user/legacy/report.py"
        with open(script_path, "r") as f:
            content = f.read()

        try:
            compile(content, script_path, "exec")
        except SyntaxError as e:
            pytest.fail(f"Script has invalid Python 3 syntax: {e}")
