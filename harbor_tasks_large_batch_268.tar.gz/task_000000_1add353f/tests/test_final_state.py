# test_final_state.py
"""
Tests to validate the final state after the fraud log extraction task is completed.
Verifies that the extraction produces exactly 4,218 lines with proper format.
"""

import os
import subprocess
import pytest
import re
from pathlib import Path


HOME_DIR = Path("/home/user")
ARCHIVES_DIR = HOME_DIR / "archives"
RESULTS_FILE = HOME_DIR / "results.txt"


class TestResultsFileExists:
    """Verify the results file exists and is accessible."""

    def test_results_file_exists(self):
        """Results file must exist after extraction."""
        assert RESULTS_FILE.exists(), f"Results file {RESULTS_FILE} does not exist - extraction may not have been run"

    def test_results_file_is_regular_file(self):
        """Results file must be a regular file."""
        assert RESULTS_FILE.is_file(), f"{RESULTS_FILE} is not a regular file"

    def test_results_file_is_readable(self):
        """Results file must be readable."""
        assert os.access(RESULTS_FILE, os.R_OK), f"{RESULTS_FILE} is not readable"

    def test_results_file_is_not_empty(self):
        """Results file must not be empty."""
        assert RESULTS_FILE.stat().st_size > 0, f"{RESULTS_FILE} is empty"


class TestResultsLineCount:
    """Verify the exact line count requirement."""

    def test_exact_line_count(self):
        """Results file must contain exactly 4,218 lines."""
        result = subprocess.run(
            ["wc", "-l"],
            stdin=open(RESULTS_FILE, 'r'),
            capture_output=True,
            text=True
        )
        line_count = int(result.stdout.strip().split()[0])
        assert line_count == 4218, f"Expected exactly 4218 lines, found {line_count}. " \
            f"Extraction is {'missing matches' if line_count < 4218 else 'has extra/duplicate matches'}"

    def test_line_count_via_python(self):
        """Double-check line count using Python."""
        with open(RESULTS_FILE, 'r') as f:
            lines = f.readlines()
        # Filter out any completely empty lines at the end
        non_empty_lines = [l for l in lines if l.strip()]
        assert len(non_empty_lines) == 4218, f"Expected 4218 non-empty lines, found {len(non_empty_lines)}"


class TestTimestampFormat:
    """Verify all lines contain properly formatted timestamps."""

    def test_all_lines_have_timestamps(self):
        """Every line must contain a timestamp in YYYY-MM-DD HH:MM:SS format."""
        timestamp_pattern = re.compile(r'\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}')

        with open(RESULTS_FILE, 'r') as f:
            lines = [l.strip() for l in f.readlines() if l.strip()]

        lines_without_timestamp = []
        for i, line in enumerate(lines, 1):
            if not timestamp_pattern.search(line):
                lines_without_timestamp.append((i, line[:100]))

        assert len(lines_without_timestamp) == 0, \
            f"Found {len(lines_without_timestamp)} lines without valid timestamps. " \
            f"First few: {lines_without_timestamp[:5]}"

    def test_timestamp_count_matches_line_count(self):
        """Number of timestamps should equal 4218."""
        result = subprocess.run(
            ["grep", "-cP", r"\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}"],
            stdin=open(RESULTS_FILE, 'r'),
            capture_output=True,
            text=True
        )
        # grep -c returns the count
        timestamp_count = int(result.stdout.strip()) if result.returncode == 0 else 0
        assert timestamp_count == 4218, f"Expected 4218 timestamps, found {timestamp_count}"

    def test_timestamps_are_march_2024(self):
        """All timestamps should be from March 2024."""
        march_2024_pattern = re.compile(r'2024-03-\d{2} \d{2}:\d{2}:\d{2}')

        with open(RESULTS_FILE, 'r') as f:
            lines = [l.strip() for l in f.readlines() if l.strip()]

        non_march_lines = []
        for i, line in enumerate(lines, 1):
            if not march_2024_pattern.search(line):
                non_march_lines.append((i, line[:100]))

        assert len(non_march_lines) == 0, \
            f"Found {len(non_march_lines)} lines with timestamps not from March 2024. " \
            f"First few: {non_march_lines[:5]}"


class TestFRDCodes:
    """Verify all lines contain FRD codes."""

    def test_all_lines_have_frd_codes(self):
        """Every line must contain an FRD code (FRD-NNNNN format)."""
        frd_pattern = re.compile(r'FRD-\d+')

        with open(RESULTS_FILE, 'r') as f:
            lines = [l.strip() for l in f.readlines() if l.strip()]

        lines_without_frd = []
        for i, line in enumerate(lines, 1):
            if not frd_pattern.search(line):
                lines_without_frd.append((i, line[:100]))

        assert len(lines_without_frd) == 0, \
            f"Found {len(lines_without_frd)} lines without FRD codes. " \
            f"First few: {lines_without_frd[:5]}"

    def test_frd_code_count_matches_line_count(self):
        """Number of FRD codes should equal 4218."""
        result = subprocess.run(
            ["grep", "-cP", r"FRD-\d+"],
            stdin=open(RESULTS_FILE, 'r'),
            capture_output=True,
            text=True
        )
        frd_count = int(result.stdout.strip()) if result.returncode == 0 else 0
        assert frd_count == 4218, f"Expected 4218 FRD codes, found {frd_count}"


class TestSourceFilePaths:
    """Verify all lines contain source file paths."""

    def test_all_lines_have_file_paths(self):
        """Every line must contain a source file path from /home/user/archives/."""
        path_pattern = re.compile(r'/home/user/archives/')

        with open(RESULTS_FILE, 'r') as f:
            lines = [l.strip() for l in f.readlines() if l.strip()]

        lines_without_path = []
        for i, line in enumerate(lines, 1):
            if not path_pattern.search(line):
                lines_without_path.append((i, line[:100]))

        assert len(lines_without_path) == 0, \
            f"Found {len(lines_without_path)} lines without source file paths. " \
            f"First few: {lines_without_path[:5]}"

    def test_file_path_count_matches_line_count(self):
        """Number of file paths should equal 4218."""
        result = subprocess.run(
            ["grep", "-c", "/home/user/archives/"],
            stdin=open(RESULTS_FILE, 'r'),
            capture_output=True,
            text=True
        )
        path_count = int(result.stdout.strip()) if result.returncode == 0 else 0
        assert path_count == 4218, f"Expected 4218 file paths, found {path_count}"

    def test_paths_reference_2024_03(self):
        """File paths should reference the 2024/03 directory structure."""
        with open(RESULTS_FILE, 'r') as f:
            lines = [l.strip() for l in f.readlines() if l.strip()]

        # Check a sample of lines for 2024/03 in the path
        sample_size = min(100, len(lines))
        lines_with_correct_path = 0
        for line in lines[:sample_size]:
            if '2024/03' in line or '2024-03' in line:
                lines_with_correct_path += 1

        # At least 90% of sampled lines should have the correct path structure
        assert lines_with_correct_path >= sample_size * 0.9, \
            f"Only {lines_with_correct_path}/{sample_size} sampled lines reference 2024/03 path"


class TestLineCompleteness:
    """Verify each line has all three required components."""

    def test_all_components_present_on_each_line(self):
        """Each line must have timestamp, FRD code, and file path."""
        timestamp_pattern = re.compile(r'\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}')
        frd_pattern = re.compile(r'FRD-\d+')
        path_pattern = re.compile(r'/home/user/archives/[^\s]+')

        with open(RESULTS_FILE, 'r') as f:
            lines = [l.strip() for l in f.readlines() if l.strip()]

        incomplete_lines = []
        for i, line in enumerate(lines, 1):
            has_timestamp = bool(timestamp_pattern.search(line))
            has_frd = bool(frd_pattern.search(line))
            has_path = bool(path_pattern.search(line))

            if not (has_timestamp and has_frd and has_path):
                missing = []
                if not has_timestamp:
                    missing.append("timestamp")
                if not has_frd:
                    missing.append("FRD code")
                if not has_path:
                    missing.append("file path")
                incomplete_lines.append((i, missing, line[:80]))

        assert len(incomplete_lines) == 0, \
            f"Found {len(incomplete_lines)} incomplete lines. First few: {incomplete_lines[:5]}"


class TestArchivesUnchanged:
    """Verify the archives directory was not modified."""

    def test_archives_directory_exists(self):
        """Archives directory must still exist."""
        assert ARCHIVES_DIR.exists(), f"Archives directory {ARCHIVES_DIR} no longer exists!"

    def test_archives_structure_intact(self):
        """Archives directory structure should be intact."""
        march_2024_path = ARCHIVES_DIR / "2024" / "03"
        assert march_2024_path.exists(), f"Archives structure damaged - {march_2024_path} missing"

    def test_no_results_file_in_archives(self):
        """No results.txt should be created inside archives."""
        result = subprocess.run(
            ["find", str(ARCHIVES_DIR), "-name", "results.txt", "-type", "f"],
            capture_output=True,
            text=True
        )
        found_files = [f for f in result.stdout.strip().split('\n') if f]
        assert len(found_files) == 0, f"Found results.txt inside archives: {found_files}"

    def test_log_file_count_unchanged(self):
        """Number of log files should be approximately the same as initial state (~847)."""
        result = subprocess.run(
            ["bash", "-c",
             f'find {ARCHIVES_DIR} -path "*2024/03*" \\( -name "*.log" -o -name "*.log.gz" \\) -type f | wc -l'],
            capture_output=True,
            text=True
        )
        count = int(result.stdout.strip())
        assert 800 <= count <= 900, f"Log file count changed unexpectedly: {count} (expected ~847)"


class TestGzipFilesProcessed:
    """Verify that gzipped files were properly processed (the main bug fix)."""

    def test_results_include_gz_file_sources(self):
        """Results should include matches from .log.gz files."""
        with open(RESULTS_FILE, 'r') as f:
            content = f.read()

        gz_references = content.count('.log.gz')
        # Since ~60% of files are .log.gz and they should now be processed
        # we expect a significant number of .log.gz references
        assert gz_references > 100, \
            f"Only {gz_references} references to .log.gz files found. " \
            f"Gzipped files may not be properly processed."

    def test_results_include_plain_log_sources(self):
        """Results should include matches from plain .log files."""
        with open(RESULTS_FILE, 'r') as f:
            content = f.read()

        # Count .log but not .log.gz
        log_pattern = re.compile(r'\.log(?!\.gz)')
        log_matches = len(log_pattern.findall(content))

        assert log_matches > 100, \
            f"Only {log_matches} references to plain .log files found. " \
            f"Plain log files may not be properly processed."


class TestNoShortcuts:
    """Anti-shortcut tests to ensure legitimate extraction."""

    def test_results_not_hardcoded(self):
        """Results should contain varied content, not hardcoded data."""
        with open(RESULTS_FILE, 'r') as f:
            lines = [l.strip() for l in f.readlines() if l.strip()]

        # Check for variety in FRD codes
        frd_pattern = re.compile(r'FRD-(\d+)')
        frd_codes = set()
        for line in lines:
            match = frd_pattern.search(line)
            if match:
                frd_codes.add(match.group(1))

        # Should have many unique FRD codes
        assert len(frd_codes) > 100, \
            f"Only {len(frd_codes)} unique FRD codes found - results may be fabricated"

    def test_variety_in_timestamps(self):
        """Results should have varied timestamps across March 2024."""
        timestamp_pattern = re.compile(r'2024-03-(\d{2})')

        with open(RESULTS_FILE, 'r') as f:
            lines = f.readlines()

        days = set()
        for line in lines:
            match = timestamp_pattern.search(line)
            if match:
                days.add(int(match.group(1)))

        # Should have entries from multiple days in March
        assert len(days) >= 10, \
            f"Only {len(days)} different days found in timestamps - expected variety across March"

    def test_variety_in_file_paths(self):
        """Results should reference multiple different source files."""
        path_pattern = re.compile(r'(/home/user/archives/[^\s:]+)')

        with open(RESULTS_FILE, 'r') as f:
            lines = f.readlines()

        unique_paths = set()
        for line in lines:
            match = path_pattern.search(line)
            if match:
                unique_paths.add(match.group(1))

        # Should have many unique source files
        assert len(unique_paths) > 50, \
            f"Only {len(unique_paths)} unique file paths found - expected many source files"
