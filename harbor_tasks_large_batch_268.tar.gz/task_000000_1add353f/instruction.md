I'm trying to extract timestamps from our archived logs for a fraud investigation — need everything from 2024-03 specifically. The logs are under /home/user/archives, nested pretty deep in dated folders, mix of .log and .log.gz files. I wrote a quick pipeline at /home/user/extract.sh that finds the right files and greps for the fraud patterns we're tracking (FRD-[0-9]+ codes), but it's giving me way fewer hits than I know exist.

Running it manually on individual files I can see matches, but the batch extraction is missing most of them. Thought maybe it was a quoting issue with the filenames (some have spaces from the old windows migration) but I tried -print0 and it's still weird. Output goes to /home/user/results.txt — should have thousands of lines based on our sample counts, getting like 200.

Need the full extraction working. The auditors want every FRD code from March 2024 with its timestamp and source file path.
