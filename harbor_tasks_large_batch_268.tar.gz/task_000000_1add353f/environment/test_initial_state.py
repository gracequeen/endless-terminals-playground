# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the fraud log extraction task.
"""

import os
import subprocess
import pytest
import gzip
import re
from pathlib import Path


HOME_DIR = Path("/home/user")
ARCHIVES_DIR = HOME_DIR / "archives"
EXTRACT_SCRIPT = HOME_DIR / "extract.sh"


class TestArchivesDirectoryStructure:
    """Verify the archives directory exists with expected structure."""

    def test_archives_directory_exists(self):
        """Archives directory must exist."""
        assert ARCHIVES_DIR.exists(), f"Archives directory {ARCHIVES_DIR} does not exist"
        assert ARCHIVES_DIR.is_dir(), f"{ARCHIVES_DIR} is not a directory"

    def test_archives_is_readable(self):
        """Archives directory must be readable."""
        assert os.access(ARCHIVES_DIR, os.R_OK), f"{ARCHIVES_DIR} is not readable"

    def test_2024_03_path_exists(self):
        """There should be a 2024/03 path structure in archives."""
        march_2024_path = ARCHIVES_DIR / "2024" / "03"
        assert march_2024_path.exists(), f"Expected path {march_2024_path} does not exist"
        assert march_2024_path.is_dir(), f"{march_2024_path} is not a directory"

    def test_nested_region_directories_exist(self):
        """There should be region subdirectories under 2024/03."""
        march_2024_path = ARCHIVES_DIR / "2024" / "03"
        subdirs = [d for d in march_2024_path.iterdir() if d.is_dir()]
        assert len(subdirs) > 0, f"No subdirectories found under {march_2024_path}"

    def test_directory_with_space_exists(self):
        """At least one directory with a space in the name should exist (Windows migration artifact)."""
        result = subprocess.run(
            ["find", str(ARCHIVES_DIR), "-type", "d", "-name", "* *"],
            capture_output=True,
            text=True
        )
        dirs_with_spaces = [d for d in result.stdout.strip().split('\n') if d]
        assert len(dirs_with_spaces) > 0, "No directories with spaces found - expected Windows migration artifacts"


class TestLogFiles:
    """Verify log files exist in expected formats."""

    def test_log_files_exist(self):
        """Plain .log files should exist in the archives."""
        result = subprocess.run(
            ["find", str(ARCHIVES_DIR), "-path", "*2024/03*", "-name", "*.log", "-type", "f"],
            capture_output=True,
            text=True
        )
        log_files = [f for f in result.stdout.strip().split('\n') if f]
        assert len(log_files) > 0, "No .log files found in 2024/03 path"

    def test_log_gz_files_exist(self):
        """Gzipped .log.gz files should exist in the archives."""
        result = subprocess.run(
            ["find", str(ARCHIVES_DIR), "-path", "*2024/03*", "-name", "*.log.gz", "-type", "f"],
            capture_output=True,
            text=True
        )
        gz_files = [f for f in result.stdout.strip().split('\n') if f]
        assert len(gz_files) > 0, "No .log.gz files found in 2024/03 path"

    def test_approximate_total_file_count(self):
        """Should have approximately 847 total log files matching 2024-03."""
        result = subprocess.run(
            ["find", str(ARCHIVES_DIR), "-path", "*2024/03*", 
             "(", "-name", "*.log", "-o", "-name", "*.log.gz", ")", "-type", "f"],
            capture_output=True,
            text=True,
            shell=False
        )
        # Use bash for the complex find command
        result = subprocess.run(
            ["bash", "-c", 
             f'find {ARCHIVES_DIR} -path "*2024/03*" \\( -name "*.log" -o -name "*.log.gz" \\) -type f | wc -l'],
            capture_output=True,
            text=True
        )
        count = int(result.stdout.strip())
        # Allow some tolerance around 847
        assert 800 <= count <= 900, f"Expected ~847 log files, found {count}"

    def test_files_with_spaces_in_names_exist(self):
        """Some files should have spaces in their paths (from Windows migration)."""
        result = subprocess.run(
            ["bash", "-c",
             f'find {ARCHIVES_DIR} -path "*2024/03*" \\( -name "*.log" -o -name "*.log.gz" \\) -type f | grep " "'],
            capture_output=True,
            text=True
        )
        files_with_spaces = [f for f in result.stdout.strip().split('\n') if f]
        assert len(files_with_spaces) > 0, "No files with spaces in path found"


class TestLogFileContents:
    """Verify log files contain expected content format."""

    def test_log_files_contain_frd_codes(self):
        """At least some .log files should contain FRD codes."""
        result = subprocess.run(
            ["bash", "-c",
             f'find {ARCHIVES_DIR} -path "*2024/03*" -name "*.log" -type f | head -5'],
            capture_output=True,
            text=True
        )
        log_files = [f for f in result.stdout.strip().split('\n') if f]

        frd_found = False
        for log_file in log_files:
            if os.path.exists(log_file):
                with open(log_file, 'r', errors='ignore') as f:
                    content = f.read()
                    if re.search(r'FRD-\d+', content):
                        frd_found = True
                        break

        assert frd_found, "No FRD codes found in sampled .log files"

    def test_log_files_contain_timestamps(self):
        """Log files should contain timestamps in expected format."""
        result = subprocess.run(
            ["bash", "-c",
             f'find {ARCHIVES_DIR} -path "*2024/03*" -name "*.log" -type f | head -5'],
            capture_output=True,
            text=True
        )
        log_files = [f for f in result.stdout.strip().split('\n') if f]

        timestamp_found = False
        for log_file in log_files:
            if os.path.exists(log_file):
                with open(log_file, 'r', errors='ignore') as f:
                    content = f.read()
                    if re.search(r'\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}', content):
                        timestamp_found = True
                        break

        assert timestamp_found, "No timestamps in expected format found in sampled .log files"

    def test_mix_of_real_gzipped_and_plaintext_gz_files(self):
        """Some .log.gz files should be actually gzipped, some should be plaintext (legacy naming)."""
        result = subprocess.run(
            ["bash", "-c",
             f'find {ARCHIVES_DIR} -path "*2024/03*" -name "*.log.gz" -type f'],
            capture_output=True,
            text=True
        )
        gz_files = [f for f in result.stdout.strip().split('\n') if f]

        real_gzip_count = 0
        fake_gzip_count = 0

        for gz_file in gz_files[:50]:  # Sample first 50
            if os.path.exists(gz_file):
                with open(gz_file, 'rb') as f:
                    magic = f.read(2)
                    if magic == b'\x1f\x8b':  # Gzip magic number
                        real_gzip_count += 1
                    else:
                        fake_gzip_count += 1

        assert real_gzip_count > 0, "No actually gzipped .log.gz files found"
        # The fake gzip (plaintext) files are part of the problem setup
        # but may not be required for initial state validation


class TestExtractScript:
    """Verify the buggy extract script exists with expected content."""

    def test_extract_script_exists(self):
        """The extract.sh script must exist."""
        assert EXTRACT_SCRIPT.exists(), f"Extract script {EXTRACT_SCRIPT} does not exist"

    def test_extract_script_is_file(self):
        """extract.sh must be a regular file."""
        assert EXTRACT_SCRIPT.is_file(), f"{EXTRACT_SCRIPT} is not a regular file"

    def test_extract_script_is_readable(self):
        """extract.sh must be readable."""
        assert os.access(EXTRACT_SCRIPT, os.R_OK), f"{EXTRACT_SCRIPT} is not readable"

    def test_extract_script_is_bash_script(self):
        """extract.sh should be a bash script."""
        with open(EXTRACT_SCRIPT, 'r') as f:
            first_line = f.readline()
        assert '#!/bin/bash' in first_line or first_line.startswith('#!') and 'bash' in first_line, \
            f"extract.sh doesn't appear to be a bash script, first line: {first_line}"

    def test_extract_script_uses_find(self):
        """extract.sh should use find command."""
        with open(EXTRACT_SCRIPT, 'r') as f:
            content = f.read()
        assert 'find' in content, "extract.sh doesn't contain 'find' command"

    def test_extract_script_uses_grep(self):
        """extract.sh should use grep command."""
        with open(EXTRACT_SCRIPT, 'r') as f:
            content = f.read()
        assert 'grep' in content, "extract.sh doesn't contain 'grep' command"

    def test_extract_script_searches_for_frd_pattern(self):
        """extract.sh should search for FRD pattern."""
        with open(EXTRACT_SCRIPT, 'r') as f:
            content = f.read()
        assert 'FRD' in content, "extract.sh doesn't search for FRD pattern"

    def test_extract_script_outputs_to_results(self):
        """extract.sh should output to results.txt."""
        with open(EXTRACT_SCRIPT, 'r') as f:
            content = f.read()
        assert 'results.txt' in content, "extract.sh doesn't reference results.txt"

    def test_extract_script_uses_print0_xargs0(self):
        """extract.sh should use -print0 and xargs -0 (handling spaces)."""
        with open(EXTRACT_SCRIPT, 'r') as f:
            content = f.read()
        assert '-print0' in content, "extract.sh doesn't use -print0"
        assert 'xargs -0' in content or 'xargs  -0' in content, "extract.sh doesn't use xargs -0"

    def test_extract_script_has_the_bug(self):
        """extract.sh should use plain grep (not zgrep/zcat) - this is the bug."""
        with open(EXTRACT_SCRIPT, 'r') as f:
            content = f.read()
        # The buggy script uses plain grep, not zgrep or zcat
        # It should NOT have proper gzip handling
        has_zgrep = 'zgrep' in content
        has_zcat = 'zcat' in content
        has_gunzip = 'gunzip' in content
        has_gzip_d = 'gzip -d' in content

        # The bug is that it DOESN'T handle gzip properly
        assert not (has_zgrep or has_zcat or has_gunzip or has_gzip_d), \
            "extract.sh already has gzip handling - expected the buggy version without it"


class TestRequiredTools:
    """Verify required tools are available."""

    def test_bash_available(self):
        """bash must be available."""
        result = subprocess.run(["which", "bash"], capture_output=True)
        assert result.returncode == 0, "bash is not available"

    def test_grep_available(self):
        """grep must be available."""
        result = subprocess.run(["which", "grep"], capture_output=True)
        assert result.returncode == 0, "grep is not available"

    def test_zgrep_available(self):
        """zgrep must be available (needed for fix)."""
        result = subprocess.run(["which", "zgrep"], capture_output=True)
        assert result.returncode == 0, "zgrep is not available"

    def test_zcat_available(self):
        """zcat must be available (alternative fix)."""
        result = subprocess.run(["which", "zcat"], capture_output=True)
        assert result.returncode == 0, "zcat is not available"

    def test_find_available(self):
        """find must be available."""
        result = subprocess.run(["which", "find"], capture_output=True)
        assert result.returncode == 0, "find is not available"

    def test_xargs_available(self):
        """xargs must be available."""
        result = subprocess.run(["which", "xargs"], capture_output=True)
        assert result.returncode == 0, "xargs is not available"

    def test_python3_available(self):
        """Python 3 must be available."""
        result = subprocess.run(["python3", "--version"], capture_output=True)
        assert result.returncode == 0, "python3 is not available"


class TestHomeDirectory:
    """Verify home directory is properly set up."""

    def test_home_directory_exists(self):
        """Home directory must exist."""
        assert HOME_DIR.exists(), f"Home directory {HOME_DIR} does not exist"

    def test_home_directory_is_writable(self):
        """Home directory must be writable."""
        assert os.access(HOME_DIR, os.W_OK), f"Home directory {HOME_DIR} is not writable"

    def test_archives_not_writable(self):
        """Archives directory should not be writable (per task spec)."""
        # This might not be strictly enforced in all setups, so we make it a soft check
        if os.access(ARCHIVES_DIR, os.W_OK):
            pytest.skip("Archives directory is writable - this is acceptable but noted")
