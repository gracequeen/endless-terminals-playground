# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student performs the task.
This verifies the environment is set up correctly for the artifact manifest validation debugging task.
"""

import json
import os
import subprocess
import pytest


class TestDirectoriesExist:
    """Test that required directories exist."""

    def test_repo_tools_directory_exists(self):
        """Verify /home/user/repo-tools/ directory exists."""
        path = "/home/user/repo-tools"
        assert os.path.isdir(path), f"Directory {path} does not exist"

    def test_artifacts_directory_exists(self):
        """Verify /home/user/artifacts/ directory exists."""
        path = "/home/user/artifacts"
        assert os.path.isdir(path), f"Directory {path} does not exist"


class TestRequiredFilesExist:
    """Test that required files exist."""

    def test_validate_script_exists(self):
        """Verify /home/user/repo-tools/validate.sh exists."""
        path = "/home/user/repo-tools/validate.sh"
        assert os.path.isfile(path), f"File {path} does not exist"

    def test_validate_script_is_executable(self):
        """Verify validate.sh is executable."""
        path = "/home/user/repo-tools/validate.sh"
        assert os.access(path, os.X_OK), f"File {path} is not executable"

    def test_schema_file_exists(self):
        """Verify /home/user/repo-tools/schema.json exists."""
        path = "/home/user/repo-tools/schema.json"
        assert os.path.isfile(path), f"File {path} does not exist"

    def test_good_manifest_exists(self):
        """Verify /home/user/artifacts/libcrypto-3.1.2.json exists."""
        path = "/home/user/artifacts/libcrypto-3.1.2.json"
        assert os.path.isfile(path), f"File {path} does not exist"

    def test_bad_manifest_exists(self):
        """Verify /home/user/artifacts/malformed-test.json exists."""
        path = "/home/user/artifacts/malformed-test.json"
        assert os.path.isfile(path), f"File {path} does not exist"


class TestRequiredToolsInstalled:
    """Test that required tools are installed and available."""

    def test_jq_installed(self):
        """Verify jq is installed and available."""
        result = subprocess.run(["which", "jq"], capture_output=True, text=True)
        assert result.returncode == 0, "jq is not installed or not in PATH"

    def test_ajv_installed(self):
        """Verify ajv-cli is installed and available."""
        result = subprocess.run(["which", "ajv"], capture_output=True, text=True)
        assert result.returncode == 0, "ajv-cli is not installed or not in PATH"

    def test_node_installed(self):
        """Verify Node.js is installed."""
        result = subprocess.run(["which", "node"], capture_output=True, text=True)
        assert result.returncode == 0, "Node.js is not installed or not in PATH"

    def test_node_version_18_plus(self):
        """Verify Node.js version is 18 or higher."""
        result = subprocess.run(["node", "--version"], capture_output=True, text=True)
        assert result.returncode == 0, "Failed to get Node.js version"
        version_str = result.stdout.strip()
        # Version format is like v18.x.x or v20.x.x
        assert version_str.startswith("v"), f"Unexpected Node version format: {version_str}"
        major_version = int(version_str[1:].split(".")[0])
        assert major_version >= 18, f"Node.js version {major_version} is less than required 18"


class TestGoodManifestContent:
    """Test that the good manifest has expected content."""

    def test_good_manifest_is_valid_json(self):
        """Verify libcrypto-3.1.2.json is valid JSON."""
        path = "/home/user/artifacts/libcrypto-3.1.2.json"
        with open(path, "r") as f:
            try:
                data = json.load(f)
            except json.JSONDecodeError as e:
                pytest.fail(f"File {path} is not valid JSON: {e}")

    def test_good_manifest_has_expected_structure(self):
        """Verify libcrypto-3.1.2.json has the expected structure."""
        path = "/home/user/artifacts/libcrypto-3.1.2.json"
        with open(path, "r") as f:
            data = json.load(f)

        assert "name" in data, "Good manifest missing 'name' field"
        assert data["name"] == "libcrypto", f"Good manifest name should be 'libcrypto', got '{data['name']}'"
        assert "version" in data, "Good manifest missing 'version' field"
        assert data["version"] == "3.1.2", f"Good manifest version should be '3.1.2', got '{data['version']}'"
        assert "metadata" in data, "Good manifest missing 'metadata' field"
        assert "checksums" in data["metadata"], "Good manifest missing 'metadata.checksums' field"
        assert "sha256" in data["metadata"]["checksums"], "Good manifest missing sha256 checksum"
        # Verify the checksum is 64 hex characters
        checksum = data["metadata"]["checksums"]["sha256"]
        assert len(checksum) == 64, f"SHA256 checksum should be 64 characters, got {len(checksum)}"
        assert all(c in "0123456789abcdef" for c in checksum), "SHA256 checksum should be hex characters"


class TestBadManifestContent:
    """Test that the bad manifest has expected content with known issues."""

    def test_bad_manifest_is_valid_json(self):
        """Verify malformed-test.json is valid JSON (malformed in schema sense, not JSON syntax)."""
        path = "/home/user/artifacts/malformed-test.json"
        with open(path, "r") as f:
            try:
                data = json.load(f)
            except json.JSONDecodeError as e:
                pytest.fail(f"File {path} is not valid JSON: {e}")

    def test_bad_manifest_has_schema_violations(self):
        """Verify malformed-test.json has known schema violations."""
        path = "/home/user/artifacts/malformed-test.json"
        with open(path, "r") as f:
            data = json.load(f)

        # Should have non-semver version
        assert data.get("version") == "not-semver", "Bad manifest should have 'not-semver' as version"
        # Should have too-short checksum
        assert data.get("metadata", {}).get("checksums", {}).get("sha256") == "tooshort", \
            "Bad manifest should have 'tooshort' as sha256 checksum"
        # Should have string instead of integer for size
        assert data.get("metadata", {}).get("size") == "notanumber", \
            "Bad manifest should have 'notanumber' as size"


class TestSchemaContent:
    """Test that the schema has expected structure."""

    def test_schema_is_valid_json(self):
        """Verify schema.json is valid JSON."""
        path = "/home/user/repo-tools/schema.json"
        with open(path, "r") as f:
            try:
                data = json.load(f)
            except json.JSONDecodeError as e:
                pytest.fail(f"File {path} is not valid JSON: {e}")

    def test_schema_expects_object_type(self):
        """Verify schema expects an object at root level."""
        path = "/home/user/repo-tools/schema.json"
        with open(path, "r") as f:
            schema = json.load(f)

        assert schema.get("type") == "object", "Schema should expect 'object' type at root"

    def test_schema_requires_name_version_metadata(self):
        """Verify schema requires name, version, and metadata fields."""
        path = "/home/user/repo-tools/schema.json"
        with open(path, "r") as f:
            schema = json.load(f)

        required = schema.get("required", [])
        assert "name" in required, "Schema should require 'name' field"
        assert "version" in required, "Schema should require 'version' field"
        assert "metadata" in required, "Schema should require 'metadata' field"

    def test_schema_has_semver_pattern(self):
        """Verify schema has semver pattern for version field."""
        path = "/home/user/repo-tools/schema.json"
        with open(path, "r") as f:
            schema = json.load(f)

        version_schema = schema.get("properties", {}).get("version", {})
        assert "pattern" in version_schema, "Schema should have pattern for version field"
        # Should match semver pattern (X.Y.Z)
        pattern = version_schema["pattern"]
        assert "\\." in pattern or "." in pattern, "Version pattern should include dots for semver"


class TestValidateScriptContent:
    """Test that validate.sh has the expected buggy behavior."""

    def test_validate_script_is_bash(self):
        """Verify validate.sh is a bash script."""
        path = "/home/user/repo-tools/validate.sh"
        with open(path, "r") as f:
            content = f.read()

        # Should start with shebang for bash
        assert content.startswith("#!/") and "bash" in content.split("\n")[0], \
            "validate.sh should be a bash script"

    def test_validate_script_uses_jq(self):
        """Verify validate.sh uses jq."""
        path = "/home/user/repo-tools/validate.sh"
        with open(path, "r") as f:
            content = f.read()

        assert "jq" in content, "validate.sh should use jq"

    def test_validate_script_uses_ajv(self):
        """Verify validate.sh uses ajv."""
        path = "/home/user/repo-tools/validate.sh"
        with open(path, "r") as f:
            content = f.read()

        assert "ajv" in content, "validate.sh should use ajv"

    def test_validate_script_references_schema(self):
        """Verify validate.sh references the schema file."""
        path = "/home/user/repo-tools/validate.sh"
        with open(path, "r") as f:
            content = f.read()

        assert "schema.json" in content, "validate.sh should reference schema.json"


class TestDirectoriesWritable:
    """Test that required directories are writable."""

    def test_repo_tools_writable(self):
        """Verify /home/user/repo-tools/ is writable."""
        path = "/home/user/repo-tools"
        assert os.access(path, os.W_OK), f"Directory {path} is not writable"

    def test_artifacts_writable(self):
        """Verify /home/user/artifacts/ is writable."""
        path = "/home/user/artifacts"
        assert os.access(path, os.W_OK), f"Directory {path} is not writable"
