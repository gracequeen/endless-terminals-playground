# test_final_state.py
"""
Tests to validate the final state after the student has fixed the artifact manifest validation pipeline.
The fix should make validate.sh correctly validate whole manifests against the schema,
so good manifests pass and bad manifests fail.
"""

import json
import os
import subprocess
import tempfile
import pytest


class TestInvariantsPreserved:
    """Test that files that should not be modified remain unchanged."""

    def test_good_manifest_unchanged(self):
        """Verify libcrypto-3.1.2.json has expected content (not modified to match broken pipeline)."""
        path = "/home/user/artifacts/libcrypto-3.1.2.json"
        with open(path, "r") as f:
            data = json.load(f)

        # Verify the exact expected structure
        assert data.get("name") == "libcrypto", "Good manifest name should be 'libcrypto'"
        assert data.get("version") == "3.1.2", "Good manifest version should be '3.1.2'"
        assert "metadata" in data, "Good manifest should have 'metadata' field"

        metadata = data["metadata"]
        assert "checksums" in metadata, "Good manifest should have 'checksums' in metadata"
        assert "size" in metadata, "Good manifest should have 'size' in metadata"
        assert "timestamp" in metadata, "Good manifest should have 'timestamp' in metadata"

        # Checksums should be an object with sha256 key (original format)
        checksums = metadata["checksums"]
        assert isinstance(checksums, dict), "Checksums should be an object/dict in the manifest"
        assert "sha256" in checksums, "Checksums should have 'sha256' key"
        assert checksums["sha256"] == "a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2", \
            "SHA256 checksum value should be unchanged"

        assert metadata["size"] == 2458624, "Size should be 2458624"
        assert metadata["timestamp"] == "2024-11-15T09:23:17Z", "Timestamp should be unchanged"

    def test_bad_manifest_unchanged(self):
        """Verify malformed-test.json has expected content (not modified)."""
        path = "/home/user/artifacts/malformed-test.json"
        with open(path, "r") as f:
            data = json.load(f)

        assert data.get("name") == "badpkg", "Bad manifest name should be 'badpkg'"
        assert data.get("version") == "not-semver", "Bad manifest version should be 'not-semver'"
        assert data.get("metadata", {}).get("checksums", {}).get("sha256") == "tooshort", \
            "Bad manifest sha256 should be 'tooshort'"
        assert data.get("metadata", {}).get("size") == "notanumber", \
            "Bad manifest size should be 'notanumber'"


class TestSchemaStillEnforcesRules:
    """Test that the schema still enforces required validation rules."""

    def test_schema_exists(self):
        """Verify schema.json still exists."""
        path = "/home/user/repo-tools/schema.json"
        assert os.path.isfile(path), f"Schema file {path} should exist"

    def test_schema_enforces_semver_pattern(self):
        """Verify schema still has semver pattern requirement."""
        path = "/home/user/repo-tools/schema.json"
        with open(path, "r") as f:
            schema = json.load(f)

        # Find version pattern - could be at root or nested
        def find_version_pattern(obj, depth=0):
            if depth > 10:
                return None
            if isinstance(obj, dict):
                if obj.get("type") == "string" and "pattern" in obj:
                    pattern = obj["pattern"]
                    # Check if it looks like a semver pattern
                    if "\\." in pattern or "[0-9]" in pattern:
                        return pattern
                for key, value in obj.items():
                    if key == "version" and isinstance(value, dict) and "pattern" in value:
                        return value["pattern"]
                    result = find_version_pattern(value, depth + 1)
                    if result:
                        return result
            elif isinstance(obj, list):
                for item in obj:
                    result = find_version_pattern(item, depth + 1)
                    if result:
                        return result
            return None

        pattern = find_version_pattern(schema)
        assert pattern is not None, "Schema should have a pattern for version validation"

    def test_schema_requires_integer_size(self):
        """Verify schema still requires size to be integer."""
        path = "/home/user/repo-tools/schema.json"
        with open(path, "r") as f:
            schema = json.load(f)

        # Search for size field with integer type
        schema_str = json.dumps(schema)
        assert '"size"' in schema_str, "Schema should define 'size' field"
        assert '"integer"' in schema_str, "Schema should have 'integer' type (likely for size)"


class TestValidateScriptWorks:
    """Test that validate.sh correctly validates manifests."""

    def test_validate_script_exists(self):
        """Verify validate.sh exists."""
        path = "/home/user/repo-tools/validate.sh"
        assert os.path.isfile(path), f"Script {path} should exist"

    def test_validate_script_is_executable(self):
        """Verify validate.sh is executable."""
        path = "/home/user/repo-tools/validate.sh"
        assert os.access(path, os.X_OK), f"Script {path} should be executable"

    def test_good_manifest_passes_validation(self):
        """Verify libcrypto-3.1.2.json passes validation (exit code 0)."""
        result = subprocess.run(
            ["/home/user/repo-tools/validate.sh", "/home/user/artifacts/libcrypto-3.1.2.json"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            f"Good manifest should pass validation (exit 0), but got exit {result.returncode}.\n" \
            f"stdout: {result.stdout}\nstderr: {result.stderr}"

    def test_bad_manifest_fails_validation(self):
        """Verify malformed-test.json fails validation (exit code non-zero)."""
        result = subprocess.run(
            ["/home/user/repo-tools/validate.sh", "/home/user/artifacts/malformed-test.json"],
            capture_output=True,
            text=True
        )
        assert result.returncode != 0, \
            f"Bad manifest should fail validation (exit non-zero), but got exit {result.returncode}.\n" \
            f"stdout: {result.stdout}\nstderr: {result.stderr}"


class TestAntiShortcutGuards:
    """Test that the solution doesn't use shortcuts that bypass real validation."""

    def test_no_hardcoded_exit_codes(self):
        """Verify validate.sh doesn't have unconditional hardcoded exit codes."""
        path = "/home/user/repo-tools/validate.sh"
        with open(path, "r") as f:
            lines = f.readlines()

        for i, line in enumerate(lines, 1):
            stripped = line.strip()
            # Skip comments
            if stripped.startswith("#"):
                continue
            # Skip empty lines
            if not stripped:
                continue
            # Check for unconditional exit 0 or exit 1
            # These patterns would be suspicious if they're not part of conditional logic
            if stripped == "exit 0" or stripped == "exit 1":
                # Check if previous non-empty, non-comment line contains conditional logic
                prev_line = ""
                for j in range(i - 2, -1, -1):
                    prev = lines[j].strip()
                    if prev and not prev.startswith("#"):
                        prev_line = prev
                        break
                # If the exit is at the end and follows ajv or a conditional, it's okay
                if not any(kw in prev_line.lower() for kw in ["if", "then", "else", "fi", "ajv", "$?", "||", "&&"]):
                    # Check if it's the last line (which is okay if it's `exit $?` equivalent)
                    if i == len(lines) or all(l.strip() == "" or l.strip().startswith("#") for l in lines[i:]):
                        # Last meaningful line being exit 0 unconditionally is suspicious
                        if stripped == "exit 0":
                            pytest.fail(f"Line {i}: Suspicious unconditional 'exit 0' found: {stripped}")

    def test_real_validation_with_bad_version_only(self):
        """Test that a manifest with only a bad version (missing patch number) fails validation."""
        # Create a test manifest that has valid checksums but invalid version (missing patch)
        test_manifest = {
            "name": "testpkg",
            "version": "1.2",  # Missing patch number - should fail semver pattern
            "metadata": {
                "checksums": {
                    "sha256": "a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2"
                },
                "size": 12345,
                "timestamp": "2024-11-15T09:23:17Z"
            }
        }

        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump(test_manifest, f)
            temp_path = f.name

        try:
            result = subprocess.run(
                ["/home/user/repo-tools/validate.sh", temp_path],
                capture_output=True,
                text=True
            )
            assert result.returncode != 0, \
                f"Manifest with invalid version '1.2' (missing patch) should fail validation, " \
                f"but got exit {result.returncode}. This suggests real schema validation is not happening.\n" \
                f"stdout: {result.stdout}\nstderr: {result.stderr}"
        finally:
            os.unlink(temp_path)

    def test_real_validation_with_bad_checksum_length(self):
        """Test that a manifest with wrong checksum length fails validation."""
        test_manifest = {
            "name": "testpkg",
            "version": "1.2.3",
            "metadata": {
                "checksums": {
                    "sha256": "abc123"  # Too short - should be 64 hex chars
                },
                "size": 12345,
                "timestamp": "2024-11-15T09:23:17Z"
            }
        }

        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump(test_manifest, f)
            temp_path = f.name

        try:
            result = subprocess.run(
                ["/home/user/repo-tools/validate.sh", temp_path],
                capture_output=True,
                text=True
            )
            assert result.returncode != 0, \
                f"Manifest with short checksum 'abc123' should fail validation, " \
                f"but got exit {result.returncode}. This suggests real schema validation is not happening.\n" \
                f"stdout: {result.stdout}\nstderr: {result.stderr}"
        finally:
            os.unlink(temp_path)

    def test_real_validation_with_string_size(self):
        """Test that a manifest with string size instead of integer fails validation."""
        test_manifest = {
            "name": "testpkg",
            "version": "1.2.3",
            "metadata": {
                "checksums": {
                    "sha256": "a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2"
                },
                "size": "12345",  # String instead of integer
                "timestamp": "2024-11-15T09:23:17Z"
            }
        }

        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump(test_manifest, f)
            temp_path = f.name

        try:
            result = subprocess.run(
                ["/home/user/repo-tools/validate.sh", temp_path],
                capture_output=True,
                text=True
            )
            assert result.returncode != 0, \
                f"Manifest with string size '12345' should fail validation, " \
                f"but got exit {result.returncode}. This suggests real schema validation is not happening.\n" \
                f"stdout: {result.stdout}\nstderr: {result.stderr}"
        finally:
            os.unlink(temp_path)


class TestValidationUsesAjv:
    """Test that the validation actually uses ajv for schema validation."""

    def test_script_still_uses_ajv(self):
        """Verify validate.sh still uses ajv for validation."""
        path = "/home/user/repo-tools/validate.sh"
        with open(path, "r") as f:
            content = f.read()

        assert "ajv" in content, "validate.sh should still use ajv for validation"

    def test_script_references_schema(self):
        """Verify validate.sh still references the schema file."""
        path = "/home/user/repo-tools/validate.sh"
        with open(path, "r") as f:
            content = f.read()

        assert "schema" in content.lower(), "validate.sh should reference a schema file"
