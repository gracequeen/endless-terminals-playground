# test_initial_state.py
"""
Tests to validate the initial state of the system before the student
performs the kubectl version pinning task in the Dockerfile.
"""

import os
import pytest


DOCKERFILE_PATH = "/home/user/infra/Dockerfile"


def test_dockerfile_exists():
    """Verify that the Dockerfile exists at the expected path."""
    assert os.path.exists(DOCKERFILE_PATH), (
        f"Dockerfile does not exist at {DOCKERFILE_PATH}. "
        "The file must exist before the task can be performed."
    )


def test_dockerfile_is_file():
    """Verify that the path points to a file, not a directory."""
    assert os.path.isfile(DOCKERFILE_PATH), (
        f"{DOCKERFILE_PATH} exists but is not a regular file."
    )


def test_dockerfile_is_writable():
    """Verify that the Dockerfile is writable."""
    assert os.access(DOCKERFILE_PATH, os.W_OK), (
        f"Dockerfile at {DOCKERFILE_PATH} is not writable. "
        "The student needs write access to modify the file."
    )


def test_dockerfile_is_readable():
    """Verify that the Dockerfile is readable."""
    assert os.access(DOCKERFILE_PATH, os.R_OK), (
        f"Dockerfile at {DOCKERFILE_PATH} is not readable."
    )


def test_dockerfile_contains_stable_txt_fetch():
    """Verify that the Dockerfile currently uses the dynamic stable.txt fetch."""
    with open(DOCKERFILE_PATH, 'r') as f:
        content = f.read()

    assert 'stable.txt' in content, (
        "The Dockerfile does not contain 'stable.txt'. "
        "The initial state should have the dynamic kubectl version fetch "
        "using 'https://dl.k8s.io/release/stable.txt'."
    )


def test_dockerfile_contains_kubectl_curl_command():
    """Verify that the Dockerfile has the kubectl download command."""
    with open(DOCKERFILE_PATH, 'r') as f:
        content = f.read()

    assert 'curl' in content and 'kubectl' in content, (
        "The Dockerfile should contain a curl command to download kubectl."
    )


def test_dockerfile_contains_kubectl_install_command():
    """Verify that the Dockerfile has the kubectl install command."""
    with open(DOCKERFILE_PATH, 'r') as f:
        content = f.read()

    assert 'install' in content and '/usr/local/bin/kubectl' in content, (
        "The Dockerfile should contain an install command that places "
        "kubectl in /usr/local/bin/kubectl."
    )


def test_dockerfile_has_from_instruction():
    """Verify that the Dockerfile has a valid FROM instruction."""
    with open(DOCKERFILE_PATH, 'r') as f:
        content = f.read()

    assert 'FROM' in content, (
        "The Dockerfile should have a FROM instruction."
    )


def test_dockerfile_does_not_already_have_pinned_version():
    """Verify that the Dockerfile does NOT already have v1.28.4 pinned."""
    with open(DOCKERFILE_PATH, 'r') as f:
        content = f.read()

    assert 'v1.28.4' not in content, (
        "The Dockerfile already contains 'v1.28.4'. "
        "The initial state should have the dynamic version fetch, "
        "not the pinned version."
    )


def test_dockerfile_has_dl_k8s_io_url():
    """Verify that the Dockerfile uses the official Kubernetes download URL."""
    with open(DOCKERFILE_PATH, 'r') as f:
        content = f.read()

    assert 'dl.k8s.io' in content, (
        "The Dockerfile should contain the official Kubernetes download URL "
        "(dl.k8s.io) for downloading kubectl."
    )


def test_infra_directory_exists():
    """Verify that the /home/user/infra directory exists."""
    infra_dir = "/home/user/infra"
    assert os.path.isdir(infra_dir), (
        f"The directory {infra_dir} does not exist. "
        "This directory should contain the Dockerfile."
    )
