# test_final_state.py
"""
Tests to validate the final state of the system after the student
has completed the kubectl version pinning task in the Dockerfile.
"""

import os
import re
import pytest


DOCKERFILE_PATH = "/home/user/infra/Dockerfile"


def test_dockerfile_exists():
    """Verify that the Dockerfile still exists at the expected path."""
    assert os.path.exists(DOCKERFILE_PATH), (
        f"Dockerfile does not exist at {DOCKERFILE_PATH}. "
        "The file should still exist after the modification."
    )


def test_dockerfile_is_file():
    """Verify that the path points to a file, not a directory."""
    assert os.path.isfile(DOCKERFILE_PATH), (
        f"{DOCKERFILE_PATH} exists but is not a regular file."
    )


def test_dockerfile_is_readable():
    """Verify that the Dockerfile is readable."""
    assert os.access(DOCKERFILE_PATH, os.R_OK), (
        f"Dockerfile at {DOCKERFILE_PATH} is not readable."
    )


def test_stable_txt_removed():
    """Verify that the dynamic stable.txt fetch has been removed."""
    with open(DOCKERFILE_PATH, 'r') as f:
        content = f.read()

    assert 'stable.txt' not in content, (
        "The Dockerfile still contains 'stable.txt'. "
        "The dynamic kubectl version fetch should be replaced with "
        "the pinned version v1.28.4."
    )


def test_pinned_version_present():
    """Verify that the pinned version v1.28.4 is present in the Dockerfile."""
    with open(DOCKERFILE_PATH, 'r') as f:
        content = f.read()

    assert 'v1.28.4' in content, (
        "The Dockerfile does not contain 'v1.28.4'. "
        "The kubectl version should be pinned to v1.28.4."
    )


def test_correct_kubectl_download_url():
    """Verify that the correct pinned kubectl download URL is used."""
    with open(DOCKERFILE_PATH, 'r') as f:
        content = f.read()

    expected_url = "https://dl.k8s.io/release/v1.28.4/bin/linux/amd64/kubectl"

    assert expected_url in content, (
        f"The Dockerfile does not contain the expected kubectl download URL: "
        f"'{expected_url}'. The URL should use the pinned version v1.28.4 "
        "with the 'v' prefix."
    )


def test_no_curl_subshell_for_version():
    """Verify that the $(curl ...) subshell for fetching version is removed."""
    with open(DOCKERFILE_PATH, 'r') as f:
        content = f.read()

    # Check that there's no subshell fetching the version dynamically
    subshell_pattern = r'\$\(curl[^)]*stable\.txt[^)]*\)'
    match = re.search(subshell_pattern, content)

    assert match is None, (
        "The Dockerfile still contains a $(curl ...) subshell that fetches "
        "the kubectl version dynamically. This should be replaced with "
        "the hardcoded version v1.28.4."
    )


def test_kubectl_install_command_present():
    """Verify that the kubectl install command is still present."""
    with open(DOCKERFILE_PATH, 'r') as f:
        content = f.read()

    assert 'install' in content and '/usr/local/bin/kubectl' in content, (
        "The Dockerfile should still contain an install command that places "
        "kubectl in /usr/local/bin/kubectl. The install logic should remain "
        "functional after the version pinning change."
    )


def test_kubectl_rm_command_present():
    """Verify that the cleanup rm command is still present."""
    with open(DOCKERFILE_PATH, 'r') as f:
        content = f.read()

    # Check for rm kubectl (with various possible formats)
    assert 'rm kubectl' in content or 'rm ./kubectl' in content, (
        "The Dockerfile should still contain the 'rm kubectl' cleanup command. "
        "The rest of the install logic should remain functional."
    )


def test_dockerfile_has_from_instruction():
    """Verify that the Dockerfile still has a valid FROM instruction."""
    with open(DOCKERFILE_PATH, 'r') as f:
        content = f.read()

    assert 'FROM' in content, (
        "The Dockerfile should still have a FROM instruction. "
        "Other lines should remain unchanged."
    )


def test_dockerfile_has_run_instruction_for_kubectl():
    """Verify that kubectl installation is in a RUN instruction."""
    with open(DOCKERFILE_PATH, 'r') as f:
        content = f.read()

    # Check that there's a RUN instruction that includes kubectl download
    assert 'RUN' in content, (
        "The Dockerfile should have RUN instructions."
    )

    # Verify the kubectl download is part of a RUN instruction
    lines = content.split('\n')
    found_run_with_kubectl = False
    in_run_block = False

    for line in lines:
        stripped = line.strip()
        if stripped.startswith('RUN '):
            in_run_block = True
        if in_run_block and 'kubectl' in line and 'dl.k8s.io' in line:
            found_run_with_kubectl = True
            break
        if in_run_block and not stripped.endswith('\\') and stripped:
            in_run_block = False

    assert found_run_with_kubectl, (
        "The Dockerfile should have a RUN instruction that downloads kubectl "
        "from dl.k8s.io."
    )


def test_version_format_correct():
    """Verify that the version is specified with the 'v' prefix."""
    with open(DOCKERFILE_PATH, 'r') as f:
        content = f.read()

    # Check that we have v1.28.4 not just 1.28.4 in the URL context
    # The URL should be .../release/v1.28.4/...
    assert 'release/v1.28.4/' in content, (
        "The kubectl download URL should use 'release/v1.28.4/' with the 'v' prefix. "
        "Found content does not match the expected URL pattern."
    )


def test_infra_directory_exists():
    """Verify that the /home/user/infra directory still exists."""
    infra_dir = "/home/user/infra"
    assert os.path.isdir(infra_dir), (
        f"The directory {infra_dir} does not exist."
    )


def test_dockerfile_not_empty():
    """Verify that the Dockerfile is not empty after modification."""
    with open(DOCKERFILE_PATH, 'r') as f:
        content = f.read()

    assert len(content.strip()) > 0, (
        "The Dockerfile is empty. The file should contain valid Dockerfile content."
    )


def test_dockerfile_has_reasonable_length():
    """Verify that the Dockerfile has reasonable content (not truncated)."""
    with open(DOCKERFILE_PATH, 'r') as f:
        content = f.read()
        lines = content.strip().split('\n')

    # The original Dockerfile should have multiple lines
    # (FROM, apt-get, kubectl install, COPY, ENTRYPOINT, etc.)
    assert len(lines) >= 5, (
        f"The Dockerfile only has {len(lines)} lines. "
        "It should have more content including FROM, apt-get installs, "
        "kubectl install, COPY, and ENTRYPOINT instructions."
    )
