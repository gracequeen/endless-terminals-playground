# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the task to fix the Flask profiler app's negative latency bug.
"""

import os
import subprocess
import pytest


HOME = "/home/user"
APP_DIR = os.path.join(HOME, "profiler_app")


class TestDirectoryStructure:
    """Test that the required directory structure exists."""

    def test_profiler_app_directory_exists(self):
        """The profiler_app directory must exist."""
        assert os.path.isdir(APP_DIR), f"Directory {APP_DIR} does not exist"

    def test_config_directory_exists(self):
        """The config directory must exist."""
        config_dir = os.path.join(APP_DIR, "config")
        assert os.path.isdir(config_dir), f"Directory {config_dir} does not exist"

    def test_results_directory_exists(self):
        """The results directory must exist."""
        results_dir = os.path.join(APP_DIR, "results")
        assert os.path.isdir(results_dir), f"Directory {results_dir} does not exist"


class TestRequiredFiles:
    """Test that all required files exist."""

    def test_app_py_exists(self):
        """app.py must exist."""
        app_py = os.path.join(APP_DIR, "app.py")
        assert os.path.isfile(app_py), f"File {app_py} does not exist"

    def test_timing_py_exists(self):
        """timing.py must exist."""
        timing_py = os.path.join(APP_DIR, "timing.py")
        assert os.path.isfile(timing_py), f"File {timing_py} does not exist"

    def test_locale_conf_exists(self):
        """config/locale.conf must exist."""
        locale_conf = os.path.join(APP_DIR, "config", "locale.conf")
        assert os.path.isfile(locale_conf), f"File {locale_conf} does not exist"

    def test_tz_conf_exists(self):
        """config/tz.conf must exist."""
        tz_conf = os.path.join(APP_DIR, "config", "tz.conf")
        assert os.path.isfile(tz_conf), f"File {tz_conf} does not exist"

    def test_timings_csv_exists(self):
        """results/timings.csv must exist."""
        timings_csv = os.path.join(APP_DIR, "results", "timings.csv")
        assert os.path.isfile(timings_csv), f"File {timings_csv} does not exist"

    def test_run_sh_exists(self):
        """run.sh must exist."""
        run_sh = os.path.join(APP_DIR, "run.sh")
        assert os.path.isfile(run_sh), f"File {run_sh} does not exist"

    def test_test_timing_py_exists(self):
        """test_timing.py must exist."""
        test_timing_py = os.path.join(APP_DIR, "test_timing.py")
        assert os.path.isfile(test_timing_py), f"File {test_timing_py} does not exist"


class TestLocaleConfiguration:
    """Test the locale configuration file contents."""

    def test_locale_conf_sets_lc_time(self):
        """locale.conf must set LC_TIME to en_DK.UTF-8."""
        locale_conf = os.path.join(APP_DIR, "config", "locale.conf")
        with open(locale_conf, "r") as f:
            content = f.read()
        assert "LC_TIME" in content, "locale.conf must contain LC_TIME setting"
        assert "en_DK" in content, "locale.conf must set LC_TIME to en_DK locale"


class TestTimezoneConfiguration:
    """Test the timezone configuration file contents."""

    def test_tz_conf_sets_timezone(self):
        """tz.conf must set TZ to America/New_York."""
        tz_conf = os.path.join(APP_DIR, "config", "tz.conf")
        with open(tz_conf, "r") as f:
            content = f.read()
        assert "TZ" in content, "tz.conf must contain TZ setting"
        assert "America/New_York" in content, "tz.conf must set TZ to America/New_York"


class TestTimingsCSVHasNegativeValues:
    """Test that the timings.csv file contains negative latency values (the bug)."""

    def test_timings_csv_has_negative_latencies(self):
        """timings.csv should contain at least one negative latency value."""
        timings_csv = os.path.join(APP_DIR, "results", "timings.csv")
        with open(timings_csv, "r") as f:
            content = f.read()

        # Look for negative numbers in the CSV
        lines = content.strip().split("\n")
        has_negative = False
        for line in lines:
            # Skip header line if present
            if "latency" in line.lower() and "request" in line.lower():
                continue
            # Check for negative values
            parts = line.split(",")
            for part in parts:
                try:
                    val = float(part.strip())
                    if val < 0:
                        has_negative = True
                        break
                except ValueError:
                    continue
            if has_negative:
                break

        assert has_negative, "timings.csv should contain negative latency values (this is the bug to fix)"


class TestRunShellScript:
    """Test the run.sh script configuration."""

    def test_run_sh_sources_locale_conf(self):
        """run.sh must source config/locale.conf."""
        run_sh = os.path.join(APP_DIR, "run.sh")
        with open(run_sh, "r") as f:
            content = f.read()
        assert "locale.conf" in content, "run.sh must source locale.conf"
        assert "source" in content or "." in content.split(), "run.sh must use source command"

    def test_run_sh_sources_tz_conf(self):
        """run.sh must source config/tz.conf."""
        run_sh = os.path.join(APP_DIR, "run.sh")
        with open(run_sh, "r") as f:
            content = f.read()
        assert "tz.conf" in content, "run.sh must source tz.conf"

    def test_run_sh_is_executable(self):
        """run.sh should be executable."""
        run_sh = os.path.join(APP_DIR, "run.sh")
        assert os.access(run_sh, os.X_OK), f"{run_sh} should be executable"


class TestTimingModuleBug:
    """Test that timing.py has the buggy 12-hour format."""

    def test_timing_py_uses_12_hour_format(self):
        """timing.py should use 12-hour format with %I and %p (the bug)."""
        timing_py = os.path.join(APP_DIR, "timing.py")
        with open(timing_py, "r") as f:
            content = f.read()
        # The bug is using %I (12-hour) and %p (AM/PM) format
        assert "%I" in content or "%p" in content, \
            "timing.py should contain 12-hour format specifiers (%I or %p) - this is the bug"


class TestAppModuleLogging:
    """Test that app.py uses locale-dependent time format."""

    def test_app_py_uses_locale_dependent_format(self):
        """app.py should use %X (locale-dependent) format for timestamps."""
        app_py = os.path.join(APP_DIR, "app.py")
        with open(app_py, "r") as f:
            content = f.read()
        # %X is the locale-dependent time format
        assert "%X" in content, \
            "app.py should use %X (locale-dependent) format for timestamps"


class TestFlaskAppStructure:
    """Test that the Flask app has proper structure."""

    def test_app_py_is_flask_app(self):
        """app.py should be a Flask application."""
        app_py = os.path.join(APP_DIR, "app.py")
        with open(app_py, "r") as f:
            content = f.read()
        assert "flask" in content.lower() or "Flask" in content, \
            "app.py should import Flask"

    def test_app_py_has_profile_endpoint(self):
        """app.py should have a /profile endpoint."""
        app_py = os.path.join(APP_DIR, "app.py")
        with open(app_py, "r") as f:
            content = f.read()
        assert "profile" in content, "app.py should have a profile endpoint"


class TestFilesAreWritable:
    """Test that all relevant files are writable."""

    def test_app_py_is_writable(self):
        """app.py must be writable."""
        app_py = os.path.join(APP_DIR, "app.py")
        assert os.access(app_py, os.W_OK), f"{app_py} must be writable"

    def test_timing_py_is_writable(self):
        """timing.py must be writable."""
        timing_py = os.path.join(APP_DIR, "timing.py")
        assert os.access(timing_py, os.W_OK), f"{timing_py} must be writable"

    def test_locale_conf_is_writable(self):
        """locale.conf must be writable."""
        locale_conf = os.path.join(APP_DIR, "config", "locale.conf")
        assert os.access(locale_conf, os.W_OK), f"{locale_conf} must be writable"

    def test_tz_conf_is_writable(self):
        """tz.conf must be writable."""
        tz_conf = os.path.join(APP_DIR, "config", "tz.conf")
        assert os.access(tz_conf, os.W_OK), f"{tz_conf} must be writable"


class TestAppNotRunning:
    """Test that the Flask app is not currently running."""

    def test_flask_app_not_running_on_port_5000(self):
        """The Flask app should not be running on port 5000."""
        result = subprocess.run(
            ["ss", "-tlnp"],
            capture_output=True,
            text=True
        )
        # Check if port 5000 is NOT in use
        assert ":5000" not in result.stdout, \
            "Port 5000 should not be in use - Flask app should not be running"

    def test_no_python_flask_process(self):
        """No Flask/Python process should be running the profiler app."""
        result = subprocess.run(
            ["pgrep", "-f", "profiler_app"],
            capture_output=True,
            text=True
        )
        # pgrep returns 1 if no processes found
        assert result.returncode != 0 or result.stdout.strip() == "", \
            "No profiler_app process should be running"


class TestPythonEnvironment:
    """Test that Python and Flask are available."""

    def test_python3_available(self):
        """Python 3 must be available."""
        result = subprocess.run(
            ["python3", "--version"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "Python 3 must be available"
        assert "Python 3" in result.stdout or "Python 3" in result.stderr, \
            "Python 3 must be installed"

    def test_flask_importable(self):
        """Flask must be importable."""
        result = subprocess.run(
            ["python3", "-c", "import flask; print(flask.__version__)"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "Flask must be importable in Python"


class TestTestTimingScript:
    """Test that test_timing.py exists and has expected structure."""

    def test_test_timing_checks_positive_latency(self):
        """test_timing.py should check for positive latency."""
        test_timing_py = os.path.join(APP_DIR, "test_timing.py")
        with open(test_timing_py, "r") as f:
            content = f.read()
        # Should have assertion for positive latency
        assert "latency" in content.lower() or "assert" in content, \
            "test_timing.py should verify latency values"

    def test_test_timing_sources_configs(self):
        """test_timing.py or its execution should use the config files."""
        test_timing_py = os.path.join(APP_DIR, "test_timing.py")
        with open(test_timing_py, "r") as f:
            content = f.read()
        # Should reference locale or environment setup
        assert "LC_TIME" in content or "locale" in content.lower() or "environ" in content, \
            "test_timing.py should work with locale configuration"
