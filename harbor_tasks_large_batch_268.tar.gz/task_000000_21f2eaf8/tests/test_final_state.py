# test_final_state.py
"""
Tests to validate the final state after the student has fixed the Flask profiler app's
negative latency bug. The fix should make timestamp format consistent between logging
and parsing while preserving the locale/timezone configuration.
"""

import os
import subprocess
import time
import signal
import pytest
import csv
import re


HOME = "/home/user"
APP_DIR = os.path.join(HOME, "profiler_app")


class TestDirectoryStructurePreserved:
    """Test that the required directory structure is still intact."""

    def test_profiler_app_directory_exists(self):
        """The profiler_app directory must still exist."""
        assert os.path.isdir(APP_DIR), f"Directory {APP_DIR} does not exist"

    def test_config_directory_exists(self):
        """The config directory must still exist."""
        config_dir = os.path.join(APP_DIR, "config")
        assert os.path.isdir(config_dir), f"Directory {config_dir} does not exist"

    def test_results_directory_exists(self):
        """The results directory must still exist."""
        results_dir = os.path.join(APP_DIR, "results")
        assert os.path.isdir(results_dir), f"Directory {results_dir} does not exist"


class TestRequiredFilesPreserved:
    """Test that all required files still exist (structure preserved)."""

    def test_app_py_exists(self):
        """app.py must still exist."""
        app_py = os.path.join(APP_DIR, "app.py")
        assert os.path.isfile(app_py), f"File {app_py} does not exist - Flask app structure must be preserved"

    def test_timing_py_exists(self):
        """timing.py must still exist as a separate module."""
        timing_py = os.path.join(APP_DIR, "timing.py")
        assert os.path.isfile(timing_py), f"File {timing_py} does not exist - timing module must remain separate"

    def test_locale_conf_exists(self):
        """config/locale.conf must still exist."""
        locale_conf = os.path.join(APP_DIR, "config", "locale.conf")
        assert os.path.isfile(locale_conf), f"File {locale_conf} does not exist - cannot delete locale config"

    def test_tz_conf_exists(self):
        """config/tz.conf must still exist."""
        tz_conf = os.path.join(APP_DIR, "config", "tz.conf")
        assert os.path.isfile(tz_conf), f"File {tz_conf} does not exist - cannot delete timezone config"

    def test_timings_csv_exists(self):
        """results/timings.csv must still exist."""
        timings_csv = os.path.join(APP_DIR, "results", "timings.csv")
        assert os.path.isfile(timings_csv), f"File {timings_csv} does not exist"

    def test_run_sh_exists(self):
        """run.sh must still exist."""
        run_sh = os.path.join(APP_DIR, "run.sh")
        assert os.path.isfile(run_sh), f"File {run_sh} does not exist"

    def test_test_timing_py_exists(self):
        """test_timing.py must still exist."""
        test_timing_py = os.path.join(APP_DIR, "test_timing.py")
        assert os.path.isfile(test_timing_py), f"File {test_timing_py} does not exist"


class TestConfigFilesStillUsed:
    """Test that config files are still properly configured and used."""

    def test_locale_conf_still_sets_lc_time(self):
        """locale.conf must still set LC_TIME."""
        locale_conf = os.path.join(APP_DIR, "config", "locale.conf")
        with open(locale_conf, "r") as f:
            content = f.read()
        assert "LC_TIME" in content, "locale.conf must still contain LC_TIME setting - cannot remove locale config"

    def test_tz_conf_still_sets_timezone(self):
        """tz.conf must still set TZ."""
        tz_conf = os.path.join(APP_DIR, "config", "tz.conf")
        with open(tz_conf, "r") as f:
            content = f.read()
        assert "TZ" in content, "tz.conf must still contain TZ setting - cannot remove timezone config"

    def test_run_sh_still_sources_locale_conf(self):
        """run.sh must still source config/locale.conf."""
        run_sh = os.path.join(APP_DIR, "run.sh")
        with open(run_sh, "r") as f:
            content = f.read()
        # Check for source or . command with locale.conf
        has_source = ("source" in content and "locale.conf" in content) or \
                     (". " in content and "locale.conf" in content) or \
                     (".\t" in content and "locale.conf" in content)
        assert has_source, "run.sh must still source locale.conf - cannot remove config sourcing"

    def test_run_sh_still_sources_tz_conf(self):
        """run.sh must still source config/tz.conf."""
        run_sh = os.path.join(APP_DIR, "run.sh")
        with open(run_sh, "r") as f:
            content = f.read()
        # Check for source or . command with tz.conf
        has_source = ("source" in content and "tz.conf" in content) or \
                     (". " in content and "tz.conf" in content) or \
                     (".\t" in content and "tz.conf" in content)
        assert has_source, "run.sh must still source tz.conf - cannot remove config sourcing"


class TestFlaskAppStructurePreserved:
    """Test that the Flask app structure is preserved."""

    def test_app_py_is_still_flask_app(self):
        """app.py should still be a Flask application."""
        app_py = os.path.join(APP_DIR, "app.py")
        with open(app_py, "r") as f:
            content = f.read()
        assert "flask" in content.lower() or "Flask" in content, \
            "app.py must still be a Flask application"

    def test_app_py_still_has_profile_endpoint(self):
        """app.py should still have a /profile endpoint."""
        app_py = os.path.join(APP_DIR, "app.py")
        with open(app_py, "r") as f:
            content = f.read()
        assert "profile" in content, "app.py must still have a profile endpoint"

    def test_timing_module_still_imported_or_used(self):
        """The timing module should still be used by the app."""
        app_py = os.path.join(APP_DIR, "app.py")
        with open(app_py, "r") as f:
            content = f.read()
        assert "timing" in content, "app.py should still use the timing module"


class TestTimingTestPasses:
    """Test that the test_timing.py script passes after the fix."""

    def test_timing_test_passes_with_configs(self):
        """
        Running test_timing.py with the locale and timezone configs sourced should exit 0.
        This is the primary acceptance test for the fix.
        """
        # Build command that sources configs and runs test
        cmd = f"cd {APP_DIR} && source config/locale.conf && source config/tz.conf && python3 test_timing.py"
        result = subprocess.run(
            cmd,
            shell=True,
            capture_output=True,
            text=True,
            timeout=30
        )
        assert result.returncode == 0, \
            f"test_timing.py must pass after fix.\nSTDOUT: {result.stdout}\nSTDERR: {result.stderr}"


class TestNoAbsHack:
    """Test that the fix doesn't use abs() to force positive numbers."""

    def test_timing_py_no_abs_on_latency(self):
        """timing.py should not use abs() to force positive latency - that's cheating."""
        timing_py = os.path.join(APP_DIR, "timing.py")
        with open(timing_py, "r") as f:
            content = f.read()

        # Look for suspicious abs() usage near latency calculation
        # This is a heuristic check - abs() on its own might be fine, but abs(.*latency) or abs(.*diff) is suspicious
        lines = content.split('\n')
        for i, line in enumerate(lines):
            # Skip comments
            stripped = line.strip()
            if stripped.startswith('#'):
                continue
            # Check for abs() near latency/diff calculations
            if 'abs(' in line:
                # Check if it's near latency calculation
                context = '\n'.join(lines[max(0, i-2):min(len(lines), i+3)])
                if 'latency' in context.lower() or 'diff' in context.lower() or 'end' in context.lower() and 'start' in context.lower():
                    # This might be the cheat - but we need to be careful not to false positive
                    # The test_timing.py should catch this anyway
                    pass

    def test_app_py_no_abs_on_latency(self):
        """app.py should not use abs() to force positive latency."""
        app_py = os.path.join(APP_DIR, "app.py")
        with open(app_py, "r") as f:
            content = f.read()

        # Similar heuristic check
        lines = content.split('\n')
        for i, line in enumerate(lines):
            stripped = line.strip()
            if stripped.startswith('#'):
                continue


class TestFlaskAppProducesPositiveLatency:
    """Test that the actual Flask app produces positive latencies."""

    def test_flask_app_positive_latency_integration(self):
        """
        Start the Flask app, make a request, and verify the latency in CSV is positive.
        This is the full integration test.
        """
        run_sh = os.path.join(APP_DIR, "run.sh")
        timings_csv = os.path.join(APP_DIR, "results", "timings.csv")

        # Count existing lines in CSV
        try:
            with open(timings_csv, "r") as f:
                initial_lines = len(f.readlines())
        except FileNotFoundError:
            initial_lines = 0

        # Start the Flask app in background
        proc = subprocess.Popen(
            f"cd {APP_DIR} && ./run.sh",
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            preexec_fn=os.setsid  # Create new process group for cleanup
        )

        try:
            # Wait for server to start
            time.sleep(3)

            # Make a request to the profile endpoint
            curl_result = subprocess.run(
                ["curl", "-s", "-o", "/dev/null", "-w", "%{http_code}", "http://localhost:5000/profile"],
                capture_output=True,
                text=True,
                timeout=10
            )

            # Give time for the request to be logged
            time.sleep(1)

            # Check that request succeeded (2xx or we got a response)
            # Some implementations might return different codes, but should respond
            assert curl_result.returncode == 0, f"curl failed: {curl_result.stderr}"

            # Read the CSV and check the last line
            with open(timings_csv, "r") as f:
                lines = f.readlines()

            assert len(lines) > initial_lines, \
                "No new entries were added to timings.csv after the request"

            # Parse the last line to find latency value
            last_line = lines[-1].strip()

            # Try to find a numeric value that could be latency
            # CSV format might vary, so we look for any float
            parts = last_line.split(",")
            found_positive_latency = False
            latency_value = None

            for part in parts:
                part = part.strip()
                try:
                    val = float(part)
                    # Latency should be positive and reasonable (less than 60 seconds for a simple request)
                    if val > 0 and val < 60:
                        found_positive_latency = True
                        latency_value = val
                        break
                except ValueError:
                    continue

            assert found_positive_latency, \
                f"Last line of timings.csv should contain a positive latency value. Got: {last_line}"

        finally:
            # Clean up: kill the Flask app process group
            try:
                os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
            except (ProcessLookupError, OSError):
                pass

            # Also try to kill any remaining flask processes
            subprocess.run(
                ["pkill", "-f", "flask"],
                capture_output=True
            )
            subprocess.run(
                ["pkill", "-f", "profiler_app"],
                capture_output=True
            )

            time.sleep(1)


class TestTimestampFormatConsistency:
    """Test that the timestamp format is now consistent between logging and parsing."""

    def test_format_consistency(self):
        """
        The fix should make timestamp formats consistent.
        Either both use locale-independent format, or parsing matches what logging produces.
        """
        app_py = os.path.join(APP_DIR, "app.py")
        timing_py = os.path.join(APP_DIR, "timing.py")

        with open(app_py, "r") as f:
            app_content = f.read()

        with open(timing_py, "r") as f:
            timing_content = f.read()

        # The bug was: app.py used %X (locale-dependent), timing.py used %I:%M:%S.%f %p (12-hour)
        # Valid fixes include:
        # 1. Both use explicit 24-hour format (%H:%M:%S)
        # 2. Both use ISO format
        # 3. timing.py parses what app.py produces
        # 4. app.py produces what timing.py expects

        # Check that the problematic mismatch is fixed
        # The original bug had %I and %p in timing.py with %X in app.py

        # If timing.py still has %I and %p, app.py must also use 12-hour format
        timing_has_12hour = "%I" in timing_content and "%p" in timing_content
        app_has_locale_X = "%X" in app_content

        if timing_has_12hour and app_has_locale_X:
            # This is still the buggy state - unless locale was changed to produce 12-hour
            # But we can't easily verify that, so we rely on the test_timing.py passing
            pass

        # The test_timing_test_passes_with_configs test is the real verification
        # This test just does a sanity check that something changed

        # At minimum, verify that the test_timing.py test passes (done in other test)
        # Here we just verify files are readable Python
        try:
            compile(app_content, app_py, 'exec')
        except SyntaxError as e:
            pytest.fail(f"app.py has syntax error: {e}")

        try:
            compile(timing_content, timing_py, 'exec')
        except SyntaxError as e:
            pytest.fail(f"timing.py has syntax error: {e}")
