# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the task of pinning numpy to 1.24.3 in requirements.txt.
"""

import os
import pytest


class TestInitialState:
    """Validate the initial state before the task is performed."""

    REQUIREMENTS_PATH = "/home/user/svc/requirements.txt"
    SVC_DIR = "/home/user/svc"

    def test_svc_directory_exists(self):
        """The /home/user/svc/ directory must exist."""
        assert os.path.isdir(self.SVC_DIR), (
            f"Directory {self.SVC_DIR} does not exist. "
            "The svc directory must be present for the task."
        )

    def test_svc_directory_is_writable(self):
        """The /home/user/svc/ directory must be writable."""
        assert os.access(self.SVC_DIR, os.W_OK), (
            f"Directory {self.SVC_DIR} is not writable. "
            "The agent needs write access to modify requirements.txt."
        )

    def test_requirements_file_exists(self):
        """The requirements.txt file must exist."""
        assert os.path.isfile(self.REQUIREMENTS_PATH), (
            f"File {self.REQUIREMENTS_PATH} does not exist. "
            "The requirements.txt file must be present for the task."
        )

    def test_requirements_file_is_readable(self):
        """The requirements.txt file must be readable."""
        assert os.access(self.REQUIREMENTS_PATH, os.R_OK), (
            f"File {self.REQUIREMENTS_PATH} is not readable. "
            "The agent needs read access to the requirements file."
        )

    def test_requirements_file_is_writable(self):
        """The requirements.txt file must be writable."""
        assert os.access(self.REQUIREMENTS_PATH, os.W_OK), (
            f"File {self.REQUIREMENTS_PATH} is not writable. "
            "The agent needs write access to modify the requirements file."
        )

    def test_requirements_contains_flask(self):
        """The requirements.txt must contain flask==2.3.2."""
        with open(self.REQUIREMENTS_PATH, 'r') as f:
            content = f.read()
        assert "flask==2.3.2" in content, (
            "requirements.txt must contain 'flask==2.3.2'. "
            "This is part of the expected initial state."
        )

    def test_requirements_contains_requests(self):
        """The requirements.txt must contain requests>=2.28.0."""
        with open(self.REQUIREMENTS_PATH, 'r') as f:
            content = f.read()
        assert "requests>=2.28.0" in content, (
            "requirements.txt must contain 'requests>=2.28.0'. "
            "This is part of the expected initial state."
        )

    def test_requirements_contains_numpy_unpinned(self):
        """The requirements.txt must contain numpy (unpinned) initially."""
        with open(self.REQUIREMENTS_PATH, 'r') as f:
            lines = [line.strip() for line in f.readlines()]

        # Check that there's a line that is exactly "numpy" (unpinned)
        assert "numpy" in lines, (
            "requirements.txt must contain an unpinned 'numpy' line. "
            "This is the line that needs to be pinned to 1.24.3."
        )

    def test_numpy_is_not_already_pinned(self):
        """The numpy entry must NOT already be pinned (it should be unpinned)."""
        with open(self.REQUIREMENTS_PATH, 'r') as f:
            content = f.read()

        # numpy should not have any version specifier in the initial state
        assert "numpy==" not in content, (
            "numpy should not already be pinned with '=='. "
            "The initial state should have unpinned 'numpy'."
        )
        assert "numpy>=" not in content, (
            "numpy should not have a '>=' version specifier. "
            "The initial state should have unpinned 'numpy'."
        )
        assert "numpy<=" not in content, (
            "numpy should not have a '<=' version specifier. "
            "The initial state should have unpinned 'numpy'."
        )

    def test_requirements_contains_pandas(self):
        """The requirements.txt must contain pandas==2.0.3."""
        with open(self.REQUIREMENTS_PATH, 'r') as f:
            content = f.read()
        assert "pandas==2.0.3" in content, (
            "requirements.txt must contain 'pandas==2.0.3'. "
            "This is part of the expected initial state."
        )

    def test_requirements_contains_redis(self):
        """The requirements.txt must contain redis==4.5.1."""
        with open(self.REQUIREMENTS_PATH, 'r') as f:
            content = f.read()
        assert "redis==4.5.1" in content, (
            "requirements.txt must contain 'redis==4.5.1'. "
            "This is part of the expected initial state."
        )

    def test_requirements_has_five_lines(self):
        """The requirements.txt must have exactly 5 non-empty lines."""
        with open(self.REQUIREMENTS_PATH, 'r') as f:
            lines = [line.strip() for line in f.readlines() if line.strip()]

        assert len(lines) == 5, (
            f"requirements.txt should have exactly 5 package lines, "
            f"but found {len(lines)}. Expected: flask, requests, numpy, pandas, redis."
        )

    def test_requirements_expected_content(self):
        """Verify the complete expected initial content of requirements.txt."""
        expected_lines = [
            "flask==2.3.2",
            "requests>=2.28.0",
            "numpy",
            "pandas==2.0.3",
            "redis==4.5.1",
        ]

        with open(self.REQUIREMENTS_PATH, 'r') as f:
            actual_lines = [line.strip() for line in f.readlines() if line.strip()]

        assert actual_lines == expected_lines, (
            f"requirements.txt content does not match expected initial state.\n"
            f"Expected:\n{expected_lines}\n"
            f"Actual:\n{actual_lines}"
        )
