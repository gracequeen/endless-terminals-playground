# test_final_state.py
"""
Tests to validate the final state of the OS/filesystem after the student
has completed the task of pinning numpy to 1.24.3 in requirements.txt.
"""

import os
import subprocess
import pytest


class TestFinalState:
    """Validate the final state after the task is performed."""

    REQUIREMENTS_PATH = "/home/user/svc/requirements.txt"
    SVC_DIR = "/home/user/svc"

    def test_requirements_file_exists(self):
        """The requirements.txt file must still exist."""
        assert os.path.isfile(self.REQUIREMENTS_PATH), (
            f"File {self.REQUIREMENTS_PATH} does not exist. "
            "The requirements.txt file must be present after the task."
        )

    def test_numpy_is_pinned_to_correct_version(self):
        """The requirements.txt must contain numpy==1.24.3."""
        with open(self.REQUIREMENTS_PATH, 'r') as f:
            content = f.read()
        assert "numpy==1.24.3" in content, (
            "requirements.txt must contain 'numpy==1.24.3'. "
            f"Current content:\n{content}"
        )

    def test_numpy_pinned_on_own_line(self):
        """numpy==1.24.3 must be on its own line (not combined with other packages)."""
        with open(self.REQUIREMENTS_PATH, 'r') as f:
            lines = [line.strip() for line in f.readlines() if line.strip()]

        assert "numpy==1.24.3" in lines, (
            "numpy==1.24.3 must be on its own line. "
            f"Current lines: {lines}"
        )

    def test_grep_matches_exactly_one_numpy_line(self):
        """grep -E '^numpy==1\\.24\\.3$' must match exactly one line."""
        result = subprocess.run(
            ["grep", "-E", "^numpy==1\\.24\\.3$", self.REQUIREMENTS_PATH],
            capture_output=True,
            text=True
        )
        matches = [line for line in result.stdout.strip().split('\n') if line]
        assert len(matches) == 1, (
            f"Expected exactly one line matching '^numpy==1.24.3$', "
            f"but found {len(matches)}. Matches: {matches}"
        )

    def test_file_has_exactly_five_lines(self):
        """The requirements.txt must have exactly 5 lines (wc -l)."""
        with open(self.REQUIREMENTS_PATH, 'r') as f:
            content = f.read()

        # Count lines (including the final newline as a line terminator)
        # wc -l counts newline characters, so a file with 5 lines ending with newline has 5
        line_count = content.count('\n')

        # If file doesn't end with newline, we need to add 1 for the last line
        if content and not content.endswith('\n'):
            line_count += 1

        assert line_count == 5, (
            f"requirements.txt should have exactly 5 lines, "
            f"but found {line_count}."
        )

    def test_file_ends_with_newline(self):
        """The file must end with a newline."""
        with open(self.REQUIREMENTS_PATH, 'r') as f:
            content = f.read()
        assert content.endswith('\n'), (
            "requirements.txt must end with a newline character."
        )

    def test_flask_unchanged(self):
        """flask==2.3.2 must remain unchanged."""
        with open(self.REQUIREMENTS_PATH, 'r') as f:
            lines = [line.strip() for line in f.readlines() if line.strip()]
        assert "flask==2.3.2" in lines, (
            "flask==2.3.2 must remain in requirements.txt. "
            f"Current lines: {lines}"
        )

    def test_requests_unchanged(self):
        """requests>=2.28.0 must remain unchanged."""
        with open(self.REQUIREMENTS_PATH, 'r') as f:
            lines = [line.strip() for line in f.readlines() if line.strip()]
        assert "requests>=2.28.0" in lines, (
            "requests>=2.28.0 must remain in requirements.txt. "
            f"Current lines: {lines}"
        )

    def test_pandas_unchanged(self):
        """pandas==2.0.3 must remain unchanged."""
        with open(self.REQUIREMENTS_PATH, 'r') as f:
            lines = [line.strip() for line in f.readlines() if line.strip()]
        assert "pandas==2.0.3" in lines, (
            "pandas==2.0.3 must remain in requirements.txt. "
            f"Current lines: {lines}"
        )

    def test_redis_unchanged(self):
        """redis==4.5.1 must remain unchanged."""
        with open(self.REQUIREMENTS_PATH, 'r') as f:
            lines = [line.strip() for line in f.readlines() if line.strip()]
        assert "redis==4.5.1" in lines, (
            "redis==4.5.1 must remain in requirements.txt. "
            f"Current lines: {lines}"
        )

    def test_no_unpinned_numpy_remains(self):
        """There should be no unpinned 'numpy' line remaining."""
        with open(self.REQUIREMENTS_PATH, 'r') as f:
            lines = [line.strip() for line in f.readlines() if line.strip()]

        # Check that there's no line that is exactly "numpy" (unpinned)
        assert "numpy" not in lines, (
            "The unpinned 'numpy' line should have been replaced with 'numpy==1.24.3'. "
            f"Current lines: {lines}"
        )

    def test_line_order_preserved(self):
        """The line order must be preserved: flask, requests, numpy, pandas, redis."""
        expected_lines = [
            "flask==2.3.2",
            "requests>=2.28.0",
            "numpy==1.24.3",
            "pandas==2.0.3",
            "redis==4.5.1",
        ]

        with open(self.REQUIREMENTS_PATH, 'r') as f:
            actual_lines = [line.strip() for line in f.readlines() if line.strip()]

        assert actual_lines == expected_lines, (
            f"requirements.txt content does not match expected final state.\n"
            f"Expected:\n{expected_lines}\n"
            f"Actual:\n{actual_lines}"
        )

    def test_no_extra_packages_added(self):
        """No extra packages should have been added."""
        with open(self.REQUIREMENTS_PATH, 'r') as f:
            lines = [line.strip() for line in f.readlines() if line.strip()]

        expected_package_prefixes = ["flask", "requests", "numpy", "pandas", "redis"]

        for line in lines:
            package_name = line.split('=')[0].split('>')[0].split('<')[0].split('[')[0]
            assert package_name in expected_package_prefixes, (
                f"Unexpected package found: '{line}'. "
                f"Only flask, requests, numpy, pandas, and redis should be present."
            )

    def test_exactly_five_packages(self):
        """There should be exactly 5 packages in the file."""
        with open(self.REQUIREMENTS_PATH, 'r') as f:
            lines = [line.strip() for line in f.readlines() if line.strip()]

        assert len(lines) == 5, (
            f"Expected exactly 5 packages, but found {len(lines)}. "
            f"Lines: {lines}"
        )
