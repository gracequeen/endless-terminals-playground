I need to pin numpy to 1.24.3 in /home/user/svc/requirements.txt — it's currently unpinned and the latest 2.x breaks our image build. Just that one line, leave everything else alone.
