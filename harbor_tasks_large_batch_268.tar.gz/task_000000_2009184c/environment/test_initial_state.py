# test_initial_state.py
"""
Tests to validate the initial state before the student adds a `last_login` column
to the `users` table in /home/user/app/data.db.
"""

import os
import subprocess
import sqlite3
import pytest


DATABASE_PATH = "/home/user/app/data.db"
APP_DIR = "/home/user/app"


class TestDirectoryStructure:
    """Test that required directories exist and are writable."""

    def test_app_directory_exists(self):
        """The /home/user/app/ directory must exist."""
        assert os.path.isdir(APP_DIR), f"Directory {APP_DIR} does not exist"

    def test_app_directory_is_writable(self):
        """The /home/user/app/ directory must be writable."""
        assert os.access(APP_DIR, os.W_OK), f"Directory {APP_DIR} is not writable"


class TestDatabaseFile:
    """Test that the database file exists and is valid SQLite3."""

    def test_database_file_exists(self):
        """The database file /home/user/app/data.db must exist."""
        assert os.path.isfile(DATABASE_PATH), f"Database file {DATABASE_PATH} does not exist"

    def test_database_is_valid_sqlite3(self):
        """The database file must be a valid SQLite3 database."""
        try:
            conn = sqlite3.connect(DATABASE_PATH)
            cursor = conn.cursor()
            cursor.execute("SELECT 1")
            conn.close()
        except sqlite3.DatabaseError as e:
            pytest.fail(f"Database file {DATABASE_PATH} is not a valid SQLite3 database: {e}")


class TestSqlite3CLI:
    """Test that sqlite3 CLI is available."""

    def test_sqlite3_cli_available(self):
        """The sqlite3 CLI tool must be available."""
        result = subprocess.run(
            ["which", "sqlite3"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "sqlite3 CLI is not available in PATH"

    def test_sqlite3_cli_works(self):
        """The sqlite3 CLI must be functional."""
        result = subprocess.run(
            ["sqlite3", "--version"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, f"sqlite3 CLI is not working: {result.stderr}"


class TestUsersTableSchema:
    """Test that the users table exists with the expected initial schema."""

    def test_users_table_exists(self):
        """The users table must exist in the database."""
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        cursor.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='users'"
        )
        result = cursor.fetchone()
        conn.close()
        assert result is not None, "Table 'users' does not exist in the database"

    def test_users_table_has_id_column(self):
        """The users table must have an 'id' column."""
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        cursor.execute("PRAGMA table_info(users)")
        columns = {row[1]: row for row in cursor.fetchall()}
        conn.close()
        assert "id" in columns, "Column 'id' is missing from users table"

    def test_users_table_has_email_column(self):
        """The users table must have an 'email' column."""
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        cursor.execute("PRAGMA table_info(users)")
        columns = {row[1]: row for row in cursor.fetchall()}
        conn.close()
        assert "email" in columns, "Column 'email' is missing from users table"

    def test_users_table_has_created_at_column(self):
        """The users table must have a 'created_at' column."""
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        cursor.execute("PRAGMA table_info(users)")
        columns = {row[1]: row for row in cursor.fetchall()}
        conn.close()
        assert "created_at" in columns, "Column 'created_at' is missing from users table"

    def test_users_table_does_not_have_last_login_column(self):
        """The users table must NOT have a 'last_login' column yet (this is what the student needs to add)."""
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        cursor.execute("PRAGMA table_info(users)")
        columns = {row[1]: row for row in cursor.fetchall()}
        conn.close()
        assert "last_login" not in columns, (
            "Column 'last_login' already exists in users table - "
            "the student task is to add this column"
        )


class TestUsersTableData:
    """Test that the users table has the expected initial data."""

    def test_users_table_has_three_rows(self):
        """The users table must have exactly 3 rows of test data."""
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM users")
        count = cursor.fetchone()[0]
        conn.close()
        assert count == 3, f"Expected 3 rows in users table, found {count}"

    def test_users_table_data_is_queryable(self):
        """The existing columns must be queryable."""
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        cursor.execute("SELECT id, email, created_at FROM users")
        rows = cursor.fetchall()
        conn.close()
        assert len(rows) == 3, f"Expected 3 rows, got {len(rows)}"
        for row in rows:
            assert row[0] is not None, "id should not be None"
            assert row[1] is not None, "email should not be None (NOT NULL constraint)"

    def test_users_have_valid_ids(self):
        """Each user must have a valid integer id."""
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        cursor.execute("SELECT id FROM users")
        ids = [row[0] for row in cursor.fetchall()]
        conn.close()
        assert len(ids) == 3, f"Expected 3 ids, got {len(ids)}"
        for user_id in ids:
            assert isinstance(user_id, int), f"id should be an integer, got {type(user_id)}"

    def test_users_have_valid_emails(self):
        """Each user must have a non-empty email."""
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        cursor.execute("SELECT email FROM users")
        emails = [row[0] for row in cursor.fetchall()]
        conn.close()
        assert len(emails) == 3, f"Expected 3 emails, got {len(emails)}"
        for email in emails:
            assert email is not None and len(email) > 0, "email should not be empty"


class TestDatabaseIntegrity:
    """Test database integrity."""

    def test_database_integrity_check(self):
        """The database must pass SQLite integrity check."""
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        cursor.execute("PRAGMA integrity_check")
        result = cursor.fetchone()[0]
        conn.close()
        assert result == "ok", f"Database integrity check failed: {result}"
