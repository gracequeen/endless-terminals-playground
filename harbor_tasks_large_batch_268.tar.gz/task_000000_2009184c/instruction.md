I need to add a column `last_login` (timestamp, nullable) to the `users` table in /home/user/app/data.db — it's sqlite3. Don't want to lose the existing rows obviously.
