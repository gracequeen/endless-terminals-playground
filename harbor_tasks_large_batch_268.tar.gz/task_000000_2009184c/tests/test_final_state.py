# test_final_state.py
"""
Tests to validate the final state after the student has added a `last_login` column
to the `users` table in /home/user/app/data.db.
"""

import os
import subprocess
import sqlite3
import pytest


DATABASE_PATH = "/home/user/app/data.db"
APP_DIR = "/home/user/app"


class TestDatabaseFileIntegrity:
    """Test that the database file is still valid after modifications."""

    def test_database_file_exists(self):
        """The database file /home/user/app/data.db must still exist."""
        assert os.path.isfile(DATABASE_PATH), f"Database file {DATABASE_PATH} does not exist"

    def test_database_is_valid_sqlite3(self):
        """The database file must still be a valid SQLite3 database."""
        try:
            conn = sqlite3.connect(DATABASE_PATH)
            cursor = conn.cursor()
            cursor.execute("SELECT 1")
            conn.close()
        except sqlite3.DatabaseError as e:
            pytest.fail(f"Database file {DATABASE_PATH} is not a valid SQLite3 database: {e}")

    def test_database_integrity_check(self):
        """The database must pass SQLite integrity check."""
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        cursor.execute("PRAGMA integrity_check")
        result = cursor.fetchone()[0]
        conn.close()
        assert result == "ok", f"Database integrity check failed: {result}"


class TestLastLoginColumnExists:
    """Test that the last_login column was added correctly."""

    def test_last_login_column_exists_in_schema(self):
        """The users table must have a 'last_login' column in its schema."""
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        cursor.execute("PRAGMA table_info(users)")
        columns = {row[1]: row for row in cursor.fetchall()}
        conn.close()
        assert "last_login" in columns, (
            "Column 'last_login' does not exist in users table schema. "
            "The column must be added using ALTER TABLE."
        )

    def test_last_login_column_via_cli(self):
        """The last_login column must appear in .schema output via sqlite3 CLI."""
        result = subprocess.run(
            ["sqlite3", DATABASE_PATH, ".schema users"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, f"sqlite3 CLI failed: {result.stderr}"
        schema_output = result.stdout.lower()
        assert "last_login" in schema_output, (
            f"Column 'last_login' not found in schema output. "
            f"Schema: {result.stdout}"
        )

    def test_last_login_column_is_nullable(self):
        """The last_login column must be nullable (no NOT NULL constraint)."""
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        cursor.execute("PRAGMA table_info(users)")
        columns = {row[1]: row for row in cursor.fetchall()}
        conn.close()

        assert "last_login" in columns, "Column 'last_login' does not exist"

        # PRAGMA table_info returns: (cid, name, type, notnull, dflt_value, pk)
        # notnull is at index 3: 0 means nullable, 1 means NOT NULL
        notnull = columns["last_login"][3]
        assert notnull == 0, (
            f"Column 'last_login' has NOT NULL constraint but should be nullable. "
            f"notnull flag is {notnull}"
        )

    def test_last_login_column_has_timestamp_compatible_type(self):
        """The last_login column should have a timestamp-compatible type."""
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        cursor.execute("PRAGMA table_info(users)")
        columns = {row[1]: row for row in cursor.fetchall()}
        conn.close()

        assert "last_login" in columns, "Column 'last_login' does not exist"

        # PRAGMA table_info returns: (cid, name, type, notnull, dflt_value, pk)
        # type is at index 2
        col_type = columns["last_login"][2].upper() if columns["last_login"][2] else ""

        # SQLite is flexible with types - these are all valid for timestamps
        valid_types = ["TEXT", "INTEGER", "REAL", "TIMESTAMP", "DATETIME", ""]
        type_is_valid = any(valid_type in col_type for valid_type in valid_types) or col_type == ""

        assert type_is_valid, (
            f"Column 'last_login' has type '{col_type}' which may not be suitable for timestamps. "
            f"Expected one of: TEXT, INTEGER, REAL, TIMESTAMP, DATETIME, or no type (SQLite is flexible)"
        )


class TestOriginalColumnsPreserved:
    """Test that the original columns are still present and unchanged."""

    def test_id_column_still_exists(self):
        """The 'id' column must still exist."""
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        cursor.execute("PRAGMA table_info(users)")
        columns = {row[1]: row for row in cursor.fetchall()}
        conn.close()
        assert "id" in columns, "Column 'id' is missing from users table"

    def test_email_column_still_exists(self):
        """The 'email' column must still exist."""
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        cursor.execute("PRAGMA table_info(users)")
        columns = {row[1]: row for row in cursor.fetchall()}
        conn.close()
        assert "email" in columns, "Column 'email' is missing from users table"

    def test_created_at_column_still_exists(self):
        """The 'created_at' column must still exist."""
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        cursor.execute("PRAGMA table_info(users)")
        columns = {row[1]: row for row in cursor.fetchall()}
        conn.close()
        assert "created_at" in columns, "Column 'created_at' is missing from users table"


class TestDataPreservation:
    """Test that all original data rows are preserved."""

    def test_row_count_preserved(self):
        """The users table must still have exactly 3 rows."""
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM users")
        count = cursor.fetchone()[0]
        conn.close()
        assert count == 3, (
            f"Expected 3 rows in users table, found {count}. "
            "Original data may have been lost during the column addition."
        )

    def test_row_count_via_cli(self):
        """Verify row count using sqlite3 CLI as specified in requirements."""
        result = subprocess.run(
            ["sqlite3", DATABASE_PATH, "SELECT COUNT(*) FROM users"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, f"sqlite3 CLI failed: {result.stderr}"
        count = int(result.stdout.strip())
        assert count == 3, (
            f"Expected 3 rows via CLI, got {count}. "
            "Original data may have been lost."
        )

    def test_original_columns_queryable(self):
        """The original columns must still be queryable."""
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        cursor.execute("SELECT id, email, created_at FROM users")
        rows = cursor.fetchall()
        conn.close()
        assert len(rows) == 3, f"Expected 3 rows, got {len(rows)}"

    def test_original_data_integrity(self):
        """Each row must have valid id and email values (not corrupted)."""
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        cursor.execute("SELECT id, email, created_at FROM users")
        rows = cursor.fetchall()
        conn.close()

        for row in rows:
            user_id, email, created_at = row
            assert user_id is not None, "id should not be None"
            assert isinstance(user_id, int), f"id should be an integer, got {type(user_id)}"
            assert email is not None, "email should not be None (NOT NULL constraint)"
            assert len(email) > 0, "email should not be empty"

    def test_original_columns_via_cli(self):
        """Verify original columns are queryable via CLI as specified."""
        result = subprocess.run(
            ["sqlite3", DATABASE_PATH, "SELECT id, email, created_at FROM users"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, f"sqlite3 CLI failed: {result.stderr}"
        lines = [line for line in result.stdout.strip().split('\n') if line]
        assert len(lines) == 3, (
            f"Expected 3 rows of output, got {len(lines)}. "
            f"Output: {result.stdout}"
        )


class TestNewColumnFunctionality:
    """Test that the new last_login column works correctly."""

    def test_last_login_column_queryable(self):
        """The last_login column must be queryable."""
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        try:
            cursor.execute("SELECT last_login FROM users")
            rows = cursor.fetchall()
            assert len(rows) == 3, f"Expected 3 rows, got {len(rows)}"
        except sqlite3.OperationalError as e:
            pytest.fail(f"Cannot query last_login column: {e}")
        finally:
            conn.close()

    def test_last_login_accepts_null(self):
        """The last_login column must accept NULL values."""
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        try:
            # Existing rows should have NULL for last_login (since column was just added)
            cursor.execute("SELECT last_login FROM users WHERE last_login IS NULL")
            null_rows = cursor.fetchall()
            # At minimum, the column should accept NULL - we don't require all to be NULL
            # but typically newly added columns will have NULL for existing rows
            cursor.execute("SELECT COUNT(*) FROM users")
            total = cursor.fetchone()[0]
            assert total == 3, "Row count changed unexpectedly"
        except sqlite3.OperationalError as e:
            pytest.fail(f"Error querying last_login column: {e}")
        finally:
            conn.close()

    def test_last_login_can_be_updated(self):
        """The last_login column must be updatable (verify it's a real column)."""
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        try:
            # Get the first user's id
            cursor.execute("SELECT id FROM users LIMIT 1")
            user_id = cursor.fetchone()[0]

            # Try to update last_login
            cursor.execute(
                "UPDATE users SET last_login = '2024-01-01 12:00:00' WHERE id = ?",
                (user_id,)
            )

            # Verify the update worked
            cursor.execute("SELECT last_login FROM users WHERE id = ?", (user_id,))
            result = cursor.fetchone()[0]
            assert result == '2024-01-01 12:00:00', (
                f"last_login update failed. Expected '2024-01-01 12:00:00', got '{result}'"
            )

            # Rollback to not affect other tests
            conn.rollback()
        except sqlite3.OperationalError as e:
            pytest.fail(f"Cannot update last_login column: {e}")
        finally:
            conn.close()


class TestAntiShortcutGuards:
    """Tests to ensure the column was added properly, not via views or aliases."""

    def test_users_is_a_table_not_view(self):
        """The 'users' must be a table, not a view."""
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        cursor.execute(
            "SELECT type FROM sqlite_master WHERE name='users'"
        )
        result = cursor.fetchone()
        conn.close()
        assert result is not None, "'users' not found in sqlite_master"
        assert result[0] == 'table', (
            f"'users' is a {result[0]}, not a table. "
            "The column must be added to the actual table."
        )

    def test_last_login_in_table_schema(self):
        """The last_login column must appear in the actual table schema in sqlite_master."""
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        cursor.execute(
            "SELECT sql FROM sqlite_master WHERE type='table' AND name='users'"
        )
        result = cursor.fetchone()
        conn.close()
        assert result is not None, "Table 'users' not found in sqlite_master"
        schema_sql = result[0].lower()
        assert "last_login" in schema_sql, (
            f"Column 'last_login' not found in table schema. "
            f"Schema: {result[0]}"
        )
