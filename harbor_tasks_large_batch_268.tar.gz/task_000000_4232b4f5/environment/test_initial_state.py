# test_initial_state.py
"""
Tests to validate the initial state of the system before the student installs jq.
"""

import os
import subprocess
import stat
import pytest


class TestInitialState:
    """Validate the system state before jq installation."""

    def test_script_exists(self):
        """Verify /home/user/scripts/parse_logs.sh exists."""
        script_path = "/home/user/scripts/parse_logs.sh"
        assert os.path.exists(script_path), (
            f"Script {script_path} does not exist. "
            "The parse_logs.sh script should be present in /home/user/scripts/"
        )

    def test_script_is_file(self):
        """Verify parse_logs.sh is a regular file."""
        script_path = "/home/user/scripts/parse_logs.sh"
        assert os.path.isfile(script_path), (
            f"{script_path} exists but is not a regular file"
        )

    def test_script_is_executable(self):
        """Verify parse_logs.sh is executable."""
        script_path = "/home/user/scripts/parse_logs.sh"
        file_stat = os.stat(script_path)
        is_executable = file_stat.st_mode & (stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
        assert is_executable, (
            f"{script_path} is not executable. "
            "The script should have execute permissions."
        )

    def test_script_contains_jq_command(self):
        """Verify the script contains a jq command (pipes JSON through jq)."""
        script_path = "/home/user/scripts/parse_logs.sh"
        with open(script_path, 'r') as f:
            content = f.read()
        assert 'jq' in content, (
            f"{script_path} does not contain 'jq' command. "
            "The script should pipe JSON through jq."
        )

    def test_script_has_shebang(self):
        """Verify the script has a proper shebang."""
        script_path = "/home/user/scripts/parse_logs.sh"
        with open(script_path, 'r') as f:
            first_line = f.readline()
        assert first_line.startswith('#!'), (
            f"{script_path} does not have a shebang line. "
            "Expected script to start with #!/bin/bash or similar."
        )

    def test_jq_not_installed_which(self):
        """Verify jq is NOT installed (which jq returns nothing)."""
        result = subprocess.run(
            ['which', 'jq'],
            capture_output=True,
            text=True
        )
        assert result.returncode != 0, (
            "jq is already installed (which jq succeeded). "
            "Initial state requires jq to NOT be installed."
        )

    def test_jq_not_installed_command_v(self):
        """Verify jq is NOT available via command -v."""
        result = subprocess.run(
            ['bash', '-c', 'command -v jq'],
            capture_output=True,
            text=True
        )
        assert result.returncode != 0, (
            "jq is already available in PATH. "
            "Initial state requires jq to NOT be installed."
        )

    def test_script_fails_without_jq(self):
        """Verify the script fails because jq is not installed."""
        script_path = "/home/user/scripts/parse_logs.sh"
        result = subprocess.run(
            [script_path],
            capture_output=True,
            text=True
        )
        assert result.returncode != 0, (
            "Script succeeded but should fail because jq is not installed. "
            f"stdout: {result.stdout}, stderr: {result.stderr}"
        )
        # Check that the error is related to jq not being found
        combined_output = result.stdout + result.stderr
        assert 'jq' in combined_output.lower() or 'not found' in combined_output.lower(), (
            "Script failed but not with expected 'jq not found' error. "
            f"stderr: {result.stderr}"
        )

    def test_scripts_directory_exists(self):
        """Verify /home/user/scripts directory exists."""
        scripts_dir = "/home/user/scripts"
        assert os.path.isdir(scripts_dir), (
            f"Directory {scripts_dir} does not exist. "
            "The scripts directory should be present."
        )

    def test_scripts_directory_writable(self):
        """Verify /home/user/scripts is writable."""
        scripts_dir = "/home/user/scripts"
        assert os.access(scripts_dir, os.W_OK), (
            f"Directory {scripts_dir} is not writable. "
            "The scripts directory should be writable."
        )

    def test_apt_available(self):
        """Verify apt is available on the system."""
        result = subprocess.run(
            ['which', 'apt'],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "apt is not available on this system. "
            "This should be an Ubuntu system with apt package manager."
        )

    def test_sudo_available(self):
        """Verify sudo is available."""
        result = subprocess.run(
            ['which', 'sudo'],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "sudo is not available on this system. "
            "sudo should be available for package installation."
        )

    def test_home_user_exists(self):
        """Verify /home/user directory exists."""
        home_dir = "/home/user"
        assert os.path.isdir(home_dir), (
            f"Home directory {home_dir} does not exist."
        )
