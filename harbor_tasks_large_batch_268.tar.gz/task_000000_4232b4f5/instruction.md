Need to install jq on this box — /home/user/scripts/parse_logs.sh keeps failing because it's not there. Pretty sure it's in the standard repos, just hasn't been installed yet.
