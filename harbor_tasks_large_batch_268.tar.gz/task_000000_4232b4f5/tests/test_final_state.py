# test_final_state.py
"""
Tests to validate the final state of the system after the student installs jq.
"""

import os
import subprocess
import stat
import hashlib
import pytest


class TestFinalState:
    """Validate the system state after jq installation."""

    def test_jq_installed_which(self):
        """Verify jq is installed and available via which."""
        result = subprocess.run(
            ['which', 'jq'],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "jq is not installed. 'which jq' failed. "
            "Please install jq using 'sudo apt install jq'."
        )
        jq_path = result.stdout.strip()
        assert jq_path, (
            "which jq returned success but no path. "
            "jq should be available in PATH."
        )

    def test_jq_installed_command_v(self):
        """Verify jq is available via command -v."""
        result = subprocess.run(
            ['bash', '-c', 'command -v jq'],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "jq is not available in PATH. 'command -v jq' failed. "
            "Please ensure jq is properly installed."
        )

    def test_jq_executable_exists(self):
        """Verify jq executable exists at expected location."""
        result = subprocess.run(
            ['which', 'jq'],
            capture_output=True,
            text=True
        )
        if result.returncode == 0:
            jq_path = result.stdout.strip()
            assert os.path.isfile(jq_path), (
                f"jq path {jq_path} does not point to a file."
            )
            assert os.access(jq_path, os.X_OK), (
                f"jq at {jq_path} is not executable."
            )

    def test_jq_runs_successfully(self):
        """Verify jq can be executed and works correctly."""
        result = subprocess.run(
            ['jq', '--version'],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "jq --version failed. jq may not be properly installed. "
            f"stderr: {result.stderr}"
        )
        assert 'jq' in result.stdout.lower(), (
            "jq --version did not return expected output. "
            f"stdout: {result.stdout}"
        )

    def test_jq_processes_json(self):
        """Verify jq can process JSON input correctly."""
        result = subprocess.run(
            ['bash', '-c', "echo '{\"test\":123}' | jq '.test'"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "jq failed to process JSON input. "
            f"stderr: {result.stderr}"
        )
        assert '123' in result.stdout, (
            "jq did not return expected value from JSON. "
            f"Expected '123' in output, got: {result.stdout}"
        )

    def test_script_exists(self):
        """Verify /home/user/scripts/parse_logs.sh still exists."""
        script_path = "/home/user/scripts/parse_logs.sh"
        assert os.path.exists(script_path), (
            f"Script {script_path} does not exist. "
            "The script should not have been removed."
        )

    def test_script_is_executable(self):
        """Verify parse_logs.sh is still executable."""
        script_path = "/home/user/scripts/parse_logs.sh"
        file_stat = os.stat(script_path)
        is_executable = file_stat.st_mode & (stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
        assert is_executable, (
            f"{script_path} is not executable. "
            "The script should retain its execute permissions."
        )

    def test_script_contains_jq(self):
        """Verify the script still contains jq command (not modified to bypass jq)."""
        script_path = "/home/user/scripts/parse_logs.sh"
        with open(script_path, 'r') as f:
            content = f.read()
        assert 'jq' in content, (
            f"{script_path} no longer contains 'jq' command. "
            "The script should not be modified - jq should be installed instead."
        )

    def test_script_not_hardcoded(self):
        """Verify the script wasn't modified to just echo 42."""
        script_path = "/home/user/scripts/parse_logs.sh"
        with open(script_path, 'r') as f:
            content = f.read()
        # The script should pipe through jq, not just echo the answer
        assert 'jq' in content, (
            "Script appears to have been modified to bypass jq. "
            "Install jq instead of modifying the script."
        )
        # Check it still has the JSON and jq pipeline
        assert '{' in content and 'jq' in content, (
            "Script content appears modified. "
            "The original script should be preserved."
        )

    def test_script_runs_successfully(self):
        """Verify /home/user/scripts/parse_logs.sh runs successfully."""
        script_path = "/home/user/scripts/parse_logs.sh"
        result = subprocess.run(
            [script_path],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"Script {script_path} failed with exit code {result.returncode}. "
            f"stdout: {result.stdout}, stderr: {result.stderr}"
        )

    def test_script_outputs_42(self):
        """Verify the script outputs 42 (the expected JSON value)."""
        script_path = "/home/user/scripts/parse_logs.sh"
        result = subprocess.run(
            [script_path],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"Script failed. Cannot check output. "
            f"stderr: {result.stderr}"
        )
        # The output should be "42" (possibly with newline)
        output = result.stdout.strip()
        assert output == "42", (
            f"Script output is incorrect. Expected '42', got '{output}'. "
            "The script should output the 'count' value from the JSON."
        )

    def test_script_uses_real_jq(self):
        """Verify the script is using the real jq binary, not a fake."""
        # Run the script and also verify jq is being called
        script_path = "/home/user/scripts/parse_logs.sh"

        # First, ensure jq binary exists and is real
        result = subprocess.run(
            ['file', '/usr/bin/jq'],
            capture_output=True,
            text=True
        )
        # jq should be an ELF executable, not a script
        if result.returncode == 0:
            assert 'ELF' in result.stdout or 'executable' in result.stdout.lower(), (
                "/usr/bin/jq does not appear to be a real binary. "
                f"file output: {result.stdout}"
            )

    def test_scripts_directory_unchanged(self):
        """Verify /home/user/scripts directory still exists."""
        scripts_dir = "/home/user/scripts"
        assert os.path.isdir(scripts_dir), (
            f"Directory {scripts_dir} no longer exists."
        )

    def test_script_content_integrity(self):
        """Verify the script content matches expected format (anti-shortcut)."""
        script_path = "/home/user/scripts/parse_logs.sh"
        with open(script_path, 'r') as f:
            content = f.read()

        # Script should have shebang
        assert content.startswith('#!'), (
            "Script should start with a shebang line."
        )

        # Script should contain the JSON with count:42
        assert 'count' in content and '42' in content, (
            "Script should contain the original JSON with 'count' and '42'. "
            "Do not modify the script."
        )

        # Script should pipe to jq
        assert '|' in content and 'jq' in content, (
            "Script should pipe JSON to jq. Do not modify the script."
        )
