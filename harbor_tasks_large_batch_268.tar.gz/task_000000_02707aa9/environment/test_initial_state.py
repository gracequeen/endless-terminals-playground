# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the task of rotating the hardcoded API key in config.py.
"""

import os
import subprocess
import pytest


class TestInitialState:
    """Validate the initial state before the task is performed."""

    CONFIG_PATH = "/home/user/webapp/config.py"

    def test_webapp_directory_exists(self):
        """Verify the webapp directory exists."""
        webapp_dir = "/home/user/webapp"
        assert os.path.isdir(webapp_dir), (
            f"Directory {webapp_dir} does not exist. "
            "The webapp directory must be present for this task."
        )

    def test_config_file_exists(self):
        """Verify config.py exists."""
        assert os.path.isfile(self.CONFIG_PATH), (
            f"File {self.CONFIG_PATH} does not exist. "
            "The config.py file must be present for this task."
        )

    def test_config_file_is_writable(self):
        """Verify config.py is writable."""
        assert os.access(self.CONFIG_PATH, os.W_OK), (
            f"File {self.CONFIG_PATH} is not writable. "
            "The config.py file must be writable to complete this task."
        )

    def test_config_file_is_readable(self):
        """Verify config.py is readable."""
        assert os.access(self.CONFIG_PATH, os.R_OK), (
            f"File {self.CONFIG_PATH} is not readable. "
            "The config.py file must be readable to complete this task."
        )

    def test_line_12_contains_hardcoded_secret(self):
        """Verify line 12 contains the hardcoded AWS_SECRET_ACCESS_KEY."""
        with open(self.CONFIG_PATH, 'r') as f:
            lines = f.readlines()

        assert len(lines) >= 12, (
            f"File {self.CONFIG_PATH} has fewer than 12 lines. "
            "Expected at least 12 lines with the hardcoded secret on line 12."
        )

        line_12 = lines[11]  # 0-indexed
        expected_content = 'AWS_SECRET_ACCESS_KEY = "AKIAIOSFODNN7EXAMPLE123456"'
        assert expected_content in line_12, (
            f"Line 12 does not contain the expected hardcoded secret.\n"
            f"Expected: {expected_content}\n"
            f"Found: {line_12.strip()}"
        )

    def test_hardcoded_secret_present_in_file(self):
        """Verify the hardcoded secret string is present in the file."""
        with open(self.CONFIG_PATH, 'r') as f:
            content = f.read()

        assert "AKIAIOSFODNN7EXAMPLE123456" in content, (
            "The hardcoded secret 'AKIAIOSFODNN7EXAMPLE123456' is not found in config.py. "
            "This secret should be present in the initial state."
        )

    def test_os_import_present(self):
        """Verify the os module is imported at the top of the file."""
        with open(self.CONFIG_PATH, 'r') as f:
            content = f.read()

        assert "import os" in content, (
            "The 'import os' statement is not found in config.py. "
            "The os module should already be imported."
        )

    def test_debug_variable_present(self):
        """Verify DEBUG variable is present."""
        with open(self.CONFIG_PATH, 'r') as f:
            content = f.read()

        assert "DEBUG = True" in content, (
            "DEBUG = True not found in config.py. "
            "This variable should be present in the initial state."
        )

    def test_database_url_present(self):
        """Verify DATABASE_URL variable is present."""
        with open(self.CONFIG_PATH, 'r') as f:
            content = f.read()

        assert 'DATABASE_URL = "postgresql://localhost/webapp"' in content, (
            "DATABASE_URL not found in config.py. "
            "This variable should be present in the initial state."
        )

    def test_aws_access_key_id_present(self):
        """Verify AWS_ACCESS_KEY_ID variable is present."""
        with open(self.CONFIG_PATH, 'r') as f:
            content = f.read()

        assert 'AWS_ACCESS_KEY_ID = "AKIAIOSFODNN7EXAMPLE"' in content, (
            "AWS_ACCESS_KEY_ID not found in config.py. "
            "This variable should be present in the initial state."
        )

    def test_aws_region_present(self):
        """Verify AWS_REGION variable is present."""
        with open(self.CONFIG_PATH, 'r') as f:
            content = f.read()

        assert 'AWS_REGION = "us-east-1"' in content, (
            "AWS_REGION not found in config.py. "
            "This variable should be present in the initial state."
        )

    def test_env_variable_aws_secret_key_exported(self):
        """Verify AWS_SECRET_KEY environment variable is set."""
        env_value = os.environ.get("AWS_SECRET_KEY")
        assert env_value is not None, (
            "Environment variable AWS_SECRET_KEY is not set. "
            "This environment variable must be exported with the rotated credential."
        )
        assert env_value == "rotated-credential-value-2024", (
            f"Environment variable AWS_SECRET_KEY has unexpected value.\n"
            f"Expected: 'rotated-credential-value-2024'\n"
            f"Found: '{env_value}'"
        )

    def test_python3_available(self):
        """Verify Python 3 is available."""
        result = subprocess.run(
            ["python3", "--version"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "Python 3 is not available. "
            "Python 3.11 should be available for this task."
        )

    def test_config_file_is_valid_python(self):
        """Verify config.py is valid Python syntax."""
        result = subprocess.run(
            ["python3", "-m", "py_compile", self.CONFIG_PATH],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"config.py has syntax errors:\n{result.stderr}"
        )

    def test_config_file_structure(self):
        """Verify the overall structure of config.py matches expected initial state."""
        expected_vars = [
            "DEBUG",
            "DATABASE_URL", 
            "LOG_LEVEL",
            "CACHE_TIMEOUT",
            "MAX_CONNECTIONS",
            "REDIS_HOST",
            "REDIS_PORT",
            "AWS_SECRET_ACCESS_KEY",
            "AWS_ACCESS_KEY_ID",
            "AWS_REGION",
            "ENABLE_METRICS",
            "ENABLE_CACHING"
        ]

        with open(self.CONFIG_PATH, 'r') as f:
            content = f.read()

        for var in expected_vars:
            assert var in content, (
                f"Variable {var} not found in config.py. "
                "All expected config variables should be present."
            )

    def test_secret_not_using_env_var_yet(self):
        """Verify AWS_SECRET_ACCESS_KEY is NOT yet reading from environment variable."""
        with open(self.CONFIG_PATH, 'r') as f:
            content = f.read()

        # Check that the current implementation uses a hardcoded string, not os.environ/os.getenv
        lines = content.split('\n')
        for line in lines:
            if 'AWS_SECRET_ACCESS_KEY' in line and '=' in line:
                # Should NOT contain os.environ or os.getenv in initial state
                assert 'os.environ' not in line and 'os.getenv' not in line, (
                    "AWS_SECRET_ACCESS_KEY already uses os.environ or os.getenv. "
                    "In the initial state, it should have a hardcoded string value."
                )
                break
