# test_final_state.py
"""
Tests to validate the final state of the OS/filesystem after the student
has completed the task of rotating the hardcoded API key in config.py.
"""

import os
import subprocess
import re
import pytest


class TestFinalState:
    """Validate the final state after the task is performed."""

    CONFIG_PATH = "/home/user/webapp/config.py"

    def test_config_file_exists(self):
        """Verify config.py still exists."""
        assert os.path.isfile(self.CONFIG_PATH), (
            f"File {self.CONFIG_PATH} does not exist. "
            "The config.py file must still be present after the task."
        )

    def test_config_file_is_valid_python(self):
        """Verify config.py is valid Python syntax."""
        result = subprocess.run(
            ["python3", "-m", "py_compile", self.CONFIG_PATH],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"config.py has syntax errors after modification:\n{result.stderr}"
        )

    def test_hardcoded_secret_removed(self):
        """Verify the hardcoded secret string is no longer in the file."""
        result = subprocess.run(
            ["grep", "-F", "AKIAIOSFODNN7EXAMPLE123456", self.CONFIG_PATH],
            capture_output=True,
            text=True
        )
        assert result.returncode != 0, (
            "The hardcoded secret 'AKIAIOSFODNN7EXAMPLE123456' is still present in config.py. "
            "This literal string must be removed and replaced with an environment variable read."
        )

    def test_env_var_read_present(self):
        """Verify the file now reads from AWS_SECRET_KEY environment variable."""
        result = subprocess.run(
            ["grep", "-E", r"os\.(environ|getenv).*AWS_SECRET_KEY", self.CONFIG_PATH],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "config.py does not contain os.environ or os.getenv reading AWS_SECRET_KEY. "
            "The AWS_SECRET_ACCESS_KEY variable must read from the AWS_SECRET_KEY environment variable."
        )

    def test_config_returns_correct_value(self):
        """Verify importing config and accessing AWS_SECRET_ACCESS_KEY returns the rotated credential."""
        # Set the environment variable for the subprocess
        env = os.environ.copy()
        env["AWS_SECRET_KEY"] = "rotated-credential-value-2024"

        result = subprocess.run(
            [
                "python3", "-c",
                "import sys; sys.path.insert(0, '/home/user/webapp'); import config; print(config.AWS_SECRET_ACCESS_KEY)"
            ],
            capture_output=True,
            text=True,
            env=env
        )
        assert result.returncode == 0, (
            f"Failed to import config.py and access AWS_SECRET_ACCESS_KEY:\n{result.stderr}"
        )
        actual_value = result.stdout.strip()
        assert actual_value == "rotated-credential-value-2024", (
            f"AWS_SECRET_ACCESS_KEY does not return the expected value from environment.\n"
            f"Expected: 'rotated-credential-value-2024'\n"
            f"Got: '{actual_value}'"
        )

    def test_os_import_still_present(self):
        """Verify the os module import is still present."""
        with open(self.CONFIG_PATH, 'r') as f:
            content = f.read()

        assert "import os" in content, (
            "The 'import os' statement is missing from config.py. "
            "The os module import must remain in the file."
        )

    def test_debug_variable_unchanged(self):
        """Verify DEBUG variable is unchanged."""
        env = os.environ.copy()
        env["AWS_SECRET_KEY"] = "rotated-credential-value-2024"

        result = subprocess.run(
            [
                "python3", "-c",
                "import sys; sys.path.insert(0, '/home/user/webapp'); import config; print(config.DEBUG)"
            ],
            capture_output=True,
            text=True,
            env=env
        )
        assert result.returncode == 0, f"Failed to access DEBUG:\n{result.stderr}"
        assert result.stdout.strip() == "True", (
            f"DEBUG variable has been modified.\n"
            f"Expected: True\n"
            f"Got: {result.stdout.strip()}"
        )

    def test_database_url_unchanged(self):
        """Verify DATABASE_URL variable is unchanged."""
        env = os.environ.copy()
        env["AWS_SECRET_KEY"] = "rotated-credential-value-2024"

        result = subprocess.run(
            [
                "python3", "-c",
                "import sys; sys.path.insert(0, '/home/user/webapp'); import config; print(config.DATABASE_URL)"
            ],
            capture_output=True,
            text=True,
            env=env
        )
        assert result.returncode == 0, f"Failed to access DATABASE_URL:\n{result.stderr}"
        assert result.stdout.strip() == "postgresql://localhost/webapp", (
            f"DATABASE_URL variable has been modified.\n"
            f"Expected: postgresql://localhost/webapp\n"
            f"Got: {result.stdout.strip()}"
        )

    def test_log_level_unchanged(self):
        """Verify LOG_LEVEL variable is unchanged."""
        env = os.environ.copy()
        env["AWS_SECRET_KEY"] = "rotated-credential-value-2024"

        result = subprocess.run(
            [
                "python3", "-c",
                "import sys; sys.path.insert(0, '/home/user/webapp'); import config; print(config.LOG_LEVEL)"
            ],
            capture_output=True,
            text=True,
            env=env
        )
        assert result.returncode == 0, f"Failed to access LOG_LEVEL:\n{result.stderr}"
        assert result.stdout.strip() == "INFO", (
            f"LOG_LEVEL variable has been modified.\n"
            f"Expected: INFO\n"
            f"Got: {result.stdout.strip()}"
        )

    def test_cache_timeout_unchanged(self):
        """Verify CACHE_TIMEOUT variable is unchanged."""
        env = os.environ.copy()
        env["AWS_SECRET_KEY"] = "rotated-credential-value-2024"

        result = subprocess.run(
            [
                "python3", "-c",
                "import sys; sys.path.insert(0, '/home/user/webapp'); import config; print(config.CACHE_TIMEOUT)"
            ],
            capture_output=True,
            text=True,
            env=env
        )
        assert result.returncode == 0, f"Failed to access CACHE_TIMEOUT:\n{result.stderr}"
        assert result.stdout.strip() == "300", (
            f"CACHE_TIMEOUT variable has been modified.\n"
            f"Expected: 300\n"
            f"Got: {result.stdout.strip()}"
        )

    def test_max_connections_unchanged(self):
        """Verify MAX_CONNECTIONS variable is unchanged."""
        env = os.environ.copy()
        env["AWS_SECRET_KEY"] = "rotated-credential-value-2024"

        result = subprocess.run(
            [
                "python3", "-c",
                "import sys; sys.path.insert(0, '/home/user/webapp'); import config; print(config.MAX_CONNECTIONS)"
            ],
            capture_output=True,
            text=True,
            env=env
        )
        assert result.returncode == 0, f"Failed to access MAX_CONNECTIONS:\n{result.stderr}"
        assert result.stdout.strip() == "50", (
            f"MAX_CONNECTIONS variable has been modified.\n"
            f"Expected: 50\n"
            f"Got: {result.stdout.strip()}"
        )

    def test_redis_host_unchanged(self):
        """Verify REDIS_HOST variable is unchanged."""
        env = os.environ.copy()
        env["AWS_SECRET_KEY"] = "rotated-credential-value-2024"

        result = subprocess.run(
            [
                "python3", "-c",
                "import sys; sys.path.insert(0, '/home/user/webapp'); import config; print(config.REDIS_HOST)"
            ],
            capture_output=True,
            text=True,
            env=env
        )
        assert result.returncode == 0, f"Failed to access REDIS_HOST:\n{result.stderr}"
        assert result.stdout.strip() == "localhost", (
            f"REDIS_HOST variable has been modified.\n"
            f"Expected: localhost\n"
            f"Got: {result.stdout.strip()}"
        )

    def test_redis_port_unchanged(self):
        """Verify REDIS_PORT variable is unchanged."""
        env = os.environ.copy()
        env["AWS_SECRET_KEY"] = "rotated-credential-value-2024"

        result = subprocess.run(
            [
                "python3", "-c",
                "import sys; sys.path.insert(0, '/home/user/webapp'); import config; print(config.REDIS_PORT)"
            ],
            capture_output=True,
            text=True,
            env=env
        )
        assert result.returncode == 0, f"Failed to access REDIS_PORT:\n{result.stderr}"
        assert result.stdout.strip() == "6379", (
            f"REDIS_PORT variable has been modified.\n"
            f"Expected: 6379\n"
            f"Got: {result.stdout.strip()}"
        )

    def test_aws_access_key_id_unchanged(self):
        """Verify AWS_ACCESS_KEY_ID variable is unchanged."""
        env = os.environ.copy()
        env["AWS_SECRET_KEY"] = "rotated-credential-value-2024"

        result = subprocess.run(
            [
                "python3", "-c",
                "import sys; sys.path.insert(0, '/home/user/webapp'); import config; print(config.AWS_ACCESS_KEY_ID)"
            ],
            capture_output=True,
            text=True,
            env=env
        )
        assert result.returncode == 0, f"Failed to access AWS_ACCESS_KEY_ID:\n{result.stderr}"
        assert result.stdout.strip() == "AKIAIOSFODNN7EXAMPLE", (
            f"AWS_ACCESS_KEY_ID variable has been modified.\n"
            f"Expected: AKIAIOSFODNN7EXAMPLE\n"
            f"Got: {result.stdout.strip()}"
        )

    def test_aws_region_unchanged(self):
        """Verify AWS_REGION variable is unchanged."""
        env = os.environ.copy()
        env["AWS_SECRET_KEY"] = "rotated-credential-value-2024"

        result = subprocess.run(
            [
                "python3", "-c",
                "import sys; sys.path.insert(0, '/home/user/webapp'); import config; print(config.AWS_REGION)"
            ],
            capture_output=True,
            text=True,
            env=env
        )
        assert result.returncode == 0, f"Failed to access AWS_REGION:\n{result.stderr}"
        assert result.stdout.strip() == "us-east-1", (
            f"AWS_REGION variable has been modified.\n"
            f"Expected: us-east-1\n"
            f"Got: {result.stdout.strip()}"
        )

    def test_enable_metrics_unchanged(self):
        """Verify ENABLE_METRICS variable is unchanged."""
        env = os.environ.copy()
        env["AWS_SECRET_KEY"] = "rotated-credential-value-2024"

        result = subprocess.run(
            [
                "python3", "-c",
                "import sys; sys.path.insert(0, '/home/user/webapp'); import config; print(config.ENABLE_METRICS)"
            ],
            capture_output=True,
            text=True,
            env=env
        )
        assert result.returncode == 0, f"Failed to access ENABLE_METRICS:\n{result.stderr}"
        assert result.stdout.strip() == "True", (
            f"ENABLE_METRICS variable has been modified.\n"
            f"Expected: True\n"
            f"Got: {result.stdout.strip()}"
        )

    def test_enable_caching_unchanged(self):
        """Verify ENABLE_CACHING variable is unchanged."""
        env = os.environ.copy()
        env["AWS_SECRET_KEY"] = "rotated-credential-value-2024"

        result = subprocess.run(
            [
                "python3", "-c",
                "import sys; sys.path.insert(0, '/home/user/webapp'); import config; print(config.ENABLE_CACHING)"
            ],
            capture_output=True,
            text=True,
            env=env
        )
        assert result.returncode == 0, f"Failed to access ENABLE_CACHING:\n{result.stderr}"
        assert result.stdout.strip() == "False", (
            f"ENABLE_CACHING variable has been modified.\n"
            f"Expected: False\n"
            f"Got: {result.stdout.strip()}"
        )

    def test_aws_secret_access_key_variable_exists(self):
        """Verify AWS_SECRET_ACCESS_KEY variable still exists in the file."""
        with open(self.CONFIG_PATH, 'r') as f:
            content = f.read()

        assert "AWS_SECRET_ACCESS_KEY" in content, (
            "AWS_SECRET_ACCESS_KEY variable is missing from config.py. "
            "The variable should still exist but read from environment variable."
        )

    def test_line_12_uses_env_var(self):
        """Verify line 12 now uses os.environ or os.getenv for AWS_SECRET_KEY."""
        with open(self.CONFIG_PATH, 'r') as f:
            lines = f.readlines()

        assert len(lines) >= 12, (
            f"File {self.CONFIG_PATH} has fewer than 12 lines after modification."
        )

        line_12 = lines[11]  # 0-indexed

        # Check that line 12 contains AWS_SECRET_ACCESS_KEY assignment using env var
        has_aws_secret_access_key = "AWS_SECRET_ACCESS_KEY" in line_12
        uses_os_environ = "os.environ" in line_12 or "os.getenv" in line_12
        references_aws_secret_key = "AWS_SECRET_KEY" in line_12

        assert has_aws_secret_access_key and uses_os_environ and references_aws_secret_key, (
            f"Line 12 should assign AWS_SECRET_ACCESS_KEY using os.environ or os.getenv with AWS_SECRET_KEY.\n"
            f"Current line 12: {line_12.strip()}"
        )
