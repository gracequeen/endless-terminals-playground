# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the nginx log extraction task.
"""

import os
import pytest
import subprocess


class TestNginxLogDirectory:
    """Tests for /var/log/nginx/ directory and its contents."""

    def test_nginx_log_directory_exists(self):
        """Verify /var/log/nginx/ directory exists."""
        assert os.path.isdir("/var/log/nginx"), \
            "/var/log/nginx/ directory does not exist"

    def test_access_log_exists(self):
        """Verify access.log exists in /var/log/nginx/."""
        path = "/var/log/nginx/access.log"
        assert os.path.isfile(path), \
            f"{path} does not exist"

    def test_access_api_log_exists(self):
        """Verify access_api.log exists in /var/log/nginx/."""
        path = "/var/log/nginx/access_api.log"
        assert os.path.isfile(path), \
            f"{path} does not exist"

    def test_access_static_log_exists(self):
        """Verify access_static.log exists in /var/log/nginx/."""
        path = "/var/log/nginx/access_static.log"
        assert os.path.isfile(path), \
            f"{path} does not exist"

    def test_access_admin_log_exists(self):
        """Verify access_admin.log exists in /var/log/nginx/."""
        path = "/var/log/nginx/access_admin.log"
        assert os.path.isfile(path), \
            f"{path} does not exist"

    def test_gzipped_archive_1_exists(self):
        """Verify access.log.1.gz (gzipped archive) exists."""
        path = "/var/log/nginx/access.log.1.gz"
        assert os.path.isfile(path), \
            f"{path} does not exist - gzipped archive should be present"

    def test_gzipped_archive_2_exists(self):
        """Verify access.log.2.gz (gzipped archive) exists."""
        path = "/var/log/nginx/access.log.2.gz"
        assert os.path.isfile(path), \
            f"{path} does not exist - gzipped archive should be present"


class TestLogFileContents:
    """Tests to verify log files have expected content/line counts."""

    def test_access_log_has_sufficient_lines(self):
        """Verify access.log has approximately 200 lines."""
        path = "/var/log/nginx/access.log"
        result = subprocess.run(
            ["wc", "-l", path],
            capture_output=True,
            text=True
        )
        line_count = int(result.stdout.split()[0])
        assert line_count >= 50, \
            f"access.log should have at least 50 lines, found {line_count}"
        assert line_count <= 250, \
            f"access.log should have around 200 lines, found {line_count}"

    def test_access_api_log_has_sufficient_lines(self):
        """Verify access_api.log has approximately 150 lines."""
        path = "/var/log/nginx/access_api.log"
        result = subprocess.run(
            ["wc", "-l", path],
            capture_output=True,
            text=True
        )
        line_count = int(result.stdout.split()[0])
        assert line_count >= 50, \
            f"access_api.log should have at least 50 lines, found {line_count}"

    def test_access_static_log_has_sufficient_lines(self):
        """Verify access_static.log has approximately 180 lines."""
        path = "/var/log/nginx/access_static.log"
        result = subprocess.run(
            ["wc", "-l", path],
            capture_output=True,
            text=True
        )
        line_count = int(result.stdout.split()[0])
        assert line_count >= 50, \
            f"access_static.log should have at least 50 lines, found {line_count}"

    def test_access_admin_log_has_sufficient_lines(self):
        """Verify access_admin.log has approximately 90 lines."""
        path = "/var/log/nginx/access_admin.log"
        result = subprocess.run(
            ["wc", "-l", path],
            capture_output=True,
            text=True
        )
        line_count = int(result.stdout.split()[0])
        assert line_count >= 50, \
            f"access_admin.log should have at least 50 lines, found {line_count}"


class TestLogFileReadability:
    """Tests to verify log files are readable by the current user."""

    def test_access_log_is_readable(self):
        """Verify access.log is readable."""
        path = "/var/log/nginx/access.log"
        assert os.access(path, os.R_OK), \
            f"{path} is not readable by the current user"

    def test_access_api_log_is_readable(self):
        """Verify access_api.log is readable."""
        path = "/var/log/nginx/access_api.log"
        assert os.access(path, os.R_OK), \
            f"{path} is not readable by the current user"

    def test_access_static_log_is_readable(self):
        """Verify access_static.log is readable."""
        path = "/var/log/nginx/access_static.log"
        assert os.access(path, os.R_OK), \
            f"{path} is not readable by the current user"

    def test_access_admin_log_is_readable(self):
        """Verify access_admin.log is readable."""
        path = "/var/log/nginx/access_admin.log"
        assert os.access(path, os.R_OK), \
            f"{path} is not readable by the current user"


class TestHomeDirectory:
    """Tests for /home/user/ directory state."""

    def test_home_user_directory_exists(self):
        """Verify /home/user/ directory exists."""
        assert os.path.isdir("/home/user"), \
            "/home/user/ directory does not exist"

    def test_home_user_directory_is_writable(self):
        """Verify /home/user/ directory is writable."""
        assert os.access("/home/user", os.W_OK), \
            "/home/user/ directory is not writable"

    def test_recent_access_txt_does_not_exist(self):
        """Verify /home/user/recent_access.txt does not exist initially."""
        path = "/home/user/recent_access.txt"
        assert not os.path.exists(path), \
            f"{path} already exists - it should not exist before the task"


class TestRequiredTools:
    """Tests to verify required tools are available."""

    def test_tail_command_available(self):
        """Verify 'tail' command is available."""
        result = subprocess.run(
            ["which", "tail"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            "'tail' command is not available"

    def test_cat_command_available(self):
        """Verify 'cat' command is available."""
        result = subprocess.run(
            ["which", "cat"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            "'cat' command is not available"

    def test_grep_command_available(self):
        """Verify 'grep' command is available."""
        result = subprocess.run(
            ["which", "grep"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            "'grep' command is not available"

    def test_find_command_available(self):
        """Verify 'find' command is available."""
        result = subprocess.run(
            ["which", "find"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            "'find' command is not available"

    def test_bash_available(self):
        """Verify 'bash' is available."""
        result = subprocess.run(
            ["which", "bash"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            "'bash' is not available"


class TestLogFilePattern:
    """Tests to verify the expected log file naming pattern."""

    def test_exactly_four_non_gzipped_access_logs(self):
        """Verify there are exactly 4 non-gzipped access*.log files."""
        nginx_dir = "/var/log/nginx"
        log_files = [
            f for f in os.listdir(nginx_dir)
            if f.startswith("access") and f.endswith(".log") and not f.endswith(".gz")
        ]
        assert len(log_files) == 4, \
            f"Expected 4 non-gzipped access*.log files, found {len(log_files)}: {log_files}"

    def test_gzipped_files_present(self):
        """Verify there are gzipped archive files present."""
        nginx_dir = "/var/log/nginx"
        gz_files = [
            f for f in os.listdir(nginx_dir)
            if f.endswith(".gz")
        ]
        assert len(gz_files) >= 2, \
            f"Expected at least 2 .gz files, found {len(gz_files)}: {gz_files}"
