# test_final_state.py
"""
Tests to validate the final state of the OS/filesystem after the student
has completed the nginx log extraction task.
"""

import os
import pytest
import subprocess


class TestOutputFileExists:
    """Tests to verify the output file exists and is accessible."""

    def test_recent_access_txt_exists(self):
        """Verify /home/user/recent_access.txt exists."""
        path = "/home/user/recent_access.txt"
        assert os.path.exists(path), \
            f"{path} does not exist - task requires creating this file"

    def test_recent_access_txt_is_file(self):
        """Verify /home/user/recent_access.txt is a regular file."""
        path = "/home/user/recent_access.txt"
        assert os.path.isfile(path), \
            f"{path} exists but is not a regular file"

    def test_recent_access_txt_is_readable(self):
        """Verify /home/user/recent_access.txt is readable."""
        path = "/home/user/recent_access.txt"
        assert os.access(path, os.R_OK), \
            f"{path} is not readable"

    def test_recent_access_txt_not_empty(self):
        """Verify /home/user/recent_access.txt is not empty."""
        path = "/home/user/recent_access.txt"
        size = os.path.getsize(path)
        assert size > 0, \
            f"{path} is empty (0 bytes)"


class TestOutputFileLineCount:
    """Tests to verify the output file has the correct number of lines."""

    def test_line_count_is_200(self):
        """Verify the output file contains exactly 200 lines (50 from each of 4 log files)."""
        path = "/home/user/recent_access.txt"
        result = subprocess.run(
            ["wc", "-l", path],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            f"Failed to count lines in {path}"

        line_count = int(result.stdout.split()[0])
        assert line_count == 200, \
            f"Expected 200 lines (50 from each of 4 log files), but found {line_count} lines"

    def test_file_ends_with_newline(self):
        """Verify the output file ends with a newline."""
        path = "/home/user/recent_access.txt"
        with open(path, 'rb') as f:
            f.seek(-1, 2)  # Go to last byte
            last_byte = f.read(1)
        assert last_byte == b'\n', \
            f"{path} does not end with a newline character"


class TestOutputFileContent:
    """Tests to verify the output file contains valid log content."""

    def test_contains_log_like_content(self):
        """Verify the output file contains content that looks like nginx access logs."""
        path = "/home/user/recent_access.txt"
        with open(path, 'r') as f:
            lines = f.readlines()

        # Check that we have actual content (non-empty lines)
        non_empty_lines = [line.strip() for line in lines if line.strip()]
        assert len(non_empty_lines) > 0, \
            f"{path} contains no non-empty lines"

    def test_no_gzip_binary_content(self):
        """Verify the output file does not contain gzip binary content."""
        path = "/home/user/recent_access.txt"
        with open(path, 'rb') as f:
            content = f.read()

        # Gzip files start with magic bytes 1f 8b
        assert not content.startswith(b'\x1f\x8b'), \
            f"{path} appears to contain gzipped content - should only include plain text logs"

        # Check for excessive null bytes which would indicate binary content
        null_count = content.count(b'\x00')
        assert null_count == 0, \
            f"{path} contains {null_count} null bytes - appears to contain binary content"


class TestSourceFilesUnchanged:
    """Tests to verify the source log files were not modified."""

    def test_nginx_log_directory_still_exists(self):
        """Verify /var/log/nginx/ directory still exists."""
        assert os.path.isdir("/var/log/nginx"), \
            "/var/log/nginx/ directory no longer exists"

    def test_access_log_still_exists(self):
        """Verify access.log still exists."""
        path = "/var/log/nginx/access.log"
        assert os.path.isfile(path), \
            f"{path} no longer exists"

    def test_access_api_log_still_exists(self):
        """Verify access_api.log still exists."""
        path = "/var/log/nginx/access_api.log"
        assert os.path.isfile(path), \
            f"{path} no longer exists"

    def test_access_static_log_still_exists(self):
        """Verify access_static.log still exists."""
        path = "/var/log/nginx/access_static.log"
        assert os.path.isfile(path), \
            f"{path} no longer exists"

    def test_access_admin_log_still_exists(self):
        """Verify access_admin.log still exists."""
        path = "/var/log/nginx/access_admin.log"
        assert os.path.isfile(path), \
            f"{path} no longer exists"

    def test_gzipped_archives_still_exist(self):
        """Verify gzipped archive files still exist."""
        gz1 = "/var/log/nginx/access.log.1.gz"
        gz2 = "/var/log/nginx/access.log.2.gz"
        assert os.path.isfile(gz1), \
            f"{gz1} no longer exists - gzipped archives should not be modified"
        assert os.path.isfile(gz2), \
            f"{gz2} no longer exists - gzipped archives should not be modified"


class TestGzippedFilesExcluded:
    """Tests to verify gzipped files were not included in the output."""

    def test_output_does_not_exceed_expected_lines(self):
        """Verify output doesn't have extra lines from gzipped files."""
        path = "/home/user/recent_access.txt"
        result = subprocess.run(
            ["wc", "-l", path],
            capture_output=True,
            text=True
        )
        line_count = int(result.stdout.split()[0])
        # If gzipped files were included, we'd have more than 200 lines
        assert line_count <= 200, \
            f"Found {line_count} lines - expected 200. Gzipped files may have been incorrectly included"


class TestLogFileIntegrity:
    """Tests to verify the source log files still have their content."""

    def test_source_logs_still_have_content(self):
        """Verify source log files still have content (weren't truncated)."""
        log_files = [
            "/var/log/nginx/access.log",
            "/var/log/nginx/access_api.log",
            "/var/log/nginx/access_static.log",
            "/var/log/nginx/access_admin.log"
        ]

        for log_file in log_files:
            result = subprocess.run(
                ["wc", "-l", log_file],
                capture_output=True,
                text=True
            )
            line_count = int(result.stdout.split()[0])
            assert line_count >= 50, \
                f"{log_file} has only {line_count} lines - source files should not be modified"
