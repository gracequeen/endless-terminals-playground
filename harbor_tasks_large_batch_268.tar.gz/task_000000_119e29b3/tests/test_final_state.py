# test_final_state.py
"""
Tests to validate the final state after adding a git submodule.
Verifies that the submodule was properly added to /home/user/infra-repo.
"""

import os
import subprocess
import pytest


class TestSubmoduleDirectory:
    """Verify the submodule directory exists and has content."""

    def test_vendor_directory_exists(self):
        """The vendor directory should exist."""
        vendor_path = "/home/user/infra-repo/vendor"
        assert os.path.isdir(vendor_path), \
            f"{vendor_path} directory does not exist - vendor directory was not created"

    def test_policy_engine_directory_exists(self):
        """The policy-engine submodule directory should exist."""
        submodule_path = "/home/user/infra-repo/vendor/policy-engine"
        assert os.path.isdir(submodule_path), \
            f"{submodule_path} directory does not exist - submodule was not added"

    def test_policy_engine_has_content(self):
        """The policy-engine directory should contain checked-out content."""
        submodule_path = "/home/user/infra-repo/vendor/policy-engine"
        # A properly initialized submodule should have at least a .git file or directory
        # and potentially other content from the repo
        contents = os.listdir(submodule_path)
        assert len(contents) > 0, \
            f"{submodule_path} is empty - submodule content was not checked out"

    def test_policy_engine_has_git_link(self):
        """The policy-engine directory should have a .git file (gitlink) or directory."""
        git_path = "/home/user/infra-repo/vendor/policy-engine/.git"
        assert os.path.exists(git_path), \
            f"{git_path} does not exist - submodule is not properly linked to git"


class TestGitmodulesFile:
    """Verify .gitmodules file is properly configured."""

    def test_gitmodules_file_exists(self):
        """The .gitmodules file should exist."""
        gitmodules_path = "/home/user/infra-repo/.gitmodules"
        assert os.path.isfile(gitmodules_path), \
            f"{gitmodules_path} does not exist - submodule was not properly registered"

    def test_gitmodules_contains_submodule_section(self):
        """The .gitmodules file should contain a section for vendor/policy-engine."""
        gitmodules_path = "/home/user/infra-repo/.gitmodules"
        with open(gitmodules_path, 'r') as f:
            content = f.read()

        assert 'vendor/policy-engine' in content, \
            ".gitmodules does not contain vendor/policy-engine section"

    def test_gitmodules_has_correct_url(self):
        """The submodule URL in .gitmodules should point to the correct path."""
        result = subprocess.run(
            ["git", "config", "--file", "/home/user/infra-repo/.gitmodules",
             "--get", "submodule.vendor/policy-engine.url"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            f"Could not get submodule URL from .gitmodules: {result.stderr}"

        url = result.stdout.strip()
        assert url == "/home/user/repos/policy-engine.git", \
            f"Submodule URL is '{url}', expected '/home/user/repos/policy-engine.git'"

    def test_gitmodules_has_correct_path(self):
        """The submodule path in .gitmodules should be vendor/policy-engine."""
        result = subprocess.run(
            ["git", "config", "--file", "/home/user/infra-repo/.gitmodules",
             "--get", "submodule.vendor/policy-engine.path"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            f"Could not get submodule path from .gitmodules: {result.stderr}"

        path = result.stdout.strip()
        assert path == "vendor/policy-engine", \
            f"Submodule path is '{path}', expected 'vendor/policy-engine'"


class TestSubmoduleStatus:
    """Verify git submodule status shows properly initialized submodule."""

    def test_submodule_status_shows_policy_engine(self):
        """git submodule status should show vendor/policy-engine."""
        result = subprocess.run(
            ["git", "submodule", "status"],
            cwd="/home/user/infra-repo",
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            f"git submodule status failed: {result.stderr}"
        assert "vendor/policy-engine" in result.stdout, \
            f"vendor/policy-engine not found in submodule status output: {result.stdout}"

    def test_submodule_is_initialized(self):
        """The submodule should be initialized (no '-' prefix in status)."""
        result = subprocess.run(
            ["git", "submodule", "status"],
            cwd="/home/user/infra-repo",
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            f"git submodule status failed: {result.stderr}"

        # Find the line for vendor/policy-engine
        lines = result.stdout.strip().split('\n')
        policy_engine_line = None
        for line in lines:
            if "vendor/policy-engine" in line:
                policy_engine_line = line
                break

        assert policy_engine_line is not None, \
            "vendor/policy-engine not found in submodule status"

        # The line should start with a commit SHA (hex chars), not with '-'
        # A '-' prefix indicates uninitialized submodule
        stripped_line = policy_engine_line.strip()
        assert not stripped_line.startswith('-'), \
            f"Submodule is uninitialized (starts with '-'): {policy_engine_line}"

    def test_submodule_has_valid_commit_sha(self):
        """The submodule status should show a valid commit SHA."""
        result = subprocess.run(
            ["git", "submodule", "status"],
            cwd="/home/user/infra-repo",
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            f"git submodule status failed: {result.stderr}"

        lines = result.stdout.strip().split('\n')
        for line in lines:
            if "vendor/policy-engine" in line:
                # Extract the SHA (first 40 hex characters, possibly with leading space or +)
                parts = line.strip().split()
                if parts:
                    sha = parts[0].lstrip('+').lstrip('-')
                    # Verify it looks like a valid SHA (40 hex characters)
                    assert len(sha) >= 7, \
                        f"Commit SHA seems too short: {sha}"
                    assert all(c in '0123456789abcdef' for c in sha.lower()), \
                        f"Invalid commit SHA format: {sha}"
                    return

        pytest.fail("Could not find commit SHA for vendor/policy-engine submodule")


class TestBareRepoUnchanged:
    """Verify the bare repo remains unchanged."""

    def test_policy_engine_bare_repo_still_exists(self):
        """policy-engine.git should still exist."""
        assert os.path.isdir("/home/user/repos/policy-engine.git"), \
            "/home/user/repos/policy-engine.git no longer exists"

    def test_policy_engine_still_bare(self):
        """policy-engine.git should still be a bare repository."""
        result = subprocess.run(
            ["git", "config", "--get", "core.bare"],
            cwd="/home/user/repos/policy-engine.git",
            capture_output=True,
            text=True
        )
        assert result.returncode == 0 and result.stdout.strip() == "true", \
            "/home/user/repos/policy-engine.git is no longer a bare repository"


class TestProperSubmoduleRegistration:
    """Verify submodule was added properly via git submodule add, not manually."""

    def test_submodule_in_git_config(self):
        """The submodule should be registered in the repo's git config."""
        # After git submodule add, the submodule should be in .git/config
        result = subprocess.run(
            ["git", "config", "--local", "--get", "submodule.vendor/policy-engine.url"],
            cwd="/home/user/infra-repo",
            capture_output=True,
            text=True
        )
        # This may or may not be set depending on git version and whether
        # submodule init was run, but .gitmodules should definitely have it
        # The key test is the .gitmodules file which we already checked

    def test_submodule_can_be_updated(self):
        """A properly registered submodule should be updatable."""
        result = subprocess.run(
            ["git", "submodule", "update", "--init", "vendor/policy-engine"],
            cwd="/home/user/infra-repo",
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            f"git submodule update failed - submodule may not be properly registered: {result.stderr}"

    def test_submodule_head_matches_bare_repo(self):
        """The submodule HEAD should reference a commit from the bare repo."""
        # Get HEAD from submodule
        result_submodule = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd="/home/user/infra-repo/vendor/policy-engine",
            capture_output=True,
            text=True
        )
        assert result_submodule.returncode == 0, \
            f"Could not get HEAD from submodule: {result_submodule.stderr}"
        submodule_head = result_submodule.stdout.strip()

        # Get HEAD from bare repo
        result_bare = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd="/home/user/repos/policy-engine.git",
            capture_output=True,
            text=True
        )
        assert result_bare.returncode == 0, \
            f"Could not get HEAD from bare repo: {result_bare.stderr}"
        bare_head = result_bare.stdout.strip()

        # The submodule should be at the same commit as the bare repo's HEAD
        # (or at least a commit that exists in the bare repo)
        assert submodule_head == bare_head, \
            f"Submodule HEAD ({submodule_head}) doesn't match bare repo HEAD ({bare_head})"
