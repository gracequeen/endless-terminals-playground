# test_initial_state.py
"""
Tests to validate the initial state before adding a git submodule.
Verifies that all prerequisites are in place for the task.
"""

import os
import subprocess
import pytest


class TestGitInstallation:
    """Verify git is installed and configured."""

    def test_git_is_installed(self):
        """Git command should be available."""
        result = subprocess.run(
            ["which", "git"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "git is not installed or not in PATH"

    def test_git_user_name_configured(self):
        """Git user.name should be configured globally."""
        result = subprocess.run(
            ["git", "config", "--global", "user.name"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "git user.name is not configured globally"
        assert result.stdout.strip(), "git user.name is empty"

    def test_git_user_email_configured(self):
        """Git user.email should be configured globally."""
        result = subprocess.run(
            ["git", "config", "--global", "user.email"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "git user.email is not configured globally"
        assert result.stdout.strip(), "git user.email is empty"


class TestInfraRepo:
    """Verify /home/user/infra-repo is properly set up."""

    def test_infra_repo_exists(self):
        """The infra-repo directory should exist."""
        assert os.path.isdir("/home/user/infra-repo"), \
            "/home/user/infra-repo directory does not exist"

    def test_infra_repo_is_git_repository(self):
        """infra-repo should be an initialized git repository."""
        git_dir = "/home/user/infra-repo/.git"
        assert os.path.isdir(git_dir), \
            "/home/user/infra-repo is not a git repository (no .git directory)"

    def test_infra_repo_has_at_least_one_commit(self):
        """infra-repo should have at least one commit on main."""
        result = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd="/home/user/infra-repo",
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            "/home/user/infra-repo has no commits (git rev-parse HEAD failed)"

    def test_infra_repo_main_branch_exists(self):
        """infra-repo should have a main branch."""
        result = subprocess.run(
            ["git", "branch", "--list", "main"],
            cwd="/home/user/infra-repo",
            capture_output=True,
            text=True
        )
        assert result.returncode == 0 and result.stdout.strip(), \
            "/home/user/infra-repo does not have a 'main' branch"

    def test_infra_repo_is_writable(self):
        """infra-repo should be writable."""
        assert os.access("/home/user/infra-repo", os.W_OK), \
            "/home/user/infra-repo is not writable"

    def test_no_existing_submodules(self):
        """No submodules should currently exist in infra-repo."""
        gitmodules_path = "/home/user/infra-repo/.gitmodules"
        if os.path.exists(gitmodules_path):
            # Check if .gitmodules is empty or has no submodule entries
            result = subprocess.run(
                ["git", "config", "--file", gitmodules_path, "--list"],
                cwd="/home/user/infra-repo",
                capture_output=True,
                text=True
            )
            assert not result.stdout.strip(), \
                f"/home/user/infra-repo already has submodules configured in .gitmodules: {result.stdout}"

    def test_no_submodule_in_git_status(self):
        """git submodule status should show no submodules."""
        result = subprocess.run(
            ["git", "submodule", "status"],
            cwd="/home/user/infra-repo",
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            f"git submodule status failed: {result.stderr}"
        assert not result.stdout.strip(), \
            f"Submodules already exist in infra-repo: {result.stdout}"

    def test_vendor_policy_engine_does_not_exist(self):
        """vendor/policy-engine should not exist yet."""
        vendor_path = "/home/user/infra-repo/vendor/policy-engine"
        assert not os.path.exists(vendor_path), \
            f"{vendor_path} already exists - submodule target path is not empty"


class TestPolicyEngineRepo:
    """Verify /home/user/repos/policy-engine.git is properly set up."""

    def test_repos_directory_exists(self):
        """The repos directory should exist."""
        assert os.path.isdir("/home/user/repos"), \
            "/home/user/repos directory does not exist"

    def test_policy_engine_bare_repo_exists(self):
        """policy-engine.git should exist."""
        assert os.path.isdir("/home/user/repos/policy-engine.git"), \
            "/home/user/repos/policy-engine.git does not exist"

    def test_policy_engine_is_bare_repo(self):
        """policy-engine.git should be a bare git repository."""
        result = subprocess.run(
            ["git", "config", "--get", "core.bare"],
            cwd="/home/user/repos/policy-engine.git",
            capture_output=True,
            text=True
        )
        assert result.returncode == 0 and result.stdout.strip() == "true", \
            "/home/user/repos/policy-engine.git is not a bare repository"

    def test_policy_engine_has_at_least_one_commit(self):
        """policy-engine.git should have at least one commit."""
        result = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd="/home/user/repos/policy-engine.git",
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            "/home/user/repos/policy-engine.git has no commits"

    def test_policy_engine_has_objects(self):
        """policy-engine.git should have git objects."""
        objects_dir = "/home/user/repos/policy-engine.git/objects"
        assert os.path.isdir(objects_dir), \
            "/home/user/repos/policy-engine.git/objects directory does not exist"
