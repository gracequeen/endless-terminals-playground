Our log archival script at /home/user/ops/archive.sh is supposed to encrypt and sign daily logs before shipping them offsite, but the verify step is failing on the receiving end. I ran it manually against yesterday's logs and the encryption seems fine — I can decrypt /home/user/ops/out/system.log.gpg no problem — but when I try to verify the signature it says it's bad. Thing is, the signing key is definitely in my keyring, I've used it for months.

Might be something with how the script calls gpg? Or maybe the detached sig is getting corrupted somehow? I'm not sure. The script worked fine until last week when I added the compression flag, but that shouldn't affect signatures... right?

Need the script fixed so the output passes verification. There's a test log at /home/user/ops/test.log you can use — just run the script against it and make sure `gpg --verify` on the resulting .sig/.gpg pair actually succeeds.
