# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the task to fix the GPG signing issue in archive.sh.
"""

import os
import subprocess
import pytest


class TestArchiveScriptExists:
    """Tests for the archive.sh script existence and properties."""

    def test_archive_script_exists(self):
        """Verify /home/user/ops/archive.sh exists."""
        script_path = "/home/user/ops/archive.sh"
        assert os.path.isfile(script_path), (
            f"Archive script not found at {script_path}. "
            "The script must exist for this task."
        )

    def test_archive_script_is_executable(self):
        """Verify /home/user/ops/archive.sh is executable."""
        script_path = "/home/user/ops/archive.sh"
        assert os.access(script_path, os.X_OK), (
            f"Archive script at {script_path} is not executable. "
            "The script must be executable."
        )

    def test_archive_script_is_bash(self):
        """Verify the script starts with a bash shebang."""
        script_path = "/home/user/ops/archive.sh"
        with open(script_path, 'r') as f:
            first_line = f.readline().strip()
        assert first_line == "#!/bin/bash", (
            f"Expected shebang '#!/bin/bash' but got '{first_line}'"
        )

    def test_archive_script_contains_textmode_flag(self):
        """Verify the script contains the --textmode flag (the bug to fix)."""
        script_path = "/home/user/ops/archive.sh"
        with open(script_path, 'r') as f:
            content = f.read()
        assert "--textmode" in content, (
            "The archive.sh script should contain '--textmode' flag. "
            "This is the bug that needs to be fixed."
        )

    def test_archive_script_contains_detach_sign(self):
        """Verify the script uses --detach-sign for signing."""
        script_path = "/home/user/ops/archive.sh"
        with open(script_path, 'r') as f:
            content = f.read()
        assert "--detach-sign" in content, (
            "The archive.sh script should contain '--detach-sign' for detached signatures."
        )

    def test_archive_script_contains_armor(self):
        """Verify the script uses --armor for ASCII armored output."""
        script_path = "/home/user/ops/archive.sh"
        with open(script_path, 'r') as f:
            content = f.read()
        assert "--armor" in content, (
            "The archive.sh script should contain '--armor' for ASCII armored signatures."
        )

    def test_archive_script_contains_encrypt(self):
        """Verify the script contains encryption command."""
        script_path = "/home/user/ops/archive.sh"
        with open(script_path, 'r') as f:
            content = f.read()
        assert "--encrypt" in content, (
            "The archive.sh script should contain '--encrypt' for encryption."
        )

    def test_archive_script_uses_correct_keyid(self):
        """Verify the script uses archive@example.com as the key ID."""
        script_path = "/home/user/ops/archive.sh"
        with open(script_path, 'r') as f:
            content = f.read()
        assert "archive@example.com" in content, (
            "The archive.sh script should use 'archive@example.com' as the key ID."
        )


class TestTestLogExists:
    """Tests for the test.log file."""

    def test_test_log_exists(self):
        """Verify /home/user/ops/test.log exists."""
        log_path = "/home/user/ops/test.log"
        assert os.path.isfile(log_path), (
            f"Test log file not found at {log_path}. "
            "A test log file must exist for testing the script."
        )

    def test_test_log_is_readable(self):
        """Verify /home/user/ops/test.log is readable."""
        log_path = "/home/user/ops/test.log"
        assert os.access(log_path, os.R_OK), (
            f"Test log file at {log_path} is not readable."
        )

    def test_test_log_has_content(self):
        """Verify /home/user/ops/test.log has content (approximately 50 lines)."""
        log_path = "/home/user/ops/test.log"
        with open(log_path, 'r') as f:
            lines = f.readlines()
        assert len(lines) >= 10, (
            f"Test log file should have substantial content. Found only {len(lines)} lines."
        )


class TestDirectoryStructure:
    """Tests for directory structure."""

    def test_ops_directory_exists(self):
        """Verify /home/user/ops/ directory exists."""
        ops_dir = "/home/user/ops"
        assert os.path.isdir(ops_dir), (
            f"Ops directory not found at {ops_dir}."
        )

    def test_ops_directory_is_writable(self):
        """Verify /home/user/ops/ directory is writable."""
        ops_dir = "/home/user/ops"
        assert os.access(ops_dir, os.W_OK), (
            f"Ops directory at {ops_dir} is not writable."
        )

    def test_out_directory_exists(self):
        """Verify /home/user/ops/out/ directory exists."""
        out_dir = "/home/user/ops/out"
        assert os.path.isdir(out_dir), (
            f"Output directory not found at {out_dir}."
        )

    def test_out_directory_is_writable(self):
        """Verify /home/user/ops/out/ directory is writable."""
        out_dir = "/home/user/ops/out"
        assert os.access(out_dir, os.W_OK), (
            f"Output directory at {out_dir} is not writable."
        )


class TestGPGSetup:
    """Tests for GPG installation and key setup."""

    def test_gpg_is_installed(self):
        """Verify gpg is installed and accessible."""
        result = subprocess.run(
            ["which", "gpg"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "gpg command not found. GnuPG must be installed."
        )

    def test_gpg_version(self):
        """Verify gpg version is 2.2.x or compatible."""
        result = subprocess.run(
            ["gpg", "--version"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "Failed to get gpg version."
        assert "gpg (GnuPG)" in result.stdout, (
            "Unexpected gpg version output."
        )

    def test_archive_key_exists_in_keyring(self):
        """Verify archive@example.com key exists in the keyring."""
        result = subprocess.run(
            ["gpg", "--list-keys", "archive@example.com"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "GPG key for 'archive@example.com' not found in keyring. "
            "The signing/encryption key must be set up."
        )

    def test_archive_secret_key_exists(self):
        """Verify secret key for archive@example.com exists (for signing)."""
        result = subprocess.run(
            ["gpg", "--list-secret-keys", "archive@example.com"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "GPG secret key for 'archive@example.com' not found. "
            "The secret key must be available for signing."
        )

    def test_gpg_agent_is_running(self):
        """Verify gpg-agent is running."""
        result = subprocess.run(
            ["pgrep", "-x", "gpg-agent"],
            capture_output=True,
            text=True
        )
        # gpg-agent might not always show up with pgrep, try alternative check
        if result.returncode != 0:
            # Try using gpg-connect-agent
            result2 = subprocess.run(
                ["gpg-connect-agent", "/bye"],
                capture_output=True,
                text=True
            )
            assert result2.returncode == 0, (
                "gpg-agent does not appear to be running or accessible."
            )


class TestScriptBugPresence:
    """Tests to confirm the bug is present in the initial state."""

    def test_signature_naming_issue(self):
        """Verify the script has the signature naming pattern that causes issues."""
        script_path = "/home/user/ops/archive.sh"
        with open(script_path, 'r') as f:
            content = f.read()
        # The bug: output is $BASENAME.sig instead of $BASENAME.gpg.sig
        # Check that the script outputs to $BASENAME.sig (or similar pattern)
        assert '$OUTDIR/$BASENAME.sig' in content or '${OUTDIR}/${BASENAME}.sig' in content, (
            "Expected to find signature output pattern '$OUTDIR/$BASENAME.sig' in script."
        )

    def test_script_signs_gpg_file(self):
        """Verify the script signs the .gpg file."""
        script_path = "/home/user/ops/archive.sh"
        with open(script_path, 'r') as f:
            content = f.read()
        # The script should be signing the .gpg file
        assert '.gpg' in content, (
            "Script should reference .gpg files for encryption/signing."
        )
