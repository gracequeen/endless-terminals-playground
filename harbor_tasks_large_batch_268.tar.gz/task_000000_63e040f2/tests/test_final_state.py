# test_final_state.py
"""
Tests to validate the final state after the student has fixed the GPG signing
issue in archive.sh. The script should now produce valid detached signatures
that can be verified against the encrypted files.
"""

import os
import subprocess
import pytest
import hashlib


class TestArchiveScriptFixed:
    """Tests for the fixed archive.sh script."""

    def test_archive_script_exists(self):
        """Verify /home/user/ops/archive.sh still exists."""
        script_path = "/home/user/ops/archive.sh"
        assert os.path.isfile(script_path), (
            f"Archive script not found at {script_path}. "
            "The script must still exist after fixing."
        )

    def test_archive_script_is_executable(self):
        """Verify /home/user/ops/archive.sh is still executable."""
        script_path = "/home/user/ops/archive.sh"
        assert os.access(script_path, os.X_OK), (
            f"Archive script at {script_path} is not executable."
        )

    def test_textmode_flag_removed(self):
        """Verify the --textmode flag has been removed from the script."""
        script_path = "/home/user/ops/archive.sh"
        with open(script_path, 'r') as f:
            content = f.read()
        assert "--textmode" not in content, (
            "The '--textmode' flag must be removed from archive.sh. "
            "This flag causes signature verification to fail on binary .gpg files "
            "because it normalizes line endings."
        )

    def test_script_still_uses_detach_sign(self):
        """Verify the script still uses --detach-sign for detached signatures."""
        script_path = "/home/user/ops/archive.sh"
        with open(script_path, 'r') as f:
            content = f.read()
        assert "--detach-sign" in content, (
            "The script must still use '--detach-sign' for detached signatures. "
            "Do not replace with embedded or clearsign signatures."
        )

    def test_script_still_uses_armor(self):
        """Verify the script still uses --armor for ASCII armored output."""
        script_path = "/home/user/ops/archive.sh"
        with open(script_path, 'r') as f:
            content = f.read()
        assert "--armor" in content, (
            "The script must still use '--armor' for ASCII armored signatures."
        )

    def test_script_still_encrypts(self):
        """Verify the script still contains encryption command."""
        script_path = "/home/user/ops/archive.sh"
        with open(script_path, 'r') as f:
            content = f.read()
        assert "--encrypt" in content, (
            "The script must still encrypt files using '--encrypt'."
        )

    def test_script_still_uses_correct_keyid(self):
        """Verify the script still uses archive@example.com as the key ID."""
        script_path = "/home/user/ops/archive.sh"
        with open(script_path, 'r') as f:
            content = f.read()
        assert "archive@example.com" in content, (
            "The script must still use 'archive@example.com' as the key ID."
        )


class TestTestLogUnchanged:
    """Tests to verify test.log was not modified."""

    def test_test_log_exists(self):
        """Verify /home/user/ops/test.log still exists."""
        log_path = "/home/user/ops/test.log"
        assert os.path.isfile(log_path), (
            f"Test log file not found at {log_path}. "
            "The test log must not be deleted."
        )

    def test_test_log_has_content(self):
        """Verify /home/user/ops/test.log still has content."""
        log_path = "/home/user/ops/test.log"
        with open(log_path, 'r') as f:
            content = f.read()
        assert len(content) > 0, (
            "Test log file should have content."
        )


class TestScriptExecution:
    """Tests for running the fixed script."""

    def test_script_runs_successfully(self):
        """Verify running archive.sh with test.log exits with code 0."""
        script_path = "/home/user/ops/archive.sh"
        test_log = "/home/user/ops/test.log"

        result = subprocess.run(
            [script_path, test_log],
            capture_output=True,
            text=True,
            cwd="/home/user/ops"
        )
        assert result.returncode == 0, (
            f"Script execution failed with exit code {result.returncode}.\n"
            f"stdout: {result.stdout}\n"
            f"stderr: {result.stderr}"
        )

    def test_encrypted_file_created(self):
        """Verify /home/user/ops/out/test.log.gpg is created."""
        # First run the script to ensure output exists
        script_path = "/home/user/ops/archive.sh"
        test_log = "/home/user/ops/test.log"
        subprocess.run([script_path, test_log], capture_output=True)

        gpg_file = "/home/user/ops/out/test.log.gpg"
        assert os.path.isfile(gpg_file), (
            f"Encrypted file not found at {gpg_file}. "
            "The script must create an encrypted .gpg file."
        )

    def test_signature_file_created(self):
        """Verify a detached signature file is created."""
        # First run the script
        script_path = "/home/user/ops/archive.sh"
        test_log = "/home/user/ops/test.log"
        subprocess.run([script_path, test_log], capture_output=True)

        out_dir = "/home/user/ops/out"
        # Check for signature file - could be .sig or .asc
        sig_files = [f for f in os.listdir(out_dir) 
                     if f.startswith("test.log") and (f.endswith(".sig") or f.endswith(".asc"))]

        assert len(sig_files) > 0, (
            f"No signature file found in {out_dir}. "
            "The script must create a detached signature file (.sig or .asc)."
        )


class TestSignatureVerification:
    """Tests for GPG signature verification - the core fix validation."""

    def test_signature_verifies_against_encrypted_file(self):
        """Verify gpg --verify succeeds on the signature and encrypted file pair."""
        # Run the script first
        script_path = "/home/user/ops/archive.sh"
        test_log = "/home/user/ops/test.log"
        run_result = subprocess.run([script_path, test_log], capture_output=True, text=True)
        assert run_result.returncode == 0, f"Script failed: {run_result.stderr}"

        out_dir = "/home/user/ops/out"
        gpg_file = "/home/user/ops/out/test.log.gpg"

        # Find the signature file
        sig_file = None
        possible_sig_names = [
            "/home/user/ops/out/test.log.gpg.sig",
            "/home/user/ops/out/test.log.gpg.asc",
            "/home/user/ops/out/test.log.sig",
            "/home/user/ops/out/test.log.asc",
        ]

        for sig_path in possible_sig_names:
            if os.path.isfile(sig_path):
                sig_file = sig_path
                break

        # Also check for any .sig or .asc file
        if sig_file is None:
            for f in os.listdir(out_dir):
                if "test.log" in f and (f.endswith(".sig") or f.endswith(".asc")):
                    sig_file = os.path.join(out_dir, f)
                    break

        assert sig_file is not None, (
            f"No signature file found in {out_dir}. "
            "Expected a .sig or .asc file for test.log."
        )

        # Verify the signature against the encrypted file
        result = subprocess.run(
            ["gpg", "--verify", sig_file, gpg_file],
            capture_output=True,
            text=True
        )

        # GPG outputs verification info to stderr
        combined_output = result.stdout + result.stderr

        assert result.returncode == 0, (
            f"Signature verification failed!\n"
            f"Command: gpg --verify {sig_file} {gpg_file}\n"
            f"Exit code: {result.returncode}\n"
            f"Output: {combined_output}\n"
            "The signature must verify successfully against the encrypted file."
        )

        assert "Good signature" in combined_output, (
            f"Expected 'Good signature' in verification output.\n"
            f"Got: {combined_output}\n"
            "The signature verification must report a good signature."
        )

    def test_encrypted_file_can_be_decrypted(self):
        """Verify the encrypted file can be decrypted to original content."""
        # Run the script first
        script_path = "/home/user/ops/archive.sh"
        test_log = "/home/user/ops/test.log"
        subprocess.run([script_path, test_log], capture_output=True)

        gpg_file = "/home/user/ops/out/test.log.gpg"

        # Read original content
        with open(test_log, 'rb') as f:
            original_content = f.read()

        # Decrypt and compare
        result = subprocess.run(
            ["gpg", "--batch", "--yes", "--decrypt", gpg_file],
            capture_output=True
        )

        assert result.returncode == 0, (
            f"Decryption failed with exit code {result.returncode}.\n"
            f"stderr: {result.stderr.decode('utf-8', errors='replace')}"
        )

        assert result.stdout == original_content, (
            "Decrypted content does not match original test.log content. "
            "The encryption/decryption must preserve the original file."
        )


class TestOutputFilesAreSeparate:
    """Tests to ensure output is separate .gpg and signature files (not embedded)."""

    def test_gpg_file_is_encrypted_not_signed(self):
        """Verify the .gpg file is an encrypted file, not a combined signed+encrypted."""
        # Run the script
        script_path = "/home/user/ops/archive.sh"
        test_log = "/home/user/ops/test.log"
        subprocess.run([script_path, test_log], capture_output=True)

        gpg_file = "/home/user/ops/out/test.log.gpg"
        assert os.path.isfile(gpg_file), f"Encrypted file {gpg_file} not found."

        # Check that it's a proper GPG encrypted file
        result = subprocess.run(
            ["gpg", "--list-packets", gpg_file],
            capture_output=True,
            text=True
        )

        # Should contain encrypted data packet
        combined = result.stdout + result.stderr
        assert "encrypted" in combined.lower() or "pubkey" in combined.lower(), (
            f"The .gpg file should be an encrypted file.\n"
            f"gpg --list-packets output: {combined}"
        )

    def test_signature_file_is_detached(self):
        """Verify the signature file is a detached signature."""
        # Run the script
        script_path = "/home/user/ops/archive.sh"
        test_log = "/home/user/ops/test.log"
        subprocess.run([script_path, test_log], capture_output=True)

        out_dir = "/home/user/ops/out"

        # Find signature file
        sig_file = None
        for f in os.listdir(out_dir):
            if "test.log" in f and (f.endswith(".sig") or f.endswith(".asc")):
                sig_file = os.path.join(out_dir, f)
                break

        assert sig_file is not None, "No signature file found."

        # Read and check it's armored or binary signature
        with open(sig_file, 'rb') as f:
            content = f.read()

        # Should be ASCII armored (--armor flag)
        content_str = content.decode('utf-8', errors='replace')
        assert "-----BEGIN PGP SIGNATURE-----" in content_str, (
            "Signature file should be ASCII armored (contain '-----BEGIN PGP SIGNATURE-----'). "
            "The --armor flag must be preserved."
        )


class TestCompressionStillWorks:
    """Tests to verify compression is still enabled (optional but good to check)."""

    def test_script_can_have_compression(self):
        """Verify the fix doesn't require removing compression."""
        script_path = "/home/user/ops/archive.sh"
        with open(script_path, 'r') as f:
            content = f.read()

        # Compression is allowed to remain
        # Just verify the script works regardless of compression setting
        # This test passes as long as verification works (tested elsewhere)
        assert os.path.isfile(script_path), "Script exists"
