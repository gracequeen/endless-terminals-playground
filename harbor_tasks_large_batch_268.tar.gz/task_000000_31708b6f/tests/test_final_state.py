# test_final_state.py
"""
Tests to validate the final state of the OS/filesystem after the student
has completed the artifact server repair task.
"""

import os
import subprocess
import base64
import tempfile
import socket
import time
import pytest

BASE_DIR = "/home/user/artifact-repo"
CERTS_DIR = os.path.join(BASE_DIR, "certs")
PACKAGES_DIR = os.path.join(BASE_DIR, "packages")


class TestServerRunning:
    """Test that the server is running and listening on port 8443."""

    def test_port_8443_listening(self):
        """Verify something is listening on port 8443."""
        result = subprocess.run(
            ["ss", "-tlnp"],
            capture_output=True, text=True
        )
        assert ":8443" in result.stdout, \
            "Port 8443 is not listening - server is not running"

    def test_server_process_running(self):
        """Verify server process is running."""
        # Check for python process related to server
        result = subprocess.run(
            ["pgrep", "-f", "server.py"],
            capture_output=True, text=True
        )
        assert result.returncode == 0, \
            "No server.py process found running"

    def test_can_connect_to_port_8443(self):
        """Verify we can establish a TCP connection to port 8443."""
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(5)
        try:
            result = sock.connect_ex(('localhost', 8443))
            assert result == 0, \
                f"Cannot connect to localhost:8443 - connection error code {result}"
        finally:
            sock.close()


class TestSigningKeyMatchesCert:
    """Test that the signing key now matches the signing certificate."""

    def test_signing_key_matches_cert(self):
        """Verify signing.key matches signing.crt (the fix)."""
        signing_crt = os.path.join(CERTS_DIR, "signing.crt")
        signing_key = os.path.join(CERTS_DIR, "signing.key")

        cert_modulus = subprocess.run(
            ["openssl", "x509", "-noout", "-modulus", "-in", signing_crt],
            capture_output=True, text=True
        )
        key_modulus = subprocess.run(
            ["openssl", "rsa", "-noout", "-modulus", "-in", signing_key],
            capture_output=True, text=True
        )

        assert cert_modulus.returncode == 0, \
            f"Failed to get cert modulus: {cert_modulus.stderr}"
        assert key_modulus.returncode == 0, \
            f"Failed to get key modulus: {key_modulus.stderr}"

        assert cert_modulus.stdout.strip() == key_modulus.stdout.strip(), \
            "signing.key does NOT match signing.crt - the key/cert mismatch is not fixed"

    def test_signing_key_md5_matches_cert_md5(self):
        """Verify using MD5 hash comparison as specified in task."""
        signing_crt = os.path.join(CERTS_DIR, "signing.crt")
        signing_key = os.path.join(CERTS_DIR, "signing.key")

        cert_result = subprocess.run(
            f"openssl x509 -noout -modulus -in {signing_crt} | openssl md5",
            shell=True, capture_output=True, text=True
        )
        key_result = subprocess.run(
            f"openssl rsa -noout -modulus -in {signing_key} | openssl md5",
            shell=True, capture_output=True, text=True
        )

        assert cert_result.returncode == 0, \
            f"Failed to compute cert modulus MD5: {cert_result.stderr}"
        assert key_result.returncode == 0, \
            f"Failed to compute key modulus MD5: {key_result.stderr}"

        assert cert_result.stdout.strip() == key_result.stdout.strip(), \
            "MD5 of signing.key modulus does not match MD5 of signing.crt modulus"


class TestHTTPResponse:
    """Test that the server responds correctly to HTTP requests."""

    def test_head_request_returns_200(self):
        """Verify HEAD request to artifact returns HTTP 200."""
        result = subprocess.run(
            ["curl", "-k", "-s", "-o", "/dev/null", "-w", "%{http_code}",
             "-I", "https://localhost:8443/packages/commons-util-1.2.jar"],
            capture_output=True, text=True, timeout=30
        )
        assert result.returncode == 0, \
            f"curl command failed: {result.stderr}"
        assert result.stdout.strip() == "200", \
            f"Expected HTTP 200, got HTTP {result.stdout.strip()}"

    def test_get_request_returns_200(self):
        """Verify GET request to artifact returns HTTP 200."""
        result = subprocess.run(
            ["curl", "-k", "-s", "-o", "/dev/null", "-w", "%{http_code}",
             "https://localhost:8443/packages/commons-util-1.2.jar"],
            capture_output=True, text=True, timeout=30
        )
        assert result.returncode == 0, \
            f"curl command failed: {result.stderr}"
        assert result.stdout.strip() == "200", \
            f"Expected HTTP 200, got HTTP {result.stdout.strip()}"


class TestSignatureHeader:
    """Test that the X-Package-Signature header is present and valid."""

    def test_signature_header_present(self):
        """Verify X-Package-Signature header is present in response."""
        result = subprocess.run(
            ["curl", "-k", "-s", "-I",
             "https://localhost:8443/packages/commons-util-1.2.jar"],
            capture_output=True, text=True, timeout=30
        )
        assert result.returncode == 0, \
            f"curl command failed: {result.stderr}"

        headers_lower = result.stdout.lower()
        assert "x-package-signature" in headers_lower, \
            f"X-Package-Signature header not found in response headers:\n{result.stdout}"

    def test_signature_header_non_empty(self):
        """Verify X-Package-Signature header has a non-empty value."""
        result = subprocess.run(
            ["curl", "-k", "-s", "-I",
             "https://localhost:8443/packages/commons-util-1.2.jar"],
            capture_output=True, text=True, timeout=30
        )
        assert result.returncode == 0, \
            f"curl command failed: {result.stderr}"

        signature = None
        for line in result.stdout.split('\n'):
            if line.lower().startswith('x-package-signature:'):
                signature = line.split(':', 1)[1].strip()
                break

        assert signature is not None, \
            "X-Package-Signature header not found"
        assert len(signature) > 0, \
            "X-Package-Signature header is empty"

    def test_signature_is_valid_base64(self):
        """Verify X-Package-Signature header contains valid base64."""
        result = subprocess.run(
            ["curl", "-k", "-s", "-I",
             "https://localhost:8443/packages/commons-util-1.2.jar"],
            capture_output=True, text=True, timeout=30
        )
        assert result.returncode == 0, \
            f"curl command failed: {result.stderr}"

        signature = None
        for line in result.stdout.split('\n'):
            if line.lower().startswith('x-package-signature:'):
                signature = line.split(':', 1)[1].strip()
                break

        assert signature is not None, \
            "X-Package-Signature header not found"

        try:
            decoded = base64.b64decode(signature)
            assert len(decoded) > 0, \
                "Decoded signature is empty"
        except Exception as e:
            pytest.fail(f"X-Package-Signature is not valid base64: {e}")


class TestSignatureVerification:
    """Test that the signature is cryptographically valid."""

    def test_signature_verifies_with_openssl(self):
        """Verify the signature is valid using openssl dgst -verify."""
        with tempfile.TemporaryDirectory() as tmpdir:
            jar_path = os.path.join(tmpdir, "test.jar")
            headers_path = os.path.join(tmpdir, "headers.txt")
            sig_path = os.path.join(tmpdir, "signature.bin")
            pubkey_path = os.path.join(tmpdir, "pubkey.pem")

            # Download the artifact and headers
            result = subprocess.run(
                ["curl", "-k", "-s", "-o", jar_path, "-D", headers_path,
                 "https://localhost:8443/packages/commons-util-1.2.jar"],
                capture_output=True, text=True, timeout=30
            )
            assert result.returncode == 0, \
                f"curl download failed: {result.stderr}"
            assert os.path.exists(jar_path), \
                "Downloaded JAR file does not exist"
            assert os.path.getsize(jar_path) > 0, \
                "Downloaded JAR file is empty"

            # Extract signature from headers
            signature = None
            with open(headers_path, 'r') as f:
                for line in f:
                    if line.lower().startswith('x-package-signature:'):
                        signature = line.split(':', 1)[1].strip()
                        break

            assert signature is not None, \
                f"X-Package-Signature header not found in headers file"

            # Decode signature and write to file
            try:
                sig_bytes = base64.b64decode(signature)
                with open(sig_path, 'wb') as f:
                    f.write(sig_bytes)
            except Exception as e:
                pytest.fail(f"Failed to decode signature: {e}")

            # Extract public key from signing certificate
            signing_crt = os.path.join(CERTS_DIR, "signing.crt")
            result = subprocess.run(
                ["openssl", "x509", "-pubkey", "-noout", "-in", signing_crt],
                capture_output=True, text=True
            )
            assert result.returncode == 0, \
                f"Failed to extract public key from signing.crt: {result.stderr}"

            with open(pubkey_path, 'w') as f:
                f.write(result.stdout)

            # Verify signature
            result = subprocess.run(
                ["openssl", "dgst", "-sha256", "-verify", pubkey_path,
                 "-signature", sig_path, jar_path],
                capture_output=True, text=True
            )

            assert result.returncode == 0, \
                f"Signature verification FAILED. The X-Package-Signature header does not contain a valid signature. " \
                f"OpenSSL output: {result.stdout} {result.stderr}"
            assert "Verified OK" in result.stdout or result.returncode == 0, \
                f"Signature verification did not confirm success: {result.stdout}"


class TestInvariants:
    """Test that invariants are preserved."""

    def test_jar_file_unchanged(self):
        """Verify the JAR file content is unchanged (byte-identical)."""
        jar_path = os.path.join(PACKAGES_DIR, "commons-util-1.2.jar")
        assert os.path.isfile(jar_path), \
            f"Package file {jar_path} does not exist"
        # Just verify it exists and has reasonable size
        size = os.path.getsize(jar_path)
        assert size > 1000, \
            f"Package file seems too small ({size} bytes), may have been corrupted"

    def test_server_crt_exists(self):
        """Verify server.crt still exists."""
        server_crt = os.path.join(CERTS_DIR, "server.crt")
        assert os.path.isfile(server_crt), \
            f"Server certificate {server_crt} does not exist"

    def test_server_key_exists(self):
        """Verify server.key still exists."""
        server_key = os.path.join(CERTS_DIR, "server.key")
        assert os.path.isfile(server_key), \
            f"Server key {server_key} does not exist"

    def test_server_cert_key_still_match(self):
        """Verify server TLS cert and key are still correctly paired."""
        server_crt = os.path.join(CERTS_DIR, "server.crt")
        server_key = os.path.join(CERTS_DIR, "server.key")

        cert_modulus = subprocess.run(
            ["openssl", "x509", "-noout", "-modulus", "-in", server_crt],
            capture_output=True, text=True
        )
        key_modulus = subprocess.run(
            ["openssl", "rsa", "-noout", "-modulus", "-in", server_key],
            capture_output=True, text=True
        )

        assert cert_modulus.returncode == 0, \
            f"Failed to get server cert modulus: {cert_modulus.stderr}"
        assert key_modulus.returncode == 0, \
            f"Failed to get server key modulus: {key_modulus.stderr}"

        assert cert_modulus.stdout.strip() == key_modulus.stdout.strip(), \
            "server.crt and server.key no longer match - they should not have been modified"

    def test_signing_crt_unchanged(self):
        """Verify signing.crt still exists (it was correct, only key needed fixing)."""
        signing_crt = os.path.join(CERTS_DIR, "signing.crt")
        assert os.path.isfile(signing_crt), \
            f"Signing certificate {signing_crt} does not exist"

        # Verify it's still a valid X.509 cert
        result = subprocess.run(
            ["openssl", "x509", "-noout", "-text", "-in", signing_crt],
            capture_output=True, text=True
        )
        assert result.returncode == 0, \
            f"signing.crt is not a valid X.509 certificate: {result.stderr}"

    def test_uses_tls_not_http(self):
        """Verify server still uses TLS (HTTPS), not plain HTTP."""
        # Try plain HTTP - should fail or not work
        result = subprocess.run(
            ["curl", "-s", "-o", "/dev/null", "-w", "%{http_code}",
             "--connect-timeout", "3",
             "http://localhost:8443/packages/commons-util-1.2.jar"],
            capture_output=True, text=True, timeout=10
        )
        # Plain HTTP to an HTTPS server should fail or return error
        # The important thing is HTTPS works (tested elsewhere)

        # Verify HTTPS works
        result = subprocess.run(
            ["curl", "-k", "-s", "-o", "/dev/null", "-w", "%{http_code}",
             "https://localhost:8443/packages/commons-util-1.2.jar"],
            capture_output=True, text=True, timeout=30
        )
        assert result.returncode == 0 and result.stdout.strip() == "200", \
            "HTTPS is not working on port 8443 - server may have been downgraded to HTTP"


class TestDownloadedArtifact:
    """Test that the downloaded artifact matches the original."""

    def test_downloaded_artifact_matches_original(self):
        """Verify downloaded artifact is identical to original on disk."""
        with tempfile.TemporaryDirectory() as tmpdir:
            downloaded_jar = os.path.join(tmpdir, "downloaded.jar")
            original_jar = os.path.join(PACKAGES_DIR, "commons-util-1.2.jar")

            # Download the artifact
            result = subprocess.run(
                ["curl", "-k", "-s", "-o", downloaded_jar,
                 "https://localhost:8443/packages/commons-util-1.2.jar"],
                capture_output=True, text=True, timeout=30
            )
            assert result.returncode == 0, \
                f"curl download failed: {result.stderr}"

            # Compare file sizes
            orig_size = os.path.getsize(original_jar)
            down_size = os.path.getsize(downloaded_jar)
            assert orig_size == down_size, \
                f"Downloaded file size ({down_size}) differs from original ({orig_size})"

            # Compare file contents using checksum
            orig_hash = subprocess.run(
                ["sha256sum", original_jar],
                capture_output=True, text=True
            )
            down_hash = subprocess.run(
                ["sha256sum", downloaded_jar],
                capture_output=True, text=True
            )

            orig_checksum = orig_hash.stdout.split()[0]
            down_checksum = down_hash.stdout.split()[0]

            assert orig_checksum == down_checksum, \
                f"Downloaded file checksum differs from original"
