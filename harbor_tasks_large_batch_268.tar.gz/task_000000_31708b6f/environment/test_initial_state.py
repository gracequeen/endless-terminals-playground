# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the artifact server repair task.
"""

import os
import subprocess
import json
import pytest

BASE_DIR = "/home/user/artifact-repo"
CERTS_DIR = os.path.join(BASE_DIR, "certs")
CONF_DIR = os.path.join(BASE_DIR, "conf")
PACKAGES_DIR = os.path.join(BASE_DIR, "packages")
LOGS_DIR = os.path.join(BASE_DIR, "logs")


class TestDirectoryStructure:
    """Test that required directories exist."""

    def test_artifact_repo_exists(self):
        assert os.path.isdir(BASE_DIR), f"Directory {BASE_DIR} does not exist"

    def test_certs_dir_exists(self):
        assert os.path.isdir(CERTS_DIR), f"Directory {CERTS_DIR} does not exist"

    def test_conf_dir_exists(self):
        assert os.path.isdir(CONF_DIR), f"Directory {CONF_DIR} does not exist"

    def test_packages_dir_exists(self):
        assert os.path.isdir(PACKAGES_DIR), f"Directory {PACKAGES_DIR} does not exist"

    def test_logs_dir_exists(self):
        assert os.path.isdir(LOGS_DIR), f"Directory {LOGS_DIR} does not exist"


class TestServerFiles:
    """Test that server-related files exist."""

    def test_server_py_exists(self):
        server_py = os.path.join(BASE_DIR, "server.py")
        assert os.path.isfile(server_py), f"Server script {server_py} does not exist"

    def test_server_py_is_readable(self):
        server_py = os.path.join(BASE_DIR, "server.py")
        assert os.access(server_py, os.R_OK), f"Server script {server_py} is not readable"

    def test_server_conf_exists(self):
        server_conf = os.path.join(CONF_DIR, "server.conf")
        assert os.path.isfile(server_conf), f"Config file {server_conf} does not exist"

    def test_server_conf_is_valid_json(self):
        server_conf = os.path.join(CONF_DIR, "server.conf")
        with open(server_conf, 'r') as f:
            try:
                config = json.load(f)
            except json.JSONDecodeError as e:
                pytest.fail(f"Config file {server_conf} is not valid JSON: {e}")
        assert isinstance(config, dict), f"Config file {server_conf} should contain a JSON object"


class TestCertificates:
    """Test that certificate files exist and have expected properties."""

    def test_signing_crt_exists(self):
        signing_crt = os.path.join(CERTS_DIR, "signing.crt")
        assert os.path.isfile(signing_crt), f"Signing certificate {signing_crt} does not exist"

    def test_signing_key_exists(self):
        signing_key = os.path.join(CERTS_DIR, "signing.key")
        assert os.path.isfile(signing_key), f"Signing key {signing_key} does not exist"

    def test_signing_key_bak_exists(self):
        signing_key_bak = os.path.join(CERTS_DIR, "signing.key.bak")
        assert os.path.isfile(signing_key_bak), f"Backup signing key {signing_key_bak} does not exist"

    def test_server_crt_exists(self):
        server_crt = os.path.join(CERTS_DIR, "server.crt")
        assert os.path.isfile(server_crt), f"Server certificate {server_crt} does not exist"

    def test_server_key_exists(self):
        server_key = os.path.join(CERTS_DIR, "server.key")
        assert os.path.isfile(server_key), f"Server key {server_key} does not exist"

    def test_signing_crt_is_valid_x509(self):
        signing_crt = os.path.join(CERTS_DIR, "signing.crt")
        result = subprocess.run(
            ["openssl", "x509", "-noout", "-text", "-in", signing_crt],
            capture_output=True, text=True
        )
        assert result.returncode == 0, f"signing.crt is not a valid X.509 certificate: {result.stderr}"

    def test_signing_key_is_valid_rsa(self):
        signing_key = os.path.join(CERTS_DIR, "signing.key")
        result = subprocess.run(
            ["openssl", "rsa", "-noout", "-check", "-in", signing_key],
            capture_output=True, text=True
        )
        assert result.returncode == 0, f"signing.key is not a valid RSA key: {result.stderr}"

    def test_signing_key_bak_is_valid_rsa(self):
        signing_key_bak = os.path.join(CERTS_DIR, "signing.key.bak")
        result = subprocess.run(
            ["openssl", "rsa", "-noout", "-check", "-in", signing_key_bak],
            capture_output=True, text=True
        )
        assert result.returncode == 0, f"signing.key.bak is not a valid RSA key: {result.stderr}"

    def test_signing_key_does_not_match_cert(self):
        """Verify the initial broken state: signing.key does NOT match signing.crt"""
        signing_crt = os.path.join(CERTS_DIR, "signing.crt")
        signing_key = os.path.join(CERTS_DIR, "signing.key")

        cert_modulus = subprocess.run(
            ["openssl", "x509", "-noout", "-modulus", "-in", signing_crt],
            capture_output=True, text=True
        )
        key_modulus = subprocess.run(
            ["openssl", "rsa", "-noout", "-modulus", "-in", signing_key],
            capture_output=True, text=True
        )

        assert cert_modulus.returncode == 0, f"Failed to get cert modulus: {cert_modulus.stderr}"
        assert key_modulus.returncode == 0, f"Failed to get key modulus: {key_modulus.stderr}"

        # The key should NOT match the cert (this is the bug to fix)
        assert cert_modulus.stdout.strip() != key_modulus.stdout.strip(), \
            "signing.key already matches signing.crt - initial broken state not set up correctly"

    def test_signing_key_bak_matches_cert(self):
        """Verify that signing.key.bak (the backup) DOES match signing.crt"""
        signing_crt = os.path.join(CERTS_DIR, "signing.crt")
        signing_key_bak = os.path.join(CERTS_DIR, "signing.key.bak")

        cert_modulus = subprocess.run(
            ["openssl", "x509", "-noout", "-modulus", "-in", signing_crt],
            capture_output=True, text=True
        )
        key_bak_modulus = subprocess.run(
            ["openssl", "rsa", "-noout", "-modulus", "-in", signing_key_bak],
            capture_output=True, text=True
        )

        assert cert_modulus.returncode == 0, f"Failed to get cert modulus: {cert_modulus.stderr}"
        assert key_bak_modulus.returncode == 0, f"Failed to get key.bak modulus: {key_bak_modulus.stderr}"

        # The backup key SHOULD match the cert
        assert cert_modulus.stdout.strip() == key_bak_modulus.stdout.strip(), \
            "signing.key.bak does not match signing.crt - the correct key is missing"

    def test_server_cert_key_pair_matches(self):
        """Verify server TLS cert and key are correctly paired."""
        server_crt = os.path.join(CERTS_DIR, "server.crt")
        server_key = os.path.join(CERTS_DIR, "server.key")

        cert_modulus = subprocess.run(
            ["openssl", "x509", "-noout", "-modulus", "-in", server_crt],
            capture_output=True, text=True
        )
        key_modulus = subprocess.run(
            ["openssl", "rsa", "-noout", "-modulus", "-in", server_key],
            capture_output=True, text=True
        )

        assert cert_modulus.returncode == 0, f"Failed to get server cert modulus: {cert_modulus.stderr}"
        assert key_modulus.returncode == 0, f"Failed to get server key modulus: {key_modulus.stderr}"

        assert cert_modulus.stdout.strip() == key_modulus.stdout.strip(), \
            "server.crt and server.key do not match"


class TestPackages:
    """Test that package files exist."""

    def test_commons_util_jar_exists(self):
        jar_file = os.path.join(PACKAGES_DIR, "commons-util-1.2.jar")
        assert os.path.isfile(jar_file), f"Package {jar_file} does not exist"

    def test_commons_util_jar_has_content(self):
        jar_file = os.path.join(PACKAGES_DIR, "commons-util-1.2.jar")
        size = os.path.getsize(jar_file)
        assert size > 0, f"Package {jar_file} is empty"
        # Task says it's about 2KB
        assert size > 1000, f"Package {jar_file} seems too small ({size} bytes)"


class TestServerNotRunning:
    """Test that the server is NOT currently running (initial broken state)."""

    def test_port_8443_not_listening(self):
        """Verify nothing is listening on port 8443."""
        result = subprocess.run(
            ["ss", "-tlnp"],
            capture_output=True, text=True
        )
        # Check if port 8443 appears in the output
        if ":8443" in result.stdout:
            pytest.fail("Port 8443 is already in use - server should not be running initially")

    def test_no_server_process(self):
        """Verify no server.py process is running."""
        result = subprocess.run(
            ["pgrep", "-f", "server.py"],
            capture_output=True, text=True
        )
        # pgrep returns 0 if process found, 1 if not found
        if result.returncode == 0:
            pytest.fail("server.py process is already running - server should not be running initially")


class TestToolsAvailable:
    """Test that required tools are available."""

    def test_python3_available(self):
        result = subprocess.run(
            ["python3", "--version"],
            capture_output=True, text=True
        )
        assert result.returncode == 0, "Python 3 is not available"

    def test_openssl_available(self):
        result = subprocess.run(
            ["openssl", "version"],
            capture_output=True, text=True
        )
        assert result.returncode == 0, "OpenSSL CLI is not available"

    def test_curl_available(self):
        result = subprocess.run(
            ["curl", "--version"],
            capture_output=True, text=True
        )
        assert result.returncode == 0, "curl is not available"


class TestPermissions:
    """Test that the artifact-repo directory is writable."""

    def test_artifact_repo_writable(self):
        assert os.access(BASE_DIR, os.W_OK), f"{BASE_DIR} is not writable"

    def test_certs_dir_writable(self):
        assert os.access(CERTS_DIR, os.W_OK), f"{CERTS_DIR} is not writable"

    def test_signing_key_writable(self):
        signing_key = os.path.join(CERTS_DIR, "signing.key")
        assert os.access(signing_key, os.W_OK), f"{signing_key} is not writable"


class TestLogFiles:
    """Test that log files exist with expected content."""

    def test_server_log_exists(self):
        server_log = os.path.join(LOGS_DIR, "server.log")
        assert os.path.isfile(server_log), f"Server log {server_log} does not exist"

    def test_server_log_contains_error(self):
        server_log = os.path.join(LOGS_DIR, "server.log")
        with open(server_log, 'r') as f:
            content = f.read()
        # The log should contain evidence of the signing failure
        assert "mismatch" in content.lower() or "signing" in content.lower() or "error" in content.lower(), \
            f"Server log does not contain expected error messages about signing failure"
