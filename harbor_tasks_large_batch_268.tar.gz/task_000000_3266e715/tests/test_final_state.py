# test_final_state.py
"""
Tests to validate the final state of the OS/filesystem after the student
has completed the log filtering task.
"""

import os
import subprocess
import pytest


class TestFinalState:
    """Validate the final state after the filtering task is completed."""

    def test_filtered_log_file_exists(self):
        """Verify /home/user/filtered.log exists."""
        assert os.path.isfile("/home/user/filtered.log"), \
            "Filtered log file /home/user/filtered.log does not exist. " \
            "You need to create this file with the filtered output."

    def test_filtered_log_file_readable(self):
        """Verify /home/user/filtered.log is readable."""
        assert os.access("/home/user/filtered.log", os.R_OK), \
            "Filtered log file /home/user/filtered.log is not readable."

    def test_filtered_log_contains_no_healthz_lines(self):
        """Verify filtered log contains zero lines matching 'GET /healthz'."""
        result = subprocess.run(
            ["grep", "-c", "GET /healthz", "/home/user/filtered.log"],
            capture_output=True,
            text=True
        )
        # grep -c returns 1 (exit code) if no matches found, 0 if matches found
        if result.returncode == 0:
            healthz_count = int(result.stdout.strip())
            assert healthz_count == 0, \
                f"Filtered log still contains {healthz_count} health check lines with 'GET /healthz'. " \
                "All healthz lines should be removed."
        # If returncode is 1, grep found no matches, which is correct

    def test_filtered_log_has_sufficient_content(self):
        """Verify filtered log has more than 100 lines (real content preserved)."""
        with open("/home/user/filtered.log", "r") as f:
            line_count = sum(1 for _ in f)
        assert line_count > 100, \
            f"Filtered log only has {line_count} lines, but should have >100 lines. " \
            "Make sure you preserved all non-healthz lines from the original log."

    def test_filtered_log_contains_real_traffic(self):
        """Verify filtered log contains real traffic patterns."""
        with open("/home/user/filtered.log", "r") as f:
            content = f.read()

        # Check for real traffic patterns that should be preserved
        has_api_traffic = "GET /api/" in content or "POST /api/" in content
        assert has_api_traffic, \
            "Filtered log should contain real API traffic (GET /api/, POST /api/, etc.) " \
            "but none was found. Make sure you're only filtering out healthz lines."

    def test_source_log_unchanged(self):
        """Verify the original source log file still exists and is unchanged."""
        assert os.path.isfile("/var/log/app/service.log"), \
            "Original source log /var/log/app/service.log should still exist."

        # Verify it still contains healthz lines (wasn't modified)
        result = subprocess.run(
            ["grep", "-c", "GET /healthz", "/var/log/app/service.log"],
            capture_output=True,
            text=True
        )
        if result.returncode == 0:
            healthz_count = int(result.stdout.strip())
            assert healthz_count > 0, \
                "Original source log should still contain healthz lines. " \
                "The original file should not be modified."

    def test_filtered_log_line_count_matches_expected(self):
        """Verify filtered log line count approximately matches non-healthz lines from source."""
        # Count non-healthz lines in source
        result_source = subprocess.run(
            ["grep", "-cv", "GET /healthz", "/var/log/app/service.log"],
            capture_output=True,
            text=True
        )
        expected_count = int(result_source.stdout.strip()) if result_source.returncode == 0 else 0

        # Count lines in filtered log
        with open("/home/user/filtered.log", "r") as f:
            filtered_count = sum(1 for _ in f)

        assert filtered_count == expected_count, \
            f"Filtered log has {filtered_count} lines but should have {expected_count} lines " \
            "(all non-healthz lines from the original). Some lines may be missing or extra."

    def test_filtered_log_preserves_line_order(self):
        """Verify that line order is preserved from the original (spot check)."""
        # Get first few non-healthz lines from source
        result_source = subprocess.run(
            ["grep", "-v", "GET /healthz", "/var/log/app/service.log"],
            capture_output=True,
            text=True
        )
        source_lines = result_source.stdout.strip().split('\n')[:10]

        # Get first few lines from filtered log
        with open("/home/user/filtered.log", "r") as f:
            filtered_lines = [f.readline().strip() for _ in range(10)]

        # Compare first lines (order should be preserved)
        for i, (src_line, filt_line) in enumerate(zip(source_lines, filtered_lines)):
            assert src_line.strip() == filt_line.strip(), \
                f"Line order not preserved. Line {i+1} differs:\n" \
                f"Expected: {src_line[:80]}...\n" \
                f"Got: {filt_line[:80]}..."

    def test_filtered_log_not_empty(self):
        """Verify filtered log is not an empty file."""
        file_size = os.path.getsize("/home/user/filtered.log")
        assert file_size > 0, \
            "Filtered log file is empty. It should contain all non-healthz lines."

    def test_no_partial_healthz_filtering(self):
        """Verify no lines containing 'healthz' in any form remain."""
        with open("/home/user/filtered.log", "r") as f:
            content = f.read().lower()

        # Check that no healthz-related content remains
        assert "/healthz" not in content, \
            "Filtered log still contains lines with '/healthz'. " \
            "All health check lines should be removed."
