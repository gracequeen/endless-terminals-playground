# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the log filtering task.
"""

import os
import subprocess
import pytest


class TestInitialState:
    """Validate the initial state before the filtering task."""

    def test_source_log_directory_exists(self):
        """Verify /var/log/app directory exists."""
        assert os.path.isdir("/var/log/app"), \
            "Directory /var/log/app does not exist"

    def test_source_log_file_exists(self):
        """Verify /var/log/app/service.log exists."""
        assert os.path.isfile("/var/log/app/service.log"), \
            "Source log file /var/log/app/service.log does not exist"

    def test_source_log_file_readable(self):
        """Verify /var/log/app/service.log is readable by current user."""
        assert os.access("/var/log/app/service.log", os.R_OK), \
            "Source log file /var/log/app/service.log is not readable by current user"

    def test_source_log_has_content(self):
        """Verify source log has approximately 200 lines."""
        with open("/var/log/app/service.log", "r") as f:
            line_count = sum(1 for _ in f)
        assert 150 <= line_count <= 250, \
            f"Source log should have ~200 lines, but has {line_count} lines"

    def test_source_log_contains_healthz_lines(self):
        """Verify source log contains health check lines (GET /healthz)."""
        result = subprocess.run(
            ["grep", "-c", "GET /healthz", "/var/log/app/service.log"],
            capture_output=True,
            text=True
        )
        # grep -c returns 0 if matches found, 1 if no matches
        healthz_count = int(result.stdout.strip()) if result.returncode == 0 else 0
        assert healthz_count > 0, \
            "Source log should contain health check lines with 'GET /healthz' but none found"
        # Should be roughly 40% of ~200 lines = ~80 healthz lines
        assert healthz_count >= 50, \
            f"Source log should have significant healthz lines (~80), but only has {healthz_count}"

    def test_source_log_contains_real_traffic(self):
        """Verify source log contains real traffic (non-healthz lines)."""
        result = subprocess.run(
            ["grep", "-cv", "GET /healthz", "/var/log/app/service.log"],
            capture_output=True,
            text=True
        )
        non_healthz_count = int(result.stdout.strip()) if result.returncode == 0 else 0
        assert non_healthz_count > 100, \
            f"Source log should have >100 non-healthz lines, but only has {non_healthz_count}"

    def test_source_log_has_mixed_content(self):
        """Verify source log has both healthz and real traffic patterns."""
        with open("/var/log/app/service.log", "r") as f:
            content = f.read()

        # Check for health check pattern
        assert "GET /healthz" in content, \
            "Source log should contain 'GET /healthz' health check lines"

        # Check for real traffic patterns
        has_real_traffic = any(pattern in content for pattern in [
            "GET /api/",
            "POST /api/",
            "/users",
            "/orders"
        ])
        assert has_real_traffic, \
            "Source log should contain real traffic patterns (GET /api/, POST /api/, etc.)"

    def test_home_user_directory_exists(self):
        """Verify /home/user directory exists."""
        assert os.path.isdir("/home/user"), \
            "Directory /home/user does not exist"

    def test_home_user_directory_writable(self):
        """Verify /home/user directory is writable."""
        assert os.access("/home/user", os.W_OK), \
            "Directory /home/user is not writable"

    def test_grep_available(self):
        """Verify grep command is available."""
        result = subprocess.run(
            ["which", "grep"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            "grep command is not available on this system"

    def test_sed_available(self):
        """Verify sed command is available."""
        result = subprocess.run(
            ["which", "sed"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            "sed command is not available on this system"

    def test_awk_available(self):
        """Verify awk command is available."""
        result = subprocess.run(
            ["which", "awk"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            "awk command is not available on this system"

    def test_source_log_format_is_nginx_style(self):
        """Verify source log follows nginx-style access log format."""
        with open("/var/log/app/service.log", "r") as f:
            first_lines = [f.readline() for _ in range(5)]

        for line in first_lines:
            if line.strip():
                # Check for typical nginx log components
                assert "HTTP/1.1" in line or "HTTP/2" in line, \
                    f"Log line doesn't appear to be nginx-style format: {line[:100]}"
                # Check for IP address pattern (simple check)
                parts = line.split()
                assert len(parts) >= 5, \
                    f"Log line doesn't have expected nginx-style structure: {line[:100]}"
