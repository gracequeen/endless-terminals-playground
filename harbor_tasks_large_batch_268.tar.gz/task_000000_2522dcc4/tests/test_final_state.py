# test_final_state.py
"""
Tests to validate the final state of the OS/filesystem after the student
has completed the docs-project build pipeline fix task.
"""

import json
import os
import subprocess
import pytest


BASE_DIR = "/home/user/docs-project"


class TestBuildSucceeds:
    """Verify the build pipeline now succeeds."""

    def test_build_script_exits_zero(self):
        """Running ./build.sh should exit with code 0."""
        result = subprocess.run(
            ["./build.sh"],
            cwd=BASE_DIR,
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"build.sh should exit 0 but exited {result.returncode}.\n"
            f"stdout: {result.stdout}\n"
            f"stderr: {result.stderr}"
        )

    def test_markdownlint_passes(self):
        """markdownlint should pass with the fixed config."""
        result = subprocess.run(
            "npx markdownlint-cli docs/*.md --config .markdownlint.json",
            cwd=BASE_DIR,
            capture_output=True,
            text=True,
            shell=True
        )
        assert result.returncode == 0, (
            f"markdownlint should pass but exited {result.returncode}.\n"
            f"stdout: {result.stdout}\n"
            f"stderr: {result.stderr}"
        )


class TestDistOutputExists:
    """Verify the dist/ folder contains expected output."""

    def test_dist_index_html_exists(self):
        """dist/index.html must exist after successful build."""
        index_path = os.path.join(BASE_DIR, "dist", "index.html")
        assert os.path.isfile(index_path), (
            f"dist/index.html not found at {index_path}. "
            "The build may not have completed successfully."
        )

    def test_dist_manifest_json_exists(self):
        """dist/manifest.json must exist after successful build."""
        manifest_path = os.path.join(BASE_DIR, "dist", "manifest.json")
        assert os.path.isfile(manifest_path), (
            f"dist/manifest.json not found at {manifest_path}. "
            "The manifest generation step may have failed."
        )

    def test_manifest_is_valid_json(self):
        """dist/manifest.json must contain valid JSON."""
        manifest_path = os.path.join(BASE_DIR, "dist", "manifest.json")
        with open(manifest_path, 'r') as f:
            content = f.read()
        try:
            data = json.loads(content)
        except json.JSONDecodeError as e:
            pytest.fail(f"dist/manifest.json is not valid JSON: {e}")

    def test_manifest_is_array_with_entries(self):
        """dist/manifest.json must be an array with at least 3 entries."""
        manifest_path = os.path.join(BASE_DIR, "dist", "manifest.json")
        with open(manifest_path, 'r') as f:
            data = json.load(f)

        assert isinstance(data, list), (
            f"manifest.json should be a JSON array, got {type(data).__name__}"
        )
        assert len(data) >= 3, (
            f"manifest.json should have at least 3 entries, found {len(data)}"
        )


class TestMarkdownLintConfigValid:
    """Verify the .markdownlint.json is properly configured (not gutted)."""

    def test_config_file_exists(self):
        """.markdownlint.json must still exist."""
        config_file = os.path.join(BASE_DIR, ".markdownlint.json")
        assert os.path.isfile(config_file), (
            f".markdownlint.json not found at {config_file}"
        )

    def test_config_is_valid_json(self):
        """.markdownlint.json must be valid JSON."""
        config_file = os.path.join(BASE_DIR, ".markdownlint.json")
        with open(config_file, 'r') as f:
            content = f.read()
        try:
            json.loads(content)
        except json.JSONDecodeError as e:
            pytest.fail(f".markdownlint.json is not valid JSON: {e}")

    def test_config_has_default_true(self):
        """Config must still have 'default': true (not gutted)."""
        config_file = os.path.join(BASE_DIR, ".markdownlint.json")
        with open(config_file, 'r') as f:
            config = json.load(f)

        assert config.get("default") is True, (
            ".markdownlint.json must have 'default': true. "
            "The config should not be gutted to bypass linting."
        )

    def test_config_has_md013_enabled(self):
        """MD013 line length checking must remain enabled."""
        config_file = os.path.join(BASE_DIR, ".markdownlint.json")
        with open(config_file, 'r') as f:
            config = json.load(f)

        # MD013 should be present and not set to false
        assert "MD013" in config, (
            "MD013 rule must be present in .markdownlint.json"
        )
        md013_value = config["MD013"]
        # It can be True, or a dict with settings, but not False
        assert md013_value is not False, (
            "MD013 must not be disabled (set to false). "
            "Line length checking should remain enabled."
        )

    def test_config_does_not_have_invalid_rule(self):
        """Config should no longer have 'no-trailing-spaces' (the bug)."""
        config_file = os.path.join(BASE_DIR, ".markdownlint.json")
        with open(config_file, 'r') as f:
            config = json.load(f)

        assert "no-trailing-spaces" not in config, (
            "The invalid rule 'no-trailing-spaces' should be removed or renamed to 'MD009'"
        )

    def test_default_count_in_config(self):
        """Anti-shortcut: grep -c '"default"' should return 1."""
        result = subprocess.run(
            ["grep", "-c", '"default"', ".markdownlint.json"],
            cwd=BASE_DIR,
            capture_output=True,
            text=True
        )
        count = int(result.stdout.strip()) if result.returncode == 0 else 0
        assert count >= 1, (
            "Config appears to be gutted. 'default' key must be present."
        )


class TestBuildScriptIntegrity:
    """Verify build.sh still runs all three steps."""

    def test_build_script_exists(self):
        """build.sh must still exist."""
        build_sh = os.path.join(BASE_DIR, "build.sh")
        assert os.path.isfile(build_sh), f"build.sh not found at {build_sh}"

    def test_build_script_has_lint_step(self):
        """build.sh must still contain markdownlint command."""
        build_sh = os.path.join(BASE_DIR, "build.sh")
        with open(build_sh, 'r') as f:
            content = f.read()

        assert "markdownlint" in content, (
            "build.sh must still contain markdownlint command. "
            "The linting step should not be removed."
        )

    def test_build_script_has_mkdocs_build(self):
        """build.sh must still contain mkdocs build command."""
        build_sh = os.path.join(BASE_DIR, "build.sh")
        with open(build_sh, 'r') as f:
            content = f.read()

        assert "mkdocs build" in content, (
            "build.sh must still contain 'mkdocs build' command"
        )

    def test_build_script_has_manifest_generation(self):
        """build.sh must still contain manifest generation step."""
        build_sh = os.path.join(BASE_DIR, "build.sh")
        with open(build_sh, 'r') as f:
            content = f.read()

        assert "gen_manifest.py" in content, (
            "build.sh must still contain gen_manifest.py for manifest generation"
        )

    def test_markdownlint_grep_count(self):
        """Anti-shortcut: grep -E 'markdownlint' build.sh | wc -l must be >= 1."""
        result = subprocess.run(
            "grep -E 'markdownlint' build.sh | wc -l",
            cwd=BASE_DIR,
            capture_output=True,
            text=True,
            shell=True
        )
        count = int(result.stdout.strip())
        assert count >= 1, (
            "build.sh must contain at least one reference to markdownlint. "
            "The linting step should not be removed."
        )


class TestMarkdownFilesIntact:
    """Verify all original markdown files still exist."""

    @pytest.mark.parametrize("md_file", [
        "index.md",
        "getting-started.md",
        "api-reference.md",
        "changelog.md"
    ])
    def test_markdown_file_exists(self, md_file):
        """Each original markdown file must still exist in docs/."""
        file_path = os.path.join(BASE_DIR, "docs", md_file)
        assert os.path.isfile(file_path), (
            f"Markdown file {md_file} not found at {file_path}. "
            "Original files should not be deleted."
        )


class TestManifestIsDynamic:
    """Verify manifest is generated dynamically, not hardcoded."""

    def test_gen_manifest_script_exists(self):
        """scripts/gen_manifest.py must still exist."""
        manifest_script = os.path.join(BASE_DIR, "scripts", "gen_manifest.py")
        assert os.path.isfile(manifest_script), (
            f"gen_manifest.py not found at {manifest_script}"
        )

    def test_manifest_reflects_dist_contents(self):
        """Manifest should reflect actual dist/ contents (not hardcoded)."""
        # Run the manifest generator directly and compare
        result = subprocess.run(
            ["python3", "scripts/gen_manifest.py", "dist"],
            cwd=BASE_DIR,
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"gen_manifest.py failed: {result.stderr}"
        )

        # Parse the generated manifest
        try:
            generated = json.loads(result.stdout)
        except json.JSONDecodeError:
            pytest.fail(f"gen_manifest.py output is not valid JSON: {result.stdout}")

        # Read the actual manifest file
        manifest_path = os.path.join(BASE_DIR, "dist", "manifest.json")
        with open(manifest_path, 'r') as f:
            saved = json.load(f)

        # They should have similar content (allowing for the manifest.json itself)
        # The key point is that the manifest is generated, not hardcoded
        assert isinstance(generated, list), "gen_manifest.py should output a list"
        assert isinstance(saved, list), "manifest.json should be a list"

        # Both should have entries
        assert len(generated) > 0, "gen_manifest.py should find files in dist/"
        assert len(saved) > 0, "manifest.json should have entries"


class TestProjectStructureIntact:
    """Verify project structure remains intact."""

    def test_project_directory_exists(self):
        """Project directory must exist."""
        assert os.path.isdir(BASE_DIR), f"Project directory {BASE_DIR} does not exist"

    def test_docs_directory_exists(self):
        """docs/ folder must exist."""
        docs_dir = os.path.join(BASE_DIR, "docs")
        assert os.path.isdir(docs_dir), f"docs/ directory not found at {docs_dir}"

    def test_dist_directory_exists(self):
        """dist/ folder must exist."""
        dist_dir = os.path.join(BASE_DIR, "dist")
        assert os.path.isdir(dist_dir), f"dist/ directory not found at {dist_dir}"

    def test_mkdocs_config_exists(self):
        """mkdocs.yml must still exist."""
        mkdocs_file = os.path.join(BASE_DIR, "mkdocs.yml")
        assert os.path.isfile(mkdocs_file), f"mkdocs.yml not found at {mkdocs_file}"
