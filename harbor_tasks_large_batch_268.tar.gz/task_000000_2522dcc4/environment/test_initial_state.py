# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the docs-project build pipeline fix task.
"""

import json
import os
import subprocess
import pytest


BASE_DIR = "/home/user/docs-project"


class TestProjectStructureExists:
    """Verify the project directory and essential files exist."""

    def test_project_directory_exists(self):
        """The docs-project directory must exist."""
        assert os.path.isdir(BASE_DIR), f"Project directory {BASE_DIR} does not exist"

    def test_build_script_exists(self):
        """build.sh must exist in the project root."""
        build_sh = os.path.join(BASE_DIR, "build.sh")
        assert os.path.isfile(build_sh), f"build.sh not found at {build_sh}"

    def test_build_script_is_executable(self):
        """build.sh must be executable."""
        build_sh = os.path.join(BASE_DIR, "build.sh")
        assert os.access(build_sh, os.X_OK), f"build.sh at {build_sh} is not executable"

    def test_markdownlint_config_exists(self):
        """.markdownlint.json must exist in the project root."""
        config_file = os.path.join(BASE_DIR, ".markdownlint.json")
        assert os.path.isfile(config_file), f".markdownlint.json not found at {config_file}"

    def test_mkdocs_config_exists(self):
        """mkdocs.yml must exist in the project root."""
        mkdocs_file = os.path.join(BASE_DIR, "mkdocs.yml")
        assert os.path.isfile(mkdocs_file), f"mkdocs.yml not found at {mkdocs_file}"

    def test_docs_directory_exists(self):
        """docs/ folder must exist."""
        docs_dir = os.path.join(BASE_DIR, "docs")
        assert os.path.isdir(docs_dir), f"docs/ directory not found at {docs_dir}"

    def test_dist_directory_exists(self):
        """dist/ folder must exist."""
        dist_dir = os.path.join(BASE_DIR, "dist")
        assert os.path.isdir(dist_dir), f"dist/ directory not found at {dist_dir}"

    def test_scripts_directory_exists(self):
        """scripts/ folder must exist for gen_manifest.py."""
        scripts_dir = os.path.join(BASE_DIR, "scripts")
        assert os.path.isdir(scripts_dir), f"scripts/ directory not found at {scripts_dir}"

    def test_gen_manifest_script_exists(self):
        """scripts/gen_manifest.py must exist."""
        manifest_script = os.path.join(BASE_DIR, "scripts", "gen_manifest.py")
        assert os.path.isfile(manifest_script), f"gen_manifest.py not found at {manifest_script}"


class TestMarkdownFilesExist:
    """Verify all expected markdown files exist in docs/."""

    @pytest.mark.parametrize("md_file", [
        "index.md",
        "getting-started.md",
        "api-reference.md",
        "changelog.md"
    ])
    def test_markdown_file_exists(self, md_file):
        """Each expected markdown file must exist in docs/."""
        file_path = os.path.join(BASE_DIR, "docs", md_file)
        assert os.path.isfile(file_path), f"Markdown file {md_file} not found at {file_path}"


class TestDistDirectoryIsEmpty:
    """Verify the dist/ folder is empty or incomplete (initial broken state)."""

    def test_dist_is_empty_or_no_manifest(self):
        """dist/ should be empty or at least missing manifest.json (broken state)."""
        dist_dir = os.path.join(BASE_DIR, "dist")
        manifest_path = os.path.join(dist_dir, "manifest.json")

        contents = os.listdir(dist_dir)
        # Either dist is empty, or manifest.json doesn't exist
        is_empty = len(contents) == 0
        no_manifest = not os.path.isfile(manifest_path)

        assert is_empty or no_manifest, (
            f"dist/ directory should be empty or missing manifest.json in initial state. "
            f"Found: {contents}"
        )


class TestMarkdownLintConfigHasBug:
    """Verify the .markdownlint.json contains the problematic configuration."""

    def test_config_is_valid_json(self):
        """.markdownlint.json must be valid JSON."""
        config_file = os.path.join(BASE_DIR, ".markdownlint.json")
        with open(config_file, 'r') as f:
            content = f.read()
        try:
            json.loads(content)
        except json.JSONDecodeError as e:
            pytest.fail(f".markdownlint.json is not valid JSON: {e}")

    def test_config_has_invalid_rule_name(self):
        """Config should contain 'no-trailing-spaces' (invalid rule name)."""
        config_file = os.path.join(BASE_DIR, ".markdownlint.json")
        with open(config_file, 'r') as f:
            config = json.load(f)

        assert "no-trailing-spaces" in config, (
            ".markdownlint.json should contain 'no-trailing-spaces' (the bug). "
            f"Found keys: {list(config.keys())}"
        )

    def test_config_has_default_true(self):
        """Config should have 'default': true."""
        config_file = os.path.join(BASE_DIR, ".markdownlint.json")
        with open(config_file, 'r') as f:
            config = json.load(f)

        assert config.get("default") is True, (
            ".markdownlint.json should have 'default': true"
        )

    def test_config_has_md013_rule(self):
        """Config should have MD013 line length rule configured."""
        config_file = os.path.join(BASE_DIR, ".markdownlint.json")
        with open(config_file, 'r') as f:
            config = json.load(f)

        assert "MD013" in config, (
            ".markdownlint.json should have MD013 rule configured"
        )


class TestBuildScriptContent:
    """Verify build.sh has the expected pipeline steps."""

    def test_build_script_has_lint_step(self):
        """build.sh must contain markdownlint command."""
        build_sh = os.path.join(BASE_DIR, "build.sh")
        with open(build_sh, 'r') as f:
            content = f.read()

        assert "markdownlint" in content, (
            "build.sh should contain markdownlint command for linting step"
        )

    def test_build_script_has_mkdocs_build(self):
        """build.sh must contain mkdocs build command."""
        build_sh = os.path.join(BASE_DIR, "build.sh")
        with open(build_sh, 'r') as f:
            content = f.read()

        assert "mkdocs build" in content, (
            "build.sh should contain 'mkdocs build' command"
        )

    def test_build_script_has_manifest_generation(self):
        """build.sh must contain manifest generation step."""
        build_sh = os.path.join(BASE_DIR, "build.sh")
        with open(build_sh, 'r') as f:
            content = f.read()

        assert "gen_manifest.py" in content, (
            "build.sh should contain gen_manifest.py for manifest generation"
        )

    def test_build_script_has_set_e(self):
        """build.sh should have 'set -e' for fail-fast behavior."""
        build_sh = os.path.join(BASE_DIR, "build.sh")
        with open(build_sh, 'r') as f:
            content = f.read()

        assert "set -e" in content, (
            "build.sh should have 'set -e' which causes it to exit on first error"
        )


class TestToolsInstalled:
    """Verify required tools are installed and functional."""

    def test_node_is_installed(self):
        """Node.js must be installed."""
        result = subprocess.run(
            ["node", "--version"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "Node.js is not installed or not in PATH"

    def test_npx_is_available(self):
        """npx must be available."""
        result = subprocess.run(
            ["npx", "--version"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "npx is not available"

    def test_markdownlint_cli_is_installed(self):
        """markdownlint-cli must be installed."""
        result = subprocess.run(
            ["npx", "markdownlint-cli", "--version"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "markdownlint-cli is not installed"

    def test_python3_is_installed(self):
        """Python 3 must be installed."""
        result = subprocess.run(
            ["python3", "--version"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "Python 3 is not installed"

    def test_mkdocs_is_installed(self):
        """MkDocs must be installed."""
        result = subprocess.run(
            ["mkdocs", "--version"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "MkDocs is not installed"


class TestBuildCurrentlyFails:
    """Verify the build currently fails (the bug exists)."""

    def test_build_script_fails(self):
        """Running build.sh should currently fail due to the bug."""
        result = subprocess.run(
            ["./build.sh"],
            cwd=BASE_DIR,
            capture_output=True,
            text=True
        )
        assert result.returncode != 0, (
            "build.sh should currently fail (exit non-zero) due to the invalid "
            "markdownlint config. If it passes, the bug may have been fixed already."
        )

    def test_markdownlint_fails_with_current_config(self):
        """markdownlint should fail with the current config due to invalid rule."""
        result = subprocess.run(
            ["npx", "markdownlint-cli", "docs/*.md", "--config", ".markdownlint.json"],
            cwd=BASE_DIR,
            capture_output=True,
            text=True,
            shell=False
        )
        # Run with shell to expand glob
        result = subprocess.run(
            "npx markdownlint-cli docs/*.md --config .markdownlint.json",
            cwd=BASE_DIR,
            capture_output=True,
            text=True,
            shell=True
        )
        assert result.returncode != 0, (
            "markdownlint should fail with current config containing invalid rule 'no-trailing-spaces'"
        )


class TestProjectIsWritable:
    """Verify the project directory is writable."""

    def test_project_dir_is_writable(self):
        """Project directory must be writable."""
        assert os.access(BASE_DIR, os.W_OK), f"{BASE_DIR} is not writable"

    def test_dist_dir_is_writable(self):
        """dist/ directory must be writable."""
        dist_dir = os.path.join(BASE_DIR, "dist")
        assert os.access(dist_dir, os.W_OK), f"{dist_dir} is not writable"

    def test_markdownlint_config_is_writable(self):
        """.markdownlint.json must be writable (for fixing the bug)."""
        config_file = os.path.join(BASE_DIR, ".markdownlint.json")
        assert os.access(config_file, os.W_OK), f"{config_file} is not writable"
