# test_initial_state.py
"""
Tests to validate the initial state before the student performs the task.
Validates that the environment is set up correctly for the PuLP installation task.
"""

import os
import subprocess
import pytest


class TestPythonEnvironment:
    """Tests for Python environment setup."""

    def test_python3_available(self):
        """Python 3 should be available."""
        result = subprocess.run(
            ["python3", "--version"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "python3 is not available"
        assert "Python 3.11" in result.stdout or "Python 3.11" in result.stderr, \
            f"Expected Python 3.11, got: {result.stdout}{result.stderr}"

    def test_pip_available(self):
        """pip should be available."""
        result = subprocess.run(
            ["python3", "-m", "pip", "--version"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "pip is not available via python3 -m pip"


class TestOptimizeScript:
    """Tests for the optimize.py script existence and content."""

    def test_optimize_script_exists(self):
        """The optimize.py script should exist."""
        script_path = "/home/user/analysis/optimize.py"
        assert os.path.isfile(script_path), \
            f"Script {script_path} does not exist"

    def test_optimize_script_readable(self):
        """The optimize.py script should be readable."""
        script_path = "/home/user/analysis/optimize.py"
        assert os.access(script_path, os.R_OK), \
            f"Script {script_path} is not readable"

    def test_optimize_script_contains_pulp_imports(self):
        """The script should contain PuLP-related imports."""
        script_path = "/home/user/analysis/optimize.py"
        with open(script_path, 'r') as f:
            content = f.read()

        assert "pulp" in content.lower(), \
            "Script does not appear to import pulp"
        assert "LpProblem" in content or "lpproblem" in content.lower(), \
            "Script does not appear to use LpProblem"
        assert "LpMinimize" in content or "lpminimize" in content.lower(), \
            "Script does not appear to use LpMinimize"

    def test_optimize_script_reasonable_size(self):
        """The script should be approximately 30 lines (reasonable LP script)."""
        script_path = "/home/user/analysis/optimize.py"
        with open(script_path, 'r') as f:
            lines = f.readlines()

        # Allow some flexibility - between 10 and 100 lines
        assert 10 <= len(lines) <= 100, \
            f"Script has {len(lines)} lines, expected approximately 30 lines for a basic LP"


class TestPipConfiguration:
    """Tests for the broken pip configuration."""

    def test_pip_config_exists(self):
        """The pip config file should exist at /home/user/.pip/pip.conf."""
        config_path = "/home/user/.pip/pip.conf"
        assert os.path.isfile(config_path), \
            f"pip config file {config_path} does not exist"

    def test_pip_config_writable(self):
        """The pip config file should be writable."""
        config_path = "/home/user/.pip/pip.conf"
        assert os.access(config_path, os.W_OK), \
            f"pip config file {config_path} is not writable"

    def test_pip_config_has_bogus_index(self):
        """The pip config should contain the bogus internal index URL."""
        config_path = "/home/user/.pip/pip.conf"
        with open(config_path, 'r') as f:
            content = f.read()

        assert "pypi.internal.corp.invalid" in content, \
            "pip config does not contain the expected bogus index URL (pypi.internal.corp.invalid)"
        assert "index-url" in content.lower(), \
            "pip config does not contain index-url setting"

    def test_system_pip_config_not_exists(self):
        """System pip config at /etc/pip.conf should not exist."""
        system_config = "/etc/pip.conf"
        assert not os.path.exists(system_config), \
            f"System pip config {system_config} should not exist"


class TestPulpNotInstalled:
    """Tests to verify PuLP is not currently installed."""

    def test_pulp_not_importable(self):
        """PuLP should not be importable (not installed)."""
        result = subprocess.run(
            ["python3", "-c", "import pulp"],
            capture_output=True,
            text=True
        )
        assert result.returncode != 0, \
            "PuLP is already installed - it should not be installed initially"

    def test_pip_install_pulp_fails(self):
        """pip install pulp should fail due to bogus index URL."""
        result = subprocess.run(
            ["python3", "-m", "pip", "install", "pulp", "--dry-run"],
            capture_output=True,
            text=True,
            timeout=30
        )
        # The command should fail due to the bogus index URL
        assert result.returncode != 0, \
            "pip install pulp should fail with the bogus index URL"


class TestDirectoryStructure:
    """Tests for directory structure."""

    def test_analysis_directory_exists(self):
        """The /home/user/analysis directory should exist."""
        dir_path = "/home/user/analysis"
        assert os.path.isdir(dir_path), \
            f"Directory {dir_path} does not exist"

    def test_pip_directory_exists(self):
        """The /home/user/.pip directory should exist."""
        dir_path = "/home/user/.pip"
        assert os.path.isdir(dir_path), \
            f"Directory {dir_path} does not exist"


class TestNoVirtualenvActive:
    """Tests to verify no virtualenv is active."""

    def test_no_virtual_env_variable(self):
        """VIRTUAL_ENV environment variable should not be set."""
        virtual_env = os.environ.get("VIRTUAL_ENV")
        assert virtual_env is None, \
            f"A virtualenv appears to be active: {virtual_env}"
