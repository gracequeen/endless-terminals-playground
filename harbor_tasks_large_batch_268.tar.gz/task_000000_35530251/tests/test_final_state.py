# test_final_state.py
"""
Tests to validate the final state after the student has completed the PuLP installation task.
Validates that PuLP is installed and the optimize.py script runs successfully.
"""

import os
import subprocess
import hashlib
import pytest


class TestPulpInstalled:
    """Tests to verify PuLP is properly installed."""

    def test_pulp_importable(self):
        """PuLP should be importable after installation."""
        result = subprocess.run(
            ["python3", "-c", "import pulp"],
            capture_output=True,
            text=True,
            timeout=30
        )
        assert result.returncode == 0, \
            f"PuLP is not importable. stderr: {result.stderr}"

    def test_pulp_core_components_available(self):
        """PuLP core components should be available."""
        result = subprocess.run(
            ["python3", "-c", "from pulp import LpProblem, LpMinimize, LpVariable, lpSum"],
            capture_output=True,
            text=True,
            timeout=30
        )
        assert result.returncode == 0, \
            f"PuLP core components not available. stderr: {result.stderr}"


class TestOptimizeScriptExecution:
    """Tests for successful execution of the optimize.py script."""

    def test_script_runs_successfully(self):
        """The optimize.py script should run without errors (exit code 0)."""
        script_path = "/home/user/analysis/optimize.py"
        result = subprocess.run(
            ["python3", script_path],
            capture_output=True,
            text=True,
            timeout=60
        )
        assert result.returncode == 0, \
            f"Script failed with exit code {result.returncode}. stderr: {result.stderr}"

    def test_script_outputs_optimal_cost(self):
        """The script should output the correct optimal cost of 4250.0."""
        script_path = "/home/user/analysis/optimize.py"
        result = subprocess.run(
            ["python3", script_path],
            capture_output=True,
            text=True,
            timeout=60
        )
        assert result.returncode == 0, \
            f"Script failed with exit code {result.returncode}. stderr: {result.stderr}"

        # Check that the output contains the expected optimal cost
        assert "Optimal cost: 4250.0" in result.stdout, \
            f"Expected 'Optimal cost: 4250.0' in output, got: {result.stdout}"

    def test_script_output_contains_optimal_keyword(self):
        """The script output should contain 'Optimal' and the cost value."""
        script_path = "/home/user/analysis/optimize.py"
        result = subprocess.run(
            ["python3", script_path],
            capture_output=True,
            text=True,
            timeout=60
        )

        stdout_lower = result.stdout.lower()
        assert "optimal" in stdout_lower, \
            f"Output should contain 'optimal'. Got: {result.stdout}"
        assert "4250" in result.stdout, \
            f"Output should contain the value 4250. Got: {result.stdout}"


class TestScriptIntegrity:
    """Tests to verify the optimize.py script was not modified."""

    def test_script_still_exists(self):
        """The optimize.py script should still exist."""
        script_path = "/home/user/analysis/optimize.py"
        assert os.path.isfile(script_path), \
            f"Script {script_path} no longer exists"

    def test_script_contains_pulp_code(self):
        """The script should still contain PuLP-related code (not replaced with hardcoded output)."""
        script_path = "/home/user/analysis/optimize.py"
        with open(script_path, 'r') as f:
            content = f.read()

        # Verify the script still uses PuLP (anti-shortcut guard)
        assert "pulp" in content.lower(), \
            "Script no longer imports pulp - it may have been replaced with hardcoded output"
        assert "LpProblem" in content or "lpproblem" in content.lower(), \
            "Script no longer uses LpProblem"
        assert "LpMinimize" in content or "lpminimize" in content.lower(), \
            "Script no longer uses LpMinimize"

    def test_script_not_just_print_statement(self):
        """The script should not be just a simple print statement (anti-shortcut guard)."""
        script_path = "/home/user/analysis/optimize.py"
        with open(script_path, 'r') as f:
            content = f.read()

        # Count non-empty, non-comment lines
        lines = [line.strip() for line in content.split('\n') 
                 if line.strip() and not line.strip().startswith('#')]

        assert len(lines) >= 10, \
            f"Script has only {len(lines)} significant lines - it may have been replaced with a simple print"


class TestPythonEnvironment:
    """Tests to verify Python environment is unchanged."""

    def test_python_version_unchanged(self):
        """Python version should still be 3.11."""
        result = subprocess.run(
            ["python3", "--version"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "python3 is not available"
        version_output = result.stdout + result.stderr
        assert "3.11" in version_output, \
            f"Python version should still be 3.11, got: {version_output}"


class TestAntiShortcutGuards:
    """Additional tests to ensure the task was completed properly."""

    def test_pulp_actually_used_in_execution(self):
        """Verify that PuLP is actually being used when running the script."""
        # Run a modified version that would fail if PuLP isn't working
        test_code = """
import sys
sys.path.insert(0, '/home/user/analysis')
import pulp
# If we get here, pulp is installed and importable
print("pulp_import_success")
"""
        result = subprocess.run(
            ["python3", "-c", test_code],
            capture_output=True,
            text=True,
            timeout=30
        )
        assert result.returncode == 0, \
            f"PuLP import failed. stderr: {result.stderr}"
        assert "pulp_import_success" in result.stdout, \
            "PuLP import verification failed"

    def test_script_uses_solver(self):
        """Verify the script actually solves an LP (not just prints a value)."""
        script_path = "/home/user/analysis/optimize.py"
        with open(script_path, 'r') as f:
            content = f.read()

        # Check for solve-related code
        assert "solve" in content.lower() or "status" in content.lower(), \
            "Script doesn't appear to call solve() - may not be a real LP solver"
