# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the task of installing Switch.pm for Perl.
"""

import os
import subprocess
import pytest


class TestInitialState:
    """Validate the initial state matches the expected conditions."""

    def test_perl_script_exists(self):
        """Verify the Perl script exists at the expected location."""
        script_path = "/home/user/scripts/useradd_batch.pl"
        assert os.path.isfile(script_path), (
            f"Perl script not found at {script_path}. "
            "The useradd_batch.pl script must exist."
        )

    def test_perl_script_is_executable(self):
        """Verify the Perl script is executable."""
        script_path = "/home/user/scripts/useradd_batch.pl"
        assert os.access(script_path, os.X_OK), (
            f"Perl script at {script_path} is not executable. "
            "The script must have execute permissions."
        )

    def test_perl_script_uses_switch(self):
        """Verify the Perl script contains 'use Switch;' directive."""
        script_path = "/home/user/scripts/useradd_batch.pl"
        result = subprocess.run(
            ["grep", "-q", "use Switch", script_path],
            capture_output=True
        )
        assert result.returncode == 0, (
            f"The Perl script at {script_path} does not contain 'use Switch'. "
            "The script must use the Switch module."
        )

    def test_perl_is_installed(self):
        """Verify Perl is installed and accessible."""
        result = subprocess.run(
            ["perl", "--version"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "Perl is not installed or not accessible. "
            "Perl must be installed on the system."
        )

    def test_perl_version_is_514_or_higher(self):
        """Verify Perl version is 5.14+ (where Switch was removed from core)."""
        result = subprocess.run(
            ["perl", "-e", "print $^V"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "Failed to get Perl version."

        version_str = result.stdout.strip()
        # Version string is like "v5.34.0"
        if version_str.startswith("v"):
            version_str = version_str[1:]

        parts = version_str.split(".")
        major = int(parts[0])
        minor = int(parts[1]) if len(parts) > 1 else 0

        assert major >= 5 and minor >= 14, (
            f"Perl version {version_str} is too old. "
            "Perl 5.14+ is required (where Switch.pm was removed from core)."
        )

    def test_switch_module_not_available(self):
        """Verify Switch.pm is NOT currently available (the problem to solve)."""
        result = subprocess.run(
            ["perl", "-MSwitch", "-e", "1"],
            capture_output=True,
            text=True
        )
        assert result.returncode != 0, (
            "Switch.pm is already installed and available. "
            "The initial state should have Switch.pm missing."
        )
        assert "Can't locate Switch.pm" in result.stderr, (
            "Expected 'Can't locate Switch.pm' error message. "
            f"Got: {result.stderr}"
        )

    def test_cpanm_is_installed(self):
        """Verify cpanminus (cpanm) is installed and functional."""
        result = subprocess.run(
            ["which", "cpanm"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "cpanm (cpanminus) is not installed or not in PATH. "
            "cpanm must be available for installing Perl modules."
        )

    def test_cpanm_is_functional(self):
        """Verify cpanm can be executed."""
        result = subprocess.run(
            ["cpanm", "--version"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "cpanm is not functional. "
            f"Error: {result.stderr}"
        )

    def test_test_csv_exists(self):
        """Verify the test CSV file exists."""
        csv_path = "/home/user/scripts/test_users.csv"
        assert os.path.isfile(csv_path), (
            f"Test CSV file not found at {csv_path}. "
            "A test_users.csv file must exist for testing the script."
        )

    def test_scripts_directory_exists(self):
        """Verify the scripts directory exists."""
        scripts_dir = "/home/user/scripts"
        assert os.path.isdir(scripts_dir), (
            f"Scripts directory not found at {scripts_dir}. "
            "The /home/user/scripts directory must exist."
        )

    def test_home_directory_is_writable(self):
        """Verify /home/user is writable."""
        home_dir = "/home/user"
        assert os.access(home_dir, os.W_OK), (
            f"{home_dir} is not writable. "
            "The home directory must be writable."
        )

    def test_perl_script_syntax_valid(self):
        """Verify the Perl script has valid syntax (aside from missing module)."""
        script_path = "/home/user/scripts/useradd_batch.pl"
        # Use -c to check syntax, but we expect it to fail due to missing Switch
        # We'll check that the only error is about Switch.pm
        result = subprocess.run(
            ["perl", "-c", script_path],
            capture_output=True,
            text=True
        )
        # The script should fail syntax check only because of missing Switch.pm
        if result.returncode != 0:
            # Acceptable if the only error is about Switch.pm
            assert "Can't locate Switch.pm" in result.stderr, (
                f"Perl script has syntax errors other than missing Switch.pm: "
                f"{result.stderr}"
            )

    def test_script_fails_with_switch_error(self):
        """Verify running the script produces the expected Switch.pm error."""
        script_path = "/home/user/scripts/useradd_batch.pl"
        csv_path = "/home/user/scripts/test_users.csv"

        result = subprocess.run(
            ["perl", script_path, csv_path],
            capture_output=True,
            text=True
        )
        assert result.returncode != 0, (
            "Script should fail due to missing Switch.pm"
        )
        assert "Can't locate Switch.pm" in result.stderr, (
            f"Expected 'Can't locate Switch.pm' error when running script. "
            f"Got: {result.stderr}"
        )
