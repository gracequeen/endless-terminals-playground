# test_final_state.py
"""
Tests to validate the final state of the OS/filesystem after the student
has completed the task of installing Switch.pm for Perl.
"""

import os
import subprocess
import hashlib
import pytest


class TestFinalState:
    """Validate the final state matches the expected conditions after task completion."""

    def test_switch_module_is_available(self):
        """Verify Switch.pm is now installed and locatable by Perl."""
        result = subprocess.run(
            ["perl", "-MSwitch", "-e", "1"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "Switch.pm is not installed or not locatable by Perl. "
            f"Error: {result.stderr}. "
            "The Switch module must be installed so that 'perl -MSwitch -e 1' exits 0."
        )

    def test_perl_script_still_exists(self):
        """Verify the Perl script still exists at the expected location."""
        script_path = "/home/user/scripts/useradd_batch.pl"
        assert os.path.isfile(script_path), (
            f"Perl script not found at {script_path}. "
            "The useradd_batch.pl script must still exist."
        )

    def test_perl_script_still_uses_switch(self):
        """Verify the Perl script still contains 'use Switch;' directive (not modified to remove it)."""
        script_path = "/home/user/scripts/useradd_batch.pl"
        result = subprocess.run(
            ["grep", "-q", "use Switch", script_path],
            capture_output=True
        )
        assert result.returncode == 0, (
            f"The Perl script at {script_path} no longer contains 'use Switch'. "
            "The script must not be modified to remove the Switch dependency. "
            "Install the Switch.pm module instead of modifying the script."
        )

    def test_perl_script_runs_without_switch_error(self):
        """Verify running the script no longer produces the Switch.pm error."""
        script_path = "/home/user/scripts/useradd_batch.pl"
        csv_path = "/home/user/scripts/test_users.csv"

        result = subprocess.run(
            ["perl", script_path, csv_path],
            capture_output=True,
            text=True
        )

        # The script should NOT fail with "Can't locate Switch.pm" error
        assert "Can't locate Switch.pm" not in result.stderr, (
            "The 'Can't locate Switch.pm' error still occurs when running the script. "
            f"Stderr: {result.stderr}. "
            "The Switch module must be properly installed."
        )

    def test_perl_script_exits_successfully_or_non_module_error(self):
        """Verify the script exits 0 or with a non-module-related error."""
        script_path = "/home/user/scripts/useradd_batch.pl"
        csv_path = "/home/user/scripts/test_users.csv"

        result = subprocess.run(
            ["perl", script_path, csv_path],
            capture_output=True,
            text=True
        )

        # Check that any failure is NOT due to missing modules
        if result.returncode != 0:
            # Make sure it's not a module loading error
            assert "Can't locate" not in result.stderr or "Switch.pm" not in result.stderr, (
                f"Script failed due to module loading issue: {result.stderr}. "
                "All required modules must be installed."
            )
            # If there's an error, it should be runtime behavior, not module-related
            # This is acceptable per the task description

    def test_perl_script_syntax_check_passes(self):
        """Verify the Perl script passes syntax check now that Switch is available."""
        script_path = "/home/user/scripts/useradd_batch.pl"

        result = subprocess.run(
            ["perl", "-c", script_path],
            capture_output=True,
            text=True
        )

        # Should pass syntax check or at least not fail due to Switch.pm
        if result.returncode != 0:
            assert "Can't locate Switch.pm" not in result.stderr, (
                f"Perl syntax check still fails due to missing Switch.pm: {result.stderr}. "
                "The Switch module must be properly installed."
            )

    def test_perl_is_still_installed(self):
        """Verify Perl is still installed (invariant check)."""
        result = subprocess.run(
            ["perl", "--version"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "Perl is no longer installed or accessible. "
            "The system Perl installation must not be removed."
        )

    def test_perl_version_not_downgraded(self):
        """Verify Perl version is still 5.14+ (not downgraded to get Switch in core)."""
        result = subprocess.run(
            ["perl", "-e", "print $^V"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "Failed to get Perl version."

        version_str = result.stdout.strip()
        # Version string is like "v5.34.0"
        if version_str.startswith("v"):
            version_str = version_str[1:]

        parts = version_str.split(".")
        major = int(parts[0])
        minor = int(parts[1]) if len(parts) > 1 else 0

        assert major >= 5 and minor >= 14, (
            f"Perl version {version_str} appears to have been downgraded. "
            "The system Perl installation must not be downgraded. "
            "Install the Switch module separately instead."
        )

    def test_test_csv_still_exists(self):
        """Verify the test CSV file still exists."""
        csv_path = "/home/user/scripts/test_users.csv"
        assert os.path.isfile(csv_path), (
            f"Test CSV file not found at {csv_path}. "
            "The test_users.csv file should not have been removed."
        )

    def test_scripts_directory_still_exists(self):
        """Verify the scripts directory still exists."""
        scripts_dir = "/home/user/scripts"
        assert os.path.isdir(scripts_dir), (
            f"Scripts directory not found at {scripts_dir}. "
            "The /home/user/scripts directory should not have been removed."
        )

    def test_switch_module_can_be_loaded_and_used(self):
        """Verify Switch module can actually be loaded and basic functionality works."""
        # Test that Switch module works with a simple switch statement
        test_code = '''
use Switch;
my $val = 1;
switch ($val) {
    case 1 { print "one"; }
    else { print "other"; }
}
'''
        result = subprocess.run(
            ["perl", "-e", test_code],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"Switch module is installed but not functional. "
            f"Error: {result.stderr}. "
            "The Switch module must work correctly."
        )
        assert "one" in result.stdout, (
            f"Switch module did not produce expected output. "
            f"Got: {result.stdout}. "
            "The Switch module must be fully functional."
        )
