# test_final_state.py
"""
Tests to validate the final state after the student has fixed the metricsd bug.
Both metricsd and aggregator should stay running for at least 120 seconds,
and aggregator should successfully fetch metrics at least 20 times.
"""

import os
import subprocess
import time
import signal
import re
import pytest


class TestAntiShortcutGuards:
    """Verify the fix is legitimate and not a workaround."""

    def test_no_restart_loop_in_run_stack(self):
        """Verify run_stack.sh doesn't have a restart/respawn loop."""
        path = "/home/user/collector/run_stack.sh"
        result = subprocess.run(
            ["grep", "-E", "while.*true|restart|respawn", path],
            capture_output=True,
            text=True
        )
        # grep returns 1 if no match found, which is what we want
        assert result.returncode == 1, \
            f"run_stack.sh must not have restart/respawn logic. Found: {result.stdout}"

    def test_metricsd_is_still_elf_binary(self):
        """Verify metricsd is still a compiled ELF binary (not replaced with script)."""
        path = "/home/user/collector/metricsd"
        assert os.path.isfile(path), f"Binary {path} does not exist"
        result = subprocess.run(["file", path], capture_output=True, text=True)
        assert result.returncode == 0, f"Could not run file command on {path}"
        assert "ELF" in result.stdout, \
            f"metricsd must still be an ELF binary, got: {result.stdout}"

    def test_metricsd_source_still_has_fork(self):
        """Verify metricsd.c still uses fork() for handling connections."""
        path = "/home/user/collector/metricsd.c"
        assert os.path.isfile(path), f"Source file {path} does not exist"
        with open(path, "r") as f:
            content = f.read()
        assert "fork" in content, \
            "metricsd.c must still use fork() to handle connections (not single-threaded)"

    def test_aggregator_fetch_interval_not_slowed(self):
        """Verify aggregator still fetches approximately every 5 seconds."""
        path = "/home/user/collector/aggregator"
        assert os.path.isfile(path), f"Aggregator script {path} does not exist"
        with open(path, "r") as f:
            content = f.read()

        # Look for sleep/time.sleep patterns and ensure they're not significantly increased
        # The original interval is ~5 seconds
        sleep_patterns = re.findall(r'sleep\s*\(\s*(\d+)', content)
        time_sleep_patterns = re.findall(r'time\.sleep\s*\(\s*(\d+)', content)

        all_sleeps = sleep_patterns + time_sleep_patterns
        for sleep_val in all_sleeps:
            val = int(sleep_val)
            # Allow some tolerance but not huge delays to avoid the bug
            assert val <= 10, \
                f"Aggregator sleep interval ({val}s) appears to be artificially slowed to avoid the bug"

    def test_socket_path_unchanged(self):
        """Verify the socket path is still /tmp/metricsd.sock."""
        # Check in metricsd.c
        metricsd_path = "/home/user/collector/metricsd.c"
        with open(metricsd_path, "r") as f:
            metricsd_content = f.read()
        assert "metricsd.sock" in metricsd_content, \
            "metricsd.c must still use metricsd.sock socket path"

        # Check in aggregator
        aggregator_path = "/home/user/collector/aggregator"
        with open(aggregator_path, "r") as f:
            aggregator_content = f.read()
        assert "metricsd.sock" in aggregator_content, \
            "aggregator must still connect to metricsd.sock"


class TestProcessStability:
    """Test that both processes stay running for the required duration."""

    @pytest.fixture(autouse=True)
    def cleanup_processes(self):
        """Clean up any existing metricsd/aggregator processes before and after test."""
        # Cleanup before test
        self._kill_existing_processes()
        # Remove stale socket if exists
        socket_path = "/tmp/metricsd.sock"
        if os.path.exists(socket_path):
            try:
                os.unlink(socket_path)
            except OSError:
                pass

        yield

        # Cleanup after test
        self._kill_existing_processes()

    def _kill_existing_processes(self):
        """Kill any existing metricsd or aggregator processes."""
        subprocess.run(["pkill", "-f", "metricsd"], capture_output=True)
        subprocess.run(["pkill", "-f", "aggregator"], capture_output=True)
        time.sleep(1)

    def _check_process_running(self, pattern):
        """Check if a process matching pattern is running."""
        result = subprocess.run(
            ["pgrep", "-f", pattern],
            capture_output=True,
            text=True
        )
        return result.returncode == 0

    def _get_process_pids(self, pattern):
        """Get PIDs of processes matching pattern."""
        result = subprocess.run(
            ["pgrep", "-f", pattern],
            capture_output=True,
            text=True
        )
        if result.returncode == 0:
            return [int(pid) for pid in result.stdout.strip().split('\n') if pid]
        return []

    def test_both_processes_stay_running_120_seconds(self):
        """
        Run run_stack.sh, wait 120 seconds, verify both processes are still running.
        This is the primary acceptance test.
        """
        script_path = "/home/user/collector/run_stack.sh"
        assert os.path.isfile(script_path), f"Script {script_path} does not exist"

        # Create a log file to capture aggregator output
        log_file = "/tmp/aggregator_test_output.log"

        # Start the stack, redirecting aggregator output to log file
        # We need to run this in a way that captures aggregator's stdout
        proc = subprocess.Popen(
            ["bash", "-c", f"cd /home/user/collector && ./run_stack.sh 2>&1 | tee {log_file}"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            cwd="/home/user/collector"
        )

        # Give processes time to start
        time.sleep(5)

        # Verify both processes started
        assert self._check_process_running("metricsd"), \
            "metricsd process did not start"

        # aggregator might be matched differently
        aggregator_running = (
            self._check_process_running("aggregator") or 
            self._check_process_running("python.*aggregator")
        )
        assert aggregator_running, "aggregator process did not start"

        # Record initial PIDs
        metricsd_pids_initial = self._get_process_pids("metricsd")

        # Wait for the required duration (120 seconds)
        # Check periodically to catch early failures
        check_interval = 15
        total_wait = 120
        elapsed = 5  # Already waited 5 seconds

        while elapsed < total_wait:
            time.sleep(check_interval)
            elapsed += check_interval

            # Check metricsd is still running
            if not self._check_process_running("metricsd"):
                pytest.fail(
                    f"metricsd process died after approximately {elapsed} seconds. "
                    "The bug has not been fixed - metricsd should stay running."
                )

            # Check aggregator is still running
            aggregator_running = (
                self._check_process_running("aggregator") or 
                self._check_process_running("python.*aggregator")
            )
            if not aggregator_running:
                pytest.fail(
                    f"aggregator process died after approximately {elapsed} seconds."
                )

        # Final verification after 120 seconds
        assert self._check_process_running("metricsd"), \
            "metricsd process is not running after 120 seconds - bug not fixed"

        aggregator_running = (
            self._check_process_running("aggregator") or 
            self._check_process_running("python.*aggregator")
        )
        assert aggregator_running, \
            "aggregator process is not running after 120 seconds"

        # Verify metricsd wasn't just restarted (same PID should still be there)
        # At least one of the original PIDs should still be running
        metricsd_pids_final = self._get_process_pids("metricsd")
        original_still_running = any(pid in metricsd_pids_final for pid in metricsd_pids_initial)
        assert original_still_running, \
            "metricsd appears to have been restarted (different PID). The fix must prevent exit, not restart."


class TestAggregatorFetchCount:
    """Test that aggregator successfully fetches metrics multiple times."""

    @pytest.fixture(autouse=True)
    def cleanup_processes(self):
        """Clean up any existing metricsd/aggregator processes before and after test."""
        self._kill_existing_processes()
        socket_path = "/tmp/metricsd.sock"
        if os.path.exists(socket_path):
            try:
                os.unlink(socket_path)
            except OSError:
                pass

        yield

        self._kill_existing_processes()

    def _kill_existing_processes(self):
        """Kill any existing metricsd or aggregator processes."""
        subprocess.run(["pkill", "-f", "metricsd"], capture_output=True)
        subprocess.run(["pkill", "-f", "aggregator"], capture_output=True)
        time.sleep(1)

    def test_aggregator_completes_at_least_20_fetches(self):
        """
        Verify aggregator successfully fetches at least 20 times in 120 seconds.
        With ~5 second intervals, 120 seconds should yield ~24 fetches.
        """
        log_file = "/tmp/aggregator_fetch_test.log"

        # Remove old log file if exists
        if os.path.exists(log_file):
            os.unlink(log_file)

        # Start metricsd first
        metricsd_proc = subprocess.Popen(
            ["/home/user/collector/metricsd"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            cwd="/home/user/collector"
        )
        time.sleep(2)

        # Start aggregator with output captured
        aggregator_proc = subprocess.Popen(
            ["/home/user/collector/aggregator"],
            stdout=open(log_file, "w"),
            stderr=subprocess.STDOUT,
            cwd="/home/user/collector"
        )

        # Wait 120 seconds
        time.sleep(120)

        # Check processes are still running
        assert metricsd_proc.poll() is None, \
            f"metricsd exited with code {metricsd_proc.poll()} - bug not fixed"
        assert aggregator_proc.poll() is None, \
            f"aggregator exited with code {aggregator_proc.poll()}"

        # Read and analyze the log
        with open(log_file, "r") as f:
            log_content = f.read()

        # Count fetch operations - look for common patterns
        # Aggregator likely logs something like "Fetched", "fetch", "FETCH", or similar
        fetch_patterns = [
            r'[Ff]etch',
            r'[Rr]eceived',
            r'[Gg]ot\s+(?:data|metrics|response)',
            r'[Ss]uccess',
            r'[Cc]onnect',
        ]

        fetch_count = 0
        lines = log_content.strip().split('\n') if log_content.strip() else []

        # Count non-empty lines as potential fetch logs
        # Most aggregators log something per fetch
        fetch_count = len([line for line in lines if line.strip()])

        # Also try pattern matching
        for pattern in fetch_patterns:
            matches = re.findall(pattern, log_content, re.IGNORECASE)
            if len(matches) >= 20:
                fetch_count = max(fetch_count, len(matches))
                break

        # Clean up
        metricsd_proc.terminate()
        aggregator_proc.terminate()

        assert fetch_count >= 20, \
            f"Aggregator only completed {fetch_count} fetches in 120 seconds. " \
            f"Expected at least 20. This suggests metricsd may be dying or connections failing. " \
            f"Log content sample: {log_content[:500] if log_content else '(empty)'}"


class TestMetricsdHandlesMultipleConnections:
    """Test that metricsd can handle multiple sequential connections without dying."""

    @pytest.fixture(autouse=True)
    def cleanup_processes(self):
        """Clean up processes and socket."""
        self._kill_existing_processes()
        socket_path = "/tmp/metricsd.sock"
        if os.path.exists(socket_path):
            try:
                os.unlink(socket_path)
            except OSError:
                pass

        yield

        self._kill_existing_processes()

    def _kill_existing_processes(self):
        subprocess.run(["pkill", "-f", "metricsd"], capture_output=True)
        time.sleep(1)

    def test_metricsd_survives_20_connections(self):
        """
        Directly test that metricsd survives at least 20 sequential connections.
        This verifies the core bug fix without waiting the full 120 seconds.
        """
        import socket as sock

        socket_path = "/tmp/metricsd.sock"

        # Start metricsd
        metricsd_proc = subprocess.Popen(
            ["/home/user/collector/metricsd"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            cwd="/home/user/collector"
        )

        # Wait for socket to be created
        for _ in range(10):
            if os.path.exists(socket_path):
                break
            time.sleep(0.5)

        assert os.path.exists(socket_path), "metricsd did not create socket"

        successful_connections = 0

        for i in range(25):  # Try 25 connections
            if metricsd_proc.poll() is not None:
                pytest.fail(
                    f"metricsd died after {successful_connections} connections "
                    f"(exit code: {metricsd_proc.poll()}). Bug not fixed."
                )

            try:
                client = sock.socket(sock.AF_UNIX, sock.SOCK_STREAM)
                client.settimeout(5)
                client.connect(socket_path)
                client.send(b"FETCH\n")
                # Try to receive response (may or may not get data)
                try:
                    data = client.recv(4096)
                except sock.timeout:
                    pass
                client.close()
                successful_connections += 1
                time.sleep(0.5)  # Brief pause between connections
            except Exception as e:
                # Connection might fail if metricsd died
                if metricsd_proc.poll() is not None:
                    pytest.fail(
                        f"metricsd died after {successful_connections} connections "
                        f"(exit code: {metricsd_proc.poll()}). Bug not fixed. Error: {e}"
                    )
                # Otherwise might be transient, continue
                time.sleep(0.5)

        # Final check
        assert metricsd_proc.poll() is None, \
            f"metricsd died after {successful_connections} connections. Bug not fixed."

        assert successful_connections >= 20, \
            f"Only {successful_connections} successful connections. Expected at least 20."

        # Cleanup
        metricsd_proc.terminate()


class TestFilesStillExist:
    """Verify required files still exist after fix."""

    def test_metricsd_binary_exists(self):
        """Verify metricsd binary exists."""
        path = "/home/user/collector/metricsd"
        assert os.path.isfile(path), f"Binary {path} does not exist"
        assert os.access(path, os.X_OK), f"Binary {path} is not executable"

    def test_metricsd_source_exists(self):
        """Verify metricsd.c source exists."""
        path = "/home/user/collector/metricsd.c"
        assert os.path.isfile(path), f"Source file {path} does not exist"

    def test_aggregator_exists(self):
        """Verify aggregator script exists."""
        path = "/home/user/collector/aggregator"
        assert os.path.isfile(path), f"Aggregator {path} does not exist"

    def test_run_stack_exists(self):
        """Verify run_stack.sh exists."""
        path = "/home/user/collector/run_stack.sh"
        assert os.path.isfile(path), f"Script {path} does not exist"
        assert os.access(path, os.X_OK), f"Script {path} is not executable"
