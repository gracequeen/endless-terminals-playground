# test_initial_state.py
"""
Tests to validate the initial state of the system before the student performs the debugging task.
This verifies that the buggy metricsd setup exists as described.
"""

import os
import subprocess
import stat
import pytest


class TestCollectorDirectoryStructure:
    """Test that the collector directory and files exist."""

    def test_collector_directory_exists(self):
        """Verify /home/user/collector directory exists."""
        path = "/home/user/collector"
        assert os.path.isdir(path), f"Directory {path} does not exist"

    def test_metricsd_binary_exists(self):
        """Verify metricsd binary exists and is executable."""
        path = "/home/user/collector/metricsd"
        assert os.path.isfile(path), f"Binary {path} does not exist"
        assert os.access(path, os.X_OK), f"Binary {path} is not executable"

    def test_metricsd_source_exists(self):
        """Verify metricsd.c source file exists."""
        path = "/home/user/collector/metricsd.c"
        assert os.path.isfile(path), f"Source file {path} does not exist"

    def test_aggregator_script_exists(self):
        """Verify aggregator script exists."""
        path = "/home/user/collector/aggregator"
        assert os.path.isfile(path), f"Aggregator script {path} does not exist"

    def test_run_stack_script_exists(self):
        """Verify run_stack.sh launcher script exists and is executable."""
        path = "/home/user/collector/run_stack.sh"
        assert os.path.isfile(path), f"Launcher script {path} does not exist"
        assert os.access(path, os.X_OK), f"Launcher script {path} is not executable"


class TestMetricsdSource:
    """Test that metricsd.c contains expected buggy code patterns."""

    def test_metricsd_source_has_socket_code(self):
        """Verify metricsd.c contains Unix socket code."""
        path = "/home/user/collector/metricsd.c"
        with open(path, "r") as f:
            content = f.read()
        assert "socket" in content.lower() or "AF_UNIX" in content, \
            "metricsd.c should contain socket-related code"

    def test_metricsd_source_has_fork(self):
        """Verify metricsd.c contains fork() call for handling connections."""
        path = "/home/user/collector/metricsd.c"
        with open(path, "r") as f:
            content = f.read()
        assert "fork" in content, "metricsd.c should contain fork() call"

    def test_metricsd_source_has_waitpid(self):
        """Verify metricsd.c contains waitpid() call."""
        path = "/home/user/collector/metricsd.c"
        with open(path, "r") as f:
            content = f.read()
        assert "waitpid" in content, "metricsd.c should contain waitpid() call"

    def test_metricsd_source_has_signal_handlers(self):
        """Verify metricsd.c has signal handler setup."""
        path = "/home/user/collector/metricsd.c"
        with open(path, "r") as f:
            content = f.read()
        assert "signal" in content.lower() or "SIGTERM" in content or "SIGINT" in content, \
            "metricsd.c should contain signal handling code"


class TestAggregatorScript:
    """Test that aggregator script has expected characteristics."""

    def test_aggregator_is_python_script(self):
        """Verify aggregator is a Python script."""
        path = "/home/user/collector/aggregator"
        with open(path, "r") as f:
            first_line = f.readline()
        assert "python" in first_line.lower(), \
            f"Aggregator should be a Python script, got shebang: {first_line}"

    def test_aggregator_connects_to_socket(self):
        """Verify aggregator connects to /tmp/metricsd.sock."""
        path = "/home/user/collector/aggregator"
        with open(path, "r") as f:
            content = f.read()
        assert "metricsd.sock" in content or "/tmp/" in content, \
            "Aggregator should connect to metricsd socket"

    def test_aggregator_has_fetch_command(self):
        """Verify aggregator sends FETCH command."""
        path = "/home/user/collector/aggregator"
        with open(path, "r") as f:
            content = f.read()
        assert "FETCH" in content, "Aggregator should send FETCH command"


class TestRunStackScript:
    """Test that run_stack.sh has expected characteristics."""

    def test_run_stack_starts_metricsd(self):
        """Verify run_stack.sh starts metricsd."""
        path = "/home/user/collector/run_stack.sh"
        with open(path, "r") as f:
            content = f.read()
        assert "metricsd" in content, "run_stack.sh should start metricsd"

    def test_run_stack_starts_aggregator(self):
        """Verify run_stack.sh starts aggregator."""
        path = "/home/user/collector/run_stack.sh"
        with open(path, "r") as f:
            content = f.read()
        assert "aggregator" in content, "run_stack.sh should start aggregator"

    def test_run_stack_no_restart_loop_initially(self):
        """Verify run_stack.sh doesn't already have a restart loop."""
        path = "/home/user/collector/run_stack.sh"
        result = subprocess.run(
            ["grep", "-E", "while.*true|restart|respawn", path],
            capture_output=True,
            text=True
        )
        # grep returns 1 if no match found, which is what we want
        assert result.returncode == 1, \
            f"run_stack.sh should not have restart/respawn logic initially. Found: {result.stdout}"


class TestDevelopmentTools:
    """Test that required development tools are available."""

    def test_gcc_available(self):
        """Verify gcc is available for recompiling metricsd."""
        result = subprocess.run(["which", "gcc"], capture_output=True, text=True)
        assert result.returncode == 0, "gcc must be available for recompiling metricsd.c"

    def test_python3_available(self):
        """Verify Python 3 is available."""
        result = subprocess.run(["python3", "--version"], capture_output=True, text=True)
        assert result.returncode == 0, "Python 3 must be available"
        # Check version is 3.11+
        version_str = result.stdout.strip()
        assert "Python 3" in version_str, f"Expected Python 3, got: {version_str}"


class TestDirectoryPermissions:
    """Test that /home/user/collector is writable."""

    def test_collector_directory_writable(self):
        """Verify /home/user/collector is writable."""
        path = "/home/user/collector"
        assert os.access(path, os.W_OK), f"Directory {path} must be writable"

    def test_metricsd_source_writable(self):
        """Verify metricsd.c is writable for fixing the bug."""
        path = "/home/user/collector/metricsd.c"
        assert os.access(path, os.W_OK), f"Source file {path} must be writable"


class TestMetricsdBinaryIsCompiled:
    """Test that metricsd is actually a compiled binary, not a script."""

    def test_metricsd_is_elf_binary(self):
        """Verify metricsd is an ELF binary."""
        path = "/home/user/collector/metricsd"
        result = subprocess.run(["file", path], capture_output=True, text=True)
        assert result.returncode == 0, f"Could not run file command on {path}"
        assert "ELF" in result.stdout, \
            f"metricsd should be an ELF binary, got: {result.stdout}"


class TestSocketPathAvailable:
    """Test that the socket path is available (not blocked by stale socket)."""

    def test_tmp_directory_exists(self):
        """Verify /tmp directory exists and is writable."""
        assert os.path.isdir("/tmp"), "/tmp directory must exist"
        assert os.access("/tmp", os.W_OK), "/tmp must be writable"
