I'm trying to figure out why our metrics collector keeps dying. Process is /home/user/collector/metricsd — we start it, it runs fine for maybe 30 seconds, then just vanishes. No crash log, no core dump, exit code is 0 when I catch it with wait. I added signal handlers for SIGTERM/SIGINT/SIGKILL that log to /tmp/metricsd.signal.log but they never fire, so it's not being killed externally afaict.

The weird thing is it only happens when the aggregator (/home/user/collector/aggregator) is also running. If I run metricsd alone it just sits there forever, happy as a clam. But we need both up — aggregator pulls from metricsd over a local socket.

There's a launcher script at /home/user/collector/run_stack.sh that starts both. I need both processes to stay up for at least 2 minutes without either one exiting. Right now they die within a minute every time.
