# test_final_state.py
"""
Tests to validate the final state of the OS/filesystem after the student
has fixed the cleanup script to handle permission errors gracefully.
"""

import os
import subprocess
import re
import pytest
from pathlib import Path


class TestCleanupScriptExitsSuccessfully:
    """Test that the cleanup script now exits successfully."""

    def test_cleanup_script_exits_zero(self):
        """Running the cleanup script should exit with code 0."""
        result = subprocess.run(
            ["/home/user/scripts/cleanup.sh"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            f"Expected cleanup.sh to exit 0, but got exit code {result.returncode}. " \
            f"stderr: {result.stderr}"

    def test_cleanup_script_runs_twice_successfully(self):
        """Running the cleanup script twice in a row should both exit 0."""
        # First run
        result1 = subprocess.run(
            ["/home/user/scripts/cleanup.sh"],
            capture_output=True,
            text=True
        )
        assert result1.returncode == 0, \
            f"First run of cleanup.sh failed with exit code {result1.returncode}. " \
            f"stderr: {result1.stderr}"

        # Second run (should handle empty find results)
        result2 = subprocess.run(
            ["/home/user/scripts/cleanup.sh"],
            capture_output=True,
            text=True
        )
        assert result2.returncode == 0, \
            f"Second run of cleanup.sh failed with exit code {result2.returncode}. " \
            f"stderr: {result2.stderr}"


class TestWritableDirectoriesCleanedUp:
    """Test that log files in writable directories have been deleted."""

    def test_app_logs_deleted(self):
        """All .log files in /home/user/logs/app should be deleted."""
        app_dir = Path("/home/user/logs/app")
        log_files = list(app_dir.glob("*.log"))
        assert len(log_files) == 0, \
            f"Expected no .log files in /home/user/logs/app, found: {[f.name for f in log_files]}"

    def test_metrics_logs_deleted(self):
        """All .log files in /home/user/logs/metrics should be deleted."""
        metrics_dir = Path("/home/user/logs/metrics")
        log_files = list(metrics_dir.glob("*.log"))
        assert len(log_files) == 0, \
            f"Expected no .log files in /home/user/logs/metrics, found: {[f.name for f in log_files]}"

    def test_debug_logs_deleted(self):
        """All .log files in /home/user/logs/debug should be deleted."""
        debug_dir = Path("/home/user/logs/debug")
        log_files = list(debug_dir.glob("*.log"))
        assert len(log_files) == 0, \
            f"Expected no .log files in /home/user/logs/debug, found: {[f.name for f in log_files]}"

    def test_system_logs_deleted(self):
        """All .log files directly in /home/user/logs/system should be deleted."""
        system_dir = Path("/home/user/logs/system")
        # Only check files directly in system, not in subdirs like locked/
        log_files = [f for f in system_dir.glob("*.log") if f.is_file()]
        assert len(log_files) == 0, \
            f"Expected no .log files directly in /home/user/logs/system, found: {[f.name for f in log_files]}"


class TestUnwritableFilesPreserved:
    """Test that files in unwritable directories are still present (as expected)."""

    def test_archive_logs_still_exist(self):
        """Files in /home/user/logs/archive should still exist (unwritable dir)."""
        archive_dir = Path("/home/user/logs/archive")
        log_files = list(archive_dir.glob("*.log"))
        assert len(log_files) >= 1, \
            "Expected .log files to still exist in /home/user/logs/archive " \
            "(they should not be deletable due to directory permissions)"

    def test_locked_audit_log_still_exists(self):
        """The audit.log in locked directory should still exist."""
        audit_log = Path("/home/user/logs/system/locked/audit.log")
        assert audit_log.exists(), \
            "Expected /home/user/logs/system/locked/audit.log to still exist " \
            "(it should not be deletable due to directory permissions)"


class TestScriptInvariants:
    """Test that the script still meets the required invariants."""

    def test_script_still_uses_find(self):
        """The cleanup script must still use the find command."""
        with open("/home/user/scripts/cleanup.sh", "r") as f:
            content = f.read()
        assert "find" in content, \
            "Cleanup script must still use 'find' command"

    def test_script_still_uses_xargs(self):
        """The cleanup script must still use xargs."""
        with open("/home/user/scripts/cleanup.sh", "r") as f:
            content = f.read()
        assert "xargs" in content, \
            "Cleanup script must still use 'xargs' command"

    def test_script_still_targets_logs_directory(self):
        """The cleanup script must still target /home/user/logs."""
        with open("/home/user/scripts/cleanup.sh", "r") as f:
            content = f.read()
        assert "/home/user/logs" in content, \
            "Cleanup script must still target /home/user/logs"

    def test_script_preserves_7_day_threshold(self):
        """The cleanup script must still have the 7-day threshold."""
        with open("/home/user/scripts/cleanup.sh", "r") as f:
            content = f.read()
        assert "-mtime +7" in content, \
            "Cleanup script must still have '-mtime +7' threshold"


class TestAntiShortcutGuards:
    """Test that the solution doesn't use shortcuts/hardcoded exclusions."""

    def test_no_hardcoded_archive_exclusion(self):
        """The script should NOT hardcode 'archive' directory exclusion."""
        with open("/home/user/scripts/cleanup.sh", "r") as f:
            content = f.read()
        # Check for common patterns that would hardcode archive exclusion
        has_archive_hardcode = bool(re.search(r'archive', content, re.IGNORECASE))
        assert not has_archive_hardcode, \
            "Cleanup script should not hardcode 'archive' directory exclusion. " \
            "The solution should handle errors generically."

    def test_no_hardcoded_locked_exclusion(self):
        """The script should NOT hardcode 'locked' directory exclusion."""
        with open("/home/user/scripts/cleanup.sh", "r") as f:
            content = f.read()
        # Check for common patterns that would hardcode locked exclusion
        has_locked_hardcode = bool(re.search(r'locked', content, re.IGNORECASE))
        assert not has_locked_hardcode, \
            "Cleanup script should not hardcode 'locked' directory exclusion. " \
            "The solution should handle errors generically."

    def test_grep_exclusion_check(self):
        """grep -E '(archive|locked)' should NOT match in the script."""
        result = subprocess.run(
            ["grep", "-E", "(archive|locked)", "/home/user/scripts/cleanup.sh"],
            capture_output=True,
            text=True
        )
        # grep returns 0 if match found, 1 if no match
        assert result.returncode != 0, \
            "Script contains hardcoded 'archive' or 'locked' exclusions. " \
            f"Matched lines: {result.stdout}"


class TestDirectoryStructurePreserved:
    """Test that the directory structure is preserved."""

    def test_logs_directory_exists(self):
        """The /home/user/logs directory must still exist."""
        assert os.path.isdir("/home/user/logs"), \
            "Directory /home/user/logs should still exist"

    def test_app_directory_exists(self):
        """The /home/user/logs/app directory must still exist."""
        assert os.path.isdir("/home/user/logs/app"), \
            "Directory /home/user/logs/app should still exist"

    def test_system_directory_exists(self):
        """The /home/user/logs/system directory must still exist."""
        assert os.path.isdir("/home/user/logs/system"), \
            "Directory /home/user/logs/system should still exist"

    def test_archive_directory_exists(self):
        """The /home/user/logs/archive directory must still exist."""
        assert os.path.isdir("/home/user/logs/archive"), \
            "Directory /home/user/logs/archive should still exist"

    def test_metrics_directory_exists(self):
        """The /home/user/logs/metrics directory must still exist."""
        assert os.path.isdir("/home/user/logs/metrics"), \
            "Directory /home/user/logs/metrics should still exist"

    def test_debug_directory_exists(self):
        """The /home/user/logs/debug directory must still exist."""
        assert os.path.isdir("/home/user/logs/debug"), \
            "Directory /home/user/logs/debug should still exist"

    def test_locked_directory_exists(self):
        """The /home/user/logs/system/locked directory must still exist."""
        assert os.path.isdir("/home/user/logs/system/locked"), \
            "Directory /home/user/logs/system/locked should still exist"


class TestScriptIsExecutable:
    """Test that the script is still properly executable."""

    def test_cleanup_script_exists(self):
        """The cleanup script must still exist."""
        assert os.path.isfile("/home/user/scripts/cleanup.sh"), \
            "File /home/user/scripts/cleanup.sh must exist"

    def test_cleanup_script_is_executable(self):
        """The cleanup script must still be executable."""
        assert os.access("/home/user/scripts/cleanup.sh", os.X_OK), \
            "File /home/user/scripts/cleanup.sh must be executable"

    def test_cleanup_script_has_shebang(self):
        """The cleanup script should have a proper shebang."""
        with open("/home/user/scripts/cleanup.sh", "r") as f:
            first_line = f.readline()
        assert first_line.startswith("#!") and "bash" in first_line or "sh" in first_line, \
            f"Cleanup script should have a proper shell shebang, got: {first_line}"
