Deployment pipeline on /home/user/logs keeps failing at the cleanup stage — says it can't delete certain files but doesn't tell me which ones. The cleanup script at /home/user/scripts/cleanup.sh is supposed to find logs older than 7 days and nuke them, pretty standard stuff. Worked fine for months until we migrated the log directory structure last week.

I'm guessing permissions but honestly not sure. Some of the subdirs came over from the old server with weird ownership, others were created fresh. The error log at /home/user/pipeline.log has the failures but it's not super helpful — just exit codes.

Need cleanup.sh to actually work again. Should be removing the old logs without erroring out.
