# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the cleanup script fix task.
"""

import os
import stat
import subprocess
import pytest
from pathlib import Path


class TestDirectoryStructure:
    """Test that the required directory structure exists."""

    def test_logs_directory_exists(self):
        """The /home/user/logs directory must exist."""
        assert os.path.isdir("/home/user/logs"), \
            "Directory /home/user/logs does not exist"

    def test_scripts_directory_exists(self):
        """The /home/user/scripts directory must exist."""
        assert os.path.isdir("/home/user/scripts"), \
            "Directory /home/user/scripts does not exist"

    def test_app_subdirectory_exists(self):
        """The /home/user/logs/app directory must exist."""
        assert os.path.isdir("/home/user/logs/app"), \
            "Directory /home/user/logs/app does not exist"

    def test_system_subdirectory_exists(self):
        """The /home/user/logs/system directory must exist."""
        assert os.path.isdir("/home/user/logs/system"), \
            "Directory /home/user/logs/system does not exist"

    def test_archive_subdirectory_exists(self):
        """The /home/user/logs/archive directory must exist."""
        assert os.path.isdir("/home/user/logs/archive"), \
            "Directory /home/user/logs/archive does not exist"

    def test_metrics_subdirectory_exists(self):
        """The /home/user/logs/metrics directory must exist."""
        assert os.path.isdir("/home/user/logs/metrics"), \
            "Directory /home/user/logs/metrics does not exist"

    def test_debug_subdirectory_exists(self):
        """The /home/user/logs/debug directory must exist."""
        assert os.path.isdir("/home/user/logs/debug"), \
            "Directory /home/user/logs/debug does not exist"

    def test_locked_subdirectory_exists(self):
        """The /home/user/logs/system/locked directory must exist."""
        assert os.path.isdir("/home/user/logs/system/locked"), \
            "Directory /home/user/logs/system/locked does not exist"


class TestLogFilesExist:
    """Test that log files exist in the expected directories."""

    def test_app_has_log_files(self):
        """The /home/user/logs/app directory should contain .log files."""
        app_dir = Path("/home/user/logs/app")
        log_files = list(app_dir.glob("*.log"))
        assert len(log_files) >= 1, \
            f"Expected .log files in /home/user/logs/app, found {len(log_files)}"

    def test_system_has_log_files(self):
        """The /home/user/logs/system directory should contain .log files."""
        system_dir = Path("/home/user/logs/system")
        log_files = [f for f in system_dir.glob("*.log") if f.is_file()]
        assert len(log_files) >= 1, \
            f"Expected .log files in /home/user/logs/system, found {len(log_files)}"

    def test_archive_has_log_files(self):
        """The /home/user/logs/archive directory should contain .log files."""
        archive_dir = Path("/home/user/logs/archive")
        log_files = list(archive_dir.glob("*.log"))
        assert len(log_files) >= 1, \
            f"Expected .log files in /home/user/logs/archive, found {len(log_files)}"

    def test_metrics_has_log_files(self):
        """The /home/user/logs/metrics directory should contain .log files."""
        metrics_dir = Path("/home/user/logs/metrics")
        log_files = list(metrics_dir.glob("*.log"))
        assert len(log_files) >= 1, \
            f"Expected .log files in /home/user/logs/metrics, found {len(log_files)}"

    def test_debug_has_log_files(self):
        """The /home/user/logs/debug directory should contain .log files."""
        debug_dir = Path("/home/user/logs/debug")
        log_files = list(debug_dir.glob("*.log"))
        assert len(log_files) >= 1, \
            f"Expected .log files in /home/user/logs/debug, found {len(log_files)}"

    def test_locked_has_audit_log(self):
        """The /home/user/logs/system/locked/audit.log file should exist."""
        assert os.path.isfile("/home/user/logs/system/locked/audit.log"), \
            "File /home/user/logs/system/locked/audit.log does not exist"


class TestPermissions:
    """Test that directory permissions are set correctly for the problem scenario."""

    def test_archive_directory_is_read_only(self):
        """The /home/user/logs/archive directory should be chmod 555 (read-only)."""
        archive_stat = os.stat("/home/user/logs/archive")
        mode = stat.S_IMODE(archive_stat.st_mode)
        # 555 in octal = 0o555 = 365 in decimal
        assert mode == 0o555, \
            f"Expected /home/user/logs/archive to have mode 555, got {oct(mode)}"

    def test_locked_directory_is_restricted(self):
        """The /home/user/logs/system/locked directory should be chmod 500."""
        locked_stat = os.stat("/home/user/logs/system/locked")
        mode = stat.S_IMODE(locked_stat.st_mode)
        # 500 in octal = 0o500 = 320 in decimal
        assert mode == 0o500, \
            f"Expected /home/user/logs/system/locked to have mode 500, got {oct(mode)}"

    def test_app_directory_is_writable(self):
        """The /home/user/logs/app directory should be writable."""
        assert os.access("/home/user/logs/app", os.W_OK), \
            "Directory /home/user/logs/app is not writable"

    def test_metrics_directory_is_writable(self):
        """The /home/user/logs/metrics directory should be writable."""
        assert os.access("/home/user/logs/metrics", os.W_OK), \
            "Directory /home/user/logs/metrics is not writable"

    def test_debug_directory_is_writable(self):
        """The /home/user/logs/debug directory should be writable."""
        assert os.access("/home/user/logs/debug", os.W_OK), \
            "Directory /home/user/logs/debug is not writable"

    def test_system_directory_is_writable(self):
        """The /home/user/logs/system directory should be writable."""
        assert os.access("/home/user/logs/system", os.W_OK), \
            "Directory /home/user/logs/system is not writable"

    def test_scripts_directory_is_writable(self):
        """The /home/user/scripts directory should be writable by the agent."""
        assert os.access("/home/user/scripts", os.W_OK), \
            "Directory /home/user/scripts is not writable"


class TestCleanupScript:
    """Test that the cleanup script exists and has the expected content."""

    def test_cleanup_script_exists(self):
        """The /home/user/scripts/cleanup.sh script must exist."""
        assert os.path.isfile("/home/user/scripts/cleanup.sh"), \
            "File /home/user/scripts/cleanup.sh does not exist"

    def test_cleanup_script_is_executable(self):
        """The cleanup script should be executable."""
        assert os.access("/home/user/scripts/cleanup.sh", os.X_OK), \
            "File /home/user/scripts/cleanup.sh is not executable"

    def test_cleanup_script_has_set_e(self):
        """The cleanup script should contain 'set -e'."""
        with open("/home/user/scripts/cleanup.sh", "r") as f:
            content = f.read()
        assert "set -e" in content, \
            "Cleanup script does not contain 'set -e'"

    def test_cleanup_script_uses_find(self):
        """The cleanup script should use find command."""
        with open("/home/user/scripts/cleanup.sh", "r") as f:
            content = f.read()
        assert "find" in content, \
            "Cleanup script does not use 'find' command"

    def test_cleanup_script_uses_xargs(self):
        """The cleanup script should use xargs command."""
        with open("/home/user/scripts/cleanup.sh", "r") as f:
            content = f.read()
        assert "xargs" in content, \
            "Cleanup script does not use 'xargs' command"

    def test_cleanup_script_targets_logs_directory(self):
        """The cleanup script should target /home/user/logs."""
        with open("/home/user/scripts/cleanup.sh", "r") as f:
            content = f.read()
        assert "/home/user/logs" in content, \
            "Cleanup script does not target /home/user/logs"

    def test_cleanup_script_has_7_day_threshold(self):
        """The cleanup script should have -mtime +7 for 7-day threshold."""
        with open("/home/user/scripts/cleanup.sh", "r") as f:
            content = f.read()
        assert "-mtime +7" in content, \
            "Cleanup script does not have '-mtime +7' threshold"


class TestPipelineLog:
    """Test that the pipeline log exists and contains failure information."""

    def test_pipeline_log_exists(self):
        """The /home/user/pipeline.log file must exist."""
        assert os.path.isfile("/home/user/pipeline.log"), \
            "File /home/user/pipeline.log does not exist"

    def test_pipeline_log_shows_cleanup_failure(self):
        """The pipeline log should show cleanup failure."""
        with open("/home/user/pipeline.log", "r") as f:
            content = f.read()
        assert "Cleanup failed" in content or "exit code 1" in content, \
            "Pipeline log does not show cleanup failure"

    def test_pipeline_log_shows_permission_denied(self):
        """The pipeline log should show permission denied error."""
        with open("/home/user/pipeline.log", "r") as f:
            content = f.read()
        assert "Permission denied" in content, \
            "Pipeline log does not show 'Permission denied' error"


class TestCleanupScriptCurrentlyFails:
    """Test that the cleanup script currently fails (the problem state)."""

    def test_cleanup_script_fails_with_current_state(self):
        """Running the cleanup script should currently fail with exit code != 0."""
        result = subprocess.run(
            ["/home/user/scripts/cleanup.sh"],
            capture_output=True,
            text=True
        )
        assert result.returncode != 0, \
            f"Expected cleanup.sh to fail, but it exited with code {result.returncode}"
