# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the backup file restoration task.
"""

import os
import tarfile
import subprocess
import pytest


class TestBackupArchiveExists:
    """Tests for the backup archive file."""

    def test_backup_directory_exists(self):
        """Verify the backups directory exists."""
        backup_dir = "/home/user/backups"
        assert os.path.isdir(backup_dir), (
            f"Backup directory '{backup_dir}' does not exist. "
            "The backups directory must exist before attempting restoration."
        )

    def test_backup_archive_exists(self):
        """Verify the backup archive file exists."""
        archive_path = "/home/user/backups/daily_2024-01-15.tar.gz"
        assert os.path.exists(archive_path), (
            f"Backup archive '{archive_path}' does not exist. "
            "The daily backup archive must be present for restoration."
        )

    def test_backup_archive_is_file(self):
        """Verify the backup archive is a regular file."""
        archive_path = "/home/user/backups/daily_2024-01-15.tar.gz"
        assert os.path.isfile(archive_path), (
            f"'{archive_path}' exists but is not a regular file. "
            "The backup archive must be a regular file."
        )

    def test_backup_archive_is_readable(self):
        """Verify the backup archive is readable."""
        archive_path = "/home/user/backups/daily_2024-01-15.tar.gz"
        assert os.access(archive_path, os.R_OK), (
            f"Backup archive '{archive_path}' is not readable. "
            "Read permission is required to extract files from the archive."
        )


class TestArchiveContents:
    """Tests for the contents of the backup archive."""

    def test_archive_is_valid_tarball(self):
        """Verify the archive is a valid tar.gz file."""
        archive_path = "/home/user/backups/daily_2024-01-15.tar.gz"
        try:
            with tarfile.open(archive_path, "r:gz") as tar:
                # Just try to get the list of members
                tar.getnames()
        except tarfile.TarError as e:
            pytest.fail(
                f"'{archive_path}' is not a valid tar.gz archive: {e}. "
                "The backup archive must be a valid gzip-compressed tar file."
            )

    def test_archive_contains_target_file(self):
        """Verify the archive contains the q2_summary.csv file."""
        archive_path = "/home/user/backups/daily_2024-01-15.tar.gz"
        target_file = "var/data/reports/q2_summary.csv"

        with tarfile.open(archive_path, "r:gz") as tar:
            members = tar.getnames()
            assert target_file in members, (
                f"The archive does not contain '{target_file}'. "
                f"Available files in archive: {members[:10]}{'...' if len(members) > 10 else ''}. "
                "The target file must exist in the archive for restoration."
            )

    def test_target_file_content_in_archive(self):
        """Verify the q2_summary.csv file in archive has expected content."""
        archive_path = "/home/user/backups/daily_2024-01-15.tar.gz"
        target_file = "var/data/reports/q2_summary.csv"

        with tarfile.open(archive_path, "r:gz") as tar:
            member = tar.getmember(target_file)
            f = tar.extractfile(member)
            assert f is not None, (
                f"Cannot extract '{target_file}' from archive - it may be a directory or link."
            )
            content = f.read().decode('utf-8')

            # Verify header line
            assert "quarter,revenue,expenses,profit" in content, (
                f"The file '{target_file}' in the archive does not contain the expected header. "
                "The CSV file must have the correct header line."
            )

            # Verify Q2 data row
            assert "Q2,142500,98200,44300" in content, (
                f"The file '{target_file}' in the archive does not contain the expected Q2 data. "
                "The CSV file must contain the Q2 financial data row."
            )


class TestRestoredDirectory:
    """Tests for the destination directory."""

    def test_restored_directory_exists(self):
        """Verify the restored directory exists."""
        restored_dir = "/home/user/restored"
        assert os.path.exists(restored_dir), (
            f"Destination directory '{restored_dir}' does not exist. "
            "The restored directory must exist before extraction."
        )

    def test_restored_directory_is_directory(self):
        """Verify the restored path is a directory."""
        restored_dir = "/home/user/restored"
        assert os.path.isdir(restored_dir), (
            f"'{restored_dir}' exists but is not a directory. "
            "The restored path must be a directory to extract files into."
        )

    def test_restored_directory_is_writable(self):
        """Verify the restored directory is writable."""
        restored_dir = "/home/user/restored"
        assert os.access(restored_dir, os.W_OK), (
            f"Directory '{restored_dir}' is not writable. "
            "Write permission is required to extract files to this directory."
        )

    def test_restored_directory_is_empty(self):
        """Verify the restored directory is currently empty."""
        restored_dir = "/home/user/restored"
        contents = os.listdir(restored_dir)
        assert len(contents) == 0, (
            f"Directory '{restored_dir}' is not empty. "
            f"Current contents: {contents}. "
            "The restored directory should be empty before the extraction task."
        )


class TestRequiredTools:
    """Tests for required command-line tools."""

    def test_tar_available(self):
        """Verify tar command is available."""
        result = subprocess.run(
            ["which", "tar"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "The 'tar' command is not available. "
            "tar must be installed to extract files from the archive."
        )

    def test_gzip_available(self):
        """Verify gzip command is available."""
        result = subprocess.run(
            ["which", "gzip"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "The 'gzip' command is not available. "
            "gzip must be installed to decompress the .tar.gz archive."
        )

    def test_tar_can_read_gzip(self):
        """Verify tar can handle gzip compression."""
        archive_path = "/home/user/backups/daily_2024-01-15.tar.gz"
        result = subprocess.run(
            ["tar", "-tzf", archive_path],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"tar cannot list contents of gzip archive: {result.stderr}. "
            "tar must be able to handle gzip-compressed archives."
        )
