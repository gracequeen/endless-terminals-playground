# test_final_state.py
"""
Tests to validate the final state of the OS/filesystem after the student
has completed the backup file restoration task.
"""

import os
import tarfile
import pytest


class TestExtractedFileExists:
    """Tests for the extracted q2_summary.csv file."""

    def test_restored_directory_still_exists(self):
        """Verify the restored directory still exists."""
        restored_dir = "/home/user/restored"
        assert os.path.isdir(restored_dir), (
            f"Destination directory '{restored_dir}' does not exist. "
            "The restored directory should still exist after extraction."
        )

    def test_q2_summary_file_exists(self):
        """Verify q2_summary.csv exists in the restored directory (with or without subdirectory structure)."""
        restored_dir = "/home/user/restored"

        # Check for file directly in restored directory
        direct_path = os.path.join(restored_dir, "q2_summary.csv")
        # Check for file with preserved directory structure
        nested_path = os.path.join(restored_dir, "var", "data", "reports", "q2_summary.csv")

        file_exists = os.path.isfile(direct_path) or os.path.isfile(nested_path)

        assert file_exists, (
            f"q2_summary.csv was not found in '{restored_dir}'. "
            f"Expected either '{direct_path}' or '{nested_path}' to exist. "
            f"Current contents of restored directory: {self._list_all_files(restored_dir)}"
        )

    def _list_all_files(self, directory):
        """Helper to list all files recursively in a directory."""
        all_files = []
        for root, dirs, files in os.walk(directory):
            for f in files:
                all_files.append(os.path.join(root, f))
        return all_files if all_files else "(empty)"

    def test_extracted_file_is_regular_file(self):
        """Verify the extracted file is a regular file."""
        restored_dir = "/home/user/restored"
        direct_path = os.path.join(restored_dir, "q2_summary.csv")
        nested_path = os.path.join(restored_dir, "var", "data", "reports", "q2_summary.csv")

        if os.path.exists(direct_path):
            file_path = direct_path
        elif os.path.exists(nested_path):
            file_path = nested_path
        else:
            pytest.fail("q2_summary.csv not found in restored directory")

        assert os.path.isfile(file_path), (
            f"'{file_path}' exists but is not a regular file."
        )

    def test_extracted_file_is_readable(self):
        """Verify the extracted file is readable."""
        restored_dir = "/home/user/restored"
        direct_path = os.path.join(restored_dir, "q2_summary.csv")
        nested_path = os.path.join(restored_dir, "var", "data", "reports", "q2_summary.csv")

        if os.path.exists(direct_path):
            file_path = direct_path
        elif os.path.exists(nested_path):
            file_path = nested_path
        else:
            pytest.fail("q2_summary.csv not found in restored directory")

        assert os.access(file_path, os.R_OK), (
            f"'{file_path}' is not readable."
        )


class TestExtractedFileContent:
    """Tests for the content of the extracted file."""

    def _get_extracted_file_path(self):
        """Helper to find the extracted file path."""
        restored_dir = "/home/user/restored"
        direct_path = os.path.join(restored_dir, "q2_summary.csv")
        nested_path = os.path.join(restored_dir, "var", "data", "reports", "q2_summary.csv")

        if os.path.isfile(direct_path):
            return direct_path
        elif os.path.isfile(nested_path):
            return nested_path
        return None

    def test_file_contains_header(self):
        """Verify the extracted file contains the expected CSV header."""
        file_path = self._get_extracted_file_path()
        assert file_path is not None, "q2_summary.csv not found in restored directory"

        with open(file_path, 'r') as f:
            content = f.read()

        assert "quarter,revenue,expenses,profit" in content, (
            f"The extracted file does not contain the expected header line. "
            f"Expected header: 'quarter,revenue,expenses,profit'. "
            f"File content: {content[:200]}"
        )

    def test_file_starts_with_header(self):
        """Verify the extracted file starts with the header line."""
        file_path = self._get_extracted_file_path()
        assert file_path is not None, "q2_summary.csv not found in restored directory"

        with open(file_path, 'r') as f:
            first_line = f.readline().strip()

        assert first_line == "quarter,revenue,expenses,profit", (
            f"The extracted file does not start with the expected header. "
            f"Expected first line: 'quarter,revenue,expenses,profit'. "
            f"Actual first line: '{first_line}'"
        )

    def test_file_contains_q2_data(self):
        """Verify the extracted file contains the Q2 data row."""
        file_path = self._get_extracted_file_path()
        assert file_path is not None, "q2_summary.csv not found in restored directory"

        with open(file_path, 'r') as f:
            content = f.read()

        # Check for Q2 data - this verifies the file came from the archive
        assert "Q2,142500" in content, (
            f"The extracted file does not contain the expected Q2 data. "
            f"Expected to find 'Q2,142500' in the file. "
            f"This verifies the file was properly extracted from the archive. "
            f"File content: {content}"
        )

    def test_file_contains_complete_q2_row(self):
        """Verify the extracted file contains the complete Q2 data row."""
        file_path = self._get_extracted_file_path()
        assert file_path is not None, "q2_summary.csv not found in restored directory"

        with open(file_path, 'r') as f:
            content = f.read()

        assert "Q2,142500,98200,44300" in content, (
            f"The extracted file does not contain the complete Q2 data row. "
            f"Expected: 'Q2,142500,98200,44300'. "
            f"File content: {content}"
        )


class TestOnlyTargetFileExtracted:
    """Tests to verify only the target file was extracted."""

    def test_only_q2_summary_extracted(self):
        """Verify only q2_summary.csv (and possibly its parent dirs) were extracted."""
        restored_dir = "/home/user/restored"

        # Collect all files in the restored directory
        all_files = []
        for root, dirs, files in os.walk(restored_dir):
            for f in files:
                rel_path = os.path.relpath(os.path.join(root, f), restored_dir)
                all_files.append(rel_path)

        # Filter out the expected file
        unexpected_files = [f for f in all_files if not f.endswith("q2_summary.csv")]

        assert len(unexpected_files) == 0, (
            f"Unexpected files found in '{restored_dir}'. "
            f"Only q2_summary.csv should be extracted. "
            f"Unexpected files: {unexpected_files}"
        )

    def test_exactly_one_file_extracted(self):
        """Verify exactly one file was extracted."""
        restored_dir = "/home/user/restored"

        # Count all files in the restored directory
        file_count = 0
        for root, dirs, files in os.walk(restored_dir):
            file_count += len(files)

        assert file_count == 1, (
            f"Expected exactly 1 file in '{restored_dir}', found {file_count}. "
            "Only q2_summary.csv should be extracted from the archive."
        )


class TestBackupArchiveIntact:
    """Tests to verify the backup archive was not modified or deleted."""

    def test_backup_archive_still_exists(self):
        """Verify the backup archive still exists."""
        archive_path = "/home/user/backups/daily_2024-01-15.tar.gz"
        assert os.path.isfile(archive_path), (
            f"Backup archive '{archive_path}' no longer exists. "
            "The archive should remain intact after extraction."
        )

    def test_backup_archive_still_readable(self):
        """Verify the backup archive is still readable."""
        archive_path = "/home/user/backups/daily_2024-01-15.tar.gz"
        assert os.access(archive_path, os.R_OK), (
            f"Backup archive '{archive_path}' is no longer readable."
        )

    def test_backup_archive_still_valid(self):
        """Verify the backup archive is still a valid tar.gz file."""
        archive_path = "/home/user/backups/daily_2024-01-15.tar.gz"
        try:
            with tarfile.open(archive_path, "r:gz") as tar:
                members = tar.getnames()
                assert "var/data/reports/q2_summary.csv" in members, (
                    "The archive no longer contains the expected file structure."
                )
        except tarfile.TarError as e:
            pytest.fail(
                f"Backup archive is no longer valid: {e}. "
                "The archive should remain intact after extraction."
            )
