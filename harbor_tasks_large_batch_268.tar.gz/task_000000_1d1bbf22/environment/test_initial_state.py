# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the CSV to JSON conversion task.
"""

import os
import subprocess
import pytest


class TestInitialState:
    """Tests to verify the initial state before the task is performed."""

    def test_inventory_directory_exists(self):
        """Verify that /home/user/inventory/ directory exists."""
        inventory_dir = "/home/user/inventory"
        assert os.path.isdir(inventory_dir), (
            f"Directory {inventory_dir} does not exist. "
            "The inventory directory must exist before starting the task."
        )

    def test_inventory_directory_is_writable(self):
        """Verify that /home/user/inventory/ directory is writable."""
        inventory_dir = "/home/user/inventory"
        assert os.access(inventory_dir, os.W_OK), (
            f"Directory {inventory_dir} is not writable. "
            "The inventory directory must be writable to create the output file."
        )

    def test_servers_csv_exists(self):
        """Verify that /home/user/inventory/servers.csv exists."""
        csv_path = "/home/user/inventory/servers.csv"
        assert os.path.isfile(csv_path), (
            f"File {csv_path} does not exist. "
            "The source CSV file must exist before starting the task."
        )

    def test_servers_csv_is_readable(self):
        """Verify that /home/user/inventory/servers.csv is readable."""
        csv_path = "/home/user/inventory/servers.csv"
        assert os.access(csv_path, os.R_OK), (
            f"File {csv_path} is not readable. "
            "The source CSV file must be readable to perform the conversion."
        )

    def test_servers_csv_has_correct_header(self):
        """Verify that servers.csv has the correct header line."""
        csv_path = "/home/user/inventory/servers.csv"
        with open(csv_path, 'r') as f:
            header = f.readline().strip()
        expected_header = "hostname,ip,region,tier"
        assert header == expected_header, (
            f"CSV header mismatch. Expected: '{expected_header}', Got: '{header}'. "
            "The CSV file must have the correct header for conversion."
        )

    def test_servers_csv_has_correct_content(self):
        """Verify that servers.csv has the expected content."""
        csv_path = "/home/user/inventory/servers.csv"
        expected_content = """hostname,ip,region,tier
web-prod-01,10.0.1.12,us-east-1,production
web-prod-02,10.0.1.13,us-east-1,production
api-staging-01,10.0.2.50,us-west-2,staging
db-prod-01,10.0.1.100,us-east-1,production
cache-01,10.0.3.22,eu-west-1,production
"""
        with open(csv_path, 'r') as f:
            actual_content = f.read()

        # Normalize line endings and trailing whitespace
        expected_lines = [line.strip() for line in expected_content.strip().split('\n')]
        actual_lines = [line.strip() for line in actual_content.strip().split('\n')]

        assert actual_lines == expected_lines, (
            f"CSV content mismatch.\n"
            f"Expected lines: {expected_lines}\n"
            f"Actual lines: {actual_lines}\n"
            "The CSV file must contain the expected server data."
        )

    def test_servers_csv_has_five_data_rows(self):
        """Verify that servers.csv has exactly 5 data rows (excluding header)."""
        csv_path = "/home/user/inventory/servers.csv"
        with open(csv_path, 'r') as f:
            lines = [line.strip() for line in f.readlines() if line.strip()]

        # Subtract 1 for header
        data_row_count = len(lines) - 1
        assert data_row_count == 5, (
            f"Expected 5 data rows in CSV, but found {data_row_count}. "
            "The CSV file must contain exactly 5 server entries."
        )

    def test_servers_json_does_not_exist(self):
        """Verify that /home/user/inventory/servers.json does NOT exist yet."""
        json_path = "/home/user/inventory/servers.json"
        assert not os.path.exists(json_path), (
            f"File {json_path} already exists. "
            "The output JSON file should not exist before the task is performed."
        )

    def test_python3_available(self):
        """Verify that Python 3.x is available."""
        result = subprocess.run(
            ["python3", "--version"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "Python 3 is not available. "
            "Python 3.x must be installed to perform the conversion."
        )
        assert "Python 3" in result.stdout or "Python 3" in result.stderr, (
            f"Expected Python 3.x, but got: {result.stdout} {result.stderr}"
        )

    def test_python_csv_module_available(self):
        """Verify that Python csv module is available."""
        result = subprocess.run(
            ["python3", "-c", "import csv"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "Python csv module is not available. "
            "The csv module is required for the conversion task."
        )

    def test_python_json_module_available(self):
        """Verify that Python json module is available."""
        result = subprocess.run(
            ["python3", "-c", "import json"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "Python json module is not available. "
            "The json module is required for the conversion task."
        )

    def test_jq_available(self):
        """Verify that jq is installed."""
        result = subprocess.run(
            ["which", "jq"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "jq is not installed. "
            "jq should be available as an alternative tool for JSON processing."
        )


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
