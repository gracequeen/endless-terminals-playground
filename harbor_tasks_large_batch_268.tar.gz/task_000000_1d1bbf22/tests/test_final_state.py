# test_final_state.py
"""
Tests to validate the final state of the OS/filesystem after the student
has completed the CSV to JSON conversion task.
"""

import json
import os
import subprocess
import pytest


class TestFinalState:
    """Tests to verify the final state after the task is performed."""

    JSON_PATH = "/home/user/inventory/servers.json"
    CSV_PATH = "/home/user/inventory/servers.csv"

    EXPECTED_KEYS = {"hostname", "ip", "region", "tier"}
    EXPECTED_DATA = [
        {"hostname": "web-prod-01", "ip": "10.0.1.12", "region": "us-east-1", "tier": "production"},
        {"hostname": "web-prod-02", "ip": "10.0.1.13", "region": "us-east-1", "tier": "production"},
        {"hostname": "api-staging-01", "ip": "10.0.2.50", "region": "us-west-2", "tier": "staging"},
        {"hostname": "db-prod-01", "ip": "10.0.1.100", "region": "us-east-1", "tier": "production"},
        {"hostname": "cache-01", "ip": "10.0.3.22", "region": "eu-west-1", "tier": "production"},
    ]

    def test_json_file_exists(self):
        """Verify that /home/user/inventory/servers.json exists."""
        assert os.path.isfile(self.JSON_PATH), (
            f"File {self.JSON_PATH} does not exist. "
            "The JSON output file must be created by the conversion task."
        )

    def test_json_file_is_readable(self):
        """Verify that /home/user/inventory/servers.json is readable."""
        assert os.access(self.JSON_PATH, os.R_OK), (
            f"File {self.JSON_PATH} is not readable. "
            "The JSON output file must be readable."
        )

    def test_json_is_valid(self):
        """Verify that the JSON file contains valid JSON."""
        try:
            with open(self.JSON_PATH, 'r') as f:
                json.load(f)
        except json.JSONDecodeError as e:
            pytest.fail(
                f"File {self.JSON_PATH} contains invalid JSON: {e}. "
                "The output must be valid, parseable JSON."
            )

    def test_json_is_array(self):
        """Verify that the JSON is an array (list)."""
        with open(self.JSON_PATH, 'r') as f:
            data = json.load(f)
        assert isinstance(data, list), (
            f"JSON root element is not an array. Got type: {type(data).__name__}. "
            "The JSON must be an array of objects."
        )

    def test_json_has_five_objects(self):
        """Verify that the JSON array contains exactly 5 objects."""
        with open(self.JSON_PATH, 'r') as f:
            data = json.load(f)
        assert len(data) == 5, (
            f"Expected 5 objects in JSON array, but found {len(data)}. "
            "The JSON must contain one object per CSV data row."
        )

    def test_all_elements_are_objects(self):
        """Verify that all elements in the JSON array are objects (dicts)."""
        with open(self.JSON_PATH, 'r') as f:
            data = json.load(f)
        for i, item in enumerate(data):
            assert isinstance(item, dict), (
                f"Element at index {i} is not an object. Got type: {type(item).__name__}. "
                "Each element in the JSON array must be an object."
            )

    def test_all_objects_have_correct_keys(self):
        """Verify that each object has exactly the keys: hostname, ip, region, tier."""
        with open(self.JSON_PATH, 'r') as f:
            data = json.load(f)
        for i, item in enumerate(data):
            actual_keys = set(item.keys())
            assert actual_keys == self.EXPECTED_KEYS, (
                f"Object at index {i} has incorrect keys. "
                f"Expected: {self.EXPECTED_KEYS}, Got: {actual_keys}. "
                "Each object must have exactly the keys from the CSV header."
            )

    def test_json_data_matches_expected(self):
        """Verify that the JSON data matches the expected values from CSV."""
        with open(self.JSON_PATH, 'r') as f:
            data = json.load(f)

        for i, (actual, expected) in enumerate(zip(data, self.EXPECTED_DATA)):
            assert actual == expected, (
                f"Object at index {i} does not match expected data.\n"
                f"Expected: {expected}\n"
                f"Got: {actual}\n"
                "The JSON data must match the CSV data exactly."
            )

    def test_json_parseable_via_python_command(self):
        """Anti-shortcut guard: Verify JSON is parseable via python3 command."""
        result = subprocess.run(
            ["python3", "-c", f"import json; json.load(open('{self.JSON_PATH}'))"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"JSON file failed to parse via python3 command.\n"
            f"stderr: {result.stderr}\n"
            "The JSON must be parseable by Python's json module."
        )

    def test_json_structure_via_python_command(self):
        """Anti-shortcut guard: Verify JSON structure via python3 command."""
        check_code = (
            "import json; "
            f"d=json.load(open('{self.JSON_PATH}')); "
            "assert len(d)==5; "
            "assert all(set(r.keys())=={'hostname','ip','region','tier'} for r in d)"
        )
        result = subprocess.run(
            ["python3", "-c", check_code],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"JSON structure validation failed via python3 command.\n"
            f"stderr: {result.stderr}\n"
            "The JSON must have 5 objects, each with exactly the keys: hostname, ip, region, tier."
        )

    def test_csv_file_unchanged(self):
        """Invariant: Verify that the original CSV file remains unchanged."""
        expected_content = """hostname,ip,region,tier
web-prod-01,10.0.1.12,us-east-1,production
web-prod-02,10.0.1.13,us-east-1,production
api-staging-01,10.0.2.50,us-west-2,staging
db-prod-01,10.0.1.100,us-east-1,production
cache-01,10.0.3.22,eu-west-1,production
"""
        assert os.path.isfile(self.CSV_PATH), (
            f"CSV file {self.CSV_PATH} no longer exists. "
            "The original CSV file must remain unchanged."
        )

        with open(self.CSV_PATH, 'r') as f:
            actual_content = f.read()

        # Normalize line endings and trailing whitespace for comparison
        expected_lines = [line.strip() for line in expected_content.strip().split('\n')]
        actual_lines = [line.strip() for line in actual_content.strip().split('\n')]

        assert actual_lines == expected_lines, (
            f"CSV content has been modified.\n"
            f"Expected lines: {expected_lines}\n"
            f"Actual lines: {actual_lines}\n"
            "The original CSV file must remain unchanged."
        )

    def test_first_object_values(self):
        """Verify the first object has correct values."""
        with open(self.JSON_PATH, 'r') as f:
            data = json.load(f)

        first = data[0]
        assert first["hostname"] == "web-prod-01", f"First hostname incorrect: {first.get('hostname')}"
        assert first["ip"] == "10.0.1.12", f"First ip incorrect: {first.get('ip')}"
        assert first["region"] == "us-east-1", f"First region incorrect: {first.get('region')}"
        assert first["tier"] == "production", f"First tier incorrect: {first.get('tier')}"

    def test_staging_server_present(self):
        """Verify the staging server (api-staging-01) is present with correct data."""
        with open(self.JSON_PATH, 'r') as f:
            data = json.load(f)

        staging_servers = [obj for obj in data if obj.get("tier") == "staging"]
        assert len(staging_servers) == 1, (
            f"Expected exactly 1 staging server, found {len(staging_servers)}."
        )

        staging = staging_servers[0]
        assert staging["hostname"] == "api-staging-01", f"Staging hostname incorrect: {staging.get('hostname')}"
        assert staging["ip"] == "10.0.2.50", f"Staging ip incorrect: {staging.get('ip')}"
        assert staging["region"] == "us-west-2", f"Staging region incorrect: {staging.get('region')}"

    def test_eu_server_present(self):
        """Verify the EU server (cache-01) is present with correct data."""
        with open(self.JSON_PATH, 'r') as f:
            data = json.load(f)

        eu_servers = [obj for obj in data if obj.get("region") == "eu-west-1"]
        assert len(eu_servers) == 1, (
            f"Expected exactly 1 EU server, found {len(eu_servers)}."
        )

        eu_server = eu_servers[0]
        assert eu_server["hostname"] == "cache-01", f"EU server hostname incorrect: {eu_server.get('hostname')}"
        assert eu_server["ip"] == "10.0.3.22", f"EU server ip incorrect: {eu_server.get('ip')}"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
