# test_initial_state.py
"""
Tests to validate the initial state of the system before the student
adds /home/user/.local/bin to PATH in .bashrc
"""

import os
import subprocess
import pytest


class TestInitialState:
    """Validate the OS state before the task is performed."""

    def test_bashrc_exists(self):
        """Verify /home/user/.bashrc exists."""
        bashrc_path = "/home/user/.bashrc"
        assert os.path.exists(bashrc_path), f"{bashrc_path} does not exist"

    def test_bashrc_is_file(self):
        """Verify /home/user/.bashrc is a regular file."""
        bashrc_path = "/home/user/.bashrc"
        assert os.path.isfile(bashrc_path), f"{bashrc_path} is not a regular file"

    def test_bashrc_is_writable(self):
        """Verify /home/user/.bashrc is writable."""
        bashrc_path = "/home/user/.bashrc"
        assert os.access(bashrc_path, os.W_OK), f"{bashrc_path} is not writable"

    def test_local_bin_directory_exists(self):
        """Verify /home/user/.local/bin directory exists."""
        local_bin_path = "/home/user/.local/bin"
        assert os.path.exists(local_bin_path), f"{local_bin_path} does not exist"

    def test_local_bin_is_directory(self):
        """Verify /home/user/.local/bin is a directory."""
        local_bin_path = "/home/user/.local/bin"
        assert os.path.isdir(local_bin_path), f"{local_bin_path} is not a directory"

    def test_bash_is_default_shell(self):
        """Verify bash is the default shell for user."""
        result = subprocess.run(
            ["getent", "passwd", "user"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "Could not get passwd entry for user"
        passwd_entry = result.stdout.strip()
        shell = passwd_entry.split(":")[-1]
        assert "bash" in shell, f"Default shell is {shell}, expected bash"

    def test_path_does_not_include_local_bin_initially(self):
        """Verify PATH does not include /home/user/.local/bin when sourcing .bashrc."""
        # Run a new bash shell that sources .bashrc and check PATH
        result = subprocess.run(
            ["bash", "-c", "source /home/user/.bashrc && echo $PATH"],
            capture_output=True,
            text=True,
            env={**os.environ, "HOME": "/home/user"}
        )
        path_value = result.stdout.strip()
        # Check that .local/bin is NOT in the PATH initially
        assert "/home/user/.local/bin" not in path_value, (
            f"PATH already includes /home/user/.local/bin: {path_value}. "
            "The initial state should not have this path configured."
        )

    def test_bashrc_does_not_contain_local_bin_path_addition(self):
        """Verify .bashrc does not already contain a line adding .local/bin to PATH."""
        bashrc_path = "/home/user/.bashrc"
        result = subprocess.run(
            ["grep", "-E", r"\.local/bin", bashrc_path],
            capture_output=True,
            text=True
        )
        # grep returns 0 if match found, 1 if no match
        assert result.returncode != 0, (
            f".bashrc already contains a line with .local/bin: {result.stdout.strip()}. "
            "The initial state should not have this configured."
        )

    def test_bashrc_has_content(self):
        """Verify .bashrc has some content (not empty)."""
        bashrc_path = "/home/user/.bashrc"
        with open(bashrc_path, "r") as f:
            content = f.read()
        assert len(content) > 0, f"{bashrc_path} is empty"

    def test_bashrc_has_no_syntax_errors(self):
        """Verify .bashrc has no syntax errors."""
        result = subprocess.run(
            ["bash", "-n", "/home/user/.bashrc"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f".bashrc has syntax errors: {result.stderr}"
        )

    def test_bash_executable_exists(self):
        """Verify bash is available."""
        result = subprocess.run(
            ["which", "bash"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "bash executable not found"
