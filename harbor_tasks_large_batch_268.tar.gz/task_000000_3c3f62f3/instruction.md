Need to add /home/user/.local/bin to my PATH in bashrc — got some CLI tools landing there from pip installs and they're not being picked up. Should be permanent, not just for the current session.
