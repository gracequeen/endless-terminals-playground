# test_final_state.py
"""
Tests to validate the final state of the system after the student
has added /home/user/.local/bin to PATH in .bashrc
"""

import os
import subprocess
import pytest


class TestFinalState:
    """Validate the OS state after the task is completed."""

    def test_bashrc_exists(self):
        """Verify /home/user/.bashrc still exists."""
        bashrc_path = "/home/user/.bashrc"
        assert os.path.exists(bashrc_path), f"{bashrc_path} does not exist"

    def test_bashrc_is_file(self):
        """Verify /home/user/.bashrc is still a regular file."""
        bashrc_path = "/home/user/.bashrc"
        assert os.path.isfile(bashrc_path), f"{bashrc_path} is not a regular file"

    def test_bashrc_contains_local_bin_path_addition(self):
        """Verify .bashrc contains a line that adds .local/bin to PATH."""
        bashrc_path = "/home/user/.bashrc"
        result = subprocess.run(
            ["grep", "-E", r"\.local/bin", bashrc_path],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f".bashrc does not contain a line with .local/bin. "
            "The PATH addition must be in the file, not just exported ephemerally."
        )

    def test_bashrc_has_no_syntax_errors(self):
        """Verify .bashrc has no syntax errors after modification."""
        result = subprocess.run(
            ["bash", "-n", "/home/user/.bashrc"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f".bashrc has syntax errors after modification: {result.stderr}"
        )

    def test_path_includes_local_bin_after_sourcing_bashrc(self):
        """Verify PATH includes /home/user/.local/bin when sourcing .bashrc."""
        result = subprocess.run(
            ["bash", "-c", "source /home/user/.bashrc && echo $PATH"],
            capture_output=True,
            text=True,
            env={**os.environ, "HOME": "/home/user"}
        )
        path_value = result.stdout.strip()
        assert "/home/user/.local/bin" in path_value, (
            f"PATH does not include /home/user/.local/bin after sourcing .bashrc. "
            f"Current PATH: {path_value}"
        )

    def test_path_includes_local_bin_in_login_shell(self):
        """Verify PATH includes /home/user/.local/bin in a login shell."""
        result = subprocess.run(
            ["bash", "-l", "-c", "echo $PATH"],
            capture_output=True,
            text=True,
            env={**os.environ, "HOME": "/home/user"}
        )
        path_value = result.stdout.strip()
        assert "/home/user/.local/bin" in path_value, (
            f"PATH does not include /home/user/.local/bin in login shell. "
            f"Current PATH: {path_value}"
        )

    def test_bashrc_preserves_existing_content(self):
        """Verify .bashrc still has reasonable content (not truncated)."""
        bashrc_path = "/home/user/.bashrc"
        with open(bashrc_path, "r") as f:
            content = f.read()

        # Check that the file has substantial content (not just the PATH line)
        assert len(content) > 50, (
            f".bashrc appears to have been truncated or replaced. "
            f"Content length: {len(content)} bytes. "
            "Existing content should be preserved."
        )

    def test_bashrc_has_multiple_lines(self):
        """Verify .bashrc has multiple lines (not replaced with single line)."""
        bashrc_path = "/home/user/.bashrc"
        with open(bashrc_path, "r") as f:
            lines = f.readlines()

        # A standard Ubuntu bashrc has many lines; should have more than just the PATH addition
        assert len(lines) > 5, (
            f".bashrc has only {len(lines)} lines. "
            "The file appears to have been truncated. "
            "Existing content should be preserved."
        )

    def test_local_bin_directory_still_exists(self):
        """Verify /home/user/.local/bin directory still exists."""
        local_bin_path = "/home/user/.local/bin"
        assert os.path.exists(local_bin_path), f"{local_bin_path} does not exist"
        assert os.path.isdir(local_bin_path), f"{local_bin_path} is not a directory"

    def test_path_addition_is_valid_export_or_assignment(self):
        """Verify the PATH addition in .bashrc is a valid export or PATH assignment."""
        bashrc_path = "/home/user/.bashrc"
        with open(bashrc_path, "r") as f:
            content = f.read()

        # Check for common valid patterns for adding to PATH
        valid_patterns = [
            "export PATH",
            "PATH=",
            "PATH+=",
        ]

        # Find lines containing .local/bin
        lines_with_local_bin = [
            line for line in content.split('\n') 
            if '.local/bin' in line and not line.strip().startswith('#')
        ]

        assert len(lines_with_local_bin) > 0, (
            "No uncommented line containing .local/bin found in .bashrc"
        )

        # At least one line should have a valid PATH modification pattern
        has_valid_pattern = False
        for line in lines_with_local_bin:
            for pattern in valid_patterns:
                if pattern in line:
                    has_valid_pattern = True
                    break
            if has_valid_pattern:
                break

        assert has_valid_pattern, (
            f"Found .local/bin in .bashrc but not in a valid PATH modification. "
            f"Lines found: {lines_with_local_bin}"
        )
