# test_final_state.py
"""
Tests to validate the final state after the student has converted the Python 2 script to Python 3.
"""

import os
import subprocess
import re
import pytest


class TestFinalState:
    """Tests to verify the final state after the Python 2 to 3 conversion task is completed."""

    def test_parse_config_file_still_exists(self):
        """Verify that parse_config.py still exists at the expected location."""
        file_path = "/home/user/docs/examples/parse_config.py"
        assert os.path.isfile(file_path), (
            f"File {file_path} does not exist. "
            "The script must remain at its original location."
        )

    def test_script_runs_successfully_with_python3(self):
        """Verify that python3 parse_config.py exits with code 0."""
        file_path = "/home/user/docs/examples/parse_config.py"
        result = subprocess.run(
            ["python3", file_path],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"Script {file_path} failed to run with Python 3. "
            f"Exit code: {result.returncode}\n"
            f"Stderr: {result.stderr}\n"
            f"Stdout: {result.stdout}"
        )

    def test_output_contains_configuration_settings_header(self):
        """Verify that output contains 'Configuration settings:' on its own line."""
        file_path = "/home/user/docs/examples/parse_config.py"
        result = subprocess.run(
            ["python3", file_path],
            capture_output=True,
            text=True
        )
        output_lines = result.stdout.strip().split('\n')
        # Check that "Configuration settings:" appears as its own line (possibly with whitespace)
        found = any(line.strip() == "Configuration settings:" for line in output_lines)
        assert found, (
            f"Output must contain 'Configuration settings:' on its own line.\n"
            f"Actual output:\n{result.stdout}"
        )

    def test_output_contains_done_footer(self):
        """Verify that output contains 'Done.' on its own line."""
        file_path = "/home/user/docs/examples/parse_config.py"
        result = subprocess.run(
            ["python3", file_path],
            capture_output=True,
            text=True
        )
        output_lines = result.stdout.strip().split('\n')
        # Check that "Done." appears as its own line (possibly with whitespace)
        found = any(line.strip() == "Done." for line in output_lines)
        assert found, (
            f"Output must contain 'Done.' on its own line.\n"
            f"Actual output:\n{result.stdout}"
        )

    def test_output_contains_host_key_value(self):
        """Verify that output contains host=localhost in the expected format."""
        file_path = "/home/user/docs/examples/parse_config.py"
        result = subprocess.run(
            ["python3", file_path],
            capture_output=True,
            text=True
        )
        # Looking for "  host = localhost" format (two leading spaces)
        pattern = r'^\s{2}host\s*=\s*localhost\s*$'
        found = any(re.match(pattern, line) for line in result.stdout.split('\n'))
        assert found, (
            f"Output must contain '  host = localhost' (with two leading spaces).\n"
            f"Actual output:\n{result.stdout}"
        )

    def test_output_contains_port_key_value(self):
        """Verify that output contains port=8080 in the expected format."""
        file_path = "/home/user/docs/examples/parse_config.py"
        result = subprocess.run(
            ["python3", file_path],
            capture_output=True,
            text=True
        )
        # Looking for "  port = 8080" format (two leading spaces)
        pattern = r'^\s{2}port\s*=\s*8080\s*$'
        found = any(re.match(pattern, line) for line in result.stdout.split('\n'))
        assert found, (
            f"Output must contain '  port = 8080' (with two leading spaces).\n"
            f"Actual output:\n{result.stdout}"
        )

    def test_output_contains_debug_key_value(self):
        """Verify that output contains debug=true in the expected format."""
        file_path = "/home/user/docs/examples/parse_config.py"
        result = subprocess.run(
            ["python3", file_path],
            capture_output=True,
            text=True
        )
        # Looking for "  debug = true" format (two leading spaces)
        pattern = r'^\s{2}debug\s*=\s*true\s*$'
        found = any(re.match(pattern, line) for line in result.stdout.split('\n'))
        assert found, (
            f"Output must contain '  debug = true' (with two leading spaces).\n"
            f"Actual output:\n{result.stdout}"
        )

    def test_output_contains_timeout_key_value(self):
        """Verify that output contains timeout=30 in the expected format."""
        file_path = "/home/user/docs/examples/parse_config.py"
        result = subprocess.run(
            ["python3", file_path],
            capture_output=True,
            text=True
        )
        # Looking for "  timeout = 30" format (two leading spaces)
        pattern = r'^\s{2}timeout\s*=\s*30\s*$'
        found = any(re.match(pattern, line) for line in result.stdout.split('\n'))
        assert found, (
            f"Output must contain '  timeout = 30' (with two leading spaces).\n"
            f"Actual output:\n{result.stdout}"
        )

    def test_no_remaining_iteritems_syntax(self):
        """Verify that no Python 2 iteritems() calls remain in the code."""
        file_path = "/home/user/docs/examples/parse_config.py"
        result = subprocess.run(
            ["grep", "-E", "iteritems", file_path],
            capture_output=True,
            text=True
        )
        # grep returns 0 if found, 1 if not found
        assert result.returncode != 0, (
            f"File {file_path} still contains 'iteritems' (Python 2 syntax).\n"
            f"Found: {result.stdout}\n"
            "Please replace .iteritems() with .items()"
        )

    def test_no_remaining_python2_print_statements(self):
        """Verify that no Python 2 style print statements remain in the code."""
        file_path = "/home/user/docs/examples/parse_config.py"
        # Check for 'print ' followed by something that's not '(' - Python 2 print statement
        result = subprocess.run(
            ["grep", "-E", r"print [^(]", file_path],
            capture_output=True,
            text=True
        )
        # grep returns 0 if found, 1 if not found
        assert result.returncode != 0, (
            f"File {file_path} still contains Python 2 style print statements.\n"
            f"Found: {result.stdout}\n"
            "Please convert print statements to print() function calls."
        )

    def test_config_dict_still_contains_all_keys(self):
        """Verify that the config dict still contains all four expected key-value pairs."""
        file_path = "/home/user/docs/examples/parse_config.py"
        with open(file_path, 'r') as f:
            content = f.read()

        # Check that the config values are still present
        assert '"localhost"' in content or "'localhost'" in content, (
            f"File {file_path} must still contain 'localhost' value in config"
        )
        assert '"8080"' in content or "'8080'" in content, (
            f"File {file_path} must still contain '8080' value in config"
        )
        assert '"true"' in content or "'true'" in content, (
            f"File {file_path} must still contain 'true' value in config"
        )
        assert '"30"' in content or "'30'" in content, (
            f"File {file_path} must still contain '30' value in config"
        )

    def test_script_is_not_a_wrapper(self):
        """Verify that the fix is in the Python code itself, not a shell wrapper."""
        file_path = "/home/user/docs/examples/parse_config.py"
        with open(file_path, 'r') as f:
            first_line = f.readline().strip()
            content = f.read()

        # Check it's not a shell script
        assert not first_line.startswith("#!/bin/bash"), (
            f"File {file_path} appears to be a shell script wrapper. "
            "The fix must be in the Python code itself."
        )
        assert not first_line.startswith("#!/bin/sh"), (
            f"File {file_path} appears to be a shell script wrapper. "
            "The fix must be in the Python code itself."
        )

        # Check it doesn't call 2to3 at runtime
        full_content = first_line + content
        assert "2to3" not in full_content, (
            f"File {file_path} appears to use 2to3 at runtime. "
            "The fix must be in the Python code itself."
        )

    def test_output_has_correct_structure(self):
        """Verify the overall output structure: header, key-values, footer."""
        file_path = "/home/user/docs/examples/parse_config.py"
        result = subprocess.run(
            ["python3", file_path],
            capture_output=True,
            text=True
        )

        lines = [line for line in result.stdout.split('\n') if line.strip()]

        # Should have at least 6 lines: header + 4 key-values + footer
        assert len(lines) >= 6, (
            f"Expected at least 6 non-empty lines in output "
            f"(header + 4 key-values + footer), got {len(lines)}.\n"
            f"Output:\n{result.stdout}"
        )

        # First line should be the header
        assert lines[0].strip() == "Configuration settings:", (
            f"First line should be 'Configuration settings:', got '{lines[0]}'"
        )

        # Last line should be the footer
        assert lines[-1].strip() == "Done.", (
            f"Last line should be 'Done.', got '{lines[-1]}'"
        )
