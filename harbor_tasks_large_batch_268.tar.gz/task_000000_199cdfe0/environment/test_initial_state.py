# test_initial_state.py
"""
Tests to validate the initial state before the student performs the Python 2 to 3 conversion task.
"""

import os
import subprocess
import pytest


class TestInitialState:
    """Tests to verify the initial state of the system before the task is performed."""

    def test_examples_directory_exists(self):
        """Verify that /home/user/docs/examples/ directory exists."""
        dir_path = "/home/user/docs/examples"
        assert os.path.isdir(dir_path), f"Directory {dir_path} does not exist"

    def test_examples_directory_is_writable(self):
        """Verify that /home/user/docs/examples/ is writable."""
        dir_path = "/home/user/docs/examples"
        assert os.access(dir_path, os.W_OK), f"Directory {dir_path} is not writable"

    def test_parse_config_file_exists(self):
        """Verify that parse_config.py exists at the expected location."""
        file_path = "/home/user/docs/examples/parse_config.py"
        assert os.path.isfile(file_path), f"File {file_path} does not exist"

    def test_parse_config_file_is_readable(self):
        """Verify that parse_config.py is readable."""
        file_path = "/home/user/docs/examples/parse_config.py"
        assert os.access(file_path, os.R_OK), f"File {file_path} is not readable"

    def test_parse_config_file_is_writable(self):
        """Verify that parse_config.py is writable (student needs to modify it)."""
        file_path = "/home/user/docs/examples/parse_config.py"
        assert os.access(file_path, os.W_OK), f"File {file_path} is not writable"

    def test_parse_config_contains_python2_print_statements(self):
        """Verify that the file contains Python 2 style print statements."""
        file_path = "/home/user/docs/examples/parse_config.py"
        with open(file_path, 'r') as f:
            content = f.read()

        # Check for Python 2 print statements (print without parentheses)
        # Looking for patterns like 'print "' which is Python 2 syntax
        assert 'print "' in content, (
            f"File {file_path} does not contain Python 2 style print statements. "
            "Expected 'print \"...' syntax."
        )

    def test_parse_config_contains_iteritems(self):
        """Verify that the file contains dict.iteritems() which is Python 2 specific."""
        file_path = "/home/user/docs/examples/parse_config.py"
        with open(file_path, 'r') as f:
            content = f.read()

        assert 'iteritems()' in content, (
            f"File {file_path} does not contain 'iteritems()' call. "
            "Expected Python 2 dict.iteritems() syntax."
        )

    def test_parse_config_contains_config_dict(self):
        """Verify that the file contains the expected config dictionary."""
        file_path = "/home/user/docs/examples/parse_config.py"
        with open(file_path, 'r') as f:
            content = f.read()

        # Check for the config dict with expected keys
        assert 'config = {' in content or 'config={' in content, (
            f"File {file_path} does not contain 'config' dictionary definition"
        )
        assert '"host"' in content, f"File {file_path} missing 'host' key in config"
        assert '"port"' in content, f"File {file_path} missing 'port' key in config"
        assert '"debug"' in content, f"File {file_path} missing 'debug' key in config"
        assert '"timeout"' in content, f"File {file_path} missing 'timeout' key in config"

    def test_python3_is_available(self):
        """Verify that Python 3 is installed and available."""
        result = subprocess.run(
            ["python3", "--version"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "Python 3 is not available on this system"
        assert "Python 3" in result.stdout, f"Expected Python 3, got: {result.stdout}"

    def test_python3_version_is_3_10_or_higher(self):
        """Verify that Python 3.10+ is installed."""
        result = subprocess.run(
            ["python3", "-c", "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "Failed to get Python version"
        version = result.stdout.strip()
        major, minor = map(int, version.split('.'))
        assert major == 3 and minor >= 10, f"Expected Python 3.10+, got Python {version}"

    def test_python2_is_not_available(self):
        """Verify that Python 2 is NOT available on the system."""
        result = subprocess.run(
            ["which", "python2"],
            capture_output=True,
            text=True
        )
        # which returns non-zero if command not found
        assert result.returncode != 0, (
            "Python 2 should NOT be available on this system, but 'python2' was found"
        )

    def test_parse_config_fails_with_python3(self):
        """Verify that running the script with Python 3 currently fails with SyntaxError."""
        file_path = "/home/user/docs/examples/parse_config.py"
        result = subprocess.run(
            ["python3", file_path],
            capture_output=True,
            text=True
        )
        assert result.returncode != 0, (
            f"Expected {file_path} to fail with Python 3, but it succeeded. "
            "The file may have already been converted."
        )
        # Check that it's a syntax error (from Python 2 print statements)
        assert "SyntaxError" in result.stderr, (
            f"Expected SyntaxError when running {file_path} with Python 3, "
            f"but got different error: {result.stderr}"
        )

    def test_parse_config_has_expected_content_structure(self):
        """Verify the file has the expected structure with header, config, and print statements."""
        file_path = "/home/user/docs/examples/parse_config.py"
        with open(file_path, 'r') as f:
            content = f.read()

        # Check for shebang
        assert content.startswith("#!/usr/bin/env python"), (
            f"File {file_path} should start with '#!/usr/bin/env python' shebang"
        )

        # Check for expected string literals
        assert '"Configuration settings:"' in content or "'Configuration settings:'" in content, (
            f"File {file_path} should contain 'Configuration settings:' string"
        )
        assert '"Done."' in content or "'Done.'" in content, (
            f"File {file_path} should contain 'Done.' string"
        )
