# test_initial_state.py
"""
Tests to validate the initial state before the student performs the optimization task.
Verifies that the buggy log parser exists with its problematic string-based counting approach,
and that the large log file exists for testing.
"""

import os
import subprocess
import pytest
import re


class TestInitialFileStructure:
    """Test that required files and directories exist."""

    def test_logparse_directory_exists(self):
        """Verify /home/user/logparse directory exists."""
        path = "/home/user/logparse"
        assert os.path.isdir(path), f"Directory {path} does not exist"

    def test_analyze_script_exists(self):
        """Verify analyze.py script exists."""
        path = "/home/user/logparse/analyze.py"
        assert os.path.isfile(path), f"Script {path} does not exist"

    def test_data_directory_exists(self):
        """Verify data directory exists."""
        path = "/home/user/logparse/data"
        assert os.path.isdir(path), f"Directory {path} does not exist"

    def test_access_log_exists(self):
        """Verify access.log file exists."""
        path = "/home/user/logparse/data/access.log"
        assert os.path.isfile(path), f"Log file {path} does not exist"


class TestAccessLogFile:
    """Test that the access log file has expected characteristics."""

    def test_access_log_has_approximately_800k_lines(self):
        """Verify access.log has approximately 800,000 lines."""
        path = "/home/user/logparse/data/access.log"
        result = subprocess.run(
            ["wc", "-l", path],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, f"Failed to count lines in {path}"
        line_count = int(result.stdout.split()[0])
        # Allow some tolerance: 750k to 850k lines
        assert 750000 <= line_count <= 850000, \
            f"Expected ~800,000 lines, got {line_count}"

    def test_access_log_file_size(self):
        """Verify access.log is approximately 120MB."""
        path = "/home/user/logparse/data/access.log"
        size_bytes = os.path.getsize(path)
        size_mb = size_bytes / (1024 * 1024)
        # Allow tolerance: 80MB to 160MB
        assert 80 <= size_mb <= 160, \
            f"Expected ~120MB file, got {size_mb:.1f}MB"

    def test_access_log_is_nginx_format(self):
        """Verify access.log contains nginx combined log format entries."""
        path = "/home/user/logparse/data/access.log"
        # Check first few lines for nginx log format patterns
        nginx_pattern = re.compile(
            r'^\d+\.\d+\.\d+\.\d+.*"(GET|POST|PUT|DELETE|PATCH|HEAD|OPTIONS) .* HTTP'
        )
        with open(path, 'r') as f:
            sample_lines = [f.readline() for _ in range(10)]

        matching_lines = sum(1 for line in sample_lines if nginx_pattern.search(line))
        assert matching_lines >= 8, \
            f"Expected nginx combined log format, only {matching_lines}/10 sample lines match pattern"


class TestAnalyzeScript:
    """Test that analyze.py has the expected buggy implementation."""

    def test_script_is_readable(self):
        """Verify analyze.py can be read."""
        path = "/home/user/logparse/analyze.py"
        with open(path, 'r') as f:
            content = f.read()
        assert len(content) > 0, f"Script {path} is empty"

    def test_script_is_executable_with_python3(self):
        """Verify analyze.py can be executed with python3 (syntax check)."""
        path = "/home/user/logparse/analyze.py"
        result = subprocess.run(
            ["python3", "-m", "py_compile", path],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            f"Script has syntax errors: {result.stderr}"

    def test_script_has_string_based_counting_bug(self):
        """Verify the script uses the buggy string-based counting approach."""
        path = "/home/user/logparse/analyze.py"
        with open(path, 'r') as f:
            content = f.read()

        # Check for the characteristic buggy patterns:
        # 1. counts initialized as empty string
        assert 'counts = ""' in content or "counts = ''" in content, \
            "Expected counts to be initialized as empty string (the bug)"

        # 2. String concatenation pattern for counting
        assert 'counts +=' in content or 'counts+=' in content, \
            "Expected string concatenation pattern 'counts +=' (the bug)"

        # 3. The split/rebuild pattern
        assert '.split(' in content, \
            "Expected .split() calls (part of the buggy string parsing)"

    def test_script_has_parse_log_function(self):
        """Verify the script has parse_log function."""
        path = "/home/user/logparse/analyze.py"
        with open(path, 'r') as f:
            content = f.read()
        assert 'def parse_log' in content, \
            "Expected parse_log function definition"

    def test_script_has_main_function(self):
        """Verify the script has main function."""
        path = "/home/user/logparse/analyze.py"
        with open(path, 'r') as f:
            content = f.read()
        assert 'def main' in content, \
            "Expected main function definition"

    def test_script_uses_regex_for_parsing(self):
        """Verify the script uses regex for log parsing."""
        path = "/home/user/logparse/analyze.py"
        with open(path, 'r') as f:
            content = f.read()
        assert 'import re' in content or 'from re import' in content, \
            "Expected re module import for log parsing"
        assert 're.search' in content or 're.match' in content or 're.findall' in content, \
            "Expected regex search/match/findall usage"


class TestPythonEnvironment:
    """Test Python environment requirements."""

    def test_python3_available(self):
        """Verify Python 3 is available."""
        result = subprocess.run(
            ["python3", "--version"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "python3 is not available"

    def test_python3_version_is_3_11_or_higher(self):
        """Verify Python version is 3.11+."""
        result = subprocess.run(
            ["python3", "-c", "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "Failed to get Python version"
        version = result.stdout.strip()
        major, minor = map(int, version.split('.'))
        assert (major, minor) >= (3, 11), \
            f"Expected Python 3.11+, got {version}"

    def test_collections_module_available(self):
        """Verify collections module is available."""
        result = subprocess.run(
            ["python3", "-c", "import collections; print('ok')"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "collections module not available"

    def test_re_module_available(self):
        """Verify re module is available."""
        result = subprocess.run(
            ["python3", "-c", "import re; print('ok')"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "re module not available"


class TestDirectoryPermissions:
    """Test that the logparse directory is writable for modifications."""

    def test_logparse_directory_is_writable(self):
        """Verify /home/user/logparse is writable."""
        path = "/home/user/logparse"
        assert os.access(path, os.W_OK), \
            f"Directory {path} is not writable"

    def test_analyze_script_is_writable(self):
        """Verify analyze.py is writable for modifications."""
        path = "/home/user/logparse/analyze.py"
        assert os.access(path, os.W_OK), \
            f"Script {path} is not writable"


class TestScriptProducesOutput:
    """Test that the script can run and produce output (on a small sample)."""

    def test_script_runs_on_small_input(self):
        """Verify the script can run on a small sample of the log file."""
        # Create a small test file with a few lines
        test_log_path = "/tmp/test_small_access.log"
        sample_lines = [
            '192.168.1.1 - - [01/Jan/2024:00:00:01 +0000] "GET /api/v1/users HTTP/1.1" 200 1234 "-" "Mozilla/5.0"\n',
            '192.168.1.2 - - [01/Jan/2024:00:00:02 +0000] "GET /api/v1/health HTTP/1.1" 200 56 "-" "curl/7.68.0"\n',
            '192.168.1.3 - - [01/Jan/2024:00:00:03 +0000] "POST /api/v1/users HTTP/1.1" 201 789 "-" "Mozilla/5.0"\n',
        ]

        with open(test_log_path, 'w') as f:
            f.writelines(sample_lines)

        try:
            result = subprocess.run(
                ["python3", "/home/user/logparse/analyze.py", test_log_path],
                capture_output=True,
                text=True,
                timeout=10
            )
            assert result.returncode == 0, \
                f"Script failed on small input: {result.stderr}"
            # Should produce some output
            assert len(result.stdout.strip()) > 0, \
                "Script produced no output on small input"
        finally:
            if os.path.exists(test_log_path):
                os.remove(test_log_path)

    def test_script_output_format(self):
        """Verify the script produces output in expected format."""
        test_log_path = "/tmp/test_format_access.log"
        sample_lines = [
            '192.168.1.1 - - [01/Jan/2024:00:00:01 +0000] "GET /api/test HTTP/1.1" 200 1234 "-" "Mozilla/5.0"\n',
        ] * 5

        with open(test_log_path, 'w') as f:
            f.writelines(sample_lines)

        try:
            result = subprocess.run(
                ["python3", "/home/user/logparse/analyze.py", test_log_path],
                capture_output=True,
                text=True,
                timeout=10
            )
            assert result.returncode == 0, f"Script failed: {result.stderr}"

            # Check output format: "endpoint: count"
            output_lines = result.stdout.strip().split('\n')
            for line in output_lines:
                if line.strip():
                    assert ': ' in line, \
                        f"Output line doesn't match 'endpoint: count' format: {line}"
                    parts = line.rsplit(': ', 1)
                    assert len(parts) == 2, \
                        f"Output line doesn't have exactly one ': ' separator: {line}"
                    # The count should be a number
                    try:
                        int(parts[1])
                    except ValueError:
                        pytest.fail(f"Count is not a number in output line: {line}")
        finally:
            if os.path.exists(test_log_path):
                os.remove(test_log_path)
