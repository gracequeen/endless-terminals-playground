# test_final_state.py
"""
Tests to validate the final state after the student has optimized the log parser.
Verifies that:
1. The script completes in under 5 seconds on the 800k line file
2. Output format is correct ("endpoint: count" lines)
3. Output is semantically correct (counts match reference values)
4. The fix is algorithmic (no string concatenation for counting)
5. No shortcuts (hardcoding, shelling out, etc.)
"""

import os
import subprocess
import pytest
import re
import time


class TestScriptExists:
    """Test that the script still exists and is valid Python."""

    def test_analyze_script_exists(self):
        """Verify analyze.py script still exists."""
        path = "/home/user/logparse/analyze.py"
        assert os.path.isfile(path), f"Script {path} does not exist"

    def test_script_is_valid_python(self):
        """Verify analyze.py has valid Python syntax."""
        path = "/home/user/logparse/analyze.py"
        result = subprocess.run(
            ["python3", "-m", "py_compile", path],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            f"Script has syntax errors: {result.stderr}"


class TestPerformanceRequirement:
    """Test that the script completes within the required time limit."""

    def test_completes_under_5_seconds(self):
        """Verify script completes in under 5 seconds on the 800k line file."""
        script_path = "/home/user/logparse/analyze.py"
        log_path = "/home/user/logparse/data/access.log"

        # Use timeout command to enforce the 5 second limit
        result = subprocess.run(
            ["timeout", "5", "python3", script_path, log_path],
            capture_output=True,
            text=True
        )

        assert result.returncode == 0, \
            f"Script did not complete within 5 seconds (exit code {result.returncode}). " \
            f"stderr: {result.stderr}"

    def test_performance_with_timing(self):
        """Measure and verify actual execution time is reasonable."""
        script_path = "/home/user/logparse/analyze.py"
        log_path = "/home/user/logparse/data/access.log"

        start_time = time.time()
        result = subprocess.run(
            ["python3", script_path, log_path],
            capture_output=True,
            text=True,
            timeout=10  # Give a bit more time for measurement
        )
        elapsed_time = time.time() - start_time

        assert result.returncode == 0, \
            f"Script failed with exit code {result.returncode}. stderr: {result.stderr}"
        assert elapsed_time < 5.0, \
            f"Script took {elapsed_time:.2f} seconds, expected under 5 seconds"


class TestOutputFormat:
    """Test that output format matches requirements."""

    def test_output_has_lines(self):
        """Verify script produces output."""
        script_path = "/home/user/logparse/analyze.py"
        log_path = "/home/user/logparse/data/access.log"

        result = subprocess.run(
            ["timeout", "5", "python3", script_path, log_path],
            capture_output=True,
            text=True
        )

        assert result.returncode == 0, f"Script failed: {result.stderr}"
        output = result.stdout.strip()
        assert len(output) > 0, "Script produced no output"

    def test_output_has_10_lines(self):
        """Verify script outputs exactly 10 lines (top 10)."""
        script_path = "/home/user/logparse/analyze.py"
        log_path = "/home/user/logparse/data/access.log"

        result = subprocess.run(
            ["timeout", "5", "python3", script_path, log_path],
            capture_output=True,
            text=True
        )

        assert result.returncode == 0, f"Script failed: {result.stderr}"
        lines = [l for l in result.stdout.strip().split('\n') if l.strip()]
        assert len(lines) == 10, \
            f"Expected 10 output lines (top 10), got {len(lines)}"

    def test_output_format_endpoint_colon_count(self):
        """Verify each line follows 'endpoint: count' format."""
        script_path = "/home/user/logparse/analyze.py"
        log_path = "/home/user/logparse/data/access.log"

        result = subprocess.run(
            ["timeout", "5", "python3", script_path, log_path],
            capture_output=True,
            text=True
        )

        assert result.returncode == 0, f"Script failed: {result.stderr}"
        lines = [l for l in result.stdout.strip().split('\n') if l.strip()]

        for line in lines:
            assert ': ' in line, \
                f"Output line doesn't contain ': ' separator: {line}"
            parts = line.rsplit(': ', 1)
            assert len(parts) == 2, \
                f"Output line format incorrect: {line}"
            endpoint, count_str = parts
            assert len(endpoint) > 0, \
                f"Endpoint is empty in line: {line}"
            try:
                count = int(count_str)
                assert count > 0, f"Count should be positive: {line}"
            except ValueError:
                pytest.fail(f"Count is not a valid integer in line: {line}")

    def test_output_is_sorted_descending(self):
        """Verify output is sorted by count in descending order."""
        script_path = "/home/user/logparse/analyze.py"
        log_path = "/home/user/logparse/data/access.log"

        result = subprocess.run(
            ["timeout", "5", "python3", script_path, log_path],
            capture_output=True,
            text=True
        )

        assert result.returncode == 0, f"Script failed: {result.stderr}"
        lines = [l for l in result.stdout.strip().split('\n') if l.strip()]

        counts = []
        for line in lines:
            parts = line.rsplit(': ', 1)
            counts.append(int(parts[1]))

        for i in range(len(counts) - 1):
            assert counts[i] >= counts[i + 1], \
                f"Output not sorted descending: {counts[i]} should be >= {counts[i+1]}"


class TestOutputCorrectness:
    """Test that output values are semantically correct."""

    def test_top_endpoint_is_api_v1_users(self):
        """Verify the top endpoint is /api/v1/users with correct count."""
        script_path = "/home/user/logparse/analyze.py"
        log_path = "/home/user/logparse/data/access.log"

        result = subprocess.run(
            ["timeout", "5", "python3", script_path, log_path],
            capture_output=True,
            text=True
        )

        assert result.returncode == 0, f"Script failed: {result.stderr}"
        lines = [l for l in result.stdout.strip().split('\n') if l.strip()]

        # Parse first line
        first_line = lines[0]
        parts = first_line.rsplit(': ', 1)
        endpoint = parts[0]
        count = int(parts[1])

        assert endpoint == "/api/v1/users", \
            f"Expected top endpoint to be /api/v1/users, got {endpoint}"
        # Allow small tolerance in count (within 1%)
        expected_count = 47832
        tolerance = expected_count * 0.01
        assert abs(count - expected_count) <= tolerance, \
            f"Expected count ~{expected_count} for /api/v1/users, got {count}"

    def test_reference_endpoints_present(self):
        """Verify reference endpoints appear in top 10 with approximately correct counts."""
        script_path = "/home/user/logparse/analyze.py"
        log_path = "/home/user/logparse/data/access.log"

        result = subprocess.run(
            ["timeout", "5", "python3", script_path, log_path],
            capture_output=True,
            text=True
        )

        assert result.returncode == 0, f"Script failed: {result.stderr}"

        # Parse output into dict
        output_counts = {}
        for line in result.stdout.strip().split('\n'):
            if line.strip():
                parts = line.rsplit(': ', 1)
                output_counts[parts[0]] = int(parts[1])

        # Reference values from truth
        reference = {
            "/api/v1/users": 47832,
            "/api/v1/health": 41256,
            "/static/js/app.js": 38944,
        }

        for endpoint, expected_count in reference.items():
            assert endpoint in output_counts, \
                f"Expected {endpoint} in top 10, but it's missing. Got: {list(output_counts.keys())}"
            actual_count = output_counts[endpoint]
            tolerance = expected_count * 0.01  # 1% tolerance
            assert abs(actual_count - expected_count) <= tolerance, \
                f"Count mismatch for {endpoint}: expected ~{expected_count}, got {actual_count}"


class TestAlgorithmicFix:
    """Test that the fix is algorithmic, not a workaround."""

    def test_no_string_concatenation_for_counts(self):
        """Verify the buggy string concatenation pattern is removed."""
        path = "/home/user/logparse/analyze.py"
        with open(path, 'r') as f:
            content = f.read()

        # The buggy pattern: counts = "" followed by counts += in a loop
        # Check that counts is not initialized as empty string
        has_string_counts_init = bool(re.search(r'counts\s*=\s*["\']["\']', content))

        # Check for the specific buggy pattern of string concatenation
        has_counts_concat = bool(re.search(r'counts\s*\+=', content))

        # If both patterns exist, the bug wasn't fixed
        if has_string_counts_init and has_counts_concat:
            pytest.fail(
                "The buggy string-based counting pattern is still present. "
                "Expected algorithmic fix using proper data structures (dict/Counter)."
            )

    def test_no_hardcoded_results(self):
        """Verify results are not hardcoded."""
        path = "/home/user/logparse/analyze.py"
        with open(path, 'r') as f:
            content = f.read()

        # Check for hardcoded reference values
        hardcoded_patterns = [
            r'47832',  # exact count for /api/v1/users
            r'41256',  # exact count for /api/v1/health
            r'38944',  # exact count for /static/js/app.js
        ]

        hardcoded_count = 0
        for pattern in hardcoded_patterns:
            if re.search(pattern, content):
                hardcoded_count += 1

        # If all three specific counts appear, likely hardcoded
        assert hardcoded_count < 3, \
            "Suspected hardcoded results - multiple exact reference counts found in source"

    def test_no_shell_commands(self):
        """Verify script doesn't shell out to external tools."""
        path = "/home/user/logparse/analyze.py"
        with open(path, 'r') as f:
            content = f.read()

        # Check for subprocess/os.system/os.popen calls with shell tools
        shell_patterns = [
            r'subprocess\.',
            r'os\.system\s*\(',
            r'os\.popen\s*\(',
            r'commands\.',
            r"Popen.*shell\s*=\s*True",
        ]

        for pattern in shell_patterns:
            match = re.search(pattern, content)
            if match:
                # Additional check - make sure it's not just importing subprocess
                # for legitimate use (though unlikely needed for this task)
                if 'awk' in content or 'grep' in content or 'wc' in content:
                    pytest.fail(
                        f"Script appears to shell out to external tools. "
                        f"Found pattern: {pattern}"
                    )

    def test_uses_proper_data_structure(self):
        """Verify script uses dict or Counter for counting."""
        path = "/home/user/logparse/analyze.py"
        with open(path, 'r') as f:
            content = f.read()

        # Should use either dict or collections.Counter
        uses_dict = bool(re.search(r'\{\s*\}', content) or re.search(r'dict\s*\(', content))
        uses_counter = 'Counter' in content
        uses_defaultdict = 'defaultdict' in content

        assert uses_dict or uses_counter or uses_defaultdict, \
            "Expected use of dict, Counter, or defaultdict for counting. " \
            "The fix should use proper data structures."


class TestScriptFunctionality:
    """Test that the script maintains required functionality."""

    def test_accepts_filepath_argument(self):
        """Verify script accepts filepath as command line argument."""
        script_path = "/home/user/logparse/analyze.py"

        # Create a small test file
        test_log = "/tmp/test_arg_access.log"
        with open(test_log, 'w') as f:
            for i in range(100):
                f.write(f'192.168.1.{i%256} - - [01/Jan/2024:00:00:01 +0000] '
                       f'"GET /test/path{i%10} HTTP/1.1" 200 1234 "-" "Mozilla/5.0"\n')

        try:
            result = subprocess.run(
                ["python3", script_path, test_log],
                capture_output=True,
                text=True,
                timeout=5
            )
            assert result.returncode == 0, \
                f"Script failed with custom filepath argument: {result.stderr}"
            assert len(result.stdout.strip()) > 0, \
                "Script produced no output with custom filepath"
        finally:
            if os.path.exists(test_log):
                os.remove(test_log)

    def test_handles_various_http_methods(self):
        """Verify script handles GET, POST, PUT, DELETE, etc."""
        script_path = "/home/user/logparse/analyze.py"

        test_log = "/tmp/test_methods_access.log"
        methods = ["GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS"]
        with open(test_log, 'w') as f:
            for i, method in enumerate(methods):
                for j in range(10):
                    f.write(f'192.168.1.{j} - - [01/Jan/2024:00:00:01 +0000] '
                           f'"{method} /api/{method.lower()} HTTP/1.1" 200 1234 "-" "Mozilla/5.0"\n')

        try:
            result = subprocess.run(
                ["python3", script_path, test_log],
                capture_output=True,
                text=True,
                timeout=5
            )
            assert result.returncode == 0, f"Script failed: {result.stderr}"

            # Should have output for the endpoints
            output = result.stdout.strip()
            assert len(output) > 0, "No output produced"

            # Check that multiple methods are recognized
            lines = output.split('\n')
            assert len(lines) >= 7, \
                f"Expected at least 7 endpoints (one per method), got {len(lines)}"
        finally:
            if os.path.exists(test_log):
                os.remove(test_log)

    def test_still_reads_from_file(self):
        """Verify script reads from file, not from cached/preprocessed source."""
        script_path = "/home/user/logparse/analyze.py"
        with open(script_path, 'r') as f:
            content = f.read()

        # Should have file opening logic
        assert 'open(' in content, \
            "Script should open and read from file"

        # Should reference filepath from argv or default
        assert 'sys.argv' in content or 'argv' in content or 'argparse' in content, \
            "Script should accept filepath from command line arguments"
