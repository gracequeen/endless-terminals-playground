# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the release pipeline fix task.
"""

import json
import os
import subprocess
import tarfile
import tempfile
import pytest


class TestReleaseDirectoryStructure:
    """Test that the release directory and its contents exist."""

    def test_release_directory_exists(self):
        """Verify /home/user/release directory exists."""
        assert os.path.isdir("/home/user/release"), \
            "Directory /home/user/release does not exist"

    def test_artifacts_directory_exists(self):
        """Verify /home/user/release/artifacts directory exists."""
        assert os.path.isdir("/home/user/release/artifacts"), \
            "Directory /home/user/release/artifacts does not exist"

    def test_scan_script_exists(self):
        """Verify scan.sh exists."""
        assert os.path.isfile("/home/user/release/scan.sh"), \
            "File /home/user/release/scan.sh does not exist"

    def test_scan_script_is_executable(self):
        """Verify scan.sh is executable."""
        assert os.access("/home/user/release/scan.sh", os.X_OK), \
            "File /home/user/release/scan.sh is not executable"

    def test_tarball_exists(self):
        """Verify the service tarball exists."""
        tarball_path = "/home/user/release/artifacts/myservice-2.4.0.tar.gz"
        assert os.path.isfile(tarball_path), \
            f"Tarball {tarball_path} does not exist"

    def test_release_directory_is_writable(self):
        """Verify /home/user/release is writable."""
        assert os.access("/home/user/release", os.W_OK), \
            "Directory /home/user/release is not writable"


class TestVulnDatabase:
    """Test the vulnerability database setup."""

    def test_vulndb_directory_exists(self):
        """Verify /var/lib/vulndb directory exists."""
        assert os.path.isdir("/var/lib/vulndb"), \
            "Directory /var/lib/vulndb does not exist"

    def test_cves_json_exists(self):
        """Verify cves.json exists."""
        assert os.path.isfile("/var/lib/vulndb/cves.json"), \
            "File /var/lib/vulndb/cves.json does not exist"

    def test_cves_json_is_readable(self):
        """Verify cves.json is readable."""
        assert os.access("/var/lib/vulndb/cves.json", os.R_OK), \
            "File /var/lib/vulndb/cves.json is not readable"

    def test_vulndb_directory_not_writable(self):
        """Verify /var/lib/vulndb is NOT writable (per task constraints)."""
        # This checks if the directory itself is writable
        # Note: This may pass if running as root, but task implies non-root user
        vulndb_path = "/var/lib/vulndb"
        cves_path = "/var/lib/vulndb/cves.json"
        # Check if we can write to the cves.json file
        assert not os.access(cves_path, os.W_OK), \
            "File /var/lib/vulndb/cves.json should NOT be writable"

    def test_cves_json_is_valid_json(self):
        """Verify cves.json contains valid JSON."""
        with open("/var/lib/vulndb/cves.json", "r") as f:
            try:
                data = json.load(f)
            except json.JSONDecodeError as e:
                pytest.fail(f"cves.json is not valid JSON: {e}")

    def test_cves_json_contains_lodash_cves(self):
        """Verify cves.json contains the expected lodash CVEs."""
        with open("/var/lib/vulndb/cves.json", "r") as f:
            data = json.load(f)

        # Convert to searchable format - handle both list and dict formats
        cve_ids = set()
        if isinstance(data, list):
            for entry in data:
                if "id" in entry:
                    cve_ids.add(entry["id"])
                elif "cve" in entry:
                    cve_ids.add(entry["cve"])
        elif isinstance(data, dict):
            cve_ids = set(data.keys())

        # Check for expected CVEs
        assert "CVE-2020-8203" in cve_ids or any("CVE-2020-8203" in str(data) for _ in [1]), \
            "CVE-2020-8203 (lodash Prototype Pollution) not found in cves.json"
        assert "CVE-2021-23337" in cve_ids or any("CVE-2021-23337" in str(data) for _ in [1]), \
            "CVE-2021-23337 (lodash Command Injection) not found in cves.json"


class TestTarballContents:
    """Test the contents of the service tarball."""

    @pytest.fixture
    def extracted_tarball(self):
        """Extract tarball to a temp directory for testing."""
        tarball_path = "/home/user/release/artifacts/myservice-2.4.0.tar.gz"
        with tempfile.TemporaryDirectory() as tmpdir:
            with tarfile.open(tarball_path, "r:gz") as tar:
                tar.extractall(tmpdir)
            yield tmpdir

    def test_tarball_is_valid_gzip(self):
        """Verify the tarball is a valid gzip file."""
        tarball_path = "/home/user/release/artifacts/myservice-2.4.0.tar.gz"
        try:
            with tarfile.open(tarball_path, "r:gz") as tar:
                # Just try to list members to verify it's valid
                tar.getmembers()
        except (tarfile.TarError, Exception) as e:
            pytest.fail(f"Tarball is not a valid gzip tar archive: {e}")

    def test_tarball_contains_package_json(self, extracted_tarball):
        """Verify tarball contains package.json."""
        # Find package.json (may be in root or subdirectory)
        found = False
        for root, dirs, files in os.walk(extracted_tarball):
            if "package.json" in files:
                found = True
                break
        assert found, "package.json not found in tarball"

    def test_tarball_contains_package_lock_json(self, extracted_tarball):
        """Verify tarball contains package-lock.json."""
        found = False
        for root, dirs, files in os.walk(extracted_tarball):
            if "package-lock.json" in files:
                found = True
                break
        assert found, "package-lock.json not found in tarball"

    def test_package_json_has_lodash_dependency(self, extracted_tarball):
        """Verify package.json lists lodash as a dependency."""
        package_json_path = None
        for root, dirs, files in os.walk(extracted_tarball):
            if "package.json" in files:
                package_json_path = os.path.join(root, "package.json")
                break

        assert package_json_path, "package.json not found"

        with open(package_json_path, "r") as f:
            data = json.load(f)

        deps = data.get("dependencies", {})
        dev_deps = data.get("devDependencies", {})
        all_deps = {**deps, **dev_deps}

        assert "lodash" in all_deps, \
            "lodash not found in package.json dependencies"

    def test_package_json_has_old_legacy_util(self, extracted_tarball):
        """Verify package.json lists old-legacy-util as a dependency."""
        package_json_path = None
        for root, dirs, files in os.walk(extracted_tarball):
            if "package.json" in files:
                package_json_path = os.path.join(root, "package.json")
                break

        assert package_json_path, "package.json not found"

        with open(package_json_path, "r") as f:
            data = json.load(f)

        deps = data.get("dependencies", {})
        dev_deps = data.get("devDependencies", {})
        all_deps = {**deps, **dev_deps}

        assert "old-legacy-util" in all_deps, \
            "old-legacy-util not found in package.json dependencies (required for the task)"

    def test_package_lock_has_vulnerable_lodash(self, extracted_tarball):
        """Verify package-lock.json contains the vulnerable nested lodash 4.17.15."""
        package_lock_path = None
        for root, dirs, files in os.walk(extracted_tarball):
            if "package-lock.json" in files:
                package_lock_path = os.path.join(root, "package-lock.json")
                break

        assert package_lock_path, "package-lock.json not found"

        with open(package_lock_path, "r") as f:
            content = f.read()

        # Check for the vulnerable version
        assert "4.17.15" in content, \
            "Vulnerable lodash version 4.17.15 not found in package-lock.json - initial state incorrect"

    def test_package_lock_has_both_lodash_versions(self, extracted_tarball):
        """Verify package-lock.json contains both lodash versions (4.17.21 and 4.17.15)."""
        package_lock_path = None
        for root, dirs, files in os.walk(extracted_tarball):
            if "package-lock.json" in files:
                package_lock_path = os.path.join(root, "package-lock.json")
                break

        assert package_lock_path, "package-lock.json not found"

        with open(package_lock_path, "r") as f:
            content = f.read()

        has_patched = "4.17.21" in content
        has_vulnerable = "4.17.15" in content

        assert has_patched, \
            "Patched lodash version 4.17.21 not found in package-lock.json"
        assert has_vulnerable, \
            "Vulnerable lodash version 4.17.15 not found in package-lock.json - this is needed for the initial state"


class TestScanScript:
    """Test the scan script properties."""

    def test_scan_script_is_bash(self):
        """Verify scan.sh is a bash script."""
        with open("/home/user/release/scan.sh", "r") as f:
            first_line = f.readline()

        assert "bash" in first_line or "sh" in first_line, \
            "scan.sh does not appear to be a shell script (no shebang)"

    def test_scan_script_references_vulndb(self):
        """Verify scan.sh references the vulnerability database."""
        with open("/home/user/release/scan.sh", "r") as f:
            content = f.read()

        assert "/var/lib/vulndb/cves.json" in content or "vulndb" in content.lower(), \
            "scan.sh does not appear to reference the vulnerability database"

    def test_scan_script_backup_exists(self):
        """Verify scan.sh.orig backup exists for integrity checking."""
        assert os.path.isfile("/home/user/release/scan.sh.orig"), \
            "Backup file /home/user/release/scan.sh.orig does not exist (needed for anti-shortcut verification)"


class TestRequiredTools:
    """Test that required tools are available."""

    def test_jq_available(self):
        """Verify jq is installed."""
        result = subprocess.run(["which", "jq"], capture_output=True)
        assert result.returncode == 0, "jq is not installed or not in PATH"

    def test_tar_available(self):
        """Verify tar is installed."""
        result = subprocess.run(["which", "tar"], capture_output=True)
        assert result.returncode == 0, "tar is not installed or not in PATH"

    def test_node_available(self):
        """Verify node is installed."""
        result = subprocess.run(["which", "node"], capture_output=True)
        assert result.returncode == 0, "node is not installed or not in PATH"

    def test_npm_available(self):
        """Verify npm is installed."""
        result = subprocess.run(["which", "npm"], capture_output=True)
        assert result.returncode == 0, "npm is not installed or not in PATH"


class TestScannerCurrentlyFails:
    """Verify that the scanner currently fails (the problem exists)."""

    def test_scan_currently_fails(self):
        """Verify that running scan.sh currently exits with failure."""
        result = subprocess.run(
            ["/home/user/release/scan.sh"],
            capture_output=True,
            cwd="/home/user/release"
        )
        assert result.returncode != 0, \
            "scan.sh currently passes - the initial problem state is not set up correctly"
