# test_final_state.py
"""
Tests to validate the final state of the OS/filesystem after the student
has completed the release pipeline fix task.
"""

import hashlib
import json
import os
import subprocess
import tarfile
import tempfile
import re
import pytest


class TestAntiShortcutGuards:
    """Ensure the student didn't bypass the task by modifying protected files."""

    def test_scan_script_unchanged(self):
        """Verify scan.sh has not been modified from its original."""
        result = subprocess.run(
            ["diff", "/home/user/release/scan.sh", "/home/user/release/scan.sh.orig"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            f"scan.sh has been modified from original - this is not allowed.\nDiff:\n{result.stdout}"

    def test_vulndb_unchanged(self):
        """Verify /var/lib/vulndb/cves.json has not been modified."""
        # Calculate current hash
        with open("/var/lib/vulndb/cves.json", "rb") as f:
            current_hash = hashlib.sha256(f.read()).hexdigest()

        # Check if there's a recorded original hash
        orig_hash_file = "/var/lib/vulndb/cves.json.sha256"
        if os.path.exists(orig_hash_file):
            with open(orig_hash_file, "r") as f:
                original_hash = f.read().strip().split()[0]
            assert current_hash == original_hash, \
                f"cves.json has been modified - this is not allowed. Current: {current_hash}, Original: {original_hash}"
        else:
            # If no hash file, at least verify the CVEs are still there
            with open("/var/lib/vulndb/cves.json", "r") as f:
                content = f.read()
            assert "CVE-2020-8203" in content, \
                "CVE-2020-8203 missing from cves.json - database may have been tampered with"
            assert "CVE-2021-23337" in content, \
                "CVE-2021-23337 missing from cves.json - database may have been tampered with"


class TestScannerPasses:
    """Verify the scanner now passes legitimately."""

    def test_scan_script_exits_zero(self):
        """Verify scan.sh exits with code 0 (success)."""
        result = subprocess.run(
            ["/home/user/release/scan.sh"],
            capture_output=True,
            text=True,
            cwd="/home/user/release"
        )
        assert result.returncode == 0, \
            f"scan.sh still fails with exit code {result.returncode}.\nStdout: {result.stdout}\nStderr: {result.stderr}"

    def test_scan_log_shows_no_critical_vulnerabilities(self):
        """Verify scan.log shows no critical vulnerabilities."""
        log_path = "/home/user/release/scan.log"

        # First run the scanner to generate fresh log
        subprocess.run(
            ["/home/user/release/scan.sh"],
            capture_output=True,
            cwd="/home/user/release"
        )

        assert os.path.exists(log_path), \
            f"Scan log {log_path} does not exist after running scan.sh"

        with open(log_path, "r") as f:
            log_content = f.read().lower()

        # Check that there are no critical vulnerability findings
        # Common patterns for vulnerability findings
        critical_patterns = [
            r"critical.*cve-\d{4}-\d+.*lodash",
            r"cve-2020-8203.*critical",
            r"cve-2021-23337.*critical",
            r"found.*critical.*vulnerabilit",
            r"critical.*found",
        ]

        for pattern in critical_patterns:
            matches = re.findall(pattern, log_content, re.IGNORECASE)
            # Only fail if it looks like an actual vulnerability finding, not a "no vulnerabilities" message
            if matches:
                # Check context - if it's saying "no" or "0" critical, that's fine
                if not re.search(r"(no|0|zero)\s+(critical|vulnerabilit)", log_content):
                    # Additional check: see if it's a "pass" or "clean" message
                    if not re.search(r"(pass|clean|clear|safe|ok)", log_content):
                        pytest.fail(f"Scan log appears to show critical vulnerabilities: {matches}")


class TestTarballFixed:
    """Verify the tarball has been legitimately fixed."""

    @pytest.fixture
    def extracted_tarball(self):
        """Extract tarball to a temp directory for testing."""
        tarball_path = "/home/user/release/artifacts/myservice-2.4.0.tar.gz"
        with tempfile.TemporaryDirectory() as tmpdir:
            with tarfile.open(tarball_path, "r:gz") as tar:
                tar.extractall(tmpdir)
            yield tmpdir

    def test_tarball_exists(self):
        """Verify the tarball still exists."""
        tarball_path = "/home/user/release/artifacts/myservice-2.4.0.tar.gz"
        assert os.path.isfile(tarball_path), \
            f"Tarball {tarball_path} does not exist"

    def test_tarball_is_valid(self):
        """Verify the tarball is still a valid gzip archive."""
        tarball_path = "/home/user/release/artifacts/myservice-2.4.0.tar.gz"
        try:
            with tarfile.open(tarball_path, "r:gz") as tar:
                tar.getmembers()
        except (tarfile.TarError, Exception) as e:
            pytest.fail(f"Tarball is not a valid gzip tar archive: {e}")

    def test_old_legacy_util_still_present(self, extracted_tarball):
        """Verify old-legacy-util is still in package.json dependencies."""
        package_json_path = None
        for root, dirs, files in os.walk(extracted_tarball):
            if "package.json" in files:
                candidate = os.path.join(root, "package.json")
                # Skip nested node_modules package.json files
                if "node_modules" not in root.split(os.sep)[-3:]:
                    package_json_path = candidate
                    break
                elif package_json_path is None:
                    package_json_path = candidate

        assert package_json_path, "package.json not found in tarball"

        with open(package_json_path, "r") as f:
            data = json.load(f)

        deps = data.get("dependencies", {})
        dev_deps = data.get("devDependencies", {})
        all_deps = {**deps, **dev_deps}

        assert "old-legacy-util" in all_deps, \
            "old-legacy-util has been removed from package.json - it must remain as a dependency"

    def test_no_vulnerable_lodash_versions_in_package_lock(self, extracted_tarball):
        """Verify all lodash entries in package-lock.json are 4.17.21 or higher."""
        package_lock_path = None
        for root, dirs, files in os.walk(extracted_tarball):
            if "package-lock.json" in files:
                candidate = os.path.join(root, "package-lock.json")
                # Prefer the root package-lock.json
                if "node_modules" not in root.split(os.sep)[-3:]:
                    package_lock_path = candidate
                    break
                elif package_lock_path is None:
                    package_lock_path = candidate

        assert package_lock_path, "package-lock.json not found in tarball"

        with open(package_lock_path, "r") as f:
            data = json.load(f)

        # Check packages section (npm v2/v3 lockfile format)
        packages = data.get("packages", {})
        vulnerable_found = []

        for pkg_path, pkg_info in packages.items():
            if "lodash" in pkg_path.lower() or pkg_info.get("name") == "lodash":
                version = pkg_info.get("version", "")
                if version:
                    # Parse version and check if it's vulnerable (< 4.17.21)
                    version_match = re.match(r"(\d+)\.(\d+)\.(\d+)", version)
                    if version_match:
                        major, minor, patch = map(int, version_match.groups())
                        if (major, minor, patch) < (4, 17, 21):
                            vulnerable_found.append(f"{pkg_path}: {version}")

        # Also check dependencies section (npm v1 lockfile format)
        def check_deps(deps, path=""):
            for name, info in deps.items():
                if name == "lodash":
                    version = info.get("version", "")
                    if version:
                        version_match = re.match(r"(\d+)\.(\d+)\.(\d+)", version)
                        if version_match:
                            major, minor, patch = map(int, version_match.groups())
                            if (major, minor, patch) < (4, 17, 21):
                                vulnerable_found.append(f"{path}/{name}: {version}")
                # Recursively check nested dependencies
                if "dependencies" in info:
                    check_deps(info["dependencies"], f"{path}/{name}")

        if "dependencies" in data:
            check_deps(data["dependencies"])

        assert not vulnerable_found, \
            f"Vulnerable lodash versions still found in package-lock.json: {vulnerable_found}"

    def test_no_vulnerable_versions_via_grep(self, extracted_tarball):
        """Use grep to ensure no vulnerable lodash versions exist in any file."""
        # Check for versions 4.17.10 through 4.17.18 (vulnerable versions)
        result = subprocess.run(
            ["grep", "-r", "-E", '"version"[[:space:]]*:[[:space:]]*"4\\.17\\.1[0-8]"', extracted_tarball],
            capture_output=True,
            text=True
        )

        # Filter results to only lodash-related files
        if result.stdout:
            lines = result.stdout.strip().split("\n")
            lodash_vulns = [l for l in lines if "lodash" in l.lower()]
            assert not lodash_vulns, \
                f"Vulnerable lodash versions (4.17.10-4.17.18) found:\n{chr(10).join(lodash_vulns)}"

    def test_lodash_present_and_patched(self, extracted_tarball):
        """Verify lodash is still present and at a safe version."""
        package_lock_path = None
        for root, dirs, files in os.walk(extracted_tarball):
            if "package-lock.json" in files:
                candidate = os.path.join(root, "package-lock.json")
                if "node_modules" not in root.split(os.sep)[-3:]:
                    package_lock_path = candidate
                    break
                elif package_lock_path is None:
                    package_lock_path = candidate

        assert package_lock_path, "package-lock.json not found in tarball"

        with open(package_lock_path, "r") as f:
            content = f.read()

        # Lodash should still be present
        assert "lodash" in content.lower(), \
            "lodash appears to have been completely removed - it should be updated, not removed"

        # Should have a safe version (4.17.21 or higher)
        assert "4.17.21" in content or "4.17.22" in content or "4.17.23" in content or "4.17.24" in content, \
            "No safe lodash version (4.17.21+) found in package-lock.json"


class TestTarballIntegrity:
    """Additional integrity checks for the tarball."""

    @pytest.fixture
    def extracted_tarball(self):
        """Extract tarball to a temp directory for testing."""
        tarball_path = "/home/user/release/artifacts/myservice-2.4.0.tar.gz"
        with tempfile.TemporaryDirectory() as tmpdir:
            with tarfile.open(tarball_path, "r:gz") as tar:
                tar.extractall(tmpdir)
            yield tmpdir

    def test_package_json_valid(self, extracted_tarball):
        """Verify package.json is still valid JSON."""
        for root, dirs, files in os.walk(extracted_tarball):
            if "package.json" in files:
                pkg_path = os.path.join(root, "package.json")
                try:
                    with open(pkg_path, "r") as f:
                        json.load(f)
                except json.JSONDecodeError as e:
                    pytest.fail(f"Invalid JSON in {pkg_path}: {e}")

    def test_package_lock_valid(self, extracted_tarball):
        """Verify package-lock.json is still valid JSON."""
        for root, dirs, files in os.walk(extracted_tarball):
            if "package-lock.json" in files:
                lock_path = os.path.join(root, "package-lock.json")
                try:
                    with open(lock_path, "r") as f:
                        json.load(f)
                except json.JSONDecodeError as e:
                    pytest.fail(f"Invalid JSON in {lock_path}: {e}")

    def test_direct_lodash_dependency_preserved(self, extracted_tarball):
        """Verify the direct lodash dependency is still in package.json."""
        package_json_path = None
        for root, dirs, files in os.walk(extracted_tarball):
            if "package.json" in files:
                candidate = os.path.join(root, "package.json")
                if "node_modules" not in root.split(os.sep)[-3:]:
                    package_json_path = candidate
                    break

        if package_json_path:
            with open(package_json_path, "r") as f:
                data = json.load(f)

            deps = data.get("dependencies", {})
            dev_deps = data.get("devDependencies", {})
            all_deps = {**deps, **dev_deps}

            assert "lodash" in all_deps, \
                "Direct lodash dependency has been removed from package.json"
