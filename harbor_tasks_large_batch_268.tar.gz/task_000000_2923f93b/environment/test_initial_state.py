# test_initial_state.py
"""
Tests to validate the initial state of the system before the student performs
the task of listing packages that depend on libssl3.
"""

import os
import subprocess
import pytest


class TestSystemPrerequisites:
    """Test that the system has required prerequisites."""

    def test_apt_available(self):
        """Verify apt is available on the system."""
        result = subprocess.run(
            ["which", "apt"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "apt command is not available on this system"

    def test_dpkg_available(self):
        """Verify dpkg is available on the system."""
        result = subprocess.run(
            ["which", "dpkg"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "dpkg command is not available on this system"

    def test_apt_cache_available(self):
        """Verify apt-cache is available on the system."""
        result = subprocess.run(
            ["which", "apt-cache"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "apt-cache command is not available on this system"


class TestLibssl3Installation:
    """Test that libssl3 is installed with reverse dependencies."""

    def test_libssl3_installed(self):
        """Verify libssl3 is installed on the system."""
        result = subprocess.run(
            ["dpkg", "-s", "libssl3"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "libssl3 is not installed. "
            "The package must be installed for this task."
        )
        assert "Status: install ok installed" in result.stdout, (
            "libssl3 is not properly installed (status check failed)"
        )

    def test_libssl3_has_reverse_dependencies(self):
        """Verify that libssl3 has reverse dependencies that can be queried."""
        result = subprocess.run(
            ["apt-cache", "rdepends", "libssl3"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "Failed to query reverse dependencies of libssl3 using apt-cache"
        )
        # Should have some output indicating reverse dependencies exist
        assert "Reverse Depends:" in result.stdout, (
            "apt-cache rdepends output does not contain expected 'Reverse Depends:' header"
        )
        # Count lines after the header - should have multiple dependencies
        lines = result.stdout.strip().split('\n')
        # Filter out empty lines and the header line
        dep_lines = [l for l in lines if l.strip() and "Reverse Depends:" not in l and "libssl3" not in l]
        assert len(dep_lines) >= 5, (
            f"Expected at least 5 reverse dependencies for libssl3, "
            f"but found only {len(dep_lines)}. The system may not have enough "
            f"packages installed that depend on libssl3."
        )

    def test_common_rdeps_installed(self):
        """Verify at least one common reverse dependency is installed."""
        common_rdeps = ["openssh-client", "curl", "wget", "python3"]
        installed = []

        for pkg in common_rdeps:
            result = subprocess.run(
                ["dpkg", "-s", pkg],
                capture_output=True,
                text=True
            )
            if result.returncode == 0 and "Status: install ok installed" in result.stdout:
                installed.append(pkg)

        assert len(installed) > 0, (
            f"None of the common libssl3 reverse dependencies are installed: "
            f"{common_rdeps}. At least one should be present for this task."
        )


class TestDirectoryStructure:
    """Test that required directories exist."""

    def test_home_user_exists(self):
        """Verify /home/user directory exists."""
        assert os.path.isdir("/home/user"), (
            "/home/user directory does not exist"
        )

    def test_docs_directory_exists(self):
        """Verify /home/user/docs directory exists."""
        assert os.path.isdir("/home/user/docs"), (
            "/home/user/docs directory does not exist. "
            "This directory must exist for the student to write output."
        )

    def test_docs_directory_writable(self):
        """Verify /home/user/docs directory is writable."""
        assert os.access("/home/user/docs", os.W_OK), (
            "/home/user/docs directory is not writable. "
            "The student needs write access to create the output file."
        )


class TestOutputFileNotExists:
    """Test that the output file does not exist yet."""

    def test_output_file_does_not_exist(self):
        """Verify /home/user/docs/libssl3-rdeps.txt does not exist."""
        output_path = "/home/user/docs/libssl3-rdeps.txt"
        assert not os.path.exists(output_path), (
            f"{output_path} already exists. "
            "The output file should not exist before the student performs the task."
        )


class TestSortCommandAvailable:
    """Test that sort command is available for verification."""

    def test_sort_available(self):
        """Verify sort command is available."""
        result = subprocess.run(
            ["which", "sort"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "sort command is not available on this system"

    def test_grep_available(self):
        """Verify grep command is available for verification."""
        result = subprocess.run(
            ["which", "grep"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "grep command is not available on this system"
