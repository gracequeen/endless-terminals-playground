# test_final_state.py
"""
Tests to validate the final state of the system after the student has completed
the task of listing packages that depend on libssl3 to /home/user/docs/libssl3-rdeps.txt.
"""

import os
import subprocess
import pytest


class TestOutputFileExists:
    """Test that the output file exists and is accessible."""

    def test_output_file_exists(self):
        """Verify /home/user/docs/libssl3-rdeps.txt exists."""
        output_path = "/home/user/docs/libssl3-rdeps.txt"
        assert os.path.exists(output_path), (
            f"{output_path} does not exist. "
            "The task requires creating this file with libssl3 reverse dependencies."
        )

    def test_output_file_is_regular_file(self):
        """Verify the output is a regular file, not a directory or symlink."""
        output_path = "/home/user/docs/libssl3-rdeps.txt"
        assert os.path.isfile(output_path), (
            f"{output_path} is not a regular file."
        )

    def test_output_file_is_readable(self):
        """Verify the output file is readable."""
        output_path = "/home/user/docs/libssl3-rdeps.txt"
        assert os.access(output_path, os.R_OK), (
            f"{output_path} is not readable."
        )


class TestOutputFileContent:
    """Test that the output file has proper content."""

    def test_file_has_minimum_lines(self):
        """Verify file has at least 5 lines (many rdeps expected)."""
        output_path = "/home/user/docs/libssl3-rdeps.txt"
        with open(output_path, 'r') as f:
            lines = [line.strip() for line in f if line.strip()]

        assert len(lines) >= 5, (
            f"Expected at least 5 package names in the file, but found only {len(lines)}. "
            "libssl3 has many reverse dependencies on a typical system."
        )

    def test_file_contains_real_rdeps(self):
        """Verify file contains at least one known common reverse dependency."""
        output_path = "/home/user/docs/libssl3-rdeps.txt"
        with open(output_path, 'r') as f:
            content = f.read()
            lines = [line.strip() for line in content.split('\n') if line.strip()]

        # These are common packages that depend on libssl3
        common_rdeps = ["openssh-client", "curl", "wget"]
        found = [pkg for pkg in common_rdeps if pkg in lines]

        assert len(found) > 0, (
            f"File does not contain any of the expected common reverse dependencies: "
            f"{common_rdeps}. The file should contain real reverse dependencies from "
            "the system, not a hardcoded or empty list."
        )

    def test_one_package_per_line(self):
        """Verify each line contains only one package name (no spaces within lines)."""
        output_path = "/home/user/docs/libssl3-rdeps.txt"
        with open(output_path, 'r') as f:
            lines = [line.rstrip('\n') for line in f if line.strip()]

        for i, line in enumerate(lines, 1):
            # Package names should not contain spaces
            assert ' ' not in line.strip(), (
                f"Line {i} contains spaces: '{line}'. "
                "Each line should contain only one package name with no extra whitespace."
            )

    def test_no_leading_whitespace(self):
        """Verify no lines have leading whitespace."""
        output_path = "/home/user/docs/libssl3-rdeps.txt"
        with open(output_path, 'r') as f:
            lines = [line.rstrip('\n') for line in f if line.rstrip('\n')]

        for i, line in enumerate(lines, 1):
            if line:  # Skip empty lines
                assert line == line.lstrip(), (
                    f"Line {i} has leading whitespace: '{line}'. "
                    "Package names should start at the beginning of the line."
                )

    def test_no_colons_in_output(self):
        """Verify no colons in output (would indicate apt-cache formatting cruft)."""
        output_path = "/home/user/docs/libssl3-rdeps.txt"
        with open(output_path, 'r') as f:
            content = f.read()

        assert ':' not in content, (
            "File contains colons, which suggests apt-cache output formatting "
            "was not properly cleaned. Lines should contain only package names."
        )

    def test_no_pipe_characters(self):
        """Verify no pipe characters in output."""
        output_path = "/home/user/docs/libssl3-rdeps.txt"
        with open(output_path, 'r') as f:
            content = f.read()

        assert '|' not in content, (
            "File contains pipe characters. "
            "Lines should contain only package names, one per line."
        )

    def test_no_reverse_depends_header(self):
        """Verify the 'Reverse Depends:' header is not in the output."""
        output_path = "/home/user/docs/libssl3-rdeps.txt"
        with open(output_path, 'r') as f:
            content = f.read()

        assert 'Reverse Depends' not in content, (
            "File contains 'Reverse Depends' header from apt-cache output. "
            "The file should contain only package names, one per line."
        )


class TestSortedOrder:
    """Test that the output is sorted alphabetically."""

    def test_sort_check_command(self):
        """Verify file is sorted using sort -c command."""
        output_path = "/home/user/docs/libssl3-rdeps.txt"
        result = subprocess.run(
            ["sort", "-c", output_path],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"File is not sorted alphabetically. "
            f"sort -c returned: {result.stderr.strip() or 'non-zero exit code'}. "
            "The task requires the output to be sorted alphabetically."
        )

    def test_sorted_python_verification(self):
        """Verify file is sorted using Python comparison."""
        output_path = "/home/user/docs/libssl3-rdeps.txt"
        with open(output_path, 'r') as f:
            lines = [line.strip() for line in f if line.strip()]

        sorted_lines = sorted(lines)
        assert lines == sorted_lines, (
            "File contents are not sorted alphabetically. "
            f"First out-of-order package found at position where "
            f"'{lines[next(i for i, (a, b) in enumerate(zip(lines, sorted_lines)) if a != b)]}' "
            f"should be '{sorted_lines[next(i for i, (a, b) in enumerate(zip(lines, sorted_lines)) if a != b)]}'."
        )


class TestNoFormatCruft:
    """Test that there's no formatting cruft from apt-cache or other tools."""

    def test_grep_no_cruft(self):
        """Use grep to verify no leading whitespace, colons, or pipes."""
        output_path = "/home/user/docs/libssl3-rdeps.txt"
        result = subprocess.run(
            ["grep", "-E", r"^\s|:|\|", output_path],
            capture_output=True,
            text=True
        )
        # grep returns 0 if matches found, 1 if no matches
        assert result.returncode == 1, (
            f"File contains formatting cruft (leading whitespace, colons, or pipes). "
            f"Matching lines: {result.stdout.strip()}"
        )

    def test_valid_package_name_format(self):
        """Verify each line looks like a valid Debian package name."""
        output_path = "/home/user/docs/libssl3-rdeps.txt"
        import re
        # Debian package names: lowercase, digits, plus, minus, period
        # Must start with alphanumeric
        pkg_pattern = re.compile(r'^[a-z0-9][a-z0-9+.\-]*$')

        with open(output_path, 'r') as f:
            lines = [line.strip() for line in f if line.strip()]

        invalid_lines = []
        for line in lines:
            if not pkg_pattern.match(line):
                invalid_lines.append(line)

        assert len(invalid_lines) == 0, (
            f"Found {len(invalid_lines)} lines that don't look like valid package names: "
            f"{invalid_lines[:5]}{'...' if len(invalid_lines) > 5 else ''}"
        )


class TestSystemInvariants:
    """Test that system invariants are maintained."""

    def test_libssl3_still_installed(self):
        """Verify libssl3 is still installed (not removed during task)."""
        result = subprocess.run(
            ["dpkg", "-s", "libssl3"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "libssl3 is no longer installed. "
            "The task should not remove any packages."
        )
        assert "Status: install ok installed" in result.stdout, (
            "libssl3 is not properly installed anymore."
        )

    def test_docs_directory_intact(self):
        """Verify /home/user/docs directory still exists."""
        assert os.path.isdir("/home/user/docs"), (
            "/home/user/docs directory no longer exists."
        )
