# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the task of fixing the endpoint extraction script.
"""

import os
import stat
import subprocess
import pytest


class TestInitialState:
    """Validate the initial state matches the task description."""

    def test_script_exists(self):
        """The extract_endpoints.py script must exist."""
        script_path = "/home/user/docs/extract_endpoints.py"
        assert os.path.exists(script_path), (
            f"Script not found at {script_path}. "
            "The task requires this script to exist."
        )

    def test_script_is_file(self):
        """The extract_endpoints.py must be a regular file."""
        script_path = "/home/user/docs/extract_endpoints.py"
        assert os.path.isfile(script_path), (
            f"{script_path} exists but is not a regular file."
        )

    def test_script_is_readable(self):
        """The script must be readable."""
        script_path = "/home/user/docs/extract_endpoints.py"
        assert os.access(script_path, os.R_OK), (
            f"{script_path} is not readable. The student needs to read and modify it."
        )

    def test_script_is_writable(self):
        """The script must be writable so the student can fix it."""
        script_path = "/home/user/docs/extract_endpoints.py"
        assert os.access(script_path, os.W_OK), (
            f"{script_path} is not writable. The student needs to modify it."
        )

    def test_docs_directory_exists(self):
        """The /home/user/docs/ directory must exist."""
        docs_path = "/home/user/docs"
        assert os.path.isdir(docs_path), (
            f"Directory {docs_path} does not exist."
        )

    def test_docs_directory_is_writable(self):
        """The /home/user/docs/ directory must be writable."""
        docs_path = "/home/user/docs"
        assert os.access(docs_path, os.W_OK), (
            f"Directory {docs_path} is not writable."
        )

    def test_webapp_log_directory_exists(self):
        """The /var/log/webapp/ directory must exist."""
        log_dir = "/var/log/webapp"
        assert os.path.isdir(log_dir), (
            f"Log directory {log_dir} does not exist. "
            "The script needs to read logs from this location."
        )

    def test_access_log_exists(self):
        """The access.log file must exist in /var/log/webapp/."""
        log_file = "/var/log/webapp/access.log"
        assert os.path.exists(log_file), (
            f"Log file {log_file} does not exist. "
            "The task requires nginx access logs to be present."
        )

    def test_access_log_is_readable(self):
        """The access.log must be readable."""
        log_file = "/var/log/webapp/access.log"
        assert os.access(log_file, os.R_OK), (
            f"Log file {log_file} is not readable."
        )

    def test_access_log_has_content(self):
        """The access.log should have substantial content (~50k lines)."""
        log_file = "/var/log/webapp/access.log"
        result = subprocess.run(
            ["wc", "-l", log_file],
            capture_output=True,
            text=True
        )
        line_count = int(result.stdout.split()[0])
        # Should be around 50k lines, allow some tolerance
        assert line_count >= 40000, (
            f"Log file {log_file} has only {line_count} lines. "
            "Expected approximately 50,000 lines of nginx access logs."
        )

    def test_access_log_is_nginx_combined_format(self):
        """Verify the log file contains nginx combined format entries."""
        log_file = "/var/log/webapp/access.log"
        with open(log_file, 'r') as f:
            # Read first few lines to check format
            sample_lines = [f.readline() for _ in range(10)]

        # nginx combined format should have IP, timestamp in brackets, 
        # quoted request, status code, etc.
        valid_lines = 0
        for line in sample_lines:
            if line.strip():
                # Check for typical nginx combined format markers
                has_brackets = '[' in line and ']' in line
                has_quotes = line.count('"') >= 4  # request, referer, user-agent
                has_http = 'HTTP/' in line
                if has_brackets and has_quotes and has_http:
                    valid_lines += 1

        assert valid_lines >= 5, (
            "Log file does not appear to be in nginx combined format. "
            f"Sample lines: {sample_lines[:3]}"
        )

    def test_endpoints_truth_file_exists(self):
        """The ground truth file must exist (even if not readable)."""
        truth_file = "/var/log/webapp/.endpoints_truth"
        assert os.path.exists(truth_file), (
            f"Ground truth file {truth_file} does not exist."
        )

    def test_endpoints_truth_file_not_readable(self):
        """The ground truth file should not be readable by the agent."""
        truth_file = "/var/log/webapp/.endpoints_truth"
        # Check if file has mode 000 (not readable/writable/executable)
        file_stat = os.stat(truth_file)
        mode = stat.S_IMODE(file_stat.st_mode)
        # The file should have no permissions for user (unless we're root)
        if os.geteuid() != 0:
            assert not os.access(truth_file, os.R_OK), (
                f"Ground truth file {truth_file} should not be readable by the agent."
            )

    def test_script_is_valid_python(self):
        """The script should be valid Python syntax."""
        script_path = "/home/user/docs/extract_endpoints.py"
        result = subprocess.run(
            ["python3", "-m", "py_compile", script_path],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"Script {script_path} has Python syntax errors: {result.stderr}"
        )

    def test_script_runs_without_crash(self):
        """The script should run without crashing (even if output is wrong)."""
        script_path = "/home/user/docs/extract_endpoints.py"
        result = subprocess.run(
            ["python3", script_path],
            capture_output=True,
            text=True,
            timeout=60
        )
        assert result.returncode == 0, (
            f"Script crashed with error: {result.stderr}"
        )

    def test_script_produces_847_endpoints(self):
        """The buggy script should currently report 847 endpoints."""
        script_path = "/home/user/docs/extract_endpoints.py"
        result = subprocess.run(
            ["python3", script_path],
            capture_output=True,
            text=True,
            timeout=60
        )
        output = result.stdout + result.stderr
        # The script should mention 847 somewhere in its output
        assert "847" in output, (
            f"Script should currently report 847 endpoints (the buggy count). "
            f"Actual output: {output[:500]}"
        )

    def test_logs_contain_uppercase_uuids(self):
        """Verify logs contain uppercase UUIDs (part of bug #1)."""
        log_file = "/var/log/webapp/access.log"
        result = subprocess.run(
            ["grep", "-E", "[A-F][0-9A-F]{7}-[0-9A-F]{4}-", log_file],
            capture_output=True,
            text=True
        )
        # Should find some uppercase UUIDs
        assert result.stdout.strip(), (
            "Log file should contain uppercase UUIDs to trigger bug #1."
        )

    def test_logs_contain_encoded_query_strings(self):
        """Verify logs contain %3F encoded query strings (part of bug #2)."""
        log_file = "/var/log/webapp/access.log"
        result = subprocess.run(
            ["grep", "-c", "%3F", log_file],
            capture_output=True,
            text=True
        )
        count = int(result.stdout.strip()) if result.stdout.strip() else 0
        assert count > 0, (
            "Log file should contain URLs with encoded %3F to trigger bug #2."
        )

    def test_logs_contain_double_slashes(self):
        """Verify logs contain double slashes in paths (part of bug #3)."""
        log_file = "/var/log/webapp/access.log"
        result = subprocess.run(
            ["grep", "-c", "//", log_file],
            capture_output=True,
            text=True
        )
        count = int(result.stdout.strip()) if result.stdout.strip() else 0
        assert count > 0, (
            "Log file should contain URLs with double slashes to trigger bug #3."
        )

    def test_script_uses_regex(self):
        """The script should use regex for extraction (not hardcoded)."""
        script_path = "/home/user/docs/extract_endpoints.py"
        with open(script_path, 'r') as f:
            content = f.read()

        # Should import or use re module
        uses_regex = 're.' in content or 'import re' in content or 'from re' in content
        assert uses_regex, (
            "Script should use regex (re module) for endpoint extraction."
        )

    def test_script_reads_from_var_log_webapp(self):
        """The script should read from /var/log/webapp/."""
        script_path = "/home/user/docs/extract_endpoints.py"
        with open(script_path, 'r') as f:
            content = f.read()

        assert "/var/log/webapp" in content, (
            "Script should read logs from /var/log/webapp/."
        )

    def test_python3_available(self):
        """Python 3 must be available."""
        result = subprocess.run(
            ["python3", "--version"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "Python 3 is not available."
        assert "Python 3" in result.stdout, (
            f"Expected Python 3, got: {result.stdout}"
        )
