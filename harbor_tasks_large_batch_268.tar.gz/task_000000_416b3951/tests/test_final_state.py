# test_final_state.py
"""
Tests to validate the final state after the student has fixed the
endpoint extraction script to correctly report 42 unique endpoints.
"""

import os
import re
import subprocess
import pytest


class TestFinalState:
    """Validate the final state after the task is completed."""

    def test_script_exists(self):
        """The extract_endpoints.py script must still exist."""
        script_path = "/home/user/docs/extract_endpoints.py"
        assert os.path.exists(script_path), (
            f"Script not found at {script_path}. "
            "The script should still exist after fixing."
        )

    def test_script_is_valid_python(self):
        """The script should be valid Python syntax."""
        script_path = "/home/user/docs/extract_endpoints.py"
        result = subprocess.run(
            ["python3", "-m", "py_compile", script_path],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"Script {script_path} has Python syntax errors: {result.stderr}"
        )

    def test_script_runs_without_crash(self):
        """The script should run without crashing."""
        script_path = "/home/user/docs/extract_endpoints.py"
        result = subprocess.run(
            ["python3", script_path],
            capture_output=True,
            text=True,
            timeout=120
        )
        assert result.returncode == 0, (
            f"Script crashed with return code {result.returncode}. "
            f"Stderr: {result.stderr}"
        )

    def test_script_outputs_42_endpoints(self):
        """The fixed script should report exactly 42 unique endpoints."""
        script_path = "/home/user/docs/extract_endpoints.py"
        result = subprocess.run(
            ["python3", script_path],
            capture_output=True,
            text=True,
            timeout=120
        )
        output = result.stdout + result.stderr

        # Check that "42" appears in the output (as the count)
        assert "42" in output, (
            f"Script should report 42 unique endpoints. "
            f"Actual output:\n{output}"
        )

        # Make sure it's not still reporting 847
        assert "847" not in output, (
            f"Script is still reporting the buggy count of 847. "
            f"The bugs have not been fixed. Output:\n{output}"
        )

    def test_script_still_reads_from_log_directory(self):
        """The script should still read from /var/log/webapp/."""
        script_path = "/home/user/docs/extract_endpoints.py"
        with open(script_path, 'r') as f:
            content = f.read()

        assert "/var/log/webapp" in content, (
            "Script should still read logs from /var/log/webapp/. "
            "The log path should not be changed or hardcoded to something else."
        )

    def test_script_still_uses_regex(self):
        """The script should still use regex for extraction."""
        script_path = "/home/user/docs/extract_endpoints.py"
        with open(script_path, 'r') as f:
            content = f.read()

        uses_regex = 're.' in content or 'import re' in content or 'from re' in content
        assert uses_regex, (
            "Script should still use regex (re module) for endpoint extraction. "
            "Do not replace the regex-based approach with hardcoded values."
        )

    def test_no_hardcoded_42_return(self):
        """The script should not simply hardcode 42 as the result."""
        script_path = "/home/user/docs/extract_endpoints.py"
        with open(script_path, 'r') as f:
            content = f.read()

        # Check for obvious hardcoding patterns like:
        # print(42), print("42"), return 42, return "42"
        hardcoded_patterns = [
            r'^\s*(print|return)\s*\(\s*42\s*\)\s*$',
            r'^\s*(print|return)\s*\(\s*["\']42["\']\s*\)\s*$',
            r'^\s*(print|return)\s+42\s*$',
            r'^\s*(print|return)\s+["\']42["\']\s*$',
        ]

        for pattern in hardcoded_patterns:
            matches = re.findall(pattern, content, re.MULTILINE)
            assert not matches, (
                f"Script appears to have hardcoded 42 as the result. "
                f"Pattern matched: {pattern}"
            )

    def test_no_hardcoded_endpoint_list(self):
        """The script should not contain a hardcoded list of 42 endpoints."""
        script_path = "/home/user/docs/extract_endpoints.py"
        with open(script_path, 'r') as f:
            content = f.read()

        # Look for patterns like: endpoints = ["/api/...", "/api/..."]
        # that would indicate a hardcoded list
        list_pattern = r'endpoints\s*=\s*\['
        if re.search(list_pattern, content):
            # If there's an endpoints list, it shouldn't contain hardcoded API paths
            # Check if there are multiple /api/ strings in a list context
            api_in_list = re.findall(r'endpoints\s*=\s*\[[^\]]*["\']\/api\/[^\]]*\]', content, re.DOTALL)
            assert not api_in_list, (
                "Script appears to have a hardcoded list of endpoints. "
                "The script should dynamically extract endpoints from logs."
            )

    def test_script_parameterizes_numeric_ids(self):
        """The script should still parameterize numeric IDs."""
        script_path = "/home/user/docs/extract_endpoints.py"
        with open(script_path, 'r') as f:
            content = f.read()

        # Should have some pattern for replacing numeric IDs with {id} or similar
        has_id_replacement = (
            '{id}' in content or 
            '{ID}' in content or
            r'\d+' in content or
            'id' in content.lower()
        )
        assert has_id_replacement, (
            "Script should parameterize numeric IDs (e.g., replace /users/123 with /users/{id})."
        )

    def test_script_parameterizes_uuids(self):
        """The script should still parameterize UUIDs."""
        script_path = "/home/user/docs/extract_endpoints.py"
        with open(script_path, 'r') as f:
            content = f.read()

        # Should have some pattern for UUIDs
        has_uuid_pattern = (
            'uuid' in content.lower() or
            '{uuid}' in content.lower() or
            '[0-9a-f]' in content.lower() or
            '[0-9a-fA-F]' in content.lower()
        )
        assert has_uuid_pattern, (
            "Script should parameterize UUIDs (e.g., replace with {uuid})."
        )

    def test_log_files_unchanged(self):
        """The log files in /var/log/webapp/ should not be modified."""
        log_file = "/var/log/webapp/access.log"
        assert os.path.exists(log_file), (
            f"Log file {log_file} should still exist."
        )

        # Check that it still has substantial content
        result = subprocess.run(
            ["wc", "-l", log_file],
            capture_output=True,
            text=True
        )
        line_count = int(result.stdout.split()[0])
        assert line_count >= 40000, (
            f"Log file appears to have been modified. "
            f"Expected ~50k lines, found {line_count}."
        )

    def test_output_contains_42_as_count(self):
        """Verify 42 appears as a count in the output (using grep)."""
        script_path = "/home/user/docs/extract_endpoints.py"

        # Run the script and grep for 42
        proc = subprocess.Popen(
            ["python3", script_path],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True
        )
        output, _ = proc.communicate(timeout=120)

        # Count occurrences of "42" in output
        count_42 = output.count("42")
        assert count_42 >= 1, (
            f"Output should contain '42' at least once (as the endpoint count). "
            f"Output:\n{output}"
        )

    def test_script_handles_uppercase_uuids(self):
        """Verify the script now handles uppercase UUIDs correctly."""
        script_path = "/home/user/docs/extract_endpoints.py"
        with open(script_path, 'r') as f:
            content = f.read()

        # The fix should include case-insensitive UUID matching
        # Either re.IGNORECASE, (?i), or [A-Fa-f] pattern
        handles_case = (
            'IGNORECASE' in content or
            '(?i)' in content or
            'A-F' in content or
            'a-fA-F' in content or
            'A-Fa-f' in content or
            '.lower()' in content or
            '.upper()' in content
        )
        assert handles_case, (
            "Script should handle uppercase UUIDs. "
            "Consider using re.IGNORECASE or [a-fA-F] in UUID pattern, "
            "or normalizing case before matching."
        )

    def test_endpoint_count_is_reasonable(self):
        """The endpoint count should be in the expected range (35-50)."""
        script_path = "/home/user/docs/extract_endpoints.py"
        result = subprocess.run(
            ["python3", script_path],
            capture_output=True,
            text=True,
            timeout=120
        )
        output = result.stdout + result.stderr

        # Try to extract numbers from the output
        numbers = re.findall(r'\b(\d+)\b', output)

        # Check if 42 is among the numbers found
        assert '42' in numbers, (
            f"Expected to find 42 as a count in the output. "
            f"Numbers found: {numbers}. "
            f"Full output:\n{output}"
        )

    def test_script_not_trivially_broken(self):
        """Ensure the script actually processes logs and doesn't just print 42."""
        script_path = "/home/user/docs/extract_endpoints.py"
        with open(script_path, 'r') as f:
            content = f.read()

        # Script should have file reading logic
        has_file_ops = (
            'open(' in content or
            'glob' in content or
            'read' in content
        )
        assert has_file_ops, (
            "Script should read files from the log directory."
        )

        # Script should have some form of collection/set for unique endpoints
        has_collection = (
            'set(' in content or
            'Set(' in content or
            '= set' in content or
            '= {}' in content or
            'dict(' in content or
            '.add(' in content or
            'unique' in content.lower()
        )
        assert has_collection, (
            "Script should use a set or similar structure to track unique endpoints."
        )
