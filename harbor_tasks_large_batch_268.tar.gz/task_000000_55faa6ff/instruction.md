I need to add a new env var to /home/user/webapp/.env — key is `CACHE_TTL`, value should be `3600`. The app loads from that file on startup. Don't touch the existing vars in there.
