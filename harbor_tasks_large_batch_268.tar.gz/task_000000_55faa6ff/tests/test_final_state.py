# test_final_state.py
"""
Tests to validate the final state of the OS/filesystem after the student
has completed the task of adding CACHE_TTL=3600 to /home/user/webapp/.env
"""

import os
import subprocess
import pytest


ENV_FILE_PATH = "/home/user/webapp/.env"

# Expected variables (original + new)
EXPECTED_VARS = {
    "DATABASE_URL": "postgres://localhost:5432/myapp",
    "REDIS_HOST": "127.0.0.1",
    "DEBUG": "false",
    "API_KEY": "sk-abc123xyz",
    "CACHE_TTL": "3600",
}


class TestFinalState:
    """Test the final state after the task is performed."""

    def test_env_file_exists(self):
        """Verify the .env file still exists."""
        assert os.path.isfile(ENV_FILE_PATH), (
            f"File {ENV_FILE_PATH} does not exist. "
            "The .env file must still be present after the task."
        )

    def test_cache_ttl_present_exactly_once(self):
        """Verify CACHE_TTL=3600 is present exactly once."""
        result = subprocess.run(
            ["grep", "-c", "^CACHE_TTL=3600$", ENV_FILE_PATH],
            capture_output=True,
            text=True
        )
        count = int(result.stdout.strip()) if result.returncode == 0 else 0
        assert count == 1, (
            f"Expected exactly 1 line matching '^CACHE_TTL=3600$' in {ENV_FILE_PATH}, "
            f"but found {count}. The CACHE_TTL variable must be added with value 3600."
        )

    def test_database_url_preserved(self):
        """Verify DATABASE_URL is still present with original value."""
        result = subprocess.run(
            ["grep", "-c", "^DATABASE_URL=postgres://localhost:5432/myapp$", ENV_FILE_PATH],
            capture_output=True,
            text=True
        )
        count = int(result.stdout.strip()) if result.returncode == 0 else 0
        assert count == 1, (
            f"Expected exactly 1 line matching '^DATABASE_URL=postgres://localhost:5432/myapp$' "
            f"in {ENV_FILE_PATH}, but found {count}. "
            "The DATABASE_URL variable must be preserved with its original value."
        )

    def test_redis_host_preserved(self):
        """Verify REDIS_HOST is still present with original value."""
        result = subprocess.run(
            ["grep", "-c", "^REDIS_HOST=127.0.0.1$", ENV_FILE_PATH],
            capture_output=True,
            text=True
        )
        count = int(result.stdout.strip()) if result.returncode == 0 else 0
        assert count == 1, (
            f"Expected exactly 1 line matching '^REDIS_HOST=127.0.0.1$' "
            f"in {ENV_FILE_PATH}, but found {count}. "
            "The REDIS_HOST variable must be preserved with its original value."
        )

    def test_debug_preserved(self):
        """Verify DEBUG is still present with original value."""
        result = subprocess.run(
            ["grep", "-c", "^DEBUG=false$", ENV_FILE_PATH],
            capture_output=True,
            text=True
        )
        count = int(result.stdout.strip()) if result.returncode == 0 else 0
        assert count == 1, (
            f"Expected exactly 1 line matching '^DEBUG=false$' "
            f"in {ENV_FILE_PATH}, but found {count}. "
            "The DEBUG variable must be preserved with its original value."
        )

    def test_api_key_preserved(self):
        """Verify API_KEY is still present with original value."""
        result = subprocess.run(
            ["grep", "-c", "^API_KEY=sk-abc123xyz$", ENV_FILE_PATH],
            capture_output=True,
            text=True
        )
        count = int(result.stdout.strip()) if result.returncode == 0 else 0
        assert count == 1, (
            f"Expected exactly 1 line matching '^API_KEY=sk-abc123xyz$' "
            f"in {ENV_FILE_PATH}, but found {count}. "
            "The API_KEY variable must be preserved with its original value."
        )

    def test_no_duplicate_cache_ttl(self):
        """Verify there are no duplicate CACHE_TTL entries."""
        with open(ENV_FILE_PATH, "r") as f:
            content = f.read()

        # Count all lines that start with CACHE_TTL=
        lines = content.splitlines()
        cache_ttl_count = sum(1 for line in lines if line.startswith("CACHE_TTL="))

        assert cache_ttl_count == 1, (
            f"Expected exactly 1 CACHE_TTL entry in {ENV_FILE_PATH}, "
            f"but found {cache_ttl_count}. There should be no duplicate CACHE_TTL entries."
        )

    def test_env_file_valid_format(self):
        """Verify all non-empty lines in .env are valid KEY=value format."""
        with open(ENV_FILE_PATH, "r") as f:
            lines = f.readlines()

        for i, line in enumerate(lines, 1):
            stripped = line.strip()
            if stripped:  # Skip empty lines
                assert "=" in stripped, (
                    f"Line {i} in {ENV_FILE_PATH} is not valid dotenv format: '{stripped}'. "
                    "Each line should be KEY=value format."
                )
                key = stripped.split("=", 1)[0]
                assert key.replace("_", "").isalnum(), (
                    f"Line {i} in {ENV_FILE_PATH} has invalid key: '{key}'. "
                    "Keys should be alphanumeric with underscores."
                )

    def test_all_expected_variables_present(self):
        """Verify all 5 expected variables are present in the file."""
        with open(ENV_FILE_PATH, "r") as f:
            content = f.read()

        # Parse the env file into a dictionary
        parsed_vars = {}
        for line in content.splitlines():
            stripped = line.strip()
            if stripped and "=" in stripped:
                key, value = stripped.split("=", 1)
                parsed_vars[key] = value

        for key, expected_value in EXPECTED_VARS.items():
            assert key in parsed_vars, (
                f"Variable '{key}' is missing from {ENV_FILE_PATH}. "
                f"Expected to find {key}={expected_value}."
            )
            assert parsed_vars[key] == expected_value, (
                f"Variable '{key}' has wrong value in {ENV_FILE_PATH}. "
                f"Expected '{expected_value}', but found '{parsed_vars[key]}'."
            )

    def test_exactly_five_variables(self):
        """Verify the .env file has exactly 5 environment variables."""
        with open(ENV_FILE_PATH, "r") as f:
            lines = f.readlines()

        # Count non-empty lines that look like KEY=value
        var_lines = [line for line in lines if line.strip() and "=" in line.strip()]

        assert len(var_lines) == 5, (
            f"Expected exactly 5 environment variables in {ENV_FILE_PATH}, "
            f"but found {len(var_lines)}. "
            "The file should have DATABASE_URL, REDIS_HOST, DEBUG, API_KEY, and CACHE_TTL."
        )
