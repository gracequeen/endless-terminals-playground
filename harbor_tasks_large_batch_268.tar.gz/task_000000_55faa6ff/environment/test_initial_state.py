# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the task of adding CACHE_TTL=3600 to /home/user/webapp/.env
"""

import os
import pytest


ENV_FILE_PATH = "/home/user/webapp/.env"
WEBAPP_DIR = "/home/user/webapp"

# Expected initial content (original variables)
EXPECTED_VARS = {
    "DATABASE_URL": "postgres://localhost:5432/myapp",
    "REDIS_HOST": "127.0.0.1",
    "DEBUG": "false",
    "API_KEY": "sk-abc123xyz",
}


class TestInitialState:
    """Test the initial state before the task is performed."""

    def test_webapp_directory_exists(self):
        """Verify the webapp directory exists."""
        assert os.path.isdir(WEBAPP_DIR), (
            f"Directory {WEBAPP_DIR} does not exist. "
            "The webapp directory must be present before the task."
        )

    def test_env_file_exists(self):
        """Verify the .env file exists."""
        assert os.path.isfile(ENV_FILE_PATH), (
            f"File {ENV_FILE_PATH} does not exist. "
            "The .env file must be present before the task."
        )

    def test_env_file_is_readable(self):
        """Verify the .env file is readable."""
        assert os.access(ENV_FILE_PATH, os.R_OK), (
            f"File {ENV_FILE_PATH} is not readable. "
            "The .env file must be readable."
        )

    def test_env_file_is_writable(self):
        """Verify the .env file is writable by the current user."""
        assert os.access(ENV_FILE_PATH, os.W_OK), (
            f"File {ENV_FILE_PATH} is not writable. "
            "The .env file must be writable for the task."
        )

    def test_env_file_contains_database_url(self):
        """Verify DATABASE_URL variable is present with correct value."""
        with open(ENV_FILE_PATH, "r") as f:
            content = f.read()

        expected_line = f"DATABASE_URL={EXPECTED_VARS['DATABASE_URL']}"
        assert expected_line in content, (
            f"Expected line '{expected_line}' not found in {ENV_FILE_PATH}. "
            "The DATABASE_URL variable must be present in the initial state."
        )

    def test_env_file_contains_redis_host(self):
        """Verify REDIS_HOST variable is present with correct value."""
        with open(ENV_FILE_PATH, "r") as f:
            content = f.read()

        expected_line = f"REDIS_HOST={EXPECTED_VARS['REDIS_HOST']}"
        assert expected_line in content, (
            f"Expected line '{expected_line}' not found in {ENV_FILE_PATH}. "
            "The REDIS_HOST variable must be present in the initial state."
        )

    def test_env_file_contains_debug(self):
        """Verify DEBUG variable is present with correct value."""
        with open(ENV_FILE_PATH, "r") as f:
            content = f.read()

        expected_line = f"DEBUG={EXPECTED_VARS['DEBUG']}"
        assert expected_line in content, (
            f"Expected line '{expected_line}' not found in {ENV_FILE_PATH}. "
            "The DEBUG variable must be present in the initial state."
        )

    def test_env_file_contains_api_key(self):
        """Verify API_KEY variable is present with correct value."""
        with open(ENV_FILE_PATH, "r") as f:
            content = f.read()

        expected_line = f"API_KEY={EXPECTED_VARS['API_KEY']}"
        assert expected_line in content, (
            f"Expected line '{expected_line}' not found in {ENV_FILE_PATH}. "
            "The API_KEY variable must be present in the initial state."
        )

    def test_env_file_has_exactly_four_variables(self):
        """Verify the .env file has exactly 4 non-empty lines (the original vars)."""
        with open(ENV_FILE_PATH, "r") as f:
            lines = f.readlines()

        # Count non-empty lines that look like KEY=value
        var_lines = [line for line in lines if line.strip() and "=" in line]

        assert len(var_lines) == 4, (
            f"Expected exactly 4 environment variables in {ENV_FILE_PATH}, "
            f"but found {len(var_lines)}. "
            "The initial state should have DATABASE_URL, REDIS_HOST, DEBUG, and API_KEY only."
        )

    def test_cache_ttl_not_present(self):
        """Verify CACHE_TTL is NOT present in the initial state."""
        with open(ENV_FILE_PATH, "r") as f:
            content = f.read()

        assert "CACHE_TTL" not in content, (
            f"CACHE_TTL should NOT be present in {ENV_FILE_PATH} in the initial state. "
            "The task is to ADD this variable."
        )

    def test_env_file_no_trailing_newline(self):
        """Verify the .env file has no trailing newline (as per initial state spec)."""
        with open(ENV_FILE_PATH, "rb") as f:
            content = f.read()

        # Check that the file doesn't end with a newline
        assert not content.endswith(b"\n\n"), (
            f"File {ENV_FILE_PATH} has multiple trailing newlines. "
            "Initial state should have no trailing newline."
        )

    def test_env_file_valid_format(self):
        """Verify all lines in .env are valid KEY=value format."""
        with open(ENV_FILE_PATH, "r") as f:
            lines = f.readlines()

        for i, line in enumerate(lines, 1):
            stripped = line.strip()
            if stripped:  # Skip empty lines
                assert "=" in stripped, (
                    f"Line {i} in {ENV_FILE_PATH} is not valid dotenv format: '{stripped}'. "
                    "Each line should be KEY=value format."
                )
                key = stripped.split("=", 1)[0]
                assert key.replace("_", "").isalnum(), (
                    f"Line {i} in {ENV_FILE_PATH} has invalid key: '{key}'. "
                    "Keys should be alphanumeric with underscores."
                )
