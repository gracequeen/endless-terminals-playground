# test_final_state.py
"""
Tests to validate the final state after the student has completed the CSV merge task.
Verifies that the merge script works correctly and produces exactly 847 matched rows.
"""

import pytest
import os
import subprocess
import csv
import re


class TestMergeScriptExecution:
    """Test that the merge script executes successfully."""

    def test_merge_script_exists(self):
        """The merge.py script must exist."""
        assert os.path.isfile('/home/user/data/merge.py'), \
            "File /home/user/data/merge.py does not exist"

    def test_merge_script_exits_zero(self):
        """Running merge.py should exit with code 0."""
        result = subprocess.run(
            ['python3', '/home/user/data/merge.py'],
            capture_output=True,
            text=True,
            cwd='/home/user/data'
        )
        assert result.returncode == 0, \
            f"merge.py exited with code {result.returncode}.\n" \
            f"stdout: {result.stdout}\nstderr: {result.stderr}"

    def test_merge_script_reports_847_matches(self):
        """The merge script should report matching 847 rows."""
        result = subprocess.run(
            ['python3', '/home/user/data/merge.py'],
            capture_output=True,
            text=True,
            cwd='/home/user/data'
        )

        output = result.stdout + result.stderr
        # Look for a number around 847 in the output
        match = re.search(r'(\d+)', output)
        if match:
            count = int(match.group(1))
            assert count == 847, \
                f"Script reports {count} matches, expected exactly 847.\n" \
                f"Output: {output}"
        else:
            # If no number found, just check that 847 appears somewhere
            assert '847' in output, \
                f"Script output doesn't indicate 847 matches.\nOutput: {output}"


class TestMergedCSVExists:
    """Test that the merged CSV output file exists and is valid."""

    def test_merged_csv_exists(self):
        """The merged.csv file must exist."""
        assert os.path.isfile('/home/user/data/merged.csv'), \
            "File /home/user/data/merged.csv does not exist. " \
            "The merge script should create this file."

    def test_merged_csv_is_readable(self):
        """The merged.csv file must be readable."""
        assert os.access('/home/user/data/merged.csv', os.R_OK), \
            "File /home/user/data/merged.csv is not readable"

    def test_merged_csv_is_valid_csv(self):
        """The merged.csv file must be a valid CSV."""
        try:
            with open('/home/user/data/merged.csv', 'r', newline='') as f:
                reader = csv.reader(f)
                rows = list(reader)
            assert len(rows) > 0, "merged.csv is empty"
        except csv.Error as e:
            pytest.fail(f"merged.csv is not a valid CSV: {e}")


class TestMergedCSVRowCount:
    """Test that the merged CSV has exactly 847 data rows."""

    def test_merged_csv_has_847_data_rows(self):
        """merged.csv must have exactly 847 data rows (848 total with header)."""
        with open('/home/user/data/merged.csv', 'r', newline='') as f:
            reader = csv.reader(f)
            rows = list(reader)

        # Total rows should be 848 (1 header + 847 data)
        total_rows = len(rows)
        data_rows = total_rows - 1  # Subtract header

        assert data_rows == 847, \
            f"merged.csv has {data_rows} data rows, expected exactly 847. " \
            f"Total lines (including header): {total_rows}"

    def test_merged_csv_line_count_with_grep(self):
        """Verify row count using grep -c (848 lines total)."""
        result = subprocess.run(
            ['grep', '-c', '^', '/home/user/data/merged.csv'],
            capture_output=True,
            text=True
        )

        if result.returncode == 0:
            line_count = int(result.stdout.strip())
            assert line_count == 848, \
                f"grep -c reports {line_count} lines, expected 848 (847 data + 1 header)"


class TestMergedCSVStructure:
    """Test that the merged CSV has the expected column structure."""

    def test_merged_csv_has_sale_id_column(self):
        """merged.csv must have a sale_id column."""
        with open('/home/user/data/merged.csv', 'r', newline='') as f:
            reader = csv.reader(f)
            headers = next(reader)

        # Check for sale_id (might be just 'sale_id' or could have suffix)
        has_sale_id = any('sale_id' in h.lower() for h in headers)
        assert has_sale_id, \
            f"merged.csv doesn't have a sale_id column. Headers: {headers}"

    def test_merged_csv_has_amount_columns_from_both_sources(self):
        """merged.csv must have amount columns from both US and DE sources."""
        with open('/home/user/data/merged.csv', 'r', newline='') as f:
            reader = csv.reader(f)
            headers = next(reader)

        headers_lower = [h.lower() for h in headers]

        # Check for USD amount
        has_usd = any('usd' in h or 'amount_us' in h for h in headers_lower)
        # Check for EUR amount  
        has_eur = any('eur' in h or 'amount_de' in h for h in headers_lower)

        assert has_usd, \
            f"merged.csv doesn't have a USD amount column. Headers: {headers}"
        assert has_eur, \
            f"merged.csv doesn't have a EUR amount column. Headers: {headers}"

    def test_merged_csv_has_product_code_columns(self):
        """merged.csv must have product_code column(s)."""
        with open('/home/user/data/merged.csv', 'r', newline='') as f:
            reader = csv.reader(f)
            headers = next(reader)

        has_product_code = any('product_code' in h.lower() for h in headers)
        assert has_product_code, \
            f"merged.csv doesn't have a product_code column. Headers: {headers}"

    def test_merged_csv_has_sale_time_column(self):
        """merged.csv must have sale_time column(s)."""
        with open('/home/user/data/merged.csv', 'r', newline='') as f:
            reader = csv.reader(f)
            headers = next(reader)

        has_sale_time = any('sale_time' in h.lower() or 'time' in h.lower() for h in headers)
        assert has_sale_time, \
            f"merged.csv doesn't have a sale_time column. Headers: {headers}"


class TestMergedCSVContent:
    """Test that the merged CSV content is valid."""

    def test_merged_csv_sale_ids_are_valid(self):
        """All sale_id values in merged.csv should be non-empty."""
        with open('/home/user/data/merged.csv', 'r', newline='') as f:
            reader = csv.DictReader(f)
            headers = reader.fieldnames

            # Find the sale_id column (might have suffix)
            sale_id_col = None
            for h in headers:
                if 'sale_id' in h.lower():
                    sale_id_col = h
                    break

            if sale_id_col:
                for i, row in enumerate(reader):
                    sale_id = row[sale_id_col]
                    assert sale_id and sale_id.strip(), \
                        f"Row {i+1} has empty sale_id"

    def test_merged_csv_has_no_empty_rows(self):
        """merged.csv should not have empty rows."""
        with open('/home/user/data/merged.csv', 'r', newline='') as f:
            reader = csv.reader(f)
            next(reader)  # Skip header

            for i, row in enumerate(reader):
                # Check that row has content
                non_empty_cells = [cell for cell in row if cell.strip()]
                assert len(non_empty_cells) > 0, \
                    f"Row {i+1} appears to be empty"


class TestOriginalFilesUnchanged:
    """Test that the original source files were not modified."""

    def test_us_csv_still_has_1200_rows(self):
        """sales_us.csv should still have 1200 data rows."""
        with open('/home/user/data/sales_us.csv', 'r', newline='') as f:
            reader = csv.reader(f)
            next(reader)  # Skip header
            row_count = sum(1 for _ in reader)

        assert row_count == 1200, \
            f"sales_us.csv now has {row_count} rows, expected 1200. " \
            "Original file should not be modified."

    def test_de_csv_still_has_1100_rows(self):
        """sales_de.csv should still have 1100 data rows."""
        with open('/home/user/data/sales_de.csv', 'r', newline='') as f:
            reader = csv.reader(f)
            next(reader)  # Skip header
            row_count = sum(1 for _ in reader)

        assert row_count == 1100, \
            f"sales_de.csv now has {row_count} rows, expected 1100. " \
            "Original file should not be modified."

    def test_us_csv_headers_unchanged(self):
        """sales_us.csv headers should be unchanged."""
        with open('/home/user/data/sales_us.csv', 'r', newline='') as f:
            reader = csv.reader(f)
            headers = next(reader)

        expected = ['sale_id', 'sale_time', 'amount_usd', 'product_code']
        assert headers == expected, \
            f"sales_us.csv headers changed from {expected} to {headers}"

    def test_de_csv_headers_unchanged(self):
        """sales_de.csv headers should be unchanged."""
        with open('/home/user/data/sales_de.csv', 'r', newline='') as f:
            reader = csv.reader(f)
            headers = next(reader)

        expected = ['sale_id', 'sale_time', 'amount_eur', 'product_code']
        assert headers == expected, \
            f"sales_de.csv headers changed from {expected} to {headers}"


class TestMergeQuality:
    """Test that the merge was done correctly based on temporal equivalence."""

    def test_merged_sale_ids_exist_in_both_sources(self):
        """All sale_ids in merged.csv should exist in both source files."""
        # Load source sale_ids
        with open('/home/user/data/sales_us.csv', 'r', newline='') as f:
            reader = csv.DictReader(f)
            us_sale_ids = set(row['sale_id'] for row in reader)

        with open('/home/user/data/sales_de.csv', 'r', newline='') as f:
            reader = csv.DictReader(f)
            de_sale_ids = set(row['sale_id'] for row in reader)

        # Load merged sale_ids
        with open('/home/user/data/merged.csv', 'r', newline='') as f:
            reader = csv.DictReader(f)
            headers = reader.fieldnames

            # Find sale_id column
            sale_id_col = None
            for h in headers:
                if 'sale_id' in h.lower():
                    sale_id_col = h
                    break

            if sale_id_col:
                merged_sale_ids = set(row[sale_id_col] for row in reader)

                # Check that all merged IDs exist in both sources
                for sale_id in list(merged_sale_ids)[:100]:  # Sample check
                    assert sale_id in us_sale_ids, \
                        f"sale_id {sale_id} in merged.csv not found in sales_us.csv"
                    assert sale_id in de_sale_ids, \
                        f"sale_id {sale_id} in merged.csv not found in sales_de.csv"

    def test_row_count_not_achievable_by_sale_id_only_merge(self):
        """
        Verify the merge used temporal equivalence, not just sale_id matching.
        A sale_id-only merge would give ~950 rows, not 847.
        """
        # Count how many sale_ids appear in both files
        with open('/home/user/data/sales_us.csv', 'r', newline='') as f:
            reader = csv.DictReader(f)
            us_sale_ids = set(row['sale_id'] for row in reader)

        with open('/home/user/data/sales_de.csv', 'r', newline='') as f:
            reader = csv.DictReader(f)
            de_sale_ids = set(row['sale_id'] for row in reader)

        common_ids = us_sale_ids & de_sale_ids

        # The number of common IDs should be different from 847
        # (it should be around 950 based on the task description)
        # This verifies that temporal matching was required
        with open('/home/user/data/merged.csv', 'r', newline='') as f:
            reader = csv.reader(f)
            next(reader)  # Skip header
            merged_count = sum(1 for _ in reader)

        assert merged_count == 847, \
            f"Merged file has {merged_count} rows, expected exactly 847. " \
            f"Number of common sale_ids between files: {len(common_ids)}. " \
            "The merge must use temporal equivalence (same UTC instant), not just sale_id."


class TestReproducibility:
    """Test that running the script again produces the same results."""

    def test_script_is_reproducible(self):
        """Running merge.py multiple times should produce consistent results."""
        # Run the script
        result1 = subprocess.run(
            ['python3', '/home/user/data/merge.py'],
            capture_output=True,
            text=True,
            cwd='/home/user/data'
        )

        # Count rows after first run
        with open('/home/user/data/merged.csv', 'r', newline='') as f:
            reader = csv.reader(f)
            count1 = sum(1 for _ in reader) - 1  # Subtract header

        # Run again
        result2 = subprocess.run(
            ['python3', '/home/user/data/merge.py'],
            capture_output=True,
            text=True,
            cwd='/home/user/data'
        )

        # Count rows after second run
        with open('/home/user/data/merged.csv', 'r', newline='') as f:
            reader = csv.reader(f)
            count2 = sum(1 for _ in reader) - 1  # Subtract header

        assert count1 == count2 == 847, \
            f"Script is not reproducible. First run: {count1} rows, Second run: {count2} rows. " \
            "Expected 847 rows each time."
