# test_initial_state.py
"""
Tests to validate the initial state before the student performs the CSV merge task.
Verifies the presence and structure of input files, the merge script, and required dependencies.
"""

import pytest
import os
import subprocess
import csv
import re


class TestDirectoryStructure:
    """Test that required directories exist."""

    def test_data_directory_exists(self):
        """The /home/user/data directory must exist."""
        assert os.path.isdir('/home/user/data'), \
            "Directory /home/user/data does not exist"

    def test_data_directory_is_writable(self):
        """The /home/user/data directory must be writable."""
        assert os.access('/home/user/data', os.W_OK), \
            "Directory /home/user/data is not writable"


class TestUSCSVFile:
    """Test the US sales CSV file exists and has correct structure."""

    def test_us_csv_exists(self):
        """The US sales CSV file must exist."""
        assert os.path.isfile('/home/user/data/sales_us.csv'), \
            "File /home/user/data/sales_us.csv does not exist"

    def test_us_csv_is_readable(self):
        """The US sales CSV file must be readable."""
        assert os.access('/home/user/data/sales_us.csv', os.R_OK), \
            "File /home/user/data/sales_us.csv is not readable"

    def test_us_csv_has_correct_headers(self):
        """The US CSV must have the expected columns."""
        with open('/home/user/data/sales_us.csv', 'r', newline='') as f:
            reader = csv.reader(f)
            headers = next(reader)

        expected_headers = ['sale_id', 'sale_time', 'amount_usd', 'product_code']
        assert headers == expected_headers, \
            f"US CSV headers are {headers}, expected {expected_headers}"

    def test_us_csv_has_1200_data_rows(self):
        """The US CSV must have exactly 1200 data rows."""
        with open('/home/user/data/sales_us.csv', 'r', newline='') as f:
            reader = csv.reader(f)
            next(reader)  # Skip header
            row_count = sum(1 for _ in reader)

        assert row_count == 1200, \
            f"US CSV has {row_count} data rows, expected 1200"

    def test_us_csv_timestamps_are_iso8601_with_timezone(self):
        """US CSV timestamps should be ISO 8601 with timezone offset."""
        # Pattern for ISO 8601 with timezone: YYYY-MM-DDTHH:MM:SS±HH:MM
        iso_pattern = re.compile(r'^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}[+-]\d{2}:\d{2}$')

        with open('/home/user/data/sales_us.csv', 'r', newline='') as f:
            reader = csv.DictReader(f)
            sample_count = 0
            valid_count = 0
            for row in reader:
                if sample_count >= 50:  # Check first 50 rows
                    break
                sample_count += 1
                if iso_pattern.match(row['sale_time']):
                    valid_count += 1

        assert valid_count == sample_count, \
            f"US CSV timestamps don't match expected ISO 8601 format with hyphen separators. " \
            f"Only {valid_count}/{sample_count} sampled rows matched pattern YYYY-MM-DDTHH:MM:SS±HH:MM"

    def test_us_csv_uses_period_decimal_separator(self):
        """US CSV amount_usd should use period as decimal separator."""
        with open('/home/user/data/sales_us.csv', 'r', newline='') as f:
            reader = csv.DictReader(f)
            for row in reader:
                amount = row['amount_usd']
                # Should contain period, not comma for decimal
                if ',' in amount:
                    pytest.fail(f"US CSV uses comma in amount_usd: {amount}")
                break  # Just check first row


class TestDECSVFile:
    """Test the German sales CSV file exists and has correct structure."""

    def test_de_csv_exists(self):
        """The German sales CSV file must exist."""
        assert os.path.isfile('/home/user/data/sales_de.csv'), \
            "File /home/user/data/sales_de.csv does not exist"

    def test_de_csv_is_readable(self):
        """The German sales CSV file must be readable."""
        assert os.access('/home/user/data/sales_de.csv', os.R_OK), \
            "File /home/user/data/sales_de.csv is not readable"

    def test_de_csv_has_correct_headers(self):
        """The German CSV must have the expected columns."""
        with open('/home/user/data/sales_de.csv', 'r', newline='') as f:
            reader = csv.reader(f)
            headers = next(reader)

        expected_headers = ['sale_id', 'sale_time', 'amount_eur', 'product_code']
        assert headers == expected_headers, \
            f"German CSV headers are {headers}, expected {expected_headers}"

    def test_de_csv_has_1100_data_rows(self):
        """The German CSV must have exactly 1100 data rows."""
        with open('/home/user/data/sales_de.csv', 'r', newline='') as f:
            reader = csv.reader(f)
            next(reader)  # Skip header
            row_count = sum(1 for _ in reader)

        assert row_count == 1100, \
            f"German CSV has {row_count} data rows, expected 1100"

    def test_de_csv_timestamps_use_period_date_separator(self):
        """German CSV timestamps should use period as date separator (the bug)."""
        # Pattern for German-style dates: YYYY.MM.DDTHH:MM:SS...
        de_date_pattern = re.compile(r'^\d{4}\.\d{2}\.\d{2}T')

        with open('/home/user/data/sales_de.csv', 'r', newline='') as f:
            reader = csv.DictReader(f)
            sample_count = 0
            valid_count = 0
            for row in reader:
                if sample_count >= 50:  # Check first 50 rows
                    break
                sample_count += 1
                if de_date_pattern.match(row['sale_time']):
                    valid_count += 1

        assert valid_count == sample_count, \
            f"German CSV timestamps don't have period date separators as expected. " \
            f"Only {valid_count}/{sample_count} sampled rows matched pattern YYYY.MM.DD..."

    def test_de_csv_uses_comma_decimal_separator_in_amount(self):
        """German CSV amount_eur should use comma as decimal separator."""
        with open('/home/user/data/sales_de.csv', 'r', newline='') as f:
            reader = csv.DictReader(f)
            found_comma = False
            for i, row in enumerate(reader):
                if i >= 50:
                    break
                amount = row['amount_eur']
                if ',' in amount:
                    found_comma = True
                    break

        assert found_comma, \
            "German CSV amount_eur doesn't appear to use comma as decimal separator"


class TestMergeScript:
    """Test the merge script exists and has expected content."""

    def test_merge_script_exists(self):
        """The merge.py script must exist."""
        assert os.path.isfile('/home/user/data/merge.py'), \
            "File /home/user/data/merge.py does not exist"

    def test_merge_script_is_readable(self):
        """The merge.py script must be readable."""
        assert os.access('/home/user/data/merge.py', os.R_OK), \
            "File /home/user/data/merge.py is not readable"

    def test_merge_script_uses_pandas(self):
        """The merge script should import pandas."""
        with open('/home/user/data/merge.py', 'r') as f:
            content = f.read()

        assert 'import pandas' in content or 'from pandas' in content, \
            "merge.py doesn't appear to use pandas"

    def test_merge_script_reads_both_csv_files(self):
        """The merge script should reference both CSV files."""
        with open('/home/user/data/merge.py', 'r') as f:
            content = f.read()

        assert 'sales_us.csv' in content, \
            "merge.py doesn't reference sales_us.csv"
        assert 'sales_de.csv' in content, \
            "merge.py doesn't reference sales_de.csv"

    def test_merge_script_outputs_to_merged_csv(self):
        """The merge script should output to merged.csv."""
        with open('/home/user/data/merge.py', 'r') as f:
            content = f.read()

        assert 'merged.csv' in content, \
            "merge.py doesn't reference merged.csv output file"


class TestPythonDependencies:
    """Test that required Python packages are installed."""

    def test_python3_available(self):
        """Python 3 must be available."""
        result = subprocess.run(['python3', '--version'], capture_output=True, text=True)
        assert result.returncode == 0, \
            "python3 is not available"
        assert 'Python 3' in result.stdout, \
            f"Unexpected python version: {result.stdout}"

    def test_pandas_installed(self):
        """pandas must be installed."""
        result = subprocess.run(
            ['python3', '-c', 'import pandas; print(pandas.__version__)'],
            capture_output=True, text=True
        )
        assert result.returncode == 0, \
            f"pandas is not installed: {result.stderr}"

    def test_pandas_version_2_or_higher(self):
        """pandas version should be 2.0+."""
        result = subprocess.run(
            ['python3', '-c', 'import pandas; print(pandas.__version__)'],
            capture_output=True, text=True
        )
        if result.returncode == 0:
            version = result.stdout.strip()
            major_version = int(version.split('.')[0])
            assert major_version >= 2, \
                f"pandas version is {version}, expected 2.0+"

    def test_pytz_installed(self):
        """pytz must be installed."""
        result = subprocess.run(
            ['python3', '-c', 'import pytz'],
            capture_output=True, text=True
        )
        assert result.returncode == 0, \
            f"pytz is not installed: {result.stderr}"

    def test_dateutil_installed(self):
        """python-dateutil must be installed."""
        result = subprocess.run(
            ['python3', '-c', 'import dateutil'],
            capture_output=True, text=True
        )
        assert result.returncode == 0, \
            f"python-dateutil is not installed: {result.stderr}"


class TestMergedCSVNotExists:
    """Test that the output file doesn't exist yet (student needs to create it)."""

    def test_merged_csv_does_not_exist(self):
        """The merged.csv output file should not exist initially."""
        # This is actually checking that the task hasn't been completed yet
        # It's okay if it exists, but we note it
        if os.path.exists('/home/user/data/merged.csv'):
            # File exists - this might be from a previous attempt
            # We don't fail, but we note it
            pass  # Allow this state


class TestCurrentMergeScriptBehavior:
    """Test that the current merge script produces incorrect results (the bug)."""

    def test_current_script_produces_few_matches(self):
        """Running the current merge.py should produce far fewer than 847 matches."""
        # Run the current script
        result = subprocess.run(
            ['python3', '/home/user/data/merge.py'],
            capture_output=True, text=True,
            cwd='/home/user/data'
        )

        # The script might error or produce few matches
        # We're checking that it doesn't already produce 847 matches
        if result.returncode == 0:
            # Look for the match count in output
            output = result.stdout + result.stderr
            match = re.search(r'Matched\s+(\d+)\s+rows', output)
            if match:
                count = int(match.group(1))
                assert count < 847, \
                    f"Current script already produces {count} matches (expected < 847). " \
                    "The bug may have already been fixed."

        # Clean up any merged.csv created by this test
        if os.path.exists('/home/user/data/merged.csv'):
            os.remove('/home/user/data/merged.csv')
