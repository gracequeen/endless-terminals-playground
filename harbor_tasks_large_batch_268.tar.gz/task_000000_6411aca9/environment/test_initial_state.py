# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the version bump and changelog update task.
"""

import os
import pytest


class TestInitialState:
    """Tests to verify the initial state before the task is performed."""

    def test_datasets_directory_exists(self):
        """Verify /home/user/datasets directory exists."""
        path = "/home/user/datasets"
        assert os.path.isdir(path), f"Directory {path} does not exist"

    def test_datasets_directory_writable(self):
        """Verify /home/user/datasets is writable."""
        path = "/home/user/datasets"
        assert os.access(path, os.W_OK), f"Directory {path} is not writable"

    def test_pyproject_toml_exists(self):
        """Verify pyproject.toml exists in the datasets directory."""
        path = "/home/user/datasets/pyproject.toml"
        assert os.path.isfile(path), f"File {path} does not exist"

    def test_pyproject_toml_readable(self):
        """Verify pyproject.toml is readable."""
        path = "/home/user/datasets/pyproject.toml"
        assert os.access(path, os.R_OK), f"File {path} is not readable"

    def test_pyproject_toml_contains_project_section(self):
        """Verify pyproject.toml contains [project] section."""
        path = "/home/user/datasets/pyproject.toml"
        with open(path, 'r') as f:
            content = f.read()
        assert "[project]" in content, f"File {path} does not contain [project] section"

    def test_pyproject_toml_contains_name(self):
        """Verify pyproject.toml contains the project name."""
        path = "/home/user/datasets/pyproject.toml"
        with open(path, 'r') as f:
            content = f.read()
        assert 'name = "annotation-toolkit"' in content, \
            f"File {path} does not contain expected project name 'annotation-toolkit'"

    def test_pyproject_toml_contains_version_0_4_2(self):
        """Verify pyproject.toml contains version = '0.4.2' (the version to be bumped)."""
        path = "/home/user/datasets/pyproject.toml"
        with open(path, 'r') as f:
            content = f.read()
        assert 'version = "0.4.2"' in content, \
            f"File {path} does not contain version = \"0.4.2\". Current version may already be changed or missing."

    def test_pyproject_toml_contains_description(self):
        """Verify pyproject.toml contains the expected description."""
        path = "/home/user/datasets/pyproject.toml"
        with open(path, 'r') as f:
            content = f.read()
        assert 'description = "Tools for managing research annotation datasets"' in content, \
            f"File {path} does not contain expected description"

    def test_changelog_exists(self):
        """Verify CHANGELOG.md exists in the datasets directory."""
        path = "/home/user/datasets/CHANGELOG.md"
        assert os.path.isfile(path), f"File {path} does not exist"

    def test_changelog_readable(self):
        """Verify CHANGELOG.md is readable."""
        path = "/home/user/datasets/CHANGELOG.md"
        assert os.access(path, os.R_OK), f"File {path} is not readable"

    def test_changelog_has_header(self):
        """Verify CHANGELOG.md starts with # Changelog header."""
        path = "/home/user/datasets/CHANGELOG.md"
        with open(path, 'r') as f:
            content = f.read()
        assert content.strip().startswith("# Changelog"), \
            f"File {path} does not start with '# Changelog' header"

    def test_changelog_contains_0_4_2_entry(self):
        """Verify CHANGELOG.md contains the 0.4.2 entry."""
        path = "/home/user/datasets/CHANGELOG.md"
        with open(path, 'r') as f:
            content = f.read()
        assert "## 0.4.2 - 2024-09-15" in content, \
            f"File {path} does not contain '## 0.4.2 - 2024-09-15' entry"

    def test_changelog_contains_0_4_2_content(self):
        """Verify CHANGELOG.md contains the 0.4.2 entry content."""
        path = "/home/user/datasets/CHANGELOG.md"
        with open(path, 'r') as f:
            content = f.read()
        assert "Fixed CSV export encoding issue" in content, \
            f"File {path} does not contain expected 0.4.2 entry content"

    def test_changelog_contains_0_4_1_entry(self):
        """Verify CHANGELOG.md contains the 0.4.1 entry."""
        path = "/home/user/datasets/CHANGELOG.md"
        with open(path, 'r') as f:
            content = f.read()
        assert "## 0.4.1 - 2024-08-03" in content, \
            f"File {path} does not contain '## 0.4.1 - 2024-08-03' entry"

    def test_changelog_contains_0_4_1_content(self):
        """Verify CHANGELOG.md contains the 0.4.1 entry content."""
        path = "/home/user/datasets/CHANGELOG.md"
        with open(path, 'r') as f:
            content = f.read()
        assert "Added batch processing mode" in content, \
            f"File {path} does not contain expected 0.4.1 entry content"

    def test_changelog_contains_0_4_0_entry(self):
        """Verify CHANGELOG.md contains the 0.4.0 entry."""
        path = "/home/user/datasets/CHANGELOG.md"
        with open(path, 'r') as f:
            content = f.read()
        assert "## 0.4.0 - 2024-07-20" in content, \
            f"File {path} does not contain '## 0.4.0 - 2024-07-20' entry"

    def test_changelog_contains_0_4_0_content(self):
        """Verify CHANGELOG.md contains the 0.4.0 entry content."""
        path = "/home/user/datasets/CHANGELOG.md"
        with open(path, 'r') as f:
            content = f.read()
        assert "Initial public release" in content, \
            f"File {path} does not contain expected 0.4.0 entry content"

    def test_changelog_does_not_contain_0_5_0(self):
        """Verify CHANGELOG.md does NOT already contain 0.5.0 entry (task not done yet)."""
        path = "/home/user/datasets/CHANGELOG.md"
        with open(path, 'r') as f:
            content = f.read()
        assert "## 0.5.0" not in content, \
            f"File {path} already contains '## 0.5.0' entry - task may have already been performed"

    def test_pyproject_does_not_contain_version_0_5_0(self):
        """Verify pyproject.toml does NOT already contain version 0.5.0 (task not done yet)."""
        path = "/home/user/datasets/pyproject.toml"
        with open(path, 'r') as f:
            content = f.read()
        assert 'version = "0.5.0"' not in content, \
            f"File {path} already contains version = \"0.5.0\" - task may have already been performed"


class TestToolsAvailable:
    """Tests to verify required tools are available."""

    def test_sed_available(self):
        """Verify sed is available."""
        import subprocess
        result = subprocess.run(["which", "sed"], capture_output=True)
        assert result.returncode == 0, "sed is not available on this system"

    def test_awk_available(self):
        """Verify awk is available."""
        import subprocess
        result = subprocess.run(["which", "awk"], capture_output=True)
        assert result.returncode == 0, "awk is not available on this system"

    def test_python3_available(self):
        """Verify python3 is available."""
        import subprocess
        result = subprocess.run(["which", "python3"], capture_output=True)
        assert result.returncode == 0, "python3 is not available on this system"
