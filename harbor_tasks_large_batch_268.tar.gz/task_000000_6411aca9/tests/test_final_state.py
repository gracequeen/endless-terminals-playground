# test_final_state.py
"""
Tests to validate the final state of the OS/filesystem after the student
has completed the version bump and changelog update task.
"""

import os
import re
from datetime import date
import pytest


class TestPyprojectToml:
    """Tests for the pyproject.toml file after the task is completed."""

    PYPROJECT_PATH = "/home/user/datasets/pyproject.toml"

    def test_pyproject_toml_exists(self):
        """Verify pyproject.toml still exists."""
        assert os.path.isfile(self.PYPROJECT_PATH), \
            f"File {self.PYPROJECT_PATH} does not exist"

    def test_pyproject_toml_contains_version_0_5_0(self):
        """Verify pyproject.toml contains version = '0.5.0'."""
        with open(self.PYPROJECT_PATH, 'r') as f:
            content = f.read()
        assert 'version = "0.5.0"' in content, \
            f"File {self.PYPROJECT_PATH} does not contain version = \"0.5.0\". " \
            f"The version was not bumped from 0.4.2 to 0.5.0."

    def test_pyproject_toml_no_longer_contains_version_0_4_2(self):
        """Verify pyproject.toml no longer contains version = '0.4.2'."""
        with open(self.PYPROJECT_PATH, 'r') as f:
            content = f.read()
        assert 'version = "0.4.2"' not in content, \
            f"File {self.PYPROJECT_PATH} still contains version = \"0.4.2\". " \
            f"The old version should be replaced, not duplicated."

    def test_pyproject_toml_preserves_project_section(self):
        """Verify pyproject.toml still contains [project] section."""
        with open(self.PYPROJECT_PATH, 'r') as f:
            content = f.read()
        assert "[project]" in content, \
            f"File {self.PYPROJECT_PATH} no longer contains [project] section. " \
            f"Other fields should remain unchanged."

    def test_pyproject_toml_preserves_name(self):
        """Verify pyproject.toml still contains the project name."""
        with open(self.PYPROJECT_PATH, 'r') as f:
            content = f.read()
        assert 'name = "annotation-toolkit"' in content, \
            f"File {self.PYPROJECT_PATH} no longer contains the project name. " \
            f"Other fields should remain unchanged."

    def test_pyproject_toml_preserves_description(self):
        """Verify pyproject.toml still contains the description."""
        with open(self.PYPROJECT_PATH, 'r') as f:
            content = f.read()
        assert 'description = "Tools for managing research annotation datasets"' in content, \
            f"File {self.PYPROJECT_PATH} no longer contains the description. " \
            f"Other fields should remain unchanged."


class TestChangelogMd:
    """Tests for the CHANGELOG.md file after the task is completed."""

    CHANGELOG_PATH = "/home/user/datasets/CHANGELOG.md"

    def test_changelog_exists(self):
        """Verify CHANGELOG.md still exists."""
        assert os.path.isfile(self.CHANGELOG_PATH), \
            f"File {self.CHANGELOG_PATH} does not exist"

    def test_changelog_has_header(self):
        """Verify CHANGELOG.md still starts with # Changelog header."""
        with open(self.CHANGELOG_PATH, 'r') as f:
            content = f.read()
        assert content.strip().startswith("# Changelog"), \
            f"File {self.CHANGELOG_PATH} does not start with '# Changelog' header. " \
            f"The header should remain at the top."

    def test_changelog_contains_0_5_0_section(self):
        """Verify CHANGELOG.md contains the new 0.5.0 section."""
        with open(self.CHANGELOG_PATH, 'r') as f:
            content = f.read()
        assert "## 0.5.0" in content, \
            f"File {self.CHANGELOG_PATH} does not contain '## 0.5.0' section. " \
            f"A new section for version 0.5.0 should be added."

    def test_changelog_0_5_0_has_date(self):
        """Verify the 0.5.0 section has today's date in YYYY-MM-DD format."""
        with open(self.CHANGELOG_PATH, 'r') as f:
            content = f.read()

        today = date.today().strftime("%Y-%m-%d")
        # Check for the 0.5.0 header with today's date
        pattern = r"## 0\.5\.0\s*-\s*" + re.escape(today)
        match = re.search(pattern, content)
        assert match is not None, \
            f"File {self.CHANGELOG_PATH} does not contain '## 0.5.0 - {today}'. " \
            f"The new section should have today's date."

    def test_changelog_contains_multi_language_support_entry(self):
        """Verify CHANGELOG.md contains the new feature entry."""
        with open(self.CHANGELOG_PATH, 'r') as f:
            content = f.read()
        assert "multi-language support for annotation labels" in content, \
            f"File {self.CHANGELOG_PATH} does not contain " \
            f"'multi-language support for annotation labels'. " \
            f"The new changelog entry should be added."

    def test_changelog_multi_language_entry_is_bullet(self):
        """Verify the multi-language support entry is formatted as a bullet point."""
        with open(self.CHANGELOG_PATH, 'r') as f:
            content = f.read()
        # Check that there's a bullet (- ) before the entry
        pattern = r"-\s+.*[Aa]dded multi-language support for annotation labels"
        match = re.search(pattern, content)
        assert match is not None, \
            f"File {self.CHANGELOG_PATH} does not have the multi-language entry " \
            f"as a bullet point (starting with '- ')."

    def test_changelog_preserves_0_4_2_entry(self):
        """Verify CHANGELOG.md still contains the 0.4.2 entry."""
        with open(self.CHANGELOG_PATH, 'r') as f:
            content = f.read()
        assert "## 0.4.2 - 2024-09-15" in content, \
            f"File {self.CHANGELOG_PATH} no longer contains '## 0.4.2 - 2024-09-15'. " \
            f"Existing entries should be preserved."

    def test_changelog_preserves_0_4_2_content(self):
        """Verify CHANGELOG.md still contains the 0.4.2 entry content."""
        with open(self.CHANGELOG_PATH, 'r') as f:
            content = f.read()
        assert "Fixed CSV export encoding issue" in content, \
            f"File {self.CHANGELOG_PATH} no longer contains 0.4.2 entry content. " \
            f"Existing entries should be preserved."

    def test_changelog_preserves_0_4_1_entry(self):
        """Verify CHANGELOG.md still contains the 0.4.1 entry."""
        with open(self.CHANGELOG_PATH, 'r') as f:
            content = f.read()
        assert "## 0.4.1 - 2024-08-03" in content, \
            f"File {self.CHANGELOG_PATH} no longer contains '## 0.4.1 - 2024-08-03'. " \
            f"Existing entries should be preserved."

    def test_changelog_preserves_0_4_1_content(self):
        """Verify CHANGELOG.md still contains the 0.4.1 entry content."""
        with open(self.CHANGELOG_PATH, 'r') as f:
            content = f.read()
        assert "Added batch processing mode" in content, \
            f"File {self.CHANGELOG_PATH} no longer contains 0.4.1 entry content. " \
            f"Existing entries should be preserved."

    def test_changelog_preserves_0_4_0_entry(self):
        """Verify CHANGELOG.md still contains the 0.4.0 entry."""
        with open(self.CHANGELOG_PATH, 'r') as f:
            content = f.read()
        assert "## 0.4.0 - 2024-07-20" in content, \
            f"File {self.CHANGELOG_PATH} no longer contains '## 0.4.0 - 2024-07-20'. " \
            f"Existing entries should be preserved."

    def test_changelog_preserves_0_4_0_content(self):
        """Verify CHANGELOG.md still contains the 0.4.0 entry content."""
        with open(self.CHANGELOG_PATH, 'r') as f:
            content = f.read()
        assert "Initial public release" in content, \
            f"File {self.CHANGELOG_PATH} no longer contains 0.4.0 entry content. " \
            f"Existing entries should be preserved."

    def test_changelog_0_5_0_appears_before_0_4_2(self):
        """Verify the 0.5.0 section appears before the 0.4.2 section."""
        with open(self.CHANGELOG_PATH, 'r') as f:
            content = f.read()

        pos_0_5_0 = content.find("## 0.5.0")
        pos_0_4_2 = content.find("## 0.4.2")

        assert pos_0_5_0 != -1, \
            f"File {self.CHANGELOG_PATH} does not contain '## 0.5.0' section."
        assert pos_0_4_2 != -1, \
            f"File {self.CHANGELOG_PATH} does not contain '## 0.4.2' section."
        assert pos_0_5_0 < pos_0_4_2, \
            f"File {self.CHANGELOG_PATH}: The 0.5.0 section should appear before " \
            f"the 0.4.2 section (prepended under the header)."

    def test_changelog_header_appears_before_0_5_0(self):
        """Verify the # Changelog header appears before the 0.5.0 section."""
        with open(self.CHANGELOG_PATH, 'r') as f:
            content = f.read()

        pos_header = content.find("# Changelog")
        pos_0_5_0 = content.find("## 0.5.0")

        assert pos_header != -1, \
            f"File {self.CHANGELOG_PATH} does not contain '# Changelog' header."
        assert pos_0_5_0 != -1, \
            f"File {self.CHANGELOG_PATH} does not contain '## 0.5.0' section."
        assert pos_header < pos_0_5_0, \
            f"File {self.CHANGELOG_PATH}: The '# Changelog' header should appear " \
            f"before the 0.5.0 section."


class TestAntiShortcutGuards:
    """Anti-shortcut guard tests using grep-like checks."""

    def test_grep_version_0_5_0_in_pyproject(self):
        """Anti-shortcut: grep -q 'version = \"0.5.0\"' must succeed."""
        import subprocess
        result = subprocess.run(
            ["grep", "-q", 'version = "0.5.0"', "/home/user/datasets/pyproject.toml"],
            capture_output=True
        )
        assert result.returncode == 0, \
            "grep -q 'version = \"0.5.0\"' /home/user/datasets/pyproject.toml failed. " \
            "The version in pyproject.toml should be 0.5.0."

    def test_grep_0_5_0_section_in_changelog(self):
        """Anti-shortcut: grep -q '## 0.5.0' must succeed."""
        import subprocess
        result = subprocess.run(
            ["grep", "-q", "## 0.5.0", "/home/user/datasets/CHANGELOG.md"],
            capture_output=True
        )
        assert result.returncode == 0, \
            "grep -q '## 0.5.0' /home/user/datasets/CHANGELOG.md failed. " \
            "CHANGELOG.md should contain a ## 0.5.0 section."

    def test_grep_multi_language_in_changelog(self):
        """Anti-shortcut: grep -q 'multi-language support for annotation labels' must succeed."""
        import subprocess
        result = subprocess.run(
            ["grep", "-q", "multi-language support for annotation labels", 
             "/home/user/datasets/CHANGELOG.md"],
            capture_output=True
        )
        assert result.returncode == 0, \
            "grep -q 'multi-language support for annotation labels' " \
            "/home/user/datasets/CHANGELOG.md failed. " \
            "CHANGELOG.md should contain the new feature entry."

    def test_grep_0_4_2_preserved_in_changelog(self):
        """Anti-shortcut: grep -q '## 0.4.2 - 2024-09-15' must succeed (old entries preserved)."""
        import subprocess
        result = subprocess.run(
            ["grep", "-q", "## 0.4.2 - 2024-09-15", "/home/user/datasets/CHANGELOG.md"],
            capture_output=True
        )
        assert result.returncode == 0, \
            "grep -q '## 0.4.2 - 2024-09-15' /home/user/datasets/CHANGELOG.md failed. " \
            "Existing changelog entries should be preserved."
