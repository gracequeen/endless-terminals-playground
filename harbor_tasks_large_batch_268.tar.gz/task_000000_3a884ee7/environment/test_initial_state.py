# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the HTML tag stripping task.
"""

import os
import subprocess
import pytest


class TestInitialState:
    """Validate the initial state before the task is performed."""

    def test_content_directory_exists(self):
        """Verify /home/user/content/ directory exists."""
        content_dir = "/home/user/content"
        assert os.path.isdir(content_dir), (
            f"Directory {content_dir} does not exist. "
            "The content directory must exist before performing the task."
        )

    def test_content_directory_is_writable(self):
        """Verify /home/user/content/ directory is writable."""
        content_dir = "/home/user/content"
        assert os.access(content_dir, os.W_OK), (
            f"Directory {content_dir} is not writable. "
            "The content directory must be writable to create the output file."
        )

    def test_article_html_exists(self):
        """Verify /home/user/content/article.html exists."""
        html_file = "/home/user/content/article.html"
        assert os.path.isfile(html_file), (
            f"File {html_file} does not exist. "
            "The source HTML file must exist before performing the task."
        )

    def test_article_html_is_readable(self):
        """Verify /home/user/content/article.html is readable."""
        html_file = "/home/user/content/article.html"
        assert os.access(html_file, os.R_OK), (
            f"File {html_file} is not readable. "
            "The source HTML file must be readable to extract its content."
        )

    def test_article_html_is_non_empty(self):
        """Verify /home/user/content/article.html is non-empty."""
        html_file = "/home/user/content/article.html"
        assert os.path.getsize(html_file) > 0, (
            f"File {html_file} is empty. "
            "The source HTML file must contain content."
        )

    def test_article_html_contains_html_tags(self):
        """Verify /home/user/content/article.html contains HTML tags."""
        html_file = "/home/user/content/article.html"
        with open(html_file, 'r') as f:
            content = f.read()
        assert '<' in content and '>' in content, (
            f"File {html_file} does not appear to contain HTML tags. "
            "The source file should be an HTML document with markup."
        )

    def test_article_html_contains_expected_structure(self):
        """Verify /home/user/content/article.html contains expected HTML elements."""
        html_file = "/home/user/content/article.html"
        with open(html_file, 'r') as f:
            content = f.read()

        # Check for basic HTML structure
        assert '<html>' in content or '<html ' in content, (
            f"File {html_file} is missing <html> tag."
        )
        assert '<body>' in content or '<body ' in content, (
            f"File {html_file} is missing <body> tag."
        )

    def test_article_html_contains_expected_text_content(self):
        """Verify /home/user/content/article.html contains the expected text content."""
        html_file = "/home/user/content/article.html"
        with open(html_file, 'r') as f:
            content = f.read()

        expected_phrases = [
            "Introduction to Gardening",
            "Getting Started with Your Garden",
            "rewarding",
            "tomatoes",
            "basil",
            "Choose a sunny spot",
            "Prepare the soil",
            "Water regularly",
            "Happy gardening"
        ]

        for phrase in expected_phrases:
            assert phrase in content, (
                f"File {html_file} is missing expected content: '{phrase}'. "
                "The HTML file should contain the gardening article content."
            )

    def test_article_txt_does_not_exist(self):
        """Verify /home/user/content/article.txt does not exist yet."""
        txt_file = "/home/user/content/article.txt"
        assert not os.path.exists(txt_file), (
            f"File {txt_file} already exists. "
            "The output file should not exist before the task is performed."
        )

    def test_sed_is_available(self):
        """Verify sed command is available."""
        result = subprocess.run(['which', 'sed'], capture_output=True)
        assert result.returncode == 0, (
            "sed command is not available. "
            "Standard text processing tools should be installed."
        )

    def test_awk_is_available(self):
        """Verify awk command is available."""
        result = subprocess.run(['which', 'awk'], capture_output=True)
        assert result.returncode == 0, (
            "awk command is not available. "
            "Standard text processing tools should be installed."
        )

    def test_grep_is_available(self):
        """Verify grep command is available."""
        result = subprocess.run(['which', 'grep'], capture_output=True)
        assert result.returncode == 0, (
            "grep command is not available. "
            "Standard text processing tools should be installed."
        )

    def test_perl_is_available(self):
        """Verify perl command is available."""
        result = subprocess.run(['which', 'perl'], capture_output=True)
        assert result.returncode == 0, (
            "perl command is not available. "
            "Standard text processing tools should be installed."
        )

    def test_python3_is_available(self):
        """Verify python3 command is available."""
        result = subprocess.run(['which', 'python3'], capture_output=True)
        assert result.returncode == 0, (
            "python3 command is not available. "
            "Standard text processing tools should be installed."
        )
