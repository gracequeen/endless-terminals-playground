# test_final_state.py
"""
Tests to validate the final state of the OS/filesystem after the student
has completed the HTML tag stripping task.
"""

import os
import subprocess
import pytest


class TestFinalState:
    """Validate the final state after the task is performed."""

    def test_article_txt_exists(self):
        """Verify /home/user/content/article.txt exists."""
        txt_file = "/home/user/content/article.txt"
        assert os.path.isfile(txt_file), (
            f"File {txt_file} does not exist. "
            "The output text file must be created by stripping HTML tags."
        )

    def test_article_txt_is_non_empty(self):
        """Verify /home/user/content/article.txt is non-empty."""
        txt_file = "/home/user/content/article.txt"
        assert os.path.getsize(txt_file) > 0, (
            f"File {txt_file} is empty. "
            "The output file must contain the extracted text content."
        )

    def test_article_txt_has_no_html_tags(self):
        """Verify /home/user/content/article.txt contains no HTML tag characters."""
        txt_file = "/home/user/content/article.txt"
        with open(txt_file, 'r') as f:
            content = f.read()

        assert '<' not in content, (
            f"File {txt_file} still contains '<' character. "
            "All HTML tags must be removed from the output."
        )
        assert '>' not in content, (
            f"File {txt_file} still contains '>' character. "
            "All HTML tags must be removed from the output."
        )

    def test_article_txt_no_angle_brackets_via_grep(self):
        """Verify no angle brackets using grep command (anti-shortcut guard)."""
        txt_file = "/home/user/content/article.txt"
        result = subprocess.run(
            ['grep', '-c', '[<>]', txt_file],
            capture_output=True,
            text=True
        )
        # grep -c returns 1 if no matches found, 0 if matches found
        # The count should be 0 (no angle brackets)
        if result.returncode == 0:
            count = int(result.stdout.strip())
            assert count == 0, (
                f"Found {count} lines with angle brackets in {txt_file}. "
                "All HTML tag characters must be removed."
            )
        # returncode 1 means no matches found, which is what we want

    def test_article_txt_contains_title(self):
        """Verify output contains 'Introduction to Gardening'."""
        txt_file = "/home/user/content/article.txt"
        with open(txt_file, 'r') as f:
            content = f.read()

        assert "Introduction to Gardening" in content, (
            f"File {txt_file} is missing 'Introduction to Gardening'. "
            "The title text must be preserved in the output."
        )

    def test_article_txt_contains_heading(self):
        """Verify output contains 'Getting Started with Your Garden'."""
        txt_file = "/home/user/content/article.txt"
        with open(txt_file, 'r') as f:
            content = f.read()

        assert "Getting Started with Your Garden" in content, (
            f"File {txt_file} is missing 'Getting Started with Your Garden'. "
            "The heading text must be preserved in the output."
        )

    def test_article_txt_contains_gardening_intro(self):
        """Verify output contains 'Gardening is a'."""
        txt_file = "/home/user/content/article.txt"
        with open(txt_file, 'r') as f:
            content = f.read()

        assert "Gardening is a" in content, (
            f"File {txt_file} is missing 'Gardening is a'. "
            "The paragraph text must be preserved in the output."
        )

    def test_article_txt_contains_rewarding(self):
        """Verify output contains 'rewarding' (anti-shortcut guard)."""
        txt_file = "/home/user/content/article.txt"
        with open(txt_file, 'r') as f:
            content = f.read()

        assert "rewarding" in content, (
            f"File {txt_file} is missing 'rewarding'. "
            "The actual text content must be preserved, not just an empty file."
        )

    def test_article_txt_contains_rewarding_via_grep(self):
        """Verify 'rewarding' present using grep (anti-shortcut guard)."""
        txt_file = "/home/user/content/article.txt"
        result = subprocess.run(
            ['grep', '-q', 'rewarding', txt_file],
            capture_output=True
        )
        assert result.returncode == 0, (
            f"grep failed to find 'rewarding' in {txt_file}. "
            "The actual text content must be preserved."
        )

    def test_article_txt_contains_hobby(self):
        """Verify output contains 'hobby'."""
        txt_file = "/home/user/content/article.txt"
        with open(txt_file, 'r') as f:
            content = f.read()

        assert "hobby" in content, (
            f"File {txt_file} is missing 'hobby'. "
            "The text content must be preserved in the output."
        )

    def test_article_txt_contains_tomatoes(self):
        """Verify output contains 'tomatoes'."""
        txt_file = "/home/user/content/article.txt"
        with open(txt_file, 'r') as f:
            content = f.read()

        assert "tomatoes" in content, (
            f"File {txt_file} is missing 'tomatoes'. "
            "The text content must be preserved in the output."
        )

    def test_article_txt_contains_basil(self):
        """Verify output contains 'basil'."""
        txt_file = "/home/user/content/article.txt"
        with open(txt_file, 'r') as f:
            content = f.read()

        assert "basil" in content, (
            f"File {txt_file} is missing 'basil'. "
            "The text content must be preserved in the output."
        )

    def test_article_txt_contains_sunny_spot(self):
        """Verify output contains 'Choose a sunny spot'."""
        txt_file = "/home/user/content/article.txt"
        with open(txt_file, 'r') as f:
            content = f.read()

        assert "Choose a sunny spot" in content, (
            f"File {txt_file} is missing 'Choose a sunny spot'. "
            "The list item text must be preserved in the output."
        )

    def test_article_txt_contains_prepare_soil(self):
        """Verify output contains 'Prepare the soil'."""
        txt_file = "/home/user/content/article.txt"
        with open(txt_file, 'r') as f:
            content = f.read()

        assert "Prepare the soil" in content, (
            f"File {txt_file} is missing 'Prepare the soil'. "
            "The list item text must be preserved in the output."
        )

    def test_article_txt_contains_water_regularly(self):
        """Verify output contains 'Water regularly'."""
        txt_file = "/home/user/content/article.txt"
        with open(txt_file, 'r') as f:
            content = f.read()

        assert "Water regularly" in content, (
            f"File {txt_file} is missing 'Water regularly'. "
            "The list item text must be preserved in the output."
        )

    def test_article_txt_contains_happy_gardening(self):
        """Verify output contains 'Happy gardening'."""
        txt_file = "/home/user/content/article.txt"
        with open(txt_file, 'r') as f:
            content = f.read()

        assert "Happy gardening" in content, (
            f"File {txt_file} is missing 'Happy gardening'. "
            "The closing text must be preserved in the output."
        )

    def test_article_html_unchanged(self):
        """Verify /home/user/content/article.html still exists and contains HTML."""
        html_file = "/home/user/content/article.html"
        assert os.path.isfile(html_file), (
            f"File {html_file} no longer exists. "
            "The source HTML file must be preserved (invariant)."
        )

        with open(html_file, 'r') as f:
            content = f.read()

        # Verify it still has HTML tags
        assert '<html>' in content or '<html ' in content, (
            f"File {html_file} no longer contains <html> tag. "
            "The source HTML file must remain unchanged."
        )
        assert '<body>' in content or '<body ' in content, (
            f"File {html_file} no longer contains <body> tag. "
            "The source HTML file must remain unchanged."
        )
        assert "Introduction to Gardening" in content, (
            f"File {html_file} content has been modified. "
            "The source HTML file must remain unchanged."
        )

    def test_article_txt_is_readable_text(self):
        """Verify /home/user/content/article.txt contains readable text."""
        txt_file = "/home/user/content/article.txt"
        with open(txt_file, 'r') as f:
            content = f.read()

        # Check that it has a reasonable amount of alphabetic characters
        alpha_count = sum(1 for c in content if c.isalpha())
        assert alpha_count > 100, (
            f"File {txt_file} has only {alpha_count} alphabetic characters. "
            "The output should contain substantial readable text from the HTML."
        )
