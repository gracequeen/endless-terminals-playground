# test_final_state.py
"""
Tests to validate the final state of the system after the student fixes the script.
This verifies the script correctly parses tab-separated hosts.csv and generates valid firewall rules.
"""

import os
import re
import subprocess
import tempfile
import shutil
import pytest


class TestScriptExecution:
    """Test that the fixed script executes successfully."""

    def test_script_exists(self):
        """The apply_rules.sh script must exist."""
        path = "/home/user/netops/apply_rules.sh"
        assert os.path.isfile(path), f"Script {path} does not exist"

    def test_script_is_executable(self):
        """The apply_rules.sh script must be executable."""
        path = "/home/user/netops/apply_rules.sh"
        assert os.access(path, os.X_OK), f"Script {path} is not executable"

    def test_script_runs_successfully(self):
        """Running the script must exit with code 0."""
        result = subprocess.run(
            ['bash', '/home/user/netops/apply_rules.sh'],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, f"Script failed with exit code {result.returncode}. Stderr: {result.stderr}"


class TestHostsCsvUnchanged:
    """Test that hosts.csv remains unchanged (fix should be in script, not data)."""

    def test_hosts_csv_exists(self):
        """The hosts.csv file must still exist."""
        path = "/home/user/netops/hosts.csv"
        assert os.path.isfile(path), f"File {path} does not exist"

    def test_hosts_csv_has_12_rows(self):
        """The hosts.csv file must still have exactly 12 rows."""
        path = "/home/user/netops/hosts.csv"
        with open(path, 'r') as f:
            lines = [line for line in f.readlines() if line.strip()]
        assert len(lines) == 12, f"Expected 12 rows in hosts.csv, found {len(lines)}"

    def test_hosts_csv_is_still_tab_separated(self):
        """The hosts.csv file must still be tab-separated."""
        path = "/home/user/netops/hosts.csv"
        with open(path, 'r') as f:
            content = f.read()
        assert '\t' in content, "hosts.csv should remain tab-separated"


class TestGeneratedRulesFile:
    """Test the generated.rules file has correct content after running the fixed script."""

    def test_generated_rules_exists(self):
        """The generated.rules file must exist."""
        # First run the script to ensure fresh output
        subprocess.run(['bash', '/home/user/netops/apply_rules.sh'], capture_output=True)
        path = "/home/user/netops/generated.rules"
        assert os.path.isfile(path), f"File {path} does not exist"

    def test_generated_rules_has_12_lines(self):
        """The generated.rules file must have exactly 12 lines."""
        subprocess.run(['bash', '/home/user/netops/apply_rules.sh'], capture_output=True)
        path = "/home/user/netops/generated.rules"
        with open(path, 'r') as f:
            lines = [line.strip() for line in f.readlines() if line.strip()]
        assert len(lines) == 12, f"Expected 12 lines in generated.rules, found {len(lines)}"

    def test_all_lines_match_expected_format(self):
        """Each line must match the format 'ALLOW <ip> <port>/<proto>'."""
        subprocess.run(['bash', '/home/user/netops/apply_rules.sh'], capture_output=True)
        path = "/home/user/netops/generated.rules"

        # Pattern: ALLOW <valid_ipv4> <port>/<proto>
        pattern = re.compile(
            r'^ALLOW\s+(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})\s+(\d+)/(tcp|udp)$'
        )

        with open(path, 'r') as f:
            lines = [line.strip() for line in f.readlines() if line.strip()]

        for i, line in enumerate(lines, 1):
            match = pattern.match(line)
            assert match is not None, f"Line {i} does not match expected format 'ALLOW <ip> <port>/<proto>': '{line}'"

            # Validate IP octets are in valid range
            ip = match.group(1)
            octets = ip.split('.')
            for octet in octets:
                val = int(octet)
                assert 0 <= val <= 255, f"Line {i} has invalid IP octet {octet} in IP {ip}"

            # Validate port is reasonable
            port = int(match.group(2))
            assert 1 <= port <= 65535, f"Line {i} has invalid port {port}"

    def test_no_tabs_in_output(self):
        """Output lines must not contain tabs (indicating proper parsing)."""
        subprocess.run(['bash', '/home/user/netops/apply_rules.sh'], capture_output=True)
        path = "/home/user/netops/generated.rules"

        with open(path, 'r') as f:
            content = f.read()

        assert '\t' not in content, "generated.rules should not contain tabs (indicates parsing bug)"


class TestSpecificExpectedRules:
    """Test that specific expected rules are present with correct values."""

    @pytest.fixture(autouse=True)
    def run_script(self):
        """Run the script before each test in this class."""
        subprocess.run(['bash', '/home/user/netops/apply_rules.sh'], capture_output=True)

    def get_rules(self):
        """Helper to read and return rules as a list."""
        with open('/home/user/netops/generated.rules', 'r') as f:
            return [line.strip() for line in f.readlines() if line.strip()]

    def test_first_rule_is_web_server(self):
        """Line 1 must be 'ALLOW 192.168.1.10 443/tcp' (web server 01)."""
        rules = self.get_rules()
        assert len(rules) >= 1, "No rules found"
        assert rules[0] == "ALLOW 192.168.1.10 443/tcp", f"Line 1 expected 'ALLOW 192.168.1.10 443/tcp', got '{rules[0]}'"

    def test_second_rule_is_db_primary(self):
        """Line 2 must be 'ALLOW 10.0.0.50 5432/tcp' (db-primary)."""
        rules = self.get_rules()
        assert len(rules) >= 2, "Not enough rules found"
        assert rules[1] == "ALLOW 10.0.0.50 5432/tcp", f"Line 2 expected 'ALLOW 10.0.0.50 5432/tcp', got '{rules[1]}'"

    def test_third_rule_is_cache_node(self):
        """Line 3 must be 'ALLOW 172.16.0.5 6379/tcp' (cache node)."""
        rules = self.get_rules()
        assert len(rules) >= 3, "Not enough rules found"
        assert rules[2] == "ALLOW 172.16.0.5 6379/tcp", f"Line 3 expected 'ALLOW 172.16.0.5 6379/tcp', got '{rules[2]}'"

    def test_contains_all_expected_ips(self):
        """All 12 expected IPs must appear in the output."""
        expected_ips = [
            "192.168.1.10", "10.0.0.50", "172.16.0.5", "192.168.1.25",
            "10.0.0.100", "172.16.0.20", "10.0.0.75", "192.168.1.5",
            "172.16.0.30", "10.0.0.10", "192.168.1.100", "172.16.0.40"
        ]
        rules = self.get_rules()
        rules_text = '\n'.join(rules)

        for ip in expected_ips:
            assert ip in rules_text, f"Expected IP {ip} not found in generated.rules"

    def test_contains_udp_rules(self):
        """Output must contain UDP rules (log aggregator, dns, ntp, vpn)."""
        rules = self.get_rules()
        udp_rules = [r for r in rules if r.endswith('/udp')]
        assert len(udp_rules) >= 4, f"Expected at least 4 UDP rules, found {len(udp_rules)}"

    def test_contains_tcp_rules(self):
        """Output must contain TCP rules."""
        rules = self.get_rules()
        tcp_rules = [r for r in rules if r.endswith('/tcp')]
        assert len(tcp_rules) >= 8, f"Expected at least 8 TCP rules, found {len(tcp_rules)}"


class TestScriptDynamicParsing:
    """Test that the script dynamically parses hosts.csv (not hardcoded output)."""

    def test_script_handles_additional_entry(self):
        """Adding a 13th entry to hosts.csv should result in 13 rules."""
        hosts_csv = "/home/user/netops/hosts.csv"
        generated_rules = "/home/user/netops/generated.rules"

        # Backup original hosts.csv
        with open(hosts_csv, 'r') as f:
            original_content = f.read()

        try:
            # Append a test entry
            with open(hosts_csv, 'a') as f:
                f.write("test host\t1.2.3.4\t80\ttcp\n")

            # Run the script
            result = subprocess.run(
                ['bash', '/home/user/netops/apply_rules.sh'],
                capture_output=True,
                text=True
            )
            assert result.returncode == 0, f"Script failed after adding entry: {result.stderr}"

            # Check output has 13 lines
            with open(generated_rules, 'r') as f:
                lines = [line.strip() for line in f.readlines() if line.strip()]

            assert len(lines) == 13, f"Expected 13 lines after adding entry, found {len(lines)}"

            # Check the new entry is correctly formatted
            assert "ALLOW 1.2.3.4 80/tcp" in lines, "New entry 'ALLOW 1.2.3.4 80/tcp' not found in output"

        finally:
            # Restore original hosts.csv
            with open(hosts_csv, 'w') as f:
                f.write(original_content)

            # Re-run script to restore original generated.rules
            subprocess.run(['bash', '/home/user/netops/apply_rules.sh'], capture_output=True)


class TestScriptStillUsesCorrectPaths:
    """Test that the script still uses the correct input/output paths."""

    def test_script_references_hosts_csv(self):
        """The script must still reference hosts.csv."""
        with open('/home/user/netops/apply_rules.sh', 'r') as f:
            content = f.read()
        assert "hosts.csv" in content, "Script should reference hosts.csv"

    def test_script_references_generated_rules(self):
        """The script must still reference generated.rules."""
        with open('/home/user/netops/apply_rules.sh', 'r') as f:
            content = f.read()
        assert "generated.rules" in content, "Script should reference generated.rules"
