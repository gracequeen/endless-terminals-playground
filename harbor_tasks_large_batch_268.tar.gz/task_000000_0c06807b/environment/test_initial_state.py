# test_initial_state.py
"""
Tests to validate the initial state of the system before the student fixes the script.
This verifies the buggy state exists as described in the task.
"""

import os
import stat
import subprocess
import pytest


class TestDirectoryStructure:
    """Test that required directories exist."""

    def test_netops_directory_exists(self):
        """The /home/user/netops directory must exist."""
        path = "/home/user/netops"
        assert os.path.isdir(path), f"Directory {path} does not exist"

    def test_netops_directory_writable(self):
        """The /home/user/netops directory must be writable."""
        path = "/home/user/netops"
        assert os.access(path, os.W_OK), f"Directory {path} is not writable"


class TestHostsCsvFile:
    """Test the hosts.csv file exists with correct content."""

    def test_hosts_csv_exists(self):
        """The hosts.csv file must exist."""
        path = "/home/user/netops/hosts.csv"
        assert os.path.isfile(path), f"File {path} does not exist"

    def test_hosts_csv_readable(self):
        """The hosts.csv file must be readable."""
        path = "/home/user/netops/hosts.csv"
        assert os.access(path, os.R_OK), f"File {path} is not readable"

    def test_hosts_csv_has_12_rows(self):
        """The hosts.csv file must have exactly 12 rows."""
        path = "/home/user/netops/hosts.csv"
        with open(path, 'r') as f:
            lines = [line for line in f.readlines() if line.strip()]
        assert len(lines) == 12, f"Expected 12 rows in hosts.csv, found {len(lines)}"

    def test_hosts_csv_is_tab_separated(self):
        """The hosts.csv file must be tab-separated (not comma-separated)."""
        path = "/home/user/netops/hosts.csv"
        with open(path, 'r') as f:
            content = f.read()

        # Should contain tabs
        assert '\t' in content, "hosts.csv should be tab-separated but contains no tabs"

        # Lines should have tabs as field separators
        lines = [line for line in content.strip().split('\n') if line.strip()]
        for i, line in enumerate(lines):
            tab_count = line.count('\t')
            assert tab_count >= 3, f"Line {i+1} should have at least 3 tabs (4 fields), found {tab_count} tabs"

    def test_hosts_csv_contains_expected_ips(self):
        """The hosts.csv file must contain the expected IP addresses."""
        path = "/home/user/netops/hosts.csv"
        expected_ips = [
            "192.168.1.10", "10.0.0.50", "172.16.0.5", "192.168.1.25",
            "10.0.0.100", "172.16.0.20", "10.0.0.75", "192.168.1.5",
            "172.16.0.30", "10.0.0.10", "192.168.1.100", "172.16.0.40"
        ]

        with open(path, 'r') as f:
            content = f.read()

        for ip in expected_ips:
            assert ip in content, f"Expected IP {ip} not found in hosts.csv"

    def test_hosts_csv_has_hostnames_with_spaces(self):
        """Some hostnames in hosts.csv should contain spaces (part of the parsing challenge)."""
        path = "/home/user/netops/hosts.csv"
        with open(path, 'r') as f:
            lines = f.readlines()

        # Check that at least some lines have hostnames with spaces
        # The first field (before first tab) should contain spaces in some rows
        hostnames_with_spaces = 0
        for line in lines:
            if '\t' in line:
                hostname = line.split('\t')[0]
                if ' ' in hostname:
                    hostnames_with_spaces += 1

        assert hostnames_with_spaces > 0, "Expected some hostnames with embedded spaces in hosts.csv"


class TestApplyRulesScript:
    """Test the apply_rules.sh script exists with the buggy implementation."""

    def test_script_exists(self):
        """The apply_rules.sh script must exist."""
        path = "/home/user/netops/apply_rules.sh"
        assert os.path.isfile(path), f"Script {path} does not exist"

    def test_script_is_executable(self):
        """The apply_rules.sh script must be executable."""
        path = "/home/user/netops/apply_rules.sh"
        assert os.access(path, os.X_OK), f"Script {path} is not executable"

    def test_script_has_shebang(self):
        """The script must have a bash shebang."""
        path = "/home/user/netops/apply_rules.sh"
        with open(path, 'r') as f:
            first_line = f.readline()
        assert first_line.strip().startswith('#!/bin/bash') or first_line.strip().startswith('#!/usr/bin/env bash'), \
            f"Script should have bash shebang, found: {first_line.strip()}"

    def test_script_uses_comma_delimiter_bug(self):
        """The script must contain the bug: using comma delimiter instead of tab."""
        path = "/home/user/netops/apply_rules.sh"
        with open(path, 'r') as f:
            content = f.read()

        # The bug is using -d',' or -d"," or -d , when the file is tab-separated
        assert "-d','" in content or '-d","' in content or "-d ," in content or "-d','" in content, \
            "Script should contain the bug: using comma as delimiter in cut command"

    def test_script_reads_from_hosts_csv(self):
        """The script must read from /home/user/netops/hosts.csv."""
        path = "/home/user/netops/apply_rules.sh"
        with open(path, 'r') as f:
            content = f.read()

        assert "hosts.csv" in content, "Script should reference hosts.csv"

    def test_script_writes_to_generated_rules(self):
        """The script must write to /home/user/netops/generated.rules."""
        path = "/home/user/netops/apply_rules.sh"
        with open(path, 'r') as f:
            content = f.read()

        assert "generated.rules" in content, "Script should reference generated.rules"


class TestGeneratedRulesFile:
    """Test the generated.rules file exists with malformed output from previous run."""

    def test_generated_rules_exists(self):
        """The generated.rules file must exist from a previous buggy run."""
        path = "/home/user/netops/generated.rules"
        assert os.path.isfile(path), f"File {path} does not exist (should exist from previous buggy run)"

    def test_generated_rules_has_malformed_content(self):
        """The generated.rules file should have malformed content due to the bug."""
        path = "/home/user/netops/generated.rules"
        with open(path, 'r') as f:
            lines = [line.strip() for line in f.readlines() if line.strip()]

        # Check that the output is malformed - lines should have the bug symptoms
        # The bug causes entire lines to appear where just IP should be
        malformed_count = 0
        for line in lines:
            # A properly formatted line would be like "ALLOW 192.168.1.10 443/tcp"
            # A malformed line would have tabs in it or end with just "/"
            if '\t' in line or line.endswith('/') or line.endswith('/ '):
                malformed_count += 1

        assert malformed_count > 0, "Expected malformed output in generated.rules from the buggy script"


class TestRequiredTools:
    """Test that required tools are available."""

    def test_bash_available(self):
        """bash must be available."""
        result = subprocess.run(['which', 'bash'], capture_output=True)
        assert result.returncode == 0, "bash is not available"

    def test_cut_available(self):
        """cut command must be available."""
        result = subprocess.run(['which', 'cut'], capture_output=True)
        assert result.returncode == 0, "cut command is not available"

    def test_awk_available(self):
        """awk must be available."""
        result = subprocess.run(['which', 'awk'], capture_output=True)
        assert result.returncode == 0, "awk is not available"
