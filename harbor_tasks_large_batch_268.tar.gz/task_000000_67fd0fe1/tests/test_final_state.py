# test_final_state.py
"""
Tests to validate the final state of the OS/filesystem after the student
has completed the health endpoint task.
"""

import os
import subprocess
import socket
import time
import pytest


class TestFinalState:
    """Validate the final state after the task is performed."""

    def test_healthcheck_directory_exists(self):
        """The /home/user/healthcheck directory must still exist."""
        path = "/home/user/healthcheck"
        assert os.path.isdir(path), f"Directory {path} does not exist"

    def test_python_script_exists_in_healthcheck(self):
        """A Python script must exist in /home/user/healthcheck."""
        path = "/home/user/healthcheck"
        contents = os.listdir(path)

        # Check for any .py file
        py_files = [f for f in contents if f.endswith('.py')]
        assert len(py_files) > 0, (
            f"No Python script found in {path}. "
            f"Directory contents: {contents}"
        )

    def test_port_8080_is_listening_via_ss(self):
        """Port 8080 must have a process listening on it."""
        result = subprocess.run(
            ["ss", "-tlnp"],
            capture_output=True,
            text=True
        )

        # Check if port 8080 appears in the output with LISTEN state
        lines = result.stdout.strip().split("\n")
        listening = False
        for line in lines:
            if ":8080" in line and "LISTEN" in line:
                listening = True
                break

        assert listening, (
            f"No process is listening on port 8080. "
            f"ss output:\n{result.stdout}"
        )

    def test_port_8080_is_listening_via_lsof(self):
        """Verify port 8080 has a listening process using lsof."""
        result = subprocess.run(
            ["lsof", "-i", ":8080"],
            capture_output=True,
            text=True
        )

        # lsof should return 0 and show LISTEN
        assert result.returncode == 0, (
            f"lsof -i :8080 failed or found nothing. "
            f"Return code: {result.returncode}, stderr: {result.stderr}"
        )

        assert "LISTEN" in result.stdout, (
            f"No LISTEN state found in lsof output for port 8080. "
            f"Output: {result.stdout}"
        )

    def test_port_8080_is_connectable(self):
        """Verify we can establish a TCP connection to port 8080."""
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(5)
        try:
            result = sock.connect_ex(('localhost', 8080))
            assert result == 0, (
                f"Cannot connect to localhost:8080. "
                f"Connection error code: {result}"
            )
        finally:
            sock.close()

    def test_health_endpoint_returns_200(self):
        """
        curl -s -o /dev/null -w "%{http_code}" http://localhost:8080/health
        must return exactly "200".
        """
        result = subprocess.run(
            ["curl", "-s", "-o", "/dev/null", "-w", "%{http_code}",
             "--connect-timeout", "5", "--max-time", "10",
             "http://localhost:8080/health"],
            capture_output=True,
            text=True
        )

        http_code = result.stdout.strip()
        assert http_code == "200", (
            f"Expected HTTP 200 from /health endpoint, but got HTTP {http_code}. "
            f"curl stderr: {result.stderr}"
        )

    def test_health_endpoint_responds_to_get(self):
        """The /health endpoint must respond to GET requests with 200 OK."""
        result = subprocess.run(
            ["curl", "-s", "-X", "GET", "-w", "\n%{http_code}",
             "--connect-timeout", "5", "--max-time", "10",
             "http://localhost:8080/health"],
            capture_output=True,
            text=True
        )

        lines = result.stdout.strip().split("\n")
        http_code = lines[-1] if lines else ""

        assert http_code == "200", (
            f"GET /health did not return 200. Got HTTP {http_code}. "
            f"Response: {result.stdout}, stderr: {result.stderr}"
        )

    def test_health_endpoint_not_404(self):
        """The /health endpoint must not return 404."""
        result = subprocess.run(
            ["curl", "-s", "-o", "/dev/null", "-w", "%{http_code}",
             "--connect-timeout", "5", "--max-time", "10",
             "http://localhost:8080/health"],
            capture_output=True,
            text=True
        )

        http_code = result.stdout.strip()
        assert http_code != "404", (
            f"The /health endpoint returned 404 Not Found. "
            f"The endpoint must be configured at /health path."
        )

    def test_server_process_is_running(self):
        """A server process must be running (backgrounded or daemonized)."""
        # Check for python processes that might be the server
        result = subprocess.run(
            ["pgrep", "-f", "python"],
            capture_output=True,
            text=True
        )

        # Also check with lsof to confirm something is on 8080
        lsof_result = subprocess.run(
            ["lsof", "-i", ":8080", "-t"],
            capture_output=True,
            text=True
        )

        pids = lsof_result.stdout.strip()
        assert pids, (
            f"No process found listening on port 8080. "
            f"The server must remain running after the task is complete."
        )

    def test_multiple_requests_succeed(self):
        """The server should handle multiple requests (still running)."""
        for i in range(3):
            result = subprocess.run(
                ["curl", "-s", "-o", "/dev/null", "-w", "%{http_code}",
                 "--connect-timeout", "5", "--max-time", "10",
                 "http://localhost:8080/health"],
                capture_output=True,
                text=True
            )

            http_code = result.stdout.strip()
            assert http_code == "200", (
                f"Request {i+1}/3 to /health failed. "
                f"Expected HTTP 200, got {http_code}. "
                f"Server may have stopped running."
            )
            time.sleep(0.1)  # Small delay between requests

    def test_correct_port_8080_not_other_port(self):
        """
        Verify the server is specifically on port 8080, not another port.
        """
        # Check that 8080 is listening
        result_8080 = subprocess.run(
            ["curl", "-s", "-o", "/dev/null", "-w", "%{http_code}",
             "--connect-timeout", "2", "http://localhost:8080/health"],
            capture_output=True,
            text=True
        )

        assert result_8080.stdout.strip() == "200", (
            f"Server must be on port 8080. "
            f"Got HTTP {result_8080.stdout.strip()} from port 8080."
        )

    def test_health_path_specifically(self):
        """
        Verify the /health path specifically works (not just root).
        """
        # /health should return 200
        health_result = subprocess.run(
            ["curl", "-s", "-o", "/dev/null", "-w", "%{http_code}",
             "--connect-timeout", "5", "http://localhost:8080/health"],
            capture_output=True,
            text=True
        )

        assert health_result.stdout.strip() == "200", (
            f"The /health endpoint must return 200. "
            f"Got: {health_result.stdout.strip()}"
        )
