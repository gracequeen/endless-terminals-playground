# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the health endpoint task.
"""

import os
import subprocess
import pytest


class TestInitialState:
    """Validate the initial state before the task is performed."""

    def test_healthcheck_directory_exists(self):
        """The /home/user/healthcheck directory must exist."""
        path = "/home/user/healthcheck"
        assert os.path.isdir(path), f"Directory {path} does not exist"

    def test_healthcheck_directory_is_empty(self):
        """The /home/user/healthcheck directory must be empty."""
        path = "/home/user/healthcheck"
        contents = os.listdir(path)
        assert len(contents) == 0, (
            f"Directory {path} should be empty but contains: {contents}"
        )

    def test_healthcheck_directory_is_writable(self):
        """The /home/user/healthcheck directory must be writable."""
        path = "/home/user/healthcheck"
        assert os.access(path, os.W_OK), f"Directory {path} is not writable"

    def test_python3_installed(self):
        """Python 3.11+ must be installed."""
        result = subprocess.run(
            ["python3", "--version"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "Python 3 is not installed or not accessible"

        # Parse version to ensure 3.11+
        version_output = result.stdout.strip()
        # Expected format: "Python 3.X.Y"
        version_parts = version_output.split()[1].split(".")
        major = int(version_parts[0])
        minor = int(version_parts[1])

        assert major == 3 and minor >= 11, (
            f"Python 3.11+ required, but found {version_output}"
        )

    def test_flask_is_available(self):
        """Flask must be available via pip (already installed)."""
        result = subprocess.run(
            ["python3", "-c", "import flask; print(flask.__version__)"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"Flask is not installed or not importable. "
            f"Error: {result.stderr}"
        )

    def test_port_8080_not_in_use(self):
        """Port 8080 must not be in use."""
        # Use ss to check if anything is listening on port 8080
        result = subprocess.run(
            ["ss", "-tlnp"],
            capture_output=True,
            text=True
        )

        # Check if port 8080 appears in the output
        lines = result.stdout.strip().split("\n")
        for line in lines:
            if ":8080" in line and "LISTEN" in line:
                pytest.fail(
                    f"Port 8080 is already in use. Found: {line}"
                )

    def test_port_8080_not_listening_via_lsof(self):
        """Verify port 8080 has no listening process using lsof."""
        result = subprocess.run(
            ["lsof", "-i", ":8080"],
            capture_output=True,
            text=True
        )
        # lsof returns non-zero if nothing found, which is what we want
        # If it returns 0 and has output with LISTEN, port is in use
        if result.returncode == 0:
            if "LISTEN" in result.stdout:
                pytest.fail(
                    f"Port 8080 has a listening process: {result.stdout}"
                )

    def test_curl_to_health_endpoint_fails(self):
        """
        Verify that curl to localhost:8080/health fails (connection refused).
        This confirms no server is currently running.
        """
        result = subprocess.run(
            ["curl", "-s", "-o", "/dev/null", "-w", "%{http_code}", 
             "--connect-timeout", "2", "http://localhost:8080/health"],
            capture_output=True,
            text=True
        )
        # curl returns 000 for connection refused, or non-200 codes
        # We expect connection refused (000) or failure
        http_code = result.stdout.strip()
        assert http_code != "200", (
            f"Expected no server running, but got HTTP {http_code} from "
            f"http://localhost:8080/health"
        )

    def test_home_user_directory_exists(self):
        """The /home/user directory must exist."""
        path = "/home/user"
        assert os.path.isdir(path), f"Directory {path} does not exist"
