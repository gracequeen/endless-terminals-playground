# test_final_state.py
"""
Tests to validate the final state after the student has fixed the pip install issue
by removing the spurious requests dependency from httpcore's METADATA.
"""

import os
import subprocess
import zipfile
import tempfile
import hashlib
import shutil
import pytest


class TestHttpcoreMetadataFixed:
    """Verify the httpcore wheel METADATA no longer has the spurious requests dependency."""

    HTTPCORE_WHEEL = "/home/user/packages/mirror/simple/httpcore/httpcore-1.0.5-py3-none-any.whl"

    def test_httpcore_wheel_exists(self):
        """httpcore wheel must still exist in the mirror."""
        assert os.path.isfile(self.HTTPCORE_WHEEL), \
            f"httpcore wheel not found at {self.HTTPCORE_WHEEL}"

    def test_httpcore_wheel_is_valid_zip(self):
        """httpcore wheel must still be a valid zip file."""
        assert zipfile.is_zipfile(self.HTTPCORE_WHEEL), \
            f"{self.HTTPCORE_WHEEL} is not a valid zip/wheel file"

    def test_httpcore_metadata_no_requests_dependency(self):
        """
        The httpcore METADATA must NOT have the spurious requests dependency.
        This is the core fix that was required.
        """
        with zipfile.ZipFile(self.HTTPCORE_WHEEL, 'r') as zf:
            metadata_files = [n for n in zf.namelist() if n.endswith('/METADATA')]
            assert len(metadata_files) > 0, "No METADATA file found in httpcore wheel"

            metadata_content = zf.read(metadata_files[0]).decode('utf-8')
            lines = metadata_content.split('\n')

            # Check that there's no Requires-Dist line mentioning requests
            requests_deps = [l for l in lines if 'Requires-Dist' in l and 'requests' in l.lower()]
            assert len(requests_deps) == 0, \
                f"httpcore METADATA still has spurious requests dependency: {requests_deps}. " \
                "The fix requires removing the 'Requires-Dist: requests>=2.0' line from METADATA."

    def test_httpcore_metadata_still_has_certifi_dependency(self):
        """httpcore should still declare certifi dependency (legitimate dep)."""
        with zipfile.ZipFile(self.HTTPCORE_WHEEL, 'r') as zf:
            metadata_files = [n for n in zf.namelist() if n.endswith('/METADATA')]
            metadata_content = zf.read(metadata_files[0]).decode('utf-8')
            lines = metadata_content.split('\n')

            certifi_deps = [l for l in lines if 'Requires-Dist' in l and 'certifi' in l.lower()]
            assert len(certifi_deps) > 0, \
                "httpcore METADATA is missing the certifi dependency - only the spurious requests dep should be removed"

    def test_httpcore_metadata_still_has_h11_dependency(self):
        """httpcore should still declare h11 dependency (legitimate dep)."""
        with zipfile.ZipFile(self.HTTPCORE_WHEEL, 'r') as zf:
            metadata_files = [n for n in zf.namelist() if n.endswith('/METADATA')]
            metadata_content = zf.read(metadata_files[0]).decode('utf-8')
            lines = metadata_content.split('\n')

            h11_deps = [l for l in lines if 'Requires-Dist' in l and 'h11' in l.lower()]
            assert len(h11_deps) > 0, \
                "httpcore METADATA is missing the h11 dependency - only the spurious requests dep should be removed"


class TestMyPackageWheelUnchanged:
    """Verify the mypackage wheel remains byte-identical (invariant)."""

    WHEEL_PATH = "/home/user/packages/mypackage-2.1.0-py3-none-any.whl"

    def test_wheel_file_exists(self):
        """The mypackage wheel must still exist."""
        assert os.path.isfile(self.WHEEL_PATH), \
            f"mypackage wheel not found at {self.WHEEL_PATH}"

    def test_wheel_is_valid_zip(self):
        """The wheel must still be a valid zip file."""
        assert zipfile.is_zipfile(self.WHEEL_PATH), \
            f"{self.WHEEL_PATH} is not a valid zip/wheel file"

    def test_wheel_contains_metadata(self):
        """The wheel must still contain METADATA file."""
        with zipfile.ZipFile(self.WHEEL_PATH, 'r') as zf:
            metadata_files = [n for n in zf.namelist() if n.endswith('/METADATA')]
            assert len(metadata_files) > 0, \
                f"No METADATA file found in {self.WHEEL_PATH}"

    def test_wheel_metadata_still_declares_httpcore_dependency(self):
        """The mypackage wheel must still declare httpcore>=0.17 as a dependency."""
        with zipfile.ZipFile(self.WHEEL_PATH, 'r') as zf:
            metadata_files = [n for n in zf.namelist() if n.endswith('/METADATA')]
            metadata_content = zf.read(metadata_files[0]).decode('utf-8')
            lines = metadata_content.split('\n')

            httpcore_deps = [l for l in lines if 'Requires-Dist' in l and 'httpcore' in l.lower()]
            assert len(httpcore_deps) > 0, \
                "mypackage METADATA no longer has Requires-Dist for httpcore - wheel was modified incorrectly"


class TestMirrorStructureIntact:
    """Verify the mirror still has proper PEP 503 structure."""

    MIRROR_PATH = "/home/user/packages/mirror"
    SIMPLE_PATH = "/home/user/packages/mirror/simple"

    def test_mirror_directory_exists(self):
        """The mirror directory must still exist."""
        assert os.path.isdir(self.MIRROR_PATH), \
            f"Mirror directory not found at {self.MIRROR_PATH}"

    def test_simple_directory_exists(self):
        """The simple/ directory must still exist."""
        assert os.path.isdir(self.SIMPLE_PATH), \
            f"PEP 503 simple directory not found at {self.SIMPLE_PATH}"

    def test_simple_index_html_exists(self):
        """The simple/index.html must still exist."""
        index_path = os.path.join(self.SIMPLE_PATH, "index.html")
        assert os.path.isfile(index_path), \
            f"Main index.html not found at {index_path}"


class TestMirrorPackagesStillPresent:
    """Verify all required packages are still in the mirror."""

    SIMPLE_PATH = "/home/user/packages/mirror/simple"

    REQUIRED_PACKAGES = [
        ("httpcore", "httpcore-1.0.5-py3-none-any.whl"),
        ("certifi", "certifi-2024.2.2-py3-none-any.whl"),
        ("h11", "h11-0.14.0-py3-none-any.whl"),
        ("h11", "h11-0.12.0-py3-none-any.whl"),
        ("requests", "requests-2.31.0-py3-none-any.whl"),
        ("urllib3", "urllib3-2.2.1-py3-none-any.whl"),
        ("charset-normalizer", "charset_normalizer-3.3.2-py3-none-any.whl"),
        ("idna", "idna-3.6-py3-none-any.whl"),
    ]

    @pytest.mark.parametrize("pkg_name,wheel_name", REQUIRED_PACKAGES)
    def test_package_directory_exists(self, pkg_name, wheel_name):
        """Each package must still have its directory in the mirror."""
        pkg_dir = os.path.join(self.SIMPLE_PATH, pkg_name)
        assert os.path.isdir(pkg_dir), \
            f"Package directory not found: {pkg_dir}"

    @pytest.mark.parametrize("pkg_name,wheel_name", REQUIRED_PACKAGES)
    def test_wheel_file_exists_in_mirror(self, pkg_name, wheel_name):
        """Each wheel file must still exist in the mirror."""
        wheel_path = os.path.join(self.SIMPLE_PATH, pkg_name, wheel_name)
        assert os.path.isfile(wheel_path), \
            f"Wheel file not found: {wheel_path}"

    @pytest.mark.parametrize("pkg_name,wheel_name", REQUIRED_PACKAGES)
    def test_wheel_is_valid(self, pkg_name, wheel_name):
        """Each wheel must still be a valid zip file."""
        wheel_path = os.path.join(self.SIMPLE_PATH, pkg_name, wheel_name)
        assert zipfile.is_zipfile(wheel_path), \
            f"Invalid wheel (not a zip): {wheel_path}"

    @pytest.mark.parametrize("pkg_name,wheel_name", REQUIRED_PACKAGES)
    def test_package_index_html_exists(self, pkg_name, wheel_name):
        """Each package directory must still have an index.html."""
        index_path = os.path.join(self.SIMPLE_PATH, pkg_name, "index.html")
        assert os.path.isfile(index_path), \
            f"Package index.html not found: {index_path}"


class TestNoNewPackagesAdded:
    """Verify no new packages were added to the mirror."""

    SIMPLE_PATH = "/home/user/packages/mirror/simple"

    EXPECTED_PACKAGES = {
        "httpcore", "certifi", "h11", "requests",
        "urllib3", "charset-normalizer", "idna"
    }

    def test_no_h2_added(self):
        """h2 package should NOT have been added to the mirror."""
        h2_dir = os.path.join(self.SIMPLE_PATH, "h2")
        assert not os.path.exists(h2_dir), \
            f"h2 package was added to mirror at {h2_dir} - the fix should not add new packages"

    def test_only_expected_package_directories(self):
        """Only the original packages should exist in the mirror."""
        if not os.path.isdir(self.SIMPLE_PATH):
            pytest.skip("simple directory doesn't exist")

        entries = os.listdir(self.SIMPLE_PATH)
        # Filter out index.html and any hidden files
        pkg_dirs = {e for e in entries if os.path.isdir(os.path.join(self.SIMPLE_PATH, e))}

        unexpected = pkg_dirs - self.EXPECTED_PACKAGES
        assert len(unexpected) == 0, \
            f"Unexpected package directories found in mirror: {unexpected}. " \
            "The fix should not add new packages."


class TestPipInstallSucceeds:
    """
    The main validation: pip install of mypackage must now succeed.
    """

    def test_pip_install_mypackage_succeeds(self):
        """
        Installing mypackage using pip with the local mirror should now succeed.
        """
        venv_path = "/tmp/testenv"

        # Clean up any existing test venv
        if os.path.exists(venv_path):
            shutil.rmtree(venv_path)

        # Create venv
        result = subprocess.run(
            ["python3", "-m", "venv", venv_path],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            f"Failed to create test venv: {result.stderr}"

        pip_path = os.path.join(venv_path, "bin", "pip")

        # Install mypackage
        result = subprocess.run(
            [
                pip_path, "install",
                "--no-index",
                "--find-links", "/home/user/packages/mirror/simple",
                "/home/user/packages/mypackage-2.1.0-py3-none-any.whl"
            ],
            capture_output=True,
            text=True,
            timeout=120
        )

        assert result.returncode == 0, \
            f"pip install failed with exit code {result.returncode}.\n" \
            f"STDOUT:\n{result.stdout}\n" \
            f"STDERR:\n{result.stderr}\n" \
            "The httpcore METADATA may still have the spurious requests dependency."

    def test_mypackage_importable(self):
        """
        After installation, mypackage must be importable.
        """
        venv_path = "/tmp/testenv"
        python_path = os.path.join(venv_path, "bin", "python")

        # Check that the venv exists (created by previous test)
        if not os.path.exists(python_path):
            pytest.skip("Test venv not found - run test_pip_install_mypackage_succeeds first")

        result = subprocess.run(
            [python_path, "-c", "import mypackage; print('ok')"],
            capture_output=True,
            text=True,
            timeout=30
        )

        assert result.returncode == 0, \
            f"Failed to import mypackage: {result.stderr}"
        assert "ok" in result.stdout, \
            f"Expected 'ok' in output, got: {result.stdout}"

    def test_httpcore_installed(self):
        """
        httpcore must be installed as a dependency of mypackage.
        """
        venv_path = "/tmp/testenv"
        python_path = os.path.join(venv_path, "bin", "python")

        if not os.path.exists(python_path):
            pytest.skip("Test venv not found")

        result = subprocess.run(
            [python_path, "-c", "import httpcore; print('httpcore ok')"],
            capture_output=True,
            text=True,
            timeout=30
        )

        assert result.returncode == 0, \
            f"httpcore not installed or not importable: {result.stderr}"


class TestAntiShortcutGuards:
    """
    Verify the fix was done correctly and not via shortcuts.
    """

    def test_httpcore_metadata_grep_no_requests(self):
        """
        Using unzip to grep METADATA must show no requests dependency.
        This guards against workarounds that don't actually fix the wheel.
        """
        httpcore_wheel = "/home/user/packages/mirror/simple/httpcore/httpcore-1.0.5-py3-none-any.whl"

        # Use unzip -p to extract METADATA and grep for requests
        result = subprocess.run(
            f"unzip -p '{httpcore_wheel}' '*/METADATA' | grep -i 'Requires-Dist.*requests'",
            shell=True,
            capture_output=True,
            text=True
        )

        # grep returns 1 if no match found (which is what we want)
        assert result.returncode != 0, \
            f"Found requests dependency in httpcore METADATA: {result.stdout}\n" \
            "The spurious 'Requires-Dist: requests>=2.0' line must be removed from the wheel's METADATA."

    def test_not_using_no_deps(self):
        """
        Verify the installation works without --no-deps flag.
        Using --no-deps would be a shortcut that breaks actual dependencies.
        """
        venv_path = "/tmp/testenv"

        if os.path.exists(venv_path):
            shutil.rmtree(venv_path)

        # Create fresh venv
        result = subprocess.run(
            ["python3", "-m", "venv", venv_path],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, f"Failed to create venv: {result.stderr}"

        pip_path = os.path.join(venv_path, "bin", "pip")

        # Install WITHOUT --no-deps
        result = subprocess.run(
            [
                pip_path, "install",
                "--no-index",
                "--find-links", "/home/user/packages/mirror/simple",
                "/home/user/packages/mypackage-2.1.0-py3-none-any.whl"
            ],
            capture_output=True,
            text=True,
            timeout=120
        )

        assert result.returncode == 0, \
            f"Installation failed without --no-deps. The fix must allow normal dependency resolution.\n" \
            f"STDERR: {result.stderr}"

        # Verify dependencies were actually installed
        python_path = os.path.join(venv_path, "bin", "python")

        for pkg in ["httpcore", "certifi", "h11"]:
            result = subprocess.run(
                [python_path, "-c", f"import {pkg}"],
                capture_output=True,
                text=True
            )
            assert result.returncode == 0, \
                f"Dependency {pkg} was not installed. The fix must preserve proper dependency installation."
