# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the task of fixing the pip install issue with mypackage.
"""

import os
import subprocess
import zipfile
import tempfile
import shutil
import pytest


class TestMyPackageWheelExists:
    """Verify the mypackage wheel exists and is valid."""

    WHEEL_PATH = "/home/user/packages/mypackage-2.1.0-py3-none-any.whl"

    def test_wheel_file_exists(self):
        """The mypackage wheel must exist."""
        assert os.path.isfile(self.WHEEL_PATH), \
            f"mypackage wheel not found at {self.WHEEL_PATH}"

    def test_wheel_is_valid_zip(self):
        """The wheel must be a valid zip file."""
        assert zipfile.is_zipfile(self.WHEEL_PATH), \
            f"{self.WHEEL_PATH} is not a valid zip/wheel file"

    def test_wheel_contains_metadata(self):
        """The wheel must contain METADATA file."""
        with zipfile.ZipFile(self.WHEEL_PATH, 'r') as zf:
            metadata_files = [n for n in zf.namelist() if n.endswith('/METADATA')]
            assert len(metadata_files) > 0, \
                f"No METADATA file found in {self.WHEEL_PATH}"

    def test_wheel_metadata_declares_httpcore_dependency(self):
        """The mypackage wheel must declare httpcore>=0.17 as a dependency."""
        with zipfile.ZipFile(self.WHEEL_PATH, 'r') as zf:
            metadata_files = [n for n in zf.namelist() if n.endswith('/METADATA')]
            metadata_content = zf.read(metadata_files[0]).decode('utf-8')

            # Check for httpcore dependency
            assert 'httpcore' in metadata_content.lower(), \
                "mypackage METADATA does not mention httpcore dependency"

            # More specific check for Requires-Dist: httpcore>=0.17
            lines = metadata_content.split('\n')
            httpcore_deps = [l for l in lines if 'Requires-Dist' in l and 'httpcore' in l.lower()]
            assert len(httpcore_deps) > 0, \
                "mypackage METADATA does not have Requires-Dist for httpcore"


class TestMirrorDirectoryStructure:
    """Verify the mirror has proper PEP 503 structure."""

    MIRROR_PATH = "/home/user/packages/mirror"
    SIMPLE_PATH = "/home/user/packages/mirror/simple"

    def test_mirror_directory_exists(self):
        """The mirror directory must exist."""
        assert os.path.isdir(self.MIRROR_PATH), \
            f"Mirror directory not found at {self.MIRROR_PATH}"

    def test_simple_directory_exists(self):
        """The simple/ directory must exist for PEP 503 compliance."""
        assert os.path.isdir(self.SIMPLE_PATH), \
            f"PEP 503 simple directory not found at {self.SIMPLE_PATH}"

    def test_simple_index_html_exists(self):
        """The simple/index.html must exist."""
        index_path = os.path.join(self.SIMPLE_PATH, "index.html")
        assert os.path.isfile(index_path), \
            f"Main index.html not found at {index_path}"


class TestMirrorPackages:
    """Verify all required packages are in the mirror."""

    SIMPLE_PATH = "/home/user/packages/mirror/simple"

    REQUIRED_PACKAGES = [
        ("httpcore", "httpcore-1.0.5-py3-none-any.whl"),
        ("certifi", "certifi-2024.2.2-py3-none-any.whl"),
        ("h11", "h11-0.14.0-py3-none-any.whl"),
        ("h11", "h11-0.12.0-py3-none-any.whl"),
        ("requests", "requests-2.31.0-py3-none-any.whl"),
        ("urllib3", "urllib3-2.2.1-py3-none-any.whl"),
        ("charset-normalizer", "charset_normalizer-3.3.2-py3-none-any.whl"),
        ("idna", "idna-3.6-py3-none-any.whl"),
    ]

    @pytest.mark.parametrize("pkg_name,wheel_name", REQUIRED_PACKAGES)
    def test_package_directory_exists(self, pkg_name, wheel_name):
        """Each package must have its directory in the mirror."""
        pkg_dir = os.path.join(self.SIMPLE_PATH, pkg_name)
        assert os.path.isdir(pkg_dir), \
            f"Package directory not found: {pkg_dir}"

    @pytest.mark.parametrize("pkg_name,wheel_name", REQUIRED_PACKAGES)
    def test_wheel_file_exists_in_mirror(self, pkg_name, wheel_name):
        """Each wheel file must exist in the mirror."""
        wheel_path = os.path.join(self.SIMPLE_PATH, pkg_name, wheel_name)
        assert os.path.isfile(wheel_path), \
            f"Wheel file not found: {wheel_path}"

    @pytest.mark.parametrize("pkg_name,wheel_name", REQUIRED_PACKAGES)
    def test_wheel_is_valid(self, pkg_name, wheel_name):
        """Each wheel must be a valid zip file."""
        wheel_path = os.path.join(self.SIMPLE_PATH, pkg_name, wheel_name)
        assert zipfile.is_zipfile(wheel_path), \
            f"Invalid wheel (not a zip): {wheel_path}"

    @pytest.mark.parametrize("pkg_name,wheel_name", REQUIRED_PACKAGES)
    def test_package_index_html_exists(self, pkg_name, wheel_name):
        """Each package directory must have an index.html."""
        index_path = os.path.join(self.SIMPLE_PATH, pkg_name, "index.html")
        assert os.path.isfile(index_path), \
            f"Package index.html not found: {index_path}"


class TestHttpcoreCorruptMetadata:
    """Verify the httpcore wheel has the corrupt METADATA with spurious requests dependency."""

    HTTPCORE_WHEEL = "/home/user/packages/mirror/simple/httpcore/httpcore-1.0.5-py3-none-any.whl"

    def test_httpcore_wheel_exists(self):
        """httpcore wheel must exist."""
        assert os.path.isfile(self.HTTPCORE_WHEEL), \
            f"httpcore wheel not found at {self.HTTPCORE_WHEEL}"

    def test_httpcore_metadata_has_spurious_requests_dependency(self):
        """
        The httpcore METADATA must have the spurious requests dependency.
        This is the bug that needs to be fixed.
        """
        with zipfile.ZipFile(self.HTTPCORE_WHEEL, 'r') as zf:
            metadata_files = [n for n in zf.namelist() if n.endswith('/METADATA')]
            assert len(metadata_files) > 0, "No METADATA in httpcore wheel"

            metadata_content = zf.read(metadata_files[0]).decode('utf-8')
            lines = metadata_content.split('\n')

            # Look for the spurious requests dependency
            requests_deps = [l for l in lines if 'Requires-Dist' in l and 'requests' in l.lower()]
            assert len(requests_deps) > 0, \
                "httpcore METADATA does not have the spurious requests dependency - " \
                "the bug may have already been fixed or the initial state is incorrect"

    def test_httpcore_metadata_has_certifi_dependency(self):
        """httpcore should declare certifi dependency."""
        with zipfile.ZipFile(self.HTTPCORE_WHEEL, 'r') as zf:
            metadata_files = [n for n in zf.namelist() if n.endswith('/METADATA')]
            metadata_content = zf.read(metadata_files[0]).decode('utf-8')

            assert 'certifi' in metadata_content.lower(), \
                "httpcore METADATA should have certifi dependency"

    def test_httpcore_metadata_has_h11_dependency(self):
        """httpcore should declare h11 dependency."""
        with zipfile.ZipFile(self.HTTPCORE_WHEEL, 'r') as zf:
            metadata_files = [n for n in zf.namelist() if n.endswith('/METADATA')]
            metadata_content = zf.read(metadata_files[0]).decode('utf-8')

            assert 'h11' in metadata_content.lower(), \
                "httpcore METADATA should have h11 dependency"


class TestPythonAndPipAvailable:
    """Verify Python 3.11 and pip are available."""

    def test_python3_available(self):
        """Python 3 must be available."""
        result = subprocess.run(
            ["python3", "--version"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            f"python3 not available: {result.stderr}"

    def test_python_version_is_3_11(self):
        """Python version should be 3.11."""
        result = subprocess.run(
            ["python3", "-c", "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, f"Failed to get Python version: {result.stderr}"
        version = result.stdout.strip()
        assert version == "3.11", \
            f"Expected Python 3.11, got {version}"

    def test_pip_available(self):
        """pip must be available."""
        result = subprocess.run(
            ["python3", "-m", "pip", "--version"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            f"pip not available: {result.stderr}"

    def test_venv_module_available(self):
        """venv module must be available."""
        result = subprocess.run(
            ["python3", "-c", "import venv"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            f"venv module not available: {result.stderr}"


class TestPackagesDirectoryWritable:
    """Verify the packages directory is writable."""

    PACKAGES_DIR = "/home/user/packages"

    def test_packages_directory_exists(self):
        """The packages directory must exist."""
        assert os.path.isdir(self.PACKAGES_DIR), \
            f"Packages directory not found at {self.PACKAGES_DIR}"

    def test_packages_directory_is_writable(self):
        """The packages directory must be writable."""
        test_file = os.path.join(self.PACKAGES_DIR, ".write_test")
        try:
            with open(test_file, 'w') as f:
                f.write("test")
            os.remove(test_file)
        except (IOError, OSError) as e:
            pytest.fail(f"Packages directory is not writable: {e}")

    def test_mirror_directory_is_writable(self):
        """The mirror directory must be writable."""
        test_file = os.path.join(self.PACKAGES_DIR, "mirror", ".write_test")
        try:
            with open(test_file, 'w') as f:
                f.write("test")
            os.remove(test_file)
        except (IOError, OSError) as e:
            pytest.fail(f"Mirror directory is not writable: {e}")


class TestInstallCurrentlyFails:
    """
    Verify that the pip install currently fails due to the corrupt metadata.
    This confirms the bug exists and needs to be fixed.
    """

    def test_pip_install_fails_with_current_state(self):
        """
        Installing mypackage should currently fail due to the corrupt httpcore metadata.
        """
        # Create a temporary venv
        with tempfile.TemporaryDirectory() as tmpdir:
            venv_path = os.path.join(tmpdir, "testenv")

            # Create venv
            result = subprocess.run(
                ["python3", "-m", "venv", venv_path],
                capture_output=True,
                text=True
            )
            if result.returncode != 0:
                pytest.skip(f"Could not create test venv: {result.stderr}")

            pip_path = os.path.join(venv_path, "bin", "pip")

            # Try to install mypackage - this should fail
            result = subprocess.run(
                [
                    pip_path, "install",
                    "--no-index",
                    "--find-links", "/home/user/packages/mirror/simple",
                    "/home/user/packages/mypackage-2.1.0-py3-none-any.whl"
                ],
                capture_output=True,
                text=True,
                timeout=120
            )

            # The install should fail due to the corrupt metadata
            assert result.returncode != 0, \
                "pip install succeeded but should have failed due to corrupt httpcore metadata. " \
                "The bug may have already been fixed."


class TestNoH2InMirror:
    """Verify that h2 is NOT in the mirror (part of the bug scenario)."""

    SIMPLE_PATH = "/home/user/packages/mirror/simple"

    def test_h2_not_in_mirror(self):
        """h2 package should NOT be in the mirror."""
        h2_dir = os.path.join(self.SIMPLE_PATH, "h2")
        assert not os.path.exists(h2_dir), \
            f"h2 package found in mirror at {h2_dir} - it should NOT be there for this test scenario"
