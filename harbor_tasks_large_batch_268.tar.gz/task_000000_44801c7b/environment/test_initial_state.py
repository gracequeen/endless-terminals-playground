# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the security scanner debugging task.
"""

import os
import json
import subprocess
import pytest


HOME = "/home/user"
SCANNER_DIR = os.path.join(HOME, "scanner")
TARGETS_DIR = os.path.join(HOME, "targets")
REPORTS_DIR = os.path.join(HOME, "reports")


class TestScannerDirectoryStructure:
    """Verify the scanner directory and its contents exist."""

    def test_scanner_directory_exists(self):
        assert os.path.isdir(SCANNER_DIR), f"Scanner directory {SCANNER_DIR} does not exist"

    def test_scan_py_exists(self):
        scan_py = os.path.join(SCANNER_DIR, "scan.py")
        assert os.path.isfile(scan_py), f"scan.py not found at {scan_py}"

    def test_scanner_conf_exists(self):
        scanner_conf = os.path.join(SCANNER_DIR, "scanner.conf")
        assert os.path.isfile(scanner_conf), f"scanner.conf not found at {scanner_conf}"

    def test_patterns_txt_exists(self):
        patterns_txt = os.path.join(SCANNER_DIR, "patterns.txt")
        assert os.path.isfile(patterns_txt), f"patterns.txt not found at {patterns_txt}"

    def test_scan_log_exists(self):
        scan_log = os.path.join(SCANNER_DIR, "scan.log")
        assert os.path.isfile(scan_log), f"scan.log not found at {scan_log}"


class TestScannerConfiguration:
    """Verify scanner configuration contains expected settings."""

    def test_scanner_conf_has_timeout_per_repo(self):
        scanner_conf = os.path.join(SCANNER_DIR, "scanner.conf")
        with open(scanner_conf, 'r') as f:
            content = f.read()
        assert 'timeout_per_repo' in content, "scanner.conf missing timeout_per_repo setting"

    def test_scanner_conf_has_max_file_size_kb(self):
        scanner_conf = os.path.join(SCANNER_DIR, "scanner.conf")
        with open(scanner_conf, 'r') as f:
            content = f.read()
        assert 'max_file_size_kb' in content, "scanner.conf missing max_file_size_kb setting"

    def test_scanner_conf_has_patterns_file(self):
        scanner_conf = os.path.join(SCANNER_DIR, "scanner.conf")
        with open(scanner_conf, 'r') as f:
            content = f.read()
        assert 'patterns_file' in content, "scanner.conf missing patterns_file setting"

    def test_scanner_conf_has_fail_fast(self):
        scanner_conf = os.path.join(SCANNER_DIR, "scanner.conf")
        with open(scanner_conf, 'r') as f:
            content = f.read()
        assert 'fail_fast' in content, "scanner.conf missing fail_fast setting"

    def test_scanner_conf_fail_fast_is_true(self):
        scanner_conf = os.path.join(SCANNER_DIR, "scanner.conf")
        with open(scanner_conf, 'r') as f:
            content = f.read()
        # Check that fail_fast is set to true (YAML format)
        assert 'fail_fast: true' in content or 'fail_fast:true' in content.replace(' ', ''), \
            "scanner.conf fail_fast should be set to true initially"


class TestPatternsFile:
    """Verify patterns.txt contains security patterns."""

    def test_patterns_file_not_empty(self):
        patterns_txt = os.path.join(SCANNER_DIR, "patterns.txt")
        with open(patterns_txt, 'r') as f:
            content = f.read().strip()
        assert len(content) > 0, "patterns.txt is empty"

    def test_patterns_file_has_patterns(self):
        patterns_txt = os.path.join(SCANNER_DIR, "patterns.txt")
        with open(patterns_txt, 'r') as f:
            lines = [l.strip() for l in f.readlines() if l.strip()]
        assert len(lines) >= 1, "patterns.txt should contain at least one pattern"


class TestScanLog:
    """Verify scan.log shows previous failure."""

    def test_scan_log_shows_terminated(self):
        scan_log = os.path.join(SCANNER_DIR, "scan.log")
        with open(scan_log, 'r') as f:
            content = f.read()
        assert 'terminated' in content.lower() or 'exit' in content.lower(), \
            "scan.log should show evidence of previous scan termination"


class TestTargetsDirectory:
    """Verify the targets directory structure."""

    def test_targets_directory_exists(self):
        assert os.path.isdir(TARGETS_DIR), f"Targets directory {TARGETS_DIR} does not exist"

    def test_repo1_exists(self):
        repo1 = os.path.join(TARGETS_DIR, "repo1")
        assert os.path.isdir(repo1), f"repo1 not found at {repo1}"

    def test_repo2_exists(self):
        repo2 = os.path.join(TARGETS_DIR, "repo2")
        assert os.path.isdir(repo2), f"repo2 not found at {repo2}"

    def test_repo3_exists(self):
        repo3 = os.path.join(TARGETS_DIR, "repo3")
        assert os.path.isdir(repo3), f"repo3 not found at {repo3}"

    def test_repo4_exists(self):
        repo4 = os.path.join(TARGETS_DIR, "repo4")
        assert os.path.isdir(repo4), f"repo4 not found at {repo4}"

    def test_repo5_exists(self):
        repo5 = os.path.join(TARGETS_DIR, "repo5")
        assert os.path.isdir(repo5), f"repo5 not found at {repo5}"

    def test_exactly_five_repos(self):
        repos = [d for d in os.listdir(TARGETS_DIR) 
                 if os.path.isdir(os.path.join(TARGETS_DIR, d))]
        assert len(repos) == 5, f"Expected 5 repos in targets, found {len(repos)}: {repos}"


class TestProblematicFile:
    """Verify the problematic file in repo3 exists with expected properties."""

    def test_legacy_config_dat_exists(self):
        legacy_file = os.path.join(TARGETS_DIR, "repo3", "legacy_config.dat")
        assert os.path.isfile(legacy_file), f"legacy_config.dat not found at {legacy_file}"

    def test_legacy_config_dat_size_exceeds_512kb(self):
        legacy_file = os.path.join(TARGETS_DIR, "repo3", "legacy_config.dat")
        size_kb = os.path.getsize(legacy_file) / 1024
        assert size_kb > 512, f"legacy_config.dat should be > 512KB, but is {size_kb:.2f}KB"

    def test_legacy_config_dat_is_binary(self):
        legacy_file = os.path.join(TARGETS_DIR, "repo3", "legacy_config.dat")
        with open(legacy_file, 'rb') as f:
            content = f.read(1024)  # Read first 1KB
        # Try to decode as UTF-8 - should fail for binary data
        try:
            content.decode('utf-8')
            # If it succeeds, check for null bytes or other binary indicators
            has_null = b'\x00' in content
            assert has_null, "legacy_config.dat should contain binary data"
        except UnicodeDecodeError:
            # This is expected - file is binary
            pass


class TestReportsDirectory:
    """Verify the reports directory exists."""

    def test_reports_directory_exists(self):
        assert os.path.isdir(REPORTS_DIR), f"Reports directory {REPORTS_DIR} does not exist"


class TestScanPyContent:
    """Verify scan.py has the expected buggy structure."""

    def test_scan_py_is_python(self):
        scan_py = os.path.join(SCANNER_DIR, "scan.py")
        with open(scan_py, 'r') as f:
            content = f.read()
        # Should contain Python-like constructs
        assert 'def ' in content or 'import ' in content, "scan.py doesn't appear to be a Python file"

    def test_scan_py_reads_config(self):
        scan_py = os.path.join(SCANNER_DIR, "scan.py")
        with open(scan_py, 'r') as f:
            content = f.read()
        # Should reference the config file
        assert 'scanner.conf' in content or 'conf' in content.lower(), \
            "scan.py should reference configuration"

    def test_scan_py_has_pattern_matching(self):
        scan_py = os.path.join(SCANNER_DIR, "scan.py")
        with open(scan_py, 'r') as f:
            content = f.read()
        # Should have regex/pattern matching
        assert 're.' in content or 'regex' in content.lower() or 'pattern' in content.lower(), \
            "scan.py should perform pattern matching"

    def test_scan_py_writes_json(self):
        scan_py = os.path.join(SCANNER_DIR, "scan.py")
        with open(scan_py, 'r') as f:
            content = f.read()
        assert 'json' in content.lower(), "scan.py should work with JSON output"


class TestPythonEnvironment:
    """Verify Python environment is set up correctly."""

    def test_python3_available(self):
        result = subprocess.run(['python3', '--version'], capture_output=True, text=True)
        assert result.returncode == 0, "python3 is not available"

    def test_python_version_3_11_or_higher(self):
        result = subprocess.run(['python3', '-c', 'import sys; print(sys.version_info.minor)'], 
                               capture_output=True, text=True)
        assert result.returncode == 0, "Failed to get Python version"
        # Just verify Python 3 works, version check is informational

    def test_pyyaml_installed(self):
        result = subprocess.run(['python3', '-c', 'import yaml'], capture_output=True, text=True)
        assert result.returncode == 0, "PyYAML is not installed"


class TestScannerCurrentlyFails:
    """Verify that the scanner currently fails (the bug exists)."""

    def test_scanner_exits_nonzero(self):
        """The scanner should currently fail with exit code 1."""
        result = subprocess.run(
            ['python3', 'scan.py'],
            cwd=SCANNER_DIR,
            capture_output=True,
            text=True,
            timeout=60
        )
        assert result.returncode != 0, \
            f"Scanner should currently fail but exited with code {result.returncode}"

    def test_scan_json_incomplete_or_missing(self):
        """scan.json should be missing or incomplete."""
        scan_json = os.path.join(REPORTS_DIR, "scan.json")
        if not os.path.exists(scan_json):
            # Missing is expected
            return

        # If it exists, it should be incomplete (not all 5 repos)
        try:
            with open(scan_json, 'r') as f:
                data = json.load(f)
            if 'repos_scanned' in data:
                repos = data['repos_scanned']
                if isinstance(repos, list) and len(repos) == 5:
                    pytest.fail("scan.json already has all 5 repos - scan should be failing")
        except (json.JSONDecodeError, KeyError):
            # Partial/corrupted JSON is expected
            pass


class TestHomeWritable:
    """Verify /home/user is writable."""

    def test_home_directory_writable(self):
        test_file = os.path.join(HOME, ".write_test_tmp")
        try:
            with open(test_file, 'w') as f:
                f.write("test")
            os.remove(test_file)
        except (IOError, OSError) as e:
            pytest.fail(f"/home/user is not writable: {e}")
