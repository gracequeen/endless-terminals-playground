# test_final_state.py
"""
Tests to validate the final state of the OS/filesystem after the student
has completed the security scanner debugging task.
"""

import os
import json
import subprocess
import pytest


HOME = "/home/user"
SCANNER_DIR = os.path.join(HOME, "scanner")
TARGETS_DIR = os.path.join(HOME, "targets")
REPORTS_DIR = os.path.join(HOME, "reports")


class TestScannerExitsSuccessfully:
    """Verify the scanner now completes successfully."""

    def test_scanner_exits_zero(self):
        """The scanner should now exit with code 0."""
        result = subprocess.run(
            ['python3', 'scan.py'],
            cwd=SCANNER_DIR,
            capture_output=True,
            text=True,
            timeout=120
        )
        assert result.returncode == 0, \
            f"Scanner should exit 0 but exited with code {result.returncode}.\n" \
            f"stdout: {result.stdout}\nstderr: {result.stderr}"


class TestScanJsonOutput:
    """Verify scan.json exists and contains valid complete output."""

    def test_scan_json_exists(self):
        scan_json = os.path.join(REPORTS_DIR, "scan.json")
        assert os.path.isfile(scan_json), \
            f"scan.json not found at {scan_json}"

    def test_scan_json_is_valid_json(self):
        scan_json = os.path.join(REPORTS_DIR, "scan.json")
        with open(scan_json, 'r') as f:
            content = f.read()
        try:
            data = json.loads(content)
        except json.JSONDecodeError as e:
            pytest.fail(f"scan.json is not valid JSON: {e}")

    def test_scan_json_has_repos_scanned(self):
        scan_json = os.path.join(REPORTS_DIR, "scan.json")
        with open(scan_json, 'r') as f:
            data = json.load(f)
        assert 'repos_scanned' in data, \
            "scan.json missing 'repos_scanned' key"

    def test_repos_scanned_is_list(self):
        scan_json = os.path.join(REPORTS_DIR, "scan.json")
        with open(scan_json, 'r') as f:
            data = json.load(f)
        assert isinstance(data.get('repos_scanned'), list), \
            "'repos_scanned' should be a list"

    def test_repos_scanned_has_five_entries(self):
        scan_json = os.path.join(REPORTS_DIR, "scan.json")
        with open(scan_json, 'r') as f:
            data = json.load(f)
        repos = data.get('repos_scanned', [])
        assert len(repos) == 5, \
            f"'repos_scanned' should have 5 entries, found {len(repos)}"

    def test_all_five_repos_present(self):
        scan_json = os.path.join(REPORTS_DIR, "scan.json")
        with open(scan_json, 'r') as f:
            data = json.load(f)
        repos = data.get('repos_scanned', [])

        # Extract repo names from the list
        repo_names = set()
        for repo in repos:
            if isinstance(repo, dict) and 'name' in repo:
                repo_names.add(repo['name'])
            elif isinstance(repo, str):
                repo_names.add(repo)

        expected_repos = {'repo1', 'repo2', 'repo3', 'repo4', 'repo5'}
        missing = expected_repos - repo_names
        assert not missing, \
            f"Missing repos in scan.json: {missing}. Found: {repo_names}"


class TestTargetReposIntact:
    """Verify all target repos remain with original contents."""

    def test_targets_directory_exists(self):
        assert os.path.isdir(TARGETS_DIR), \
            f"Targets directory {TARGETS_DIR} does not exist"

    def test_repo1_exists(self):
        repo1 = os.path.join(TARGETS_DIR, "repo1")
        assert os.path.isdir(repo1), f"repo1 not found at {repo1}"

    def test_repo2_exists(self):
        repo2 = os.path.join(TARGETS_DIR, "repo2")
        assert os.path.isdir(repo2), f"repo2 not found at {repo2}"

    def test_repo3_exists(self):
        repo3 = os.path.join(TARGETS_DIR, "repo3")
        assert os.path.isdir(repo3), f"repo3 not found at {repo3}"

    def test_repo4_exists(self):
        repo4 = os.path.join(TARGETS_DIR, "repo4")
        assert os.path.isdir(repo4), f"repo4 not found at {repo4}"

    def test_repo5_exists(self):
        repo5 = os.path.join(TARGETS_DIR, "repo5")
        assert os.path.isdir(repo5), f"repo5 not found at {repo5}"

    def test_exactly_five_repos(self):
        repos = [d for d in os.listdir(TARGETS_DIR) 
                 if os.path.isdir(os.path.join(TARGETS_DIR, d))]
        assert len(repos) == 5, \
            f"Expected 5 repos in targets, found {len(repos)}: {repos}"


class TestLegacyConfigDatIntact:
    """Verify the problematic file was NOT deleted as a shortcut."""

    def test_legacy_config_dat_exists(self):
        legacy_file = os.path.join(TARGETS_DIR, "repo3", "legacy_config.dat")
        assert os.path.isfile(legacy_file), \
            f"legacy_config.dat must NOT be deleted - it should still exist at {legacy_file}"

    def test_legacy_config_dat_still_large(self):
        legacy_file = os.path.join(TARGETS_DIR, "repo3", "legacy_config.dat")
        size_kb = os.path.getsize(legacy_file) / 1024
        assert size_kb > 512, \
            f"legacy_config.dat should still be > 512KB (original size), but is {size_kb:.2f}KB"

    def test_ls_legacy_config_succeeds(self):
        """ls command on the file must succeed."""
        result = subprocess.run(
            ['ls', os.path.join(TARGETS_DIR, "repo3", "legacy_config.dat")],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            "ls /home/user/targets/repo3/legacy_config.dat must succeed - file should not be deleted"


class TestPatternsFileUnchanged:
    """Verify patterns.txt remains intact."""

    def test_patterns_file_exists(self):
        patterns_txt = os.path.join(SCANNER_DIR, "patterns.txt")
        assert os.path.isfile(patterns_txt), \
            f"patterns.txt not found at {patterns_txt}"

    def test_patterns_file_not_empty(self):
        patterns_txt = os.path.join(SCANNER_DIR, "patterns.txt")
        with open(patterns_txt, 'r') as f:
            content = f.read().strip()
        assert len(content) > 0, "patterns.txt should not be empty"

    def test_patterns_file_has_patterns(self):
        patterns_txt = os.path.join(SCANNER_DIR, "patterns.txt")
        with open(patterns_txt, 'r') as f:
            lines = [l.strip() for l in f.readlines() if l.strip() and not l.strip().startswith('#')]
        assert len(lines) >= 1, "patterns.txt should contain at least one pattern"


class TestScannerStillDoesRealPatternMatching:
    """Verify the scanner still performs actual pattern matching (not a stub)."""

    def test_scan_py_exists(self):
        scan_py = os.path.join(SCANNER_DIR, "scan.py")
        assert os.path.isfile(scan_py), f"scan.py not found at {scan_py}"

    def test_scan_py_uses_regex(self):
        scan_py = os.path.join(SCANNER_DIR, "scan.py")
        with open(scan_py, 'r') as f:
            content = f.read()
        # Should still have regex module usage
        assert 're.' in content or 'import re' in content, \
            "scan.py should still use the re module for pattern matching"

    def test_scan_py_reads_patterns_file(self):
        scan_py = os.path.join(SCANNER_DIR, "scan.py")
        with open(scan_py, 'r') as f:
            content = f.read()
        # Should reference patterns file
        assert 'patterns' in content.lower(), \
            "scan.py should still reference patterns file"

    def test_scan_py_has_pattern_from_patterns_txt(self):
        """Verify scan.py still references or uses patterns from patterns.txt."""
        patterns_txt = os.path.join(SCANNER_DIR, "patterns.txt")
        scan_py = os.path.join(SCANNER_DIR, "scan.py")

        # Read patterns
        with open(patterns_txt, 'r') as f:
            patterns = [l.strip() for l in f.readlines() if l.strip() and not l.strip().startswith('#')]

        # Read scan.py
        with open(scan_py, 'r') as f:
            scan_content = f.read()

        # The scanner should read from patterns.txt, so check it references the file
        # or check that it does pattern-based scanning
        has_pattern_loading = ('patterns.txt' in scan_content or 
                               'patterns_file' in scan_content or
                               'open(' in scan_content)

        assert has_pattern_loading, \
            "scan.py should load patterns from patterns.txt"

    def test_scan_py_iterates_targets(self):
        scan_py = os.path.join(SCANNER_DIR, "scan.py")
        with open(scan_py, 'r') as f:
            content = f.read()
        # Should iterate over targets directory
        assert 'targets' in content or 'listdir' in content or 'walk' in content or 'scandir' in content, \
            "scan.py should iterate over target directories"


class TestScannerConfigExists:
    """Verify scanner.conf still exists (may have been modified)."""

    def test_scanner_conf_exists(self):
        scanner_conf = os.path.join(SCANNER_DIR, "scanner.conf")
        assert os.path.isfile(scanner_conf), \
            f"scanner.conf not found at {scanner_conf}"


class TestScanCompletesWithAllRepos:
    """Run the scanner and verify it completes with all repos scanned."""

    def test_fresh_scan_completes_all_repos(self):
        """Run a fresh scan and verify all 5 repos are in output."""
        # Remove existing scan.json to force fresh scan
        scan_json = os.path.join(REPORTS_DIR, "scan.json")
        if os.path.exists(scan_json):
            os.remove(scan_json)

        # Run scanner
        result = subprocess.run(
            ['python3', 'scan.py'],
            cwd=SCANNER_DIR,
            capture_output=True,
            text=True,
            timeout=120
        )

        assert result.returncode == 0, \
            f"Scanner failed with exit code {result.returncode}.\n" \
            f"stdout: {result.stdout}\nstderr: {result.stderr}"

        # Verify output
        assert os.path.isfile(scan_json), \
            "scan.json was not created after running scanner"

        with open(scan_json, 'r') as f:
            data = json.load(f)

        repos = data.get('repos_scanned', [])
        repo_names = set()
        for repo in repos:
            if isinstance(repo, dict) and 'name' in repo:
                repo_names.add(repo['name'])
            elif isinstance(repo, str):
                repo_names.add(repo)

        expected_repos = {'repo1', 'repo2', 'repo3', 'repo4', 'repo5'}
        missing = expected_repos - repo_names
        assert not missing, \
            f"Fresh scan missing repos: {missing}. Found: {repo_names}"
