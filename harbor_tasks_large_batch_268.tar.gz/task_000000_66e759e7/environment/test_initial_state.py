# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the pipeline debugging task.
"""

import json
import os
import subprocess
import pytest


# === Directory Structure Tests ===

def test_ingest_directory_exists():
    """Verify /home/user/ingest/ directory exists."""
    path = "/home/user/ingest"
    assert os.path.isdir(path), f"Directory {path} does not exist"


def test_data_incoming_directory_exists():
    """Verify /data/incoming/ directory exists."""
    path = "/data/incoming"
    assert os.path.isdir(path), f"Directory {path} does not exist"


def test_data_warehouse_directory_exists():
    """Verify /data/warehouse/ directory exists."""
    path = "/data/warehouse"
    assert os.path.isdir(path), f"Directory {path} does not exist"


# === Pipeline Code Files Tests ===

def test_run_py_exists():
    """Verify run.py exists in /home/user/ingest/."""
    path = "/home/user/ingest/run.py"
    assert os.path.isfile(path), f"File {path} does not exist"


def test_transform_py_exists():
    """Verify transform.py exists in /home/user/ingest/."""
    path = "/home/user/ingest/transform.py"
    assert os.path.isfile(path), f"File {path} does not exist"


def test_policy_py_exists():
    """Verify policy.py exists in /home/user/ingest/."""
    path = "/home/user/ingest/policy.py"
    assert os.path.isfile(path), f"File {path} does not exist"


def test_progress_json_exists():
    """Verify progress.json exists in /home/user/ingest/."""
    path = "/home/user/ingest/progress.json"
    assert os.path.isfile(path), f"File {path} does not exist"


def test_config_yaml_exists():
    """Verify config.yaml exists in /home/user/ingest/."""
    path = "/home/user/ingest/config.yaml"
    assert os.path.isfile(path), f"File {path} does not exist"


def test_pipeline_log_exists():
    """Verify pipeline.log exists in /home/user/ingest/."""
    path = "/home/user/ingest/pipeline.log"
    assert os.path.isfile(path), f"File {path} does not exist"


# === CSV Input Files Tests ===

def test_all_csv_files_exist():
    """Verify all 8 CSV batch files exist in /data/incoming/."""
    incoming_dir = "/data/incoming"
    expected_files = [f"batch_{i:03d}.csv" for i in range(1, 9)]

    for filename in expected_files:
        path = os.path.join(incoming_dir, filename)
        assert os.path.isfile(path), f"CSV file {path} does not exist"


def test_csv_files_have_correct_columns():
    """Verify CSV files have the expected columns."""
    import csv

    expected_columns = {"timestamp", "user_id", "amount", "currency", "region"}

    # Check at least the first CSV file for structure
    csv_path = "/data/incoming/batch_001.csv"
    with open(csv_path, 'r') as f:
        reader = csv.DictReader(f)
        actual_columns = set(reader.fieldnames) if reader.fieldnames else set()

    assert expected_columns.issubset(actual_columns), \
        f"CSV {csv_path} missing expected columns. Expected: {expected_columns}, Got: {actual_columns}"


# === Warehouse Parquet Files Tests ===

def test_parquet_files_for_batches_1_to_3_exist():
    """Verify parquet files for batches 1-3 exist (already processed)."""
    warehouse_dir = "/data/warehouse"

    for i in range(1, 4):
        # Check for parquet files matching batch pattern
        batch_name = f"batch_{i:03d}"
        found = False
        for filename in os.listdir(warehouse_dir):
            if batch_name in filename and filename.endswith('.parquet'):
                found = True
                break
        assert found, f"Parquet file for {batch_name} not found in {warehouse_dir}"


def test_no_parquet_for_batch_4_onwards():
    """Verify parquet files for batches 4-8 do NOT exist yet."""
    warehouse_dir = "/data/warehouse"

    for i in range(4, 9):
        batch_name = f"batch_{i:03d}"
        for filename in os.listdir(warehouse_dir):
            if batch_name in filename and filename.endswith('.parquet'):
                pytest.fail(f"Parquet file for {batch_name} should NOT exist yet: {filename}")


# === Progress JSON State Tests ===

def test_progress_json_structure():
    """Verify progress.json has the expected structure."""
    path = "/home/user/ingest/progress.json"

    with open(path, 'r') as f:
        progress = json.load(f)

    assert "processed" in progress, "progress.json missing 'processed' key"
    assert isinstance(progress["processed"], list), "'processed' should be a list"


def test_progress_json_shows_batches_1_to_3_processed():
    """Verify progress.json shows batches 1-3 as processed."""
    path = "/home/user/ingest/progress.json"

    with open(path, 'r') as f:
        progress = json.load(f)

    processed = progress.get("processed", [])

    for i in range(1, 4):
        batch_name = f"batch_{i:03d}.csv"
        assert batch_name in processed, \
            f"{batch_name} should be in processed list. Current processed: {processed}"


def test_progress_json_shows_batch_4_failed():
    """Verify progress.json shows batch_004.csv as failed."""
    path = "/home/user/ingest/progress.json"

    with open(path, 'r') as f:
        progress = json.load(f)

    failed = progress.get("failed", [])
    assert "batch_004.csv" in failed, \
        f"batch_004.csv should be in failed list. Current failed: {failed}"


# === Transform.py Bug Verification ===

def test_transform_py_contains_bug():
    """Verify transform.py contains the APAC currency bug."""
    path = "/home/user/ingest/transform.py"

    with open(path, 'r') as f:
        content = f.read()

    # The bug overwrites currency with region for APAC records
    # Looking for the problematic pattern
    assert "APAC" in content, \
        "transform.py should contain APAC-related code"

    # Check for the buggy assignment pattern
    bug_indicators = [
        "region" in content and "currency" in content,
        "APAC" in content
    ]
    assert all(bug_indicators), \
        "transform.py should contain the buggy code affecting APAC region records"


# === Policy.py Validation Rules Tests ===

def test_policy_py_contains_currency_validation():
    """Verify policy.py contains currency validation rules."""
    path = "/home/user/ingest/policy.py"

    with open(path, 'r') as f:
        content = f.read()

    # Check for currency validation list
    valid_currencies = ["USD", "EUR", "GBP", "JPY", "AUD", "CAD"]
    currency_check = any(curr in content for curr in valid_currencies)

    assert currency_check, \
        f"policy.py should contain currency validation with codes like {valid_currencies}"


# === Pipeline Log Tests ===

def test_pipeline_log_shows_batch_4_failure():
    """Verify pipeline.log contains the policy violation error for batch 4."""
    path = "/home/user/ingest/pipeline.log"

    with open(path, 'r') as f:
        content = f.read()

    assert "batch_004" in content or "batch_004.csv" in content, \
        "pipeline.log should mention batch_004"

    assert "policy" in content.lower() or "violation" in content.lower() or "invalid" in content.lower(), \
        "pipeline.log should contain policy violation or invalid currency error"


def test_pipeline_log_shows_apac_currency_error():
    """Verify pipeline.log mentions the APAC currency issue."""
    path = "/home/user/ingest/pipeline.log"

    with open(path, 'r') as f:
        content = f.read()

    # The error message should mention 'APAC' as invalid currency
    assert "APAC" in content, \
        "pipeline.log should mention 'APAC' as the invalid currency value"


# === Python Environment Tests ===

def test_python_available():
    """Verify Python 3 is available."""
    result = subprocess.run(
        ["python3", "--version"],
        capture_output=True,
        text=True
    )
    assert result.returncode == 0, "Python 3 is not available"
    assert "3." in result.stdout or "3." in result.stderr, \
        "Python 3 version not detected"


def test_pandas_installed():
    """Verify pandas is installed."""
    result = subprocess.run(
        ["python3", "-c", "import pandas"],
        capture_output=True,
        text=True
    )
    assert result.returncode == 0, \
        f"pandas is not installed: {result.stderr}"


def test_pyarrow_installed():
    """Verify pyarrow is installed."""
    result = subprocess.run(
        ["python3", "-c", "import pyarrow"],
        capture_output=True,
        text=True
    )
    assert result.returncode == 0, \
        f"pyarrow is not installed: {result.stderr}"


# === Writability Tests ===

def test_ingest_directory_writable():
    """Verify /home/user/ingest/ is writable."""
    path = "/home/user/ingest"
    assert os.access(path, os.W_OK), f"Directory {path} is not writable"


def test_data_warehouse_writable():
    """Verify /data/warehouse/ is writable."""
    path = "/data/warehouse"
    assert os.access(path, os.W_OK), f"Directory {path} is not writable"


# === CSV Data Integrity Tests ===

def test_csv_files_have_apac_region_in_batch_4_onwards():
    """Verify that batch_004.csv and later contain APAC region records."""
    import csv

    csv_path = "/data/incoming/batch_004.csv"
    has_apac = False

    with open(csv_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row.get('region') == 'APAC':
                has_apac = True
                break

    assert has_apac, \
        f"{csv_path} should contain at least one APAC region record"


def test_source_csv_data_is_valid():
    """Verify source CSV data has valid currency codes (before transform bug)."""
    import csv

    valid_currencies = {"USD", "EUR", "GBP", "JPY", "AUD", "CAD"}

    # Check batch_004.csv specifically since it's the failing one
    csv_path = "/data/incoming/batch_004.csv"

    with open(csv_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            currency = row.get('currency', '').strip().upper()
            assert currency in valid_currencies, \
                f"Source CSV {csv_path} has invalid currency '{currency}' - source data should be valid"
