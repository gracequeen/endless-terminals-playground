# test_final_state.py
"""
Tests to validate the final state of the OS/filesystem after the student
has completed the pipeline debugging task.
"""

import json
import os
import subprocess
import pytest


# === Pipeline Execution Test ===

def test_pipeline_runs_successfully():
    """Verify that running the pipeline completes with exit code 0."""
    result = subprocess.run(
        ["python3", "run.py"],
        cwd="/home/user/ingest",
        capture_output=True,
        text=True,
        timeout=120
    )
    assert result.returncode == 0, \
        f"Pipeline run.py should exit with code 0. Exit code: {result.returncode}\nStdout: {result.stdout}\nStderr: {result.stderr}"


# === Parquet Files Existence Tests ===

def test_all_parquet_files_exist():
    """Verify parquet files for all 8 batches exist in /data/warehouse/."""
    warehouse_dir = "/data/warehouse"

    for i in range(1, 9):
        batch_name = f"batch_{i:03d}"
        found = False
        for filename in os.listdir(warehouse_dir):
            if batch_name in filename and filename.endswith('.parquet'):
                found = True
                break
        assert found, f"Parquet file for {batch_name} not found in {warehouse_dir}"


# === Currency Validation in Parquet Files ===

def test_all_parquet_files_have_valid_currencies():
    """Verify all parquet files have valid currency codes (no 'APAC')."""
    import pyarrow.parquet as pq

    valid_currencies = {"USD", "EUR", "GBP", "JPY", "AUD", "CAD"}
    warehouse_dir = "/data/warehouse"

    for filename in os.listdir(warehouse_dir):
        if filename.endswith('.parquet'):
            filepath = os.path.join(warehouse_dir, filename)
            table = pq.read_table(filepath)
            df = table.to_pandas()

            if 'currency' in df.columns:
                currencies_in_file = set(df['currency'].unique())
                invalid_currencies = currencies_in_file - valid_currencies

                assert not invalid_currencies, \
                    f"Parquet file {filename} contains invalid currencies: {invalid_currencies}. " \
                    f"Expected only: {valid_currencies}"


def test_no_apac_in_currency_column():
    """Explicitly verify no parquet file has 'APAC' as a currency value."""
    import pyarrow.parquet as pq

    warehouse_dir = "/data/warehouse"

    for filename in os.listdir(warehouse_dir):
        if filename.endswith('.parquet'):
            filepath = os.path.join(warehouse_dir, filename)
            table = pq.read_table(filepath)
            df = table.to_pandas()

            if 'currency' in df.columns:
                apac_count = (df['currency'] == 'APAC').sum()
                assert apac_count == 0, \
                    f"Parquet file {filename} contains {apac_count} records with currency='APAC'. " \
                    "The transform bug has not been fixed."


# === Progress JSON State Tests ===

def test_progress_json_shows_all_processed():
    """Verify progress.json shows all 8 files in 'processed' list."""
    path = "/home/user/ingest/progress.json"

    with open(path, 'r') as f:
        progress = json.load(f)

    processed = progress.get("processed", [])

    for i in range(1, 9):
        batch_name = f"batch_{i:03d}.csv"
        assert batch_name in processed, \
            f"{batch_name} should be in processed list. Current processed: {processed}"


def test_progress_json_failed_empty_or_absent():
    """Verify progress.json has empty or absent 'failed' list."""
    path = "/home/user/ingest/progress.json"

    with open(path, 'r') as f:
        progress = json.load(f)

    failed = progress.get("failed", [])
    assert len(failed) == 0, \
        f"'failed' list should be empty. Current failed: {failed}"


# === Source CSV Integrity Tests ===

def test_source_csvs_unchanged():
    """Verify source CSVs in /data/incoming/ have not been modified (still have valid currencies)."""
    import csv

    valid_currencies = {"USD", "EUR", "GBP", "JPY", "AUD", "CAD"}
    incoming_dir = "/data/incoming"

    for i in range(1, 9):
        csv_path = os.path.join(incoming_dir, f"batch_{i:03d}.csv")

        with open(csv_path, 'r') as f:
            reader = csv.DictReader(f)
            for row_num, row in enumerate(reader, start=1):
                currency = row.get('currency', '').strip().upper()
                assert currency in valid_currencies, \
                    f"Source CSV {csv_path} row {row_num} has invalid currency '{currency}'. " \
                    "Source data should not have been modified."


def test_all_source_csvs_exist():
    """Verify all 8 source CSV files still exist."""
    incoming_dir = "/data/incoming"

    for i in range(1, 9):
        csv_path = os.path.join(incoming_dir, f"batch_{i:03d}.csv")
        assert os.path.isfile(csv_path), \
            f"Source CSV {csv_path} should still exist"


# === Policy.py Integrity Tests ===

def test_policy_py_still_has_currency_validation():
    """Verify policy.py still contains currency validation rules (not bypassed)."""
    path = "/home/user/ingest/policy.py"

    with open(path, 'r') as f:
        content = f.read()

    # Check that currency validation list is still present
    valid_currencies = ["USD", "EUR", "GBP", "JPY", "AUD", "CAD"]
    currencies_present = sum(1 for curr in valid_currencies if curr in content)

    assert currencies_present >= 4, \
        f"policy.py should still contain currency validation with codes like {valid_currencies}. " \
        "The fix should be in transform.py, not by disabling policy checks."


def test_policy_validation_not_commented_out():
    """Verify policy validation is not simply commented out."""
    path = "/home/user/ingest/policy.py"

    with open(path, 'r') as f:
        lines = f.readlines()

    # Look for currency validation that's not commented
    found_active_validation = False
    for line in lines:
        stripped = line.strip()
        # Skip comments and empty lines
        if stripped.startswith('#') or not stripped:
            continue
        # Look for currency-related validation
        if 'currency' in stripped.lower() and ('USD' in stripped or 'valid' in stripped.lower() or 'in' in stripped):
            found_active_validation = True
            break

    assert found_active_validation, \
        "policy.py should have active (non-commented) currency validation"


# === Pipeline Log Tests ===

def test_pipeline_log_shows_successful_completion():
    """Verify pipeline.log shows successful completion messages for batches 4-8."""
    path = "/home/user/ingest/pipeline.log"

    with open(path, 'r') as f:
        content = f.read()

    # Check for evidence of successful processing of later batches
    for i in range(4, 9):
        batch_name = f"batch_{i:03d}"
        # Look for success indicators - could be "processed", "completed", "success", etc.
        # We just need evidence that the batch was mentioned after the fix
        assert batch_name in content, \
            f"pipeline.log should mention {batch_name} being processed"


# === Transform.py Bug Fix Verification ===

def test_transform_py_bug_fixed():
    """Verify transform.py no longer has the bug that sets currency to 'APAC'."""
    path = "/home/user/ingest/transform.py"

    with open(path, 'r') as f:
        content = f.read()

    # The original bug was:
    # df.loc[df['region'] == 'APAC', 'currency'] = df.loc[df['region'] == 'APAC', 'region']
    # This pattern assigns region to currency, which is wrong

    # Check that we don't have the buggy pattern where currency is assigned from region
    lines = content.split('\n')
    for line_num, line in enumerate(lines, start=1):
        # Skip comments
        if line.strip().startswith('#'):
            continue
        # Look for the buggy pattern: assigning 'region' column to 'currency'
        if "'currency']" in line and "['region']" in line.rstrip():
            # Check if this line ends with assigning region to currency
            if line.rstrip().endswith("['region']") or line.rstrip().endswith("'region']"):
                # This might be the bug - check more carefully
                if "= df" in line and "region" in line.split('=')[-1]:
                    pytest.fail(
                        f"transform.py line {line_num} appears to still have the bug "
                        f"that assigns region to currency: {line.strip()}"
                    )


# === Batch 4 Specific Tests ===

def test_batch_004_parquet_exists_and_valid():
    """Verify batch_004 parquet exists and has valid data (not skipped)."""
    import pyarrow.parquet as pq

    warehouse_dir = "/data/warehouse"
    batch_name = "batch_004"

    # Find the parquet file
    parquet_file = None
    for filename in os.listdir(warehouse_dir):
        if batch_name in filename and filename.endswith('.parquet'):
            parquet_file = os.path.join(warehouse_dir, filename)
            break

    assert parquet_file is not None, \
        f"Parquet file for {batch_name} must exist (not skipped)"

    # Read and verify it has data
    table = pq.read_table(parquet_file)
    df = table.to_pandas()

    assert len(df) > 0, \
        f"Parquet file for {batch_name} should contain data"

    # Verify currencies are valid
    valid_currencies = {"USD", "EUR", "GBP", "JPY", "AUD", "CAD"}
    if 'currency' in df.columns:
        currencies = set(df['currency'].unique())
        invalid = currencies - valid_currencies
        assert not invalid, \
            f"batch_004 parquet has invalid currencies: {invalid}"


def test_batch_004_parquet_has_apac_region_records():
    """Verify batch_004 parquet contains APAC region records (properly processed)."""
    import pyarrow.parquet as pq

    warehouse_dir = "/data/warehouse"
    batch_name = "batch_004"

    # Find the parquet file
    parquet_file = None
    for filename in os.listdir(warehouse_dir):
        if batch_name in filename and filename.endswith('.parquet'):
            parquet_file = os.path.join(warehouse_dir, filename)
            break

    assert parquet_file is not None, f"Parquet file for {batch_name} must exist"

    table = pq.read_table(parquet_file)
    df = table.to_pandas()

    # batch_004 should have APAC region records
    if 'region' in df.columns:
        apac_records = (df['region'] == 'APAC').sum()
        assert apac_records > 0, \
            "batch_004 should contain APAC region records that were properly processed"


# === Idempotency Check - Batches 1-3 ===

def test_batches_1_to_3_parquet_still_exist():
    """Verify parquet files for batches 1-3 still exist (idempotency)."""
    warehouse_dir = "/data/warehouse"

    for i in range(1, 4):
        batch_name = f"batch_{i:03d}"
        found = False
        for filename in os.listdir(warehouse_dir):
            if batch_name in filename and filename.endswith('.parquet'):
                found = True
                break
        assert found, \
            f"Parquet file for {batch_name} should still exist (idempotency preserved)"


# === Run Pipeline Again to Verify Idempotency ===

def test_pipeline_idempotent_second_run():
    """Verify running the pipeline again succeeds (idempotency)."""
    result = subprocess.run(
        ["python3", "run.py"],
        cwd="/home/user/ingest",
        capture_output=True,
        text=True,
        timeout=120
    )
    assert result.returncode == 0, \
        f"Pipeline should be idempotent and succeed on second run. " \
        f"Exit code: {result.returncode}\nStderr: {result.stderr}"
