Pipeline at /home/user/ingest keeps dying mid-run — we're pulling CSV batches from /data/incoming, transforming them, and writing parquet to /data/warehouse. It's supposed to be idempotent and resumable, so if it crashes it should pick up where it left off on next run. But something's wrong: it processes a few files, then barfs, and when I restart it just fails immediately on the same file every time.

    The weird part is the error message mentions a policy violation, which... shouldn't happen? We have a policy engine that validates records before they hit the warehouse, but the source data passed QA. I'm wondering if the transform step is mangling something in a way that trips the policy check, but I haven't had time to dig in.

    Need it to actually complete a full run — all CSVs processed, all valid records landed in parquet, policy engine happy.
