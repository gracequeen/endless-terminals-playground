# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student performs the action.
This verifies that the environment is correctly set up for the password migration task.
"""

import os
import pytest


class TestInitialState:
    """Test suite to validate initial state before the security remediation task."""

    def test_webapp_directory_exists(self):
        """Verify that /home/user/webapp directory exists."""
        webapp_dir = "/home/user/webapp"
        assert os.path.isdir(webapp_dir), f"Directory {webapp_dir} does not exist"

    def test_webapp_directory_is_writable(self):
        """Verify that /home/user/webapp directory is writable."""
        webapp_dir = "/home/user/webapp"
        assert os.access(webapp_dir, os.W_OK), f"Directory {webapp_dir} is not writable"

    def test_config_yaml_exists(self):
        """Verify that config.yaml exists in the webapp directory."""
        config_path = "/home/user/webapp/config.yaml"
        assert os.path.isfile(config_path), f"File {config_path} does not exist"

    def test_config_yaml_is_readable(self):
        """Verify that config.yaml is readable."""
        config_path = "/home/user/webapp/config.yaml"
        assert os.access(config_path, os.R_OK), f"File {config_path} is not readable"

    def test_config_yaml_is_writable(self):
        """Verify that config.yaml is writable."""
        config_path = "/home/user/webapp/config.yaml"
        assert os.access(config_path, os.W_OK), f"File {config_path} is not writable"

    def test_config_yaml_contains_app_name(self):
        """Verify config.yaml contains the app_name field with correct value."""
        config_path = "/home/user/webapp/config.yaml"
        with open(config_path, 'r') as f:
            content = f.read()
        assert "app_name: inventory_service" in content, \
            "config.yaml does not contain 'app_name: inventory_service'"

    def test_config_yaml_contains_db_host(self):
        """Verify config.yaml contains the db_host field with correct value."""
        config_path = "/home/user/webapp/config.yaml"
        with open(config_path, 'r') as f:
            content = f.read()
        assert "db_host: localhost" in content, \
            "config.yaml does not contain 'db_host: localhost'"

    def test_config_yaml_contains_db_port(self):
        """Verify config.yaml contains the db_port field with correct value."""
        config_path = "/home/user/webapp/config.yaml"
        with open(config_path, 'r') as f:
            content = f.read()
        assert "db_port: 5432" in content, \
            "config.yaml does not contain 'db_port: 5432'"

    def test_config_yaml_contains_db_user(self):
        """Verify config.yaml contains the db_user field with correct value."""
        config_path = "/home/user/webapp/config.yaml"
        with open(config_path, 'r') as f:
            content = f.read()
        assert "db_user: app_user" in content, \
            "config.yaml does not contain 'db_user: app_user'"

    def test_config_yaml_contains_plaintext_password(self):
        """Verify config.yaml currently contains the plaintext password (the security issue)."""
        config_path = "/home/user/webapp/config.yaml"
        with open(config_path, 'r') as f:
            content = f.read()
        assert "xK9#mL2$vP" in content, \
            "config.yaml does not contain the plaintext password 'xK9#mL2$vP' - initial state is incorrect"

    def test_config_yaml_contains_db_password_line(self):
        """Verify config.yaml contains the db_password line with the password."""
        config_path = "/home/user/webapp/config.yaml"
        with open(config_path, 'r') as f:
            content = f.read()
        assert "db_password: xK9#mL2$vP" in content, \
            "config.yaml does not contain 'db_password: xK9#mL2$vP'"

    def test_config_yaml_contains_log_level(self):
        """Verify config.yaml contains the log_level field with correct value."""
        config_path = "/home/user/webapp/config.yaml"
        with open(config_path, 'r') as f:
            content = f.read()
        assert "log_level: info" in content, \
            "config.yaml does not contain 'log_level: info'"

    def test_env_file_exists(self):
        """Verify that .env file exists in the webapp directory."""
        env_path = "/home/user/webapp/.env"
        assert os.path.isfile(env_path), f"File {env_path} does not exist"

    def test_env_file_is_empty(self):
        """Verify that .env file is empty (0 bytes)."""
        env_path = "/home/user/webapp/.env"
        file_size = os.path.getsize(env_path)
        assert file_size == 0, f".env file should be empty but has {file_size} bytes"

    def test_env_file_is_writable(self):
        """Verify that .env file is writable."""
        env_path = "/home/user/webapp/.env"
        assert os.access(env_path, os.W_OK), f"File {env_path} is not writable"

    def test_env_file_does_not_contain_db_password(self):
        """Verify that .env file does not already contain DB_PASSWORD."""
        env_path = "/home/user/webapp/.env"
        with open(env_path, 'r') as f:
            content = f.read()
        assert "DB_PASSWORD" not in content, \
            ".env file already contains DB_PASSWORD - initial state is incorrect"
