# test_final_state.py
"""
Tests to validate the final state of the OS/filesystem after the student has completed
the password migration task (moving db_password from config.yaml to .env file).
"""

import os
import re
import subprocess
import pytest


class TestFinalState:
    """Test suite to validate final state after the security remediation task."""

    def test_config_yaml_exists(self):
        """Verify that config.yaml still exists after modification."""
        config_path = "/home/user/webapp/config.yaml"
        assert os.path.isfile(config_path), f"File {config_path} does not exist"

    def test_env_file_exists(self):
        """Verify that .env file exists."""
        env_path = "/home/user/webapp/.env"
        assert os.path.isfile(env_path), f"File {env_path} does not exist"

    def test_config_yaml_does_not_contain_password(self):
        """Verify that config.yaml no longer contains the plaintext password."""
        config_path = "/home/user/webapp/config.yaml"
        with open(config_path, 'r') as f:
            content = f.read()
        assert "xK9#mL2$vP" not in content, \
            "config.yaml still contains the plaintext password 'xK9#mL2$vP' - password was not removed"

    def test_config_yaml_password_removed_via_grep(self):
        """Anti-shortcut guard: grep must not find the password in config.yaml."""
        result = subprocess.run(
            ["grep", "-F", "xK9#mL2$vP", "/home/user/webapp/config.yaml"],
            capture_output=True,
            text=True
        )
        assert result.returncode != 0, \
            "grep found 'xK9#mL2$vP' in config.yaml - password was not properly removed"

    def test_config_yaml_has_empty_db_password(self):
        """Verify that config.yaml has db_password line with empty value."""
        config_path = "/home/user/webapp/config.yaml"
        with open(config_path, 'r') as f:
            content = f.read()

        # Check for acceptable empty value patterns
        # Acceptable: db_password: or db_password: "" or db_password: ''
        empty_patterns = [
            r'^db_password:\s*$',           # db_password: (with optional trailing whitespace)
            r'^db_password:\s*""',          # db_password: ""
            r"^db_password:\s*''",          # db_password: ''
            r'^db_password:\s*~',           # db_password: ~ (YAML null)
            r'^db_password:\s*null',        # db_password: null
        ]

        found_empty_password = False
        for pattern in empty_patterns:
            if re.search(pattern, content, re.MULTILINE):
                found_empty_password = True
                break

        # Also check if db_password line exists at all
        has_db_password_line = re.search(r'^db_password:', content, re.MULTILINE)

        assert has_db_password_line, \
            "config.yaml does not contain a 'db_password:' line - the line should exist with an empty value"
        assert found_empty_password, \
            "config.yaml db_password line does not have an empty value. " \
            "Expected formats: 'db_password:', 'db_password: \"\"', or 'db_password: \"\"'"

    def test_config_yaml_is_valid_yaml(self):
        """Verify that config.yaml remains valid YAML (parseable)."""
        config_path = "/home/user/webapp/config.yaml"

        # Use a simple approach to validate YAML structure without external libs
        # Check that the file can be read and has expected key-value structure
        with open(config_path, 'r') as f:
            lines = f.readlines()

        # Basic YAML validation: each non-empty, non-comment line should have proper format
        for line in lines:
            stripped = line.strip()
            if stripped and not stripped.startswith('#'):
                # Should contain a colon for key-value pairs
                assert ':' in stripped, \
                    f"Invalid YAML line (no colon found): '{stripped}'"

    def test_config_yaml_preserves_app_name(self):
        """Verify config.yaml still contains app_name with original value."""
        config_path = "/home/user/webapp/config.yaml"
        with open(config_path, 'r') as f:
            content = f.read()
        assert re.search(r'^app_name:\s*inventory_service\s*$', content, re.MULTILINE), \
            "config.yaml does not contain 'app_name: inventory_service' - original value was modified"

    def test_config_yaml_preserves_db_host(self):
        """Verify config.yaml still contains db_host with original value."""
        config_path = "/home/user/webapp/config.yaml"
        with open(config_path, 'r') as f:
            content = f.read()
        assert re.search(r'^db_host:\s*localhost\s*$', content, re.MULTILINE), \
            "config.yaml does not contain 'db_host: localhost' - original value was modified"

    def test_config_yaml_preserves_db_port(self):
        """Verify config.yaml still contains db_port with original value."""
        config_path = "/home/user/webapp/config.yaml"
        with open(config_path, 'r') as f:
            content = f.read()
        assert re.search(r'^db_port:\s*5432\s*$', content, re.MULTILINE), \
            "config.yaml does not contain 'db_port: 5432' - original value was modified"

    def test_config_yaml_preserves_db_user(self):
        """Verify config.yaml still contains db_user with original value."""
        config_path = "/home/user/webapp/config.yaml"
        with open(config_path, 'r') as f:
            content = f.read()
        assert re.search(r'^db_user:\s*app_user\s*$', content, re.MULTILINE), \
            "config.yaml does not contain 'db_user: app_user' - original value was modified"

    def test_config_yaml_preserves_log_level(self):
        """Verify config.yaml still contains log_level with original value."""
        config_path = "/home/user/webapp/config.yaml"
        with open(config_path, 'r') as f:
            content = f.read()
        assert re.search(r'^log_level:\s*info\s*$', content, re.MULTILINE), \
            "config.yaml does not contain 'log_level: info' - original value was modified"

    def test_env_file_contains_db_password(self):
        """Verify that .env file contains DB_PASSWORD with the correct value."""
        env_path = "/home/user/webapp/.env"
        with open(env_path, 'r') as f:
            content = f.read()

        # Check for DB_PASSWORD with the correct value
        # Acceptable formats: DB_PASSWORD=xK9#mL2$vP or with quotes
        password = "xK9#mL2$vP"

        # Pattern to match DB_PASSWORD= followed by the password (with optional quotes)
        patterns = [
            rf'^DB_PASSWORD={re.escape(password)}\s*$',           # No quotes
            rf'^DB_PASSWORD="{re.escape(password)}"\s*$',         # Double quotes
            rf"^DB_PASSWORD='{re.escape(password)}'\s*$",         # Single quotes
        ]

        found_password = False
        for pattern in patterns:
            if re.search(pattern, content, re.MULTILINE):
                found_password = True
                break

        assert found_password, \
            f".env file does not contain 'DB_PASSWORD={password}' (or quoted variant). " \
            f"Current content: {repr(content)}"

    def test_env_file_db_password_via_grep(self):
        """Anti-shortcut guard: grep must find exactly one DB_PASSWORD line in .env."""
        result = subprocess.run(
            ["grep", "-E", "^DB_PASSWORD=", "/home/user/webapp/.env"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            ".env file does not contain a line starting with 'DB_PASSWORD='"

        # Check that the password value is present in the matched line
        assert "xK9#mL2$vP" in result.stdout, \
            f"DB_PASSWORD line does not contain the correct password value. Found: {result.stdout.strip()}"

    def test_env_file_is_not_empty(self):
        """Verify that .env file is no longer empty."""
        env_path = "/home/user/webapp/.env"
        file_size = os.path.getsize(env_path)
        assert file_size > 0, ".env file is still empty - DB_PASSWORD was not added"

    def test_env_file_has_single_db_password_entry(self):
        """Verify that .env file has exactly one DB_PASSWORD entry."""
        env_path = "/home/user/webapp/.env"
        with open(env_path, 'r') as f:
            content = f.read()

        # Count occurrences of DB_PASSWORD=
        matches = re.findall(r'^DB_PASSWORD=', content, re.MULTILINE)
        assert len(matches) == 1, \
            f"Expected exactly 1 DB_PASSWORD entry in .env, found {len(matches)}"
