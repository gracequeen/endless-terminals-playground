# test_final_state.py
"""
Tests to validate the final state of the OS/filesystem after the student
has completed the task of pinning requests to 2.28.0 in /home/user/app/requirements.txt
"""

import os
import subprocess
import pytest


class TestFinalState:
    """Validate the final state after the task is performed."""

    REQUIREMENTS_PATH = "/home/user/app/requirements.txt"
    APP_DIR = "/home/user/app"

    def test_app_directory_exists(self):
        """Verify /home/user/app directory still exists."""
        assert os.path.isdir(self.APP_DIR), (
            f"Directory {self.APP_DIR} does not exist. "
            "The app directory must still exist after the task."
        )

    def test_requirements_file_exists(self):
        """Verify requirements.txt still exists in /home/user/app/."""
        assert os.path.isfile(self.REQUIREMENTS_PATH), (
            f"File {self.REQUIREMENTS_PATH} does not exist. "
            "The requirements.txt file must still exist after the task."
        )

    def test_requirements_file_contains_pinned_requests(self):
        """Verify requirements.txt contains requests==2.28.0."""
        with open(self.REQUIREMENTS_PATH, 'r') as f:
            lines = [line.strip() for line in f.readlines() if line.strip()]

        assert "requests==2.28.0" in lines, (
            f"File {self.REQUIREMENTS_PATH} does not contain 'requests==2.28.0' as a line. "
            f"Actual lines: {lines}\n"
            "The task requires pinning requests to version 2.28.0."
        )

    def test_requests_not_unpinned(self):
        """Verify that the unpinned 'requests' line no longer exists."""
        with open(self.REQUIREMENTS_PATH, 'r') as f:
            lines = [line.strip() for line in f.readlines() if line.strip()]

        # Check that there's no line that is exactly 'requests' (unpinned)
        unpinned_requests_lines = [line for line in lines if line == "requests"]
        assert len(unpinned_requests_lines) == 0, (
            f"File {self.REQUIREMENTS_PATH} still contains an unpinned 'requests' line. "
            "The task requires replacing 'requests' with 'requests==2.28.0'."
        )

    def test_requirements_file_contains_flask_line(self):
        """Verify requirements.txt still contains the flask==2.2.3 line."""
        with open(self.REQUIREMENTS_PATH, 'r') as f:
            lines = [line.strip() for line in f.readlines() if line.strip()]

        assert "flask==2.2.3" in lines, (
            f"File {self.REQUIREMENTS_PATH} does not contain 'flask==2.2.3'. "
            "This line should remain unchanged."
        )

    def test_requirements_file_contains_pyyaml_line(self):
        """Verify requirements.txt still contains the pyyaml>=6.0 line."""
        with open(self.REQUIREMENTS_PATH, 'r') as f:
            lines = [line.strip() for line in f.readlines() if line.strip()]

        assert "pyyaml>=6.0" in lines, (
            f"File {self.REQUIREMENTS_PATH} does not contain 'pyyaml>=6.0'. "
            "This line should remain unchanged."
        )

    def test_requirements_file_contains_gunicorn_line(self):
        """Verify requirements.txt still contains the gunicorn==20.1.0 line."""
        with open(self.REQUIREMENTS_PATH, 'r') as f:
            lines = [line.strip() for line in f.readlines() if line.strip()]

        assert "gunicorn==20.1.0" in lines, (
            f"File {self.REQUIREMENTS_PATH} does not contain 'gunicorn==20.1.0'. "
            "This line should remain unchanged."
        )

    def test_requirements_file_has_four_lines(self):
        """Verify requirements.txt still has exactly 4 lines."""
        with open(self.REQUIREMENTS_PATH, 'r') as f:
            lines = [line for line in f.readlines() if line.strip()]

        assert len(lines) == 4, (
            f"File {self.REQUIREMENTS_PATH} has {len(lines)} non-empty lines, expected 4. "
            "The file should have the same number of lines as before."
        )

    def test_grep_exact_match_requests_pinned(self):
        """Use grep to verify exactly one line matches 'requests==2.28.0'."""
        result = subprocess.run(
            ["grep", "-E", "^requests==2\\.28\\.0$", self.REQUIREMENTS_PATH],
            capture_output=True,
            text=True
        )

        # grep returns 0 if matches found, 1 if no matches
        assert result.returncode == 0, (
            f"grep did not find a line matching '^requests==2.28.0$' in {self.REQUIREMENTS_PATH}. "
            "The task requires exactly this line to be present."
        )

        # Count the number of matching lines
        matching_lines = [line for line in result.stdout.strip().split('\n') if line]
        assert len(matching_lines) == 1, (
            f"Expected exactly 1 line matching 'requests==2.28.0', found {len(matching_lines)}. "
            f"Matching lines: {matching_lines}"
        )

    def test_wc_line_count(self):
        """Use wc -l to verify the file has exactly 4 lines."""
        result = subprocess.run(
            ["wc", "-l"],
            stdin=open(self.REQUIREMENTS_PATH, 'r'),
            capture_output=True,
            text=True
        )

        line_count = int(result.stdout.strip())
        assert line_count == 4, (
            f"wc -l reports {line_count} lines in {self.REQUIREMENTS_PATH}, expected 4. "
            "The file should have the same line count as before the task."
        )

    def test_requirements_file_expected_content(self):
        """Verify the expected content of requirements.txt after the task."""
        expected_lines = {
            "flask==2.2.3",
            "requests==2.28.0",
            "pyyaml>=6.0",
            "gunicorn==20.1.0"
        }

        with open(self.REQUIREMENTS_PATH, 'r') as f:
            actual_lines = {line.strip() for line in f.readlines() if line.strip()}

        assert actual_lines == expected_lines, (
            f"File {self.REQUIREMENTS_PATH} does not have the expected content.\n"
            f"Expected lines: {expected_lines}\n"
            f"Actual lines: {actual_lines}\n"
            f"Missing: {expected_lines - actual_lines}\n"
            f"Extra: {actual_lines - expected_lines}"
        )
