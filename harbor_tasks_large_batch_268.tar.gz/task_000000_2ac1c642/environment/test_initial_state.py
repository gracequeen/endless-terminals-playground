# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the task of pinning requests to 2.28.0 in /home/user/app/requirements.txt
"""

import os
import pytest


class TestInitialState:
    """Validate the initial state before the task is performed."""

    REQUIREMENTS_PATH = "/home/user/app/requirements.txt"
    APP_DIR = "/home/user/app"

    def test_app_directory_exists(self):
        """Verify /home/user/app directory exists."""
        assert os.path.isdir(self.APP_DIR), (
            f"Directory {self.APP_DIR} does not exist. "
            "The app directory must exist before the task can be performed."
        )

    def test_requirements_file_exists(self):
        """Verify requirements.txt exists in /home/user/app/."""
        assert os.path.isfile(self.REQUIREMENTS_PATH), (
            f"File {self.REQUIREMENTS_PATH} does not exist. "
            "The requirements.txt file must exist before the task can be performed."
        )

    def test_requirements_file_is_writable(self):
        """Verify requirements.txt is writable by the current user."""
        assert os.access(self.REQUIREMENTS_PATH, os.W_OK), (
            f"File {self.REQUIREMENTS_PATH} is not writable. "
            "The agent user must have write permissions to modify the file."
        )

    def test_requirements_file_contains_flask_line(self):
        """Verify requirements.txt contains the flask==2.2.3 line."""
        with open(self.REQUIREMENTS_PATH, 'r') as f:
            content = f.read()

        assert "flask==2.2.3" in content, (
            f"File {self.REQUIREMENTS_PATH} does not contain 'flask==2.2.3'. "
            "The initial state requires this line to be present."
        )

    def test_requirements_file_contains_unpinned_requests(self):
        """Verify requirements.txt contains an unpinned 'requests' line."""
        with open(self.REQUIREMENTS_PATH, 'r') as f:
            lines = [line.strip() for line in f.readlines()]

        # Check that there's a line that is exactly 'requests' (unpinned)
        assert "requests" in lines, (
            f"File {self.REQUIREMENTS_PATH} does not contain an unpinned 'requests' line. "
            "The initial state requires 'requests' to be unpinned (just 'requests' on its own line)."
        )

    def test_requirements_file_contains_pyyaml_line(self):
        """Verify requirements.txt contains the pyyaml>=6.0 line."""
        with open(self.REQUIREMENTS_PATH, 'r') as f:
            content = f.read()

        assert "pyyaml>=6.0" in content, (
            f"File {self.REQUIREMENTS_PATH} does not contain 'pyyaml>=6.0'. "
            "The initial state requires this line to be present."
        )

    def test_requirements_file_contains_gunicorn_line(self):
        """Verify requirements.txt contains the gunicorn==20.1.0 line."""
        with open(self.REQUIREMENTS_PATH, 'r') as f:
            content = f.read()

        assert "gunicorn==20.1.0" in content, (
            f"File {self.REQUIREMENTS_PATH} does not contain 'gunicorn==20.1.0'. "
            "The initial state requires this line to be present."
        )

    def test_requirements_file_has_four_lines(self):
        """Verify requirements.txt has exactly 4 lines."""
        with open(self.REQUIREMENTS_PATH, 'r') as f:
            lines = [line for line in f.readlines() if line.strip()]

        assert len(lines) == 4, (
            f"File {self.REQUIREMENTS_PATH} has {len(lines)} non-empty lines, expected 4. "
            "The initial state requires exactly 4 package lines."
        )

    def test_requests_not_already_pinned(self):
        """Verify that requests is NOT already pinned to 2.28.0."""
        with open(self.REQUIREMENTS_PATH, 'r') as f:
            content = f.read()

        assert "requests==2.28.0" not in content, (
            f"File {self.REQUIREMENTS_PATH} already contains 'requests==2.28.0'. "
            "The initial state should have unpinned 'requests', not the pinned version."
        )

    def test_requirements_file_exact_content(self):
        """Verify the exact expected content of requirements.txt."""
        expected_lines = [
            "flask==2.2.3",
            "requests",
            "pyyaml>=6.0",
            "gunicorn==20.1.0"
        ]

        with open(self.REQUIREMENTS_PATH, 'r') as f:
            actual_lines = [line.strip() for line in f.readlines() if line.strip()]

        assert actual_lines == expected_lines, (
            f"File {self.REQUIREMENTS_PATH} does not have the expected content.\n"
            f"Expected lines: {expected_lines}\n"
            f"Actual lines: {actual_lines}\n"
            "The initial state must match exactly."
        )
