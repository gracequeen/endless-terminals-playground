# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the database optimization task.
"""

import os
import subprocess
import sqlite3
import pytest


INFRA_DIR = "/home/user/infra"
DB_PATH = "/home/user/infra/resources.db"
REPORT_SQL_PATH = "/home/user/infra/report.sql"
SCHEMA_DUMP_PATH = "/home/user/infra/schema_dump.txt"

EXPECTED_REPORT_SQL = """SELECT 
    d.dc_name,
    d.region,
    SUM(a.cpu_used) / SUM(h.capacity_cpu) * 100 AS cpu_util_pct,
    SUM(a.mem_used) / SUM(h.capacity_mem) * 100 AS mem_util_pct,
    COUNT(DISTINCT h.host_id) AS host_count
FROM datacenters d
JOIN hosts h ON h.datacenter_id = d.datacenter_id
JOIN allocations a ON a.host_id = h.host_id
GROUP BY d.datacenter_id, d.dc_name, d.region
ORDER BY cpu_util_pct DESC;"""


class TestDirectoryStructure:
    """Test that required directories exist."""

    def test_infra_directory_exists(self):
        assert os.path.isdir(INFRA_DIR), f"Directory {INFRA_DIR} does not exist"

    def test_infra_directory_writable(self):
        assert os.access(INFRA_DIR, os.W_OK), f"Directory {INFRA_DIR} is not writable"


class TestRequiredFiles:
    """Test that required files exist."""

    def test_database_file_exists(self):
        assert os.path.isfile(DB_PATH), f"Database file {DB_PATH} does not exist"

    def test_report_sql_exists(self):
        assert os.path.isfile(REPORT_SQL_PATH), f"SQL file {REPORT_SQL_PATH} does not exist"

    def test_schema_dump_exists(self):
        assert os.path.isfile(SCHEMA_DUMP_PATH), f"Schema dump file {SCHEMA_DUMP_PATH} does not exist"

    def test_database_file_size(self):
        """Database should be approximately 50MB (allow some variance)."""
        size = os.path.getsize(DB_PATH)
        # Allow between 30MB and 70MB
        assert 30_000_000 < size < 70_000_000, (
            f"Database file size is {size} bytes, expected approximately 50MB"
        )


class TestSqlite3Installation:
    """Test that sqlite3 is available."""

    def test_sqlite3_command_available(self):
        result = subprocess.run(
            ["which", "sqlite3"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "sqlite3 command is not installed or not in PATH"

    def test_sqlite3_can_open_database(self):
        result = subprocess.run(
            ["sqlite3", DB_PATH, "SELECT 1;"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, f"Cannot open database with sqlite3: {result.stderr}"


class TestDatabaseSchema:
    """Test that the database has the expected tables and columns."""

    @pytest.fixture
    def db_connection(self):
        conn = sqlite3.connect(DB_PATH)
        yield conn
        conn.close()

    def test_hosts_table_exists(self, db_connection):
        cursor = db_connection.cursor()
        cursor.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='hosts'"
        )
        result = cursor.fetchone()
        assert result is not None, "Table 'hosts' does not exist in the database"

    def test_allocations_table_exists(self, db_connection):
        cursor = db_connection.cursor()
        cursor.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='allocations'"
        )
        result = cursor.fetchone()
        assert result is not None, "Table 'allocations' does not exist in the database"

    def test_datacenters_table_exists(self, db_connection):
        cursor = db_connection.cursor()
        cursor.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='datacenters'"
        )
        result = cursor.fetchone()
        assert result is not None, "Table 'datacenters' does not exist in the database"

    def test_hosts_table_columns(self, db_connection):
        cursor = db_connection.cursor()
        cursor.execute("PRAGMA table_info(hosts)")
        columns = {row[1] for row in cursor.fetchall()}
        expected_columns = {"host_id", "datacenter_id", "hostname", "capacity_cpu", "capacity_mem"}
        assert expected_columns.issubset(columns), (
            f"hosts table missing columns. Expected: {expected_columns}, Found: {columns}"
        )

    def test_allocations_table_columns(self, db_connection):
        cursor = db_connection.cursor()
        cursor.execute("PRAGMA table_info(allocations)")
        columns = {row[1] for row in cursor.fetchall()}
        expected_columns = {"alloc_id", "host_id", "service_name", "cpu_used", "mem_used", "created_at"}
        assert expected_columns.issubset(columns), (
            f"allocations table missing columns. Expected: {expected_columns}, Found: {columns}"
        )

    def test_datacenters_table_columns(self, db_connection):
        cursor = db_connection.cursor()
        cursor.execute("PRAGMA table_info(datacenters)")
        columns = {row[1] for row in cursor.fetchall()}
        expected_columns = {"datacenter_id", "dc_name", "region"}
        assert expected_columns.issubset(columns), (
            f"datacenters table missing columns. Expected: {expected_columns}, Found: {columns}"
        )


class TestDatabaseRowCounts:
    """Test that the database has the expected row counts."""

    @pytest.fixture
    def db_connection(self):
        conn = sqlite3.connect(DB_PATH)
        yield conn
        conn.close()

    def test_hosts_row_count(self, db_connection):
        cursor = db_connection.cursor()
        cursor.execute("SELECT COUNT(*) FROM hosts")
        count = cursor.fetchone()[0]
        # Allow some variance: ~5000 rows
        assert 4500 <= count <= 5500, (
            f"hosts table has {count} rows, expected approximately 5,000"
        )

    def test_allocations_row_count(self, db_connection):
        cursor = db_connection.cursor()
        cursor.execute("SELECT COUNT(*) FROM allocations")
        count = cursor.fetchone()[0]
        # Allow some variance: ~800,000 rows
        assert 750_000 <= count <= 850_000, (
            f"allocations table has {count} rows, expected approximately 800,000"
        )

    def test_datacenters_row_count(self, db_connection):
        cursor = db_connection.cursor()
        cursor.execute("SELECT COUNT(*) FROM datacenters")
        count = cursor.fetchone()[0]
        # Should be exactly 20 or close
        assert 18 <= count <= 22, (
            f"datacenters table has {count} rows, expected approximately 20"
        )


class TestMissingIndexes:
    """Test that the problematic indexes are missing (this is the root cause)."""

    @pytest.fixture
    def db_connection(self):
        conn = sqlite3.connect(DB_PATH)
        yield conn
        conn.close()

    def test_no_index_on_allocations_host_id(self, db_connection):
        """Verify that there is NO index on allocations.host_id (the problem)."""
        cursor = db_connection.cursor()
        cursor.execute(
            "SELECT name FROM sqlite_master WHERE type='index' AND tbl_name='allocations'"
        )
        indexes = cursor.fetchall()
        index_names = [idx[0] for idx in indexes if idx[0] is not None]

        # Check if any index covers host_id
        for idx_name in index_names:
            cursor.execute(f"PRAGMA index_info('{idx_name}')")
            columns = [row[2] for row in cursor.fetchall()]
            assert "host_id" not in columns, (
                f"Index {idx_name} on allocations.host_id already exists - "
                "this should be missing in the initial state"
            )

    def test_no_index_on_hosts_datacenter_id(self, db_connection):
        """Verify that there is NO index on hosts.datacenter_id (part of the problem)."""
        cursor = db_connection.cursor()
        cursor.execute(
            "SELECT name FROM sqlite_master WHERE type='index' AND tbl_name='hosts'"
        )
        indexes = cursor.fetchall()
        index_names = [idx[0] for idx in indexes if idx[0] is not None]

        # Check if any index covers datacenter_id
        for idx_name in index_names:
            cursor.execute(f"PRAGMA index_info('{idx_name}')")
            columns = [row[2] for row in cursor.fetchall()]
            assert "datacenter_id" not in columns, (
                f"Index {idx_name} on hosts.datacenter_id already exists - "
                "this should be missing in the initial state"
            )


class TestReportSqlContent:
    """Test that the report.sql file has the expected content."""

    def test_report_sql_content(self):
        with open(REPORT_SQL_PATH, "r") as f:
            content = f.read()

        # Normalize whitespace for comparison
        normalized_content = " ".join(content.split())
        normalized_expected = " ".join(EXPECTED_REPORT_SQL.split())

        assert normalized_content == normalized_expected, (
            f"report.sql content does not match expected query.\n"
            f"Expected:\n{EXPECTED_REPORT_SQL}\n\nFound:\n{content}"
        )

    def test_report_sql_has_join_on_host_id(self):
        with open(REPORT_SQL_PATH, "r") as f:
            content = f.read().lower()

        assert "a.host_id = h.host_id" in content or "h.host_id = a.host_id" in content, (
            "report.sql should contain a join condition on host_id between allocations and hosts"
        )

    def test_report_sql_has_join_on_datacenter_id(self):
        with open(REPORT_SQL_PATH, "r") as f:
            content = f.read().lower()

        assert "h.datacenter_id = d.datacenter_id" in content or "d.datacenter_id = h.datacenter_id" in content, (
            "report.sql should contain a join condition on datacenter_id between hosts and datacenters"
        )


class TestSchemaDumpFile:
    """Test that the schema dump file exists and contains table definitions."""

    def test_schema_dump_contains_create_table(self):
        with open(SCHEMA_DUMP_PATH, "r") as f:
            content = f.read().upper()

        assert "CREATE TABLE" in content, (
            "schema_dump.txt should contain CREATE TABLE statements"
        )

    def test_schema_dump_mentions_hosts(self):
        with open(SCHEMA_DUMP_PATH, "r") as f:
            content = f.read().lower()

        assert "hosts" in content, (
            "schema_dump.txt should mention the hosts table"
        )

    def test_schema_dump_mentions_allocations(self):
        with open(SCHEMA_DUMP_PATH, "r") as f:
            content = f.read().lower()

        assert "allocations" in content, (
            "schema_dump.txt should mention the allocations table"
        )


class TestQueryPerformanceBaseline:
    """Test that the query is currently slow (to confirm the problem exists)."""

    def test_query_plan_shows_table_scan(self):
        """Verify that EXPLAIN QUERY PLAN shows table scans (the problem)."""
        result = subprocess.run(
            ["sqlite3", DB_PATH, "EXPLAIN QUERY PLAN " + EXPECTED_REPORT_SQL],
            capture_output=True,
            text=True,
            timeout=30
        )
        assert result.returncode == 0, f"EXPLAIN QUERY PLAN failed: {result.stderr}"

        output = result.stdout.upper()
        # Should show SCAN (full table scan) rather than SEARCH (index lookup)
        # for at least the allocations table
        assert "SCAN" in output, (
            "EXPLAIN QUERY PLAN should show SCAN operations indicating table scans. "
            f"Output: {result.stdout}"
        )
