# test_final_state.py
"""
Tests to validate the final state of the OS/filesystem after the student
has completed the database optimization task.
"""

import os
import subprocess
import sqlite3
import time
import pytest


INFRA_DIR = "/home/user/infra"
DB_PATH = "/home/user/infra/resources.db"
REPORT_SQL_PATH = "/home/user/infra/report.sql"
SCHEMA_DUMP_PATH = "/home/user/infra/schema_dump.txt"

EXPECTED_REPORT_SQL = """SELECT 
    d.dc_name,
    d.region,
    SUM(a.cpu_used) / SUM(h.capacity_cpu) * 100 AS cpu_util_pct,
    SUM(a.mem_used) / SUM(h.capacity_mem) * 100 AS mem_util_pct,
    COUNT(DISTINCT h.host_id) AS host_count
FROM datacenters d
JOIN hosts h ON h.datacenter_id = d.datacenter_id
JOIN allocations a ON a.host_id = h.host_id
GROUP BY d.datacenter_id, d.dc_name, d.region
ORDER BY cpu_util_pct DESC;"""


class TestReportSqlUnchanged:
    """Test that report.sql was not modified (anti-shortcut guard)."""

    def test_report_sql_content_unchanged(self):
        """The report.sql file must be byte-identical to its initial state."""
        with open(REPORT_SQL_PATH, "r") as f:
            content = f.read()

        # Normalize whitespace for comparison
        normalized_content = " ".join(content.split())
        normalized_expected = " ".join(EXPECTED_REPORT_SQL.split())

        assert normalized_content == normalized_expected, (
            f"report.sql has been modified! The fix must be index creation, not query rewriting.\n"
            f"Expected:\n{EXPECTED_REPORT_SQL}\n\nFound:\n{content}"
        )


class TestDataIntegrity:
    """Test that all existing data in resources.db is preserved."""

    @pytest.fixture
    def db_connection(self):
        conn = sqlite3.connect(DB_PATH)
        yield conn
        conn.close()

    def test_allocations_row_count_preserved(self, db_connection):
        """allocations table should still have ~800,000 rows."""
        cursor = db_connection.cursor()
        cursor.execute("SELECT COUNT(*) FROM allocations")
        count = cursor.fetchone()[0]
        assert 750_000 <= count <= 850_000, (
            f"allocations table has {count} rows, expected approximately 800,000. "
            "Data may have been deleted or corrupted."
        )

    def test_hosts_row_count_preserved(self, db_connection):
        """hosts table should still have ~5,000 rows."""
        cursor = db_connection.cursor()
        cursor.execute("SELECT COUNT(*) FROM hosts")
        count = cursor.fetchone()[0]
        assert 4500 <= count <= 5500, (
            f"hosts table has {count} rows, expected approximately 5,000. "
            "Data may have been deleted or corrupted."
        )

    def test_datacenters_row_count_preserved(self, db_connection):
        """datacenters table should still have ~20 rows."""
        cursor = db_connection.cursor()
        cursor.execute("SELECT COUNT(*) FROM datacenters")
        count = cursor.fetchone()[0]
        assert 18 <= count <= 22, (
            f"datacenters table has {count} rows, expected approximately 20. "
            "Data may have been deleted or corrupted."
        )


class TestSchemaUnchanged:
    """Test that table schemas are unchanged (no column additions/removals)."""

    @pytest.fixture
    def db_connection(self):
        conn = sqlite3.connect(DB_PATH)
        yield conn
        conn.close()

    def test_hosts_table_columns_unchanged(self, db_connection):
        cursor = db_connection.cursor()
        cursor.execute("PRAGMA table_info(hosts)")
        columns = {row[1] for row in cursor.fetchall()}
        expected_columns = {"host_id", "datacenter_id", "hostname", "capacity_cpu", "capacity_mem"}
        assert columns == expected_columns, (
            f"hosts table schema changed. Expected columns: {expected_columns}, Found: {columns}"
        )

    def test_allocations_table_columns_unchanged(self, db_connection):
        cursor = db_connection.cursor()
        cursor.execute("PRAGMA table_info(allocations)")
        columns = {row[1] for row in cursor.fetchall()}
        expected_columns = {"alloc_id", "host_id", "service_name", "cpu_used", "mem_used", "created_at"}
        assert columns == expected_columns, (
            f"allocations table schema changed. Expected columns: {expected_columns}, Found: {columns}"
        )

    def test_datacenters_table_columns_unchanged(self, db_connection):
        cursor = db_connection.cursor()
        cursor.execute("PRAGMA table_info(datacenters)")
        columns = {row[1] for row in cursor.fetchall()}
        expected_columns = {"datacenter_id", "dc_name", "region"}
        assert columns == expected_columns, (
            f"datacenters table schema changed. Expected columns: {expected_columns}, Found: {columns}"
        )


class TestQueryPerformance:
    """Test that the query now completes in reasonable time."""

    def test_query_completes_under_10_seconds(self):
        """The report query should complete in under 10 seconds."""
        start_time = time.time()
        result = subprocess.run(
            ["sqlite3", DB_PATH],
            input=open(REPORT_SQL_PATH).read(),
            capture_output=True,
            text=True,
            timeout=15  # Give a bit of buffer beyond 10s
        )
        elapsed_time = time.time() - start_time

        assert result.returncode == 0, (
            f"Query failed with error: {result.stderr}"
        )
        assert elapsed_time < 10, (
            f"Query took {elapsed_time:.2f} seconds, expected under 10 seconds. "
            "The database optimization may not be complete."
        )

    def test_query_produces_output(self):
        """The query should produce non-empty output."""
        result = subprocess.run(
            ["sqlite3", DB_PATH],
            input=open(REPORT_SQL_PATH).read(),
            capture_output=True,
            text=True,
            timeout=15
        )
        assert result.returncode == 0, f"Query failed: {result.stderr}"
        assert result.stdout.strip(), "Query produced no output"


class TestQueryOutput:
    """Test that the query output is correct."""

    @pytest.fixture
    def query_output(self):
        """Run the query and return the output."""
        result = subprocess.run(
            ["sqlite3", "-separator", "|", DB_PATH],
            input=open(REPORT_SQL_PATH).read(),
            capture_output=True,
            text=True,
            timeout=15
        )
        assert result.returncode == 0, f"Query failed: {result.stderr}"
        return result.stdout.strip()

    def test_output_has_20_rows(self, query_output):
        """Output should contain exactly 20 rows (one per datacenter)."""
        lines = [line for line in query_output.split('\n') if line.strip()]
        assert len(lines) == 20, (
            f"Query output has {len(lines)} rows, expected exactly 20 (one per datacenter).\n"
            f"Output:\n{query_output}"
        )

    def test_output_has_correct_columns(self, query_output):
        """Each row should have 5 columns: dc_name, region, cpu_util_pct, mem_util_pct, host_count."""
        lines = [line for line in query_output.split('\n') if line.strip()]
        for i, line in enumerate(lines):
            parts = line.split('|')
            assert len(parts) == 5, (
                f"Row {i+1} has {len(parts)} columns, expected 5.\n"
                f"Row: {line}"
            )

    def test_utilization_percentages_are_valid(self, query_output):
        """cpu_util_pct and mem_util_pct should be non-null numbers between 0 and 100."""
        lines = [line for line in query_output.split('\n') if line.strip()]
        for i, line in enumerate(lines):
            parts = line.split('|')
            # parts[2] is cpu_util_pct, parts[3] is mem_util_pct
            try:
                cpu_util = float(parts[2])
                mem_util = float(parts[3])
            except (ValueError, IndexError) as e:
                pytest.fail(
                    f"Row {i+1}: Could not parse utilization values as numbers.\n"
                    f"Row: {line}\nError: {e}"
                )

            assert 0 <= cpu_util <= 100, (
                f"Row {i+1}: cpu_util_pct ({cpu_util}) is not between 0 and 100.\n"
                f"Row: {line}"
            )
            assert 0 <= mem_util <= 100, (
                f"Row {i+1}: mem_util_pct ({mem_util}) is not between 0 and 100.\n"
                f"Row: {line}"
            )

    def test_host_counts_are_positive(self, query_output):
        """host_count should be a positive integer."""
        lines = [line for line in query_output.split('\n') if line.strip()]
        for i, line in enumerate(lines):
            parts = line.split('|')
            try:
                host_count = int(parts[4])
            except (ValueError, IndexError) as e:
                pytest.fail(
                    f"Row {i+1}: Could not parse host_count as integer.\n"
                    f"Row: {line}\nError: {e}"
                )

            assert host_count > 0, (
                f"Row {i+1}: host_count ({host_count}) should be positive.\n"
                f"Row: {line}"
            )

    def test_dc_name_and_region_are_non_empty(self, query_output):
        """dc_name and region should be non-empty strings."""
        lines = [line for line in query_output.split('\n') if line.strip()]
        for i, line in enumerate(lines):
            parts = line.split('|')
            dc_name = parts[0]
            region = parts[1]

            assert dc_name.strip(), (
                f"Row {i+1}: dc_name is empty.\nRow: {line}"
            )
            assert region.strip(), (
                f"Row {i+1}: region is empty.\nRow: {line}"
            )


class TestIndexesExist:
    """Test that the required indexes now exist (the fix)."""

    @pytest.fixture
    def db_connection(self):
        conn = sqlite3.connect(DB_PATH)
        yield conn
        conn.close()

    def test_index_on_allocations_host_id_exists(self, db_connection):
        """There should now be an index on allocations.host_id."""
        cursor = db_connection.cursor()
        cursor.execute(
            "SELECT name FROM sqlite_master WHERE type='index' AND tbl_name='allocations'"
        )
        indexes = cursor.fetchall()
        index_names = [idx[0] for idx in indexes if idx[0] is not None]

        # Check if any index covers host_id
        found_host_id_index = False
        for idx_name in index_names:
            cursor.execute(f"PRAGMA index_info('{idx_name}')")
            columns = [row[2] for row in cursor.fetchall()]
            if "host_id" in columns:
                found_host_id_index = True
                break

        assert found_host_id_index, (
            "No index found on allocations.host_id. "
            "This index is required for the query to perform efficiently."
        )

    def test_query_plan_uses_indexes(self, db_connection):
        """EXPLAIN QUERY PLAN should show index usage (SEARCH) instead of full table scans."""
        cursor = db_connection.cursor()
        cursor.execute(f"EXPLAIN QUERY PLAN {EXPECTED_REPORT_SQL}")
        plan = cursor.fetchall()
        plan_text = " ".join(str(row) for row in plan).upper()

        # After adding indexes, we should see SEARCH operations using indexes
        # or at minimum, fewer SCAN operations on the large tables
        assert "SEARCH" in plan_text or "USING" in plan_text, (
            f"Query plan does not appear to use indexes effectively.\n"
            f"Plan: {plan}\n"
            "Expected to see SEARCH or USING INDEX operations."
        )


class TestDatabaseFileIntegrity:
    """Test that the database file is still valid and accessible."""

    def test_database_file_exists(self):
        assert os.path.isfile(DB_PATH), f"Database file {DB_PATH} does not exist"

    def test_database_integrity_check(self):
        """Run SQLite integrity check."""
        result = subprocess.run(
            ["sqlite3", DB_PATH, "PRAGMA integrity_check;"],
            capture_output=True,
            text=True,
            timeout=60
        )
        assert result.returncode == 0, f"Database integrity check failed: {result.stderr}"
        assert "ok" in result.stdout.lower(), (
            f"Database integrity check did not return 'ok': {result.stdout}"
        )
