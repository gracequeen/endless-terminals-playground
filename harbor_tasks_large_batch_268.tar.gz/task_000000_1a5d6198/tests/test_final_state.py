# test_final_state.py
"""
Final state validation tests for the German translation localization fix task.
Validates that the student has successfully fixed the translation issues and all tests pass.
"""

import os
import subprocess
import re
import pytest

HOME = "/home/user"
SOLVER_UI = os.path.join(HOME, "solver-ui")
LOCALES_DE = os.path.join(SOLVER_UI, "locales", "de", "LC_MESSAGES")
MESSAGES_PO = os.path.join(LOCALES_DE, "messages.po")
MESSAGES_MO = os.path.join(LOCALES_DE, "messages.mo")
TESTS_DIR = os.path.join(SOLVER_UI, "tests")
TEST_LOCALIZATION = os.path.join(TESTS_DIR, "test_localization.py")


class TestPytestPasses:
    """The primary success criterion: all tests in test_localization.py must pass."""

    def test_pytest_passes_on_test_localization(self):
        """
        Run pytest on test_localization.py and verify it passes.
        This is the main success criterion for the task.
        """
        result = subprocess.run(
            ["pytest", TEST_LOCALIZATION, "-v", "--tb=short"],
            capture_output=True,
            text=True,
            cwd=SOLVER_UI
        )
        assert result.returncode == 0, \
            f"pytest should pass but failed with exit code {result.returncode}.\n" \
            f"STDOUT:\n{result.stdout}\nSTDERR:\n{result.stderr}"

    def test_all_three_tests_pass(self):
        """Verify that all 3 previously failing tests now pass."""
        result = subprocess.run(
            ["pytest", TEST_LOCALIZATION, "-v", "--tb=no"],
            capture_output=True,
            text=True,
            cwd=SOLVER_UI
        )
        # Count passed tests
        passed_count = result.stdout.count(" PASSED")
        failed_count = result.stdout.count(" FAILED")

        assert failed_count == 0, \
            f"Expected 0 failing tests, but found {failed_count}. Output:\n{result.stdout}"
        assert passed_count >= 3, \
            f"Expected at least 3 passing tests, but found {passed_count}. Output:\n{result.stdout}"


class TestTranslationFilesIntact:
    """Verify translation files still exist and are valid."""

    def test_messages_po_exists(self):
        assert os.path.isfile(MESSAGES_PO), f"messages.po not found at {MESSAGES_PO}"

    def test_messages_mo_exists(self):
        assert os.path.isfile(MESSAGES_MO), f"messages.mo not found at {MESSAGES_MO}"

    def test_messages_mo_valid_with_msgunfmt(self):
        """Verify the .mo file is valid and can be parsed."""
        result = subprocess.run(
            ["msgunfmt", MESSAGES_MO],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            f"msgunfmt failed to parse messages.mo - file may be corrupted: {result.stderr}"

    def test_messages_po_valid_format(self):
        """Verify messages.po is valid gettext format using msgfmt check."""
        result = subprocess.run(
            ["msgfmt", "--check", MESSAGES_PO, "-o", "/dev/null"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            f"messages.po has invalid gettext format: {result.stderr}"


class TestNewTranslationsPreserved:
    """
    Anti-shortcut guard: Verify the 4 new translation entries still exist.
    Student cannot just delete the new entries to make tests pass.
    """

    def test_constraint_violation_msgid_preserved(self):
        """The constraint violation format string entry must still exist."""
        with open(MESSAGES_PO, 'r', encoding='utf-8') as f:
            content = f.read()
        assert "Constraint {name}" in content, \
            "Missing constraint violation msgid - cannot delete new translations to fix the issue"

    def test_add_constraint_entry_preserved(self):
        """The 'Add constraint' entry must still exist (without trailing space bug)."""
        with open(MESSAGES_PO, 'r', encoding='utf-8') as f:
            content = f.read()
        assert "Add constraint" in content, \
            "Missing 'Add constraint' msgid - cannot delete new translations to fix the issue"

    def test_german_translation_for_constraint_exists(self):
        """German translation content must exist (not empty or English-only)."""
        with open(MESSAGES_PO, 'r', encoding='utf-8') as f:
            content = f.read()
        # Should have German words in translations
        german_indicators = ["Beschränkung", "verletzt", "überschreitet", "hinzufügen"]
        found_german = any(word in content for word in german_indicators)
        assert found_german, \
            "German translations appear to be missing - cannot revert to English-only"


class TestBugsFixed:
    """Verify the specific bugs have been fixed."""

    def test_format_string_mismatch_fixed(self):
        """
        The bug was: German translation used {wert} instead of {value}.
        After fix: should use {value} to match the Python code.
        """
        with open(MESSAGES_PO, 'r', encoding='utf-8') as f:
            content = f.read()

        # The buggy {wert} should no longer be present
        assert "{wert}" not in content, \
            "Format string bug not fixed: {wert} should be changed to {value} in the German translation"

    def test_constraint_violation_has_correct_placeholders(self):
        """
        The constraint violation translation must have all three placeholders:
        {name}, {value}, {limit}
        """
        with open(MESSAGES_PO, 'r', encoding='utf-8') as f:
            content = f.read()

        # Find the msgstr for the constraint violation entry
        # Look for the German translation that should contain all placeholders
        lines = content.split('\n')
        in_constraint_entry = False
        msgstr_content = ""

        for i, line in enumerate(lines):
            if 'Constraint {name}' in line and line.strip().startswith('msgid'):
                in_constraint_entry = True
            elif in_constraint_entry and line.strip().startswith('msgstr'):
                # Collect the msgstr (may span multiple lines)
                msgstr_content = line
                j = i + 1
                while j < len(lines) and (lines[j].startswith('"') or not lines[j].strip()):
                    if lines[j].startswith('"'):
                        msgstr_content += lines[j]
                    j += 1
                break

        assert "{name}" in msgstr_content, \
            "German translation for constraint violation missing {name} placeholder"
        assert "{value}" in msgstr_content, \
            "German translation for constraint violation missing {value} placeholder (was {wert}?)"
        assert "{limit}" in msgstr_content, \
            "German translation for constraint violation missing {limit} placeholder"

    def test_add_constraint_no_trailing_space(self):
        """
        The bug was: msgid had 'Add constraint ' (trailing space).
        After fix: msgid should be 'Add constraint' (no trailing space).
        """
        with open(MESSAGES_PO, 'r', encoding='utf-8') as f:
            content = f.read()

        # Check that there's a proper msgid without trailing space
        # The pattern 'msgid "Add constraint"' should exist (with closing quote right after 't')
        has_correct_entry = 'msgid "Add constraint"' in content

        # Also check that the buggy trailing space version is gone
        has_buggy_entry = 'msgid "Add constraint "' in content

        assert has_correct_entry or not has_buggy_entry, \
            "Trailing space bug not fixed: 'Add constraint ' should be 'Add constraint' (no trailing space)"


class TestTestFileUnmodified:
    """
    Anti-shortcut guard: The test file should not be modified.
    Student cannot modify tests to make them pass artificially.
    """

    def test_test_file_contains_original_tests(self):
        """Verify test_localization.py still contains the original test functions."""
        with open(TEST_LOCALIZATION, 'r', encoding='utf-8') as f:
            content = f.read()

        assert "test_constraint_violation_message" in content, \
            "test_localization.py missing test_constraint_violation_message - cannot modify test file"
        assert "test_add_constraint_label" in content, \
            "test_localization.py missing test_add_constraint_label - cannot modify test file"
        assert "test_all_format_strings_valid" in content, \
            "test_localization.py missing test_all_format_strings_valid - cannot modify test file"

    def test_test_file_not_trivially_modified(self):
        """Check that tests haven't been made to trivially pass (e.g., assert True)."""
        with open(TEST_LOCALIZATION, 'r', encoding='utf-8') as f:
            content = f.read()

        # Count meaningful assertions - should have real test logic
        # A trivially modified file might just have "assert True" or "pass"
        lines = content.split('\n')

        # Check that the test functions have actual content
        assert "assert" in content.lower(), \
            "test_localization.py appears to have no assertions - cannot gut the test file"


class TestLocaleDirectoryIntact:
    """
    Anti-shortcut guard: Cannot delete or empty the German locale directory.
    """

    def test_german_locale_directory_exists(self):
        assert os.path.isdir(LOCALES_DE), \
            f"German locale directory deleted at {LOCALES_DE} - cannot delete locale to fix issue"

    def test_messages_po_not_empty(self):
        """messages.po should have substantial content."""
        with open(MESSAGES_PO, 'r', encoding='utf-8') as f:
            content = f.read()
        # A real .po file should have multiple entries
        assert len(content) > 500, \
            "messages.po appears to be emptied or severely truncated"
        assert content.count('msgid') >= 4, \
            "messages.po should have at least 4 msgid entries (including the new ones)"

    def test_messages_mo_not_empty(self):
        """messages.mo should have substantial content."""
        size = os.path.getsize(MESSAGES_MO)
        assert size > 100, \
            f"messages.mo appears to be emptied (size: {size} bytes)"


class TestMoFileRecompiled:
    """Verify the .mo file has been recompiled after .po fixes."""

    def test_mo_file_matches_po_content(self):
        """
        Verify the .mo file contains the fixed translations.
        Use msgunfmt to extract and check content.
        """
        result = subprocess.run(
            ["msgunfmt", MESSAGES_MO],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "Failed to read .mo file with msgunfmt"

        mo_content = result.stdout

        # The .mo file should have {value} not {wert}
        assert "{wert}" not in mo_content, \
            ".mo file still contains {wert} - need to recompile with msgfmt after fixing .po"

        # Should have the constraint-related German text
        assert "Beschränkung" in mo_content or "beschränkung" in mo_content.lower(), \
            ".mo file missing German constraint translations - may need recompilation"
