# test_initial_state.py
"""
Pre-task validation tests for the German translation localization fix task.
Validates that the initial state matches the expected conditions before the student performs fixes.
"""

import os
import subprocess
import pytest

HOME = "/home/user"
SOLVER_UI = os.path.join(HOME, "solver-ui")
LOCALES_DE = os.path.join(SOLVER_UI, "locales", "de", "LC_MESSAGES")
MESSAGES_PO = os.path.join(LOCALES_DE, "messages.po")
MESSAGES_MO = os.path.join(LOCALES_DE, "messages.mo")
TESTS_DIR = os.path.join(SOLVER_UI, "tests")
TEST_LOCALIZATION = os.path.join(TESTS_DIR, "test_localization.py")


class TestDirectoryStructure:
    """Verify the solver-ui project structure exists."""

    def test_solver_ui_directory_exists(self):
        assert os.path.isdir(SOLVER_UI), f"solver-ui directory not found at {SOLVER_UI}"

    def test_locales_de_directory_exists(self):
        assert os.path.isdir(LOCALES_DE), f"German locale directory not found at {LOCALES_DE}"

    def test_tests_directory_exists(self):
        assert os.path.isdir(TESTS_DIR), f"Tests directory not found at {TESTS_DIR}"


class TestTranslationFiles:
    """Verify translation files exist and are readable."""

    def test_messages_po_exists(self):
        assert os.path.isfile(MESSAGES_PO), f"messages.po not found at {MESSAGES_PO}"

    def test_messages_mo_exists(self):
        assert os.path.isfile(MESSAGES_MO), f"messages.mo not found at {MESSAGES_MO}"

    def test_messages_po_readable(self):
        with open(MESSAGES_PO, 'r', encoding='utf-8') as f:
            content = f.read()
        assert len(content) > 0, "messages.po is empty"

    def test_messages_mo_valid_with_msgunfmt(self):
        """Verify msgunfmt can read the .mo file (as stated in task description)."""
        result = subprocess.run(
            ["msgunfmt", MESSAGES_MO],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, f"msgunfmt failed to parse messages.mo: {result.stderr}"


class TestNewTranslationEntriesExist:
    """Verify the user's new translation entries are present in messages.po."""

    def test_constraint_violation_msgid_exists(self):
        """Check that the constraint violation format string entry exists."""
        with open(MESSAGES_PO, 'r', encoding='utf-8') as f:
            content = f.read()
        # The msgid should contain the constraint violation pattern
        assert "Constraint {name}" in content, \
            "Missing constraint violation msgid entry - expected 'Constraint {name}' pattern in messages.po"

    def test_add_constraint_entry_exists(self):
        """Check that an 'Add constraint' related entry exists."""
        with open(MESSAGES_PO, 'r', encoding='utf-8') as f:
            content = f.read()
        # Should have some form of "Add constraint" entry
        assert "Add constraint" in content, \
            "Missing 'Add constraint' msgid entry in messages.po"


class TestBuggyTranslationState:
    """Verify the specific bugs exist that need to be fixed."""

    def test_format_string_mismatch_exists(self):
        """
        Verify the bug: German translation uses {wert} instead of {value}.
        The msgstr should have {wert} which is the bug to fix.
        """
        with open(MESSAGES_PO, 'r', encoding='utf-8') as f:
            content = f.read()
        # The buggy translation should contain {wert} instead of {value}
        assert "{wert}" in content, \
            "Expected to find {wert} in messages.po (the format string bug that needs fixing)"

    def test_trailing_space_mismatch_exists(self):
        """
        Verify the bug: msgid has 'Add constraint ' (trailing space) but code uses 'Add constraint'.
        Look for the pattern in the .po file.
        """
        with open(MESSAGES_PO, 'r', encoding='utf-8') as f:
            content = f.read()
        # Check for msgid with trailing space before closing quote
        # The pattern 'Add constraint "' (space before quote) indicates trailing space
        assert 'Add constraint "' in content or 'msgid "Add constraint "' in content, \
            "Expected to find 'Add constraint ' with trailing space in messages.po (the whitespace bug)"


class TestTestFileExists:
    """Verify the test file that's failing exists."""

    def test_test_localization_file_exists(self):
        assert os.path.isfile(TEST_LOCALIZATION), \
            f"test_localization.py not found at {TEST_LOCALIZATION}"

    def test_test_localization_contains_expected_tests(self):
        """Verify the test file contains the three tests mentioned in the task."""
        with open(TEST_LOCALIZATION, 'r', encoding='utf-8') as f:
            content = f.read()

        assert "test_constraint_violation_message" in content, \
            "test_localization.py missing test_constraint_violation_message test"
        assert "test_add_constraint_label" in content, \
            "test_localization.py missing test_add_constraint_label test"
        assert "test_all_format_strings_valid" in content, \
            "test_localization.py missing test_all_format_strings_valid test"


class TestPytestCurrentlyFails:
    """Verify that pytest currently fails (the initial broken state)."""

    def test_pytest_fails_on_test_localization(self):
        """
        Run pytest on test_localization.py and verify it fails.
        This confirms the initial broken state that the student needs to fix.
        """
        result = subprocess.run(
            ["pytest", TEST_LOCALIZATION, "-v", "--tb=short"],
            capture_output=True,
            text=True,
            cwd=SOLVER_UI
        )
        assert result.returncode != 0, \
            f"Expected pytest to fail initially, but it passed. Output:\n{result.stdout}\n{result.stderr}"

    def test_exactly_three_tests_fail(self):
        """Verify that exactly 3 tests are failing as described in the task."""
        result = subprocess.run(
            ["pytest", TEST_LOCALIZATION, "-v", "--tb=no"],
            capture_output=True,
            text=True,
            cwd=SOLVER_UI
        )
        # Count failed tests from output
        failed_count = result.stdout.count(" FAILED")
        assert failed_count == 3, \
            f"Expected exactly 3 failing tests, but found {failed_count}. Output:\n{result.stdout}"


class TestToolsAvailable:
    """Verify required tools are available."""

    def test_python3_available(self):
        result = subprocess.run(["python3", "--version"], capture_output=True, text=True)
        assert result.returncode == 0, "python3 not available"

    def test_pytest_available(self):
        result = subprocess.run(["pytest", "--version"], capture_output=True, text=True)
        assert result.returncode == 0, "pytest not available"

    def test_msgfmt_available(self):
        result = subprocess.run(["msgfmt", "--version"], capture_output=True, text=True)
        assert result.returncode == 0, "msgfmt not available"

    def test_msgunfmt_available(self):
        result = subprocess.run(["msgunfmt", "--version"], capture_output=True, text=True)
        assert result.returncode == 0, "msgunfmt not available"


class TestDirectoryWritable:
    """Verify the solver-ui directory is writable."""

    def test_solver_ui_writable(self):
        assert os.access(SOLVER_UI, os.W_OK), f"{SOLVER_UI} is not writable"

    def test_locales_de_writable(self):
        assert os.access(LOCALES_DE, os.W_OK), f"{LOCALES_DE} is not writable"

    def test_messages_po_writable(self):
        assert os.access(MESSAGES_PO, os.W_OK), f"{MESSAGES_PO} is not writable"
