I'm updating German translations for our solver UI and the test suite is failing now — `pytest /home/user/solver-ui/tests/` used to pass, now 3 tests in test_localization.py are red. The weird thing is the translations load fine when I run the app manually, it's just the tests.

I touched /home/user/solver-ui/locales/de/LC_MESSAGES/messages.po to add some new strings for the constraint editor, then compiled it with msgfmt. Pretty sure the .mo file is valid because `msgunfmt` can read it back. Maybe I broke something in the msgid/msgstr pairs? Or the tests are checking something else entirely, idk.

Just need those 3 tests green again without reverting my new translations.
