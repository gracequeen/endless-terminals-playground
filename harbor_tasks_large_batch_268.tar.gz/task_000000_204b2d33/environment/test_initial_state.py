# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the DNS log hostname extraction task.
"""

import os
import stat
import pytest


class TestSourceLogFile:
    """Tests for the source log file /var/log/dns/queries.log"""

    LOG_FILE = "/var/log/dns/queries.log"

    def test_log_file_exists(self):
        """The source log file must exist"""
        assert os.path.exists(self.LOG_FILE), \
            f"Source log file {self.LOG_FILE} does not exist"

    def test_log_file_is_regular_file(self):
        """The source log file must be a regular file"""
        assert os.path.isfile(self.LOG_FILE), \
            f"{self.LOG_FILE} exists but is not a regular file"

    def test_log_file_is_readable(self):
        """The source log file must be readable by the current user"""
        assert os.access(self.LOG_FILE, os.R_OK), \
            f"{self.LOG_FILE} exists but is not readable by the current user"

    def test_log_file_has_content(self):
        """The source log file must have approximately 200 lines"""
        with open(self.LOG_FILE, 'r') as f:
            lines = f.readlines()
        line_count = len(lines)
        # Allow some tolerance around ~200 lines
        assert 150 <= line_count <= 250, \
            f"{self.LOG_FILE} should have ~200 lines, but has {line_count} lines"

    def test_log_file_format(self):
        """Each line must follow the expected format with hostname as 4th field"""
        with open(self.LOG_FILE, 'r') as f:
            lines = f.readlines()

        for i, line in enumerate(lines, 1):
            line = line.strip()
            if not line:
                continue  # Skip empty lines if any

            parts = line.split()
            assert len(parts) >= 6, \
                f"Line {i} has fewer than 6 fields: '{line}'"

            # Check format: [date] [time] QUERY hostname from IP
            assert parts[0].startswith('['), \
                f"Line {i} doesn't start with '[' for timestamp: '{line}'"
            assert parts[2] == 'QUERY', \
                f"Line {i} third field should be 'QUERY', got '{parts[2]}': '{line}'"
            assert parts[4] == 'from', \
                f"Line {i} fifth field should be 'from', got '{parts[4]}': '{line}'"

            # Hostname should be the 4th field (index 3)
            hostname = parts[3]
            assert '.' in hostname, \
                f"Line {i} hostname '{hostname}' doesn't look like a valid hostname"

    def test_log_file_has_unique_hostnames(self):
        """The log file should contain roughly 40 unique hostnames"""
        hostnames = set()
        with open(self.LOG_FILE, 'r') as f:
            for line in f:
                parts = line.split()
                if len(parts) >= 4:
                    hostnames.add(parts[3])

        unique_count = len(hostnames)
        # Allow some tolerance around ~40 unique hostnames
        assert 30 <= unique_count <= 60, \
            f"Expected ~40 unique hostnames, found {unique_count}"

    def test_log_file_has_duplicate_hostnames(self):
        """The log file should have many repeated hostnames (not all unique)"""
        hostnames = []
        with open(self.LOG_FILE, 'r') as f:
            for line in f:
                parts = line.split()
                if len(parts) >= 4:
                    hostnames.append(parts[3])

        total_count = len(hostnames)
        unique_count = len(set(hostnames))

        assert total_count > unique_count, \
            f"Expected duplicate hostnames but all {total_count} hostnames are unique"


class TestHomeDirectory:
    """Tests for the home directory /home/user"""

    HOME_DIR = "/home/user"

    def test_home_directory_exists(self):
        """The home directory must exist"""
        assert os.path.exists(self.HOME_DIR), \
            f"Home directory {self.HOME_DIR} does not exist"

    def test_home_directory_is_directory(self):
        """The home path must be a directory"""
        assert os.path.isdir(self.HOME_DIR), \
            f"{self.HOME_DIR} exists but is not a directory"

    def test_home_directory_is_writable(self):
        """The home directory must be writable by the current user"""
        assert os.access(self.HOME_DIR, os.W_OK), \
            f"{self.HOME_DIR} exists but is not writable by the current user"


class TestOutputFileDoesNotExist:
    """Tests to ensure the output file does not exist initially"""

    OUTPUT_FILE = "/home/user/hostnames.txt"

    def test_output_file_does_not_exist(self):
        """The output file must not exist before the task is performed"""
        assert not os.path.exists(self.OUTPUT_FILE), \
            f"Output file {self.OUTPUT_FILE} already exists - it should not exist initially"


class TestRequiredTools:
    """Tests to verify standard tools are available"""

    REQUIRED_TOOLS = ['awk', 'cut', 'sed', 'grep', 'sort', 'uniq']

    def test_tools_available(self):
        """Standard text processing tools must be available"""
        import shutil

        missing_tools = []
        for tool in self.REQUIRED_TOOLS:
            if shutil.which(tool) is None:
                missing_tools.append(tool)

        assert not missing_tools, \
            f"Required tools are missing: {', '.join(missing_tools)}"
