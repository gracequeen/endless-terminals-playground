# test_final_state.py
"""
Tests to validate the final state of the OS/filesystem after the student
has completed the DNS log hostname extraction task.
"""

import os
import subprocess
import pytest


class TestOutputFileExists:
    """Tests for the existence and basic properties of the output file"""

    OUTPUT_FILE = "/home/user/hostnames.txt"

    def test_output_file_exists(self):
        """The output file must exist"""
        assert os.path.exists(self.OUTPUT_FILE), \
            f"Output file {self.OUTPUT_FILE} does not exist - task not completed"

    def test_output_file_is_regular_file(self):
        """The output file must be a regular file"""
        assert os.path.isfile(self.OUTPUT_FILE), \
            f"{self.OUTPUT_FILE} exists but is not a regular file"

    def test_output_file_is_readable(self):
        """The output file must be readable"""
        assert os.access(self.OUTPUT_FILE, os.R_OK), \
            f"{self.OUTPUT_FILE} exists but is not readable"


class TestOutputFileContent:
    """Tests for the content of the output file"""

    OUTPUT_FILE = "/home/user/hostnames.txt"
    LOG_FILE = "/var/log/dns/queries.log"

    def test_output_file_not_empty(self):
        """The output file must not be empty"""
        with open(self.OUTPUT_FILE, 'r') as f:
            content = f.read()
        assert content.strip(), \
            f"{self.OUTPUT_FILE} is empty - should contain hostnames"

    def test_output_file_ends_with_newline(self):
        """The output file must end with a newline"""
        with open(self.OUTPUT_FILE, 'rb') as f:
            content = f.read()
        assert content.endswith(b'\n'), \
            f"{self.OUTPUT_FILE} does not end with a newline"

    def test_no_empty_lines(self):
        """The output file must not contain empty lines"""
        with open(self.OUTPUT_FILE, 'r') as f:
            lines = f.readlines()

        empty_line_numbers = []
        for i, line in enumerate(lines, 1):
            if line.strip() == '':
                empty_line_numbers.append(i)

        assert not empty_line_numbers, \
            f"{self.OUTPUT_FILE} contains empty lines at line numbers: {empty_line_numbers}"

    def test_no_leading_trailing_whitespace(self):
        """No line should have leading or trailing whitespace (except the final newline)"""
        with open(self.OUTPUT_FILE, 'r') as f:
            lines = f.readlines()

        problematic_lines = []
        for i, line in enumerate(lines, 1):
            # Remove only the trailing newline for comparison
            line_without_newline = line.rstrip('\n')
            stripped = line_without_newline.strip()
            if line_without_newline != stripped:
                problematic_lines.append((i, repr(line_without_newline)))

        assert not problematic_lines, \
            f"Lines with leading/trailing whitespace found: {problematic_lines}"

    def test_no_duplicates(self):
        """The output file must not contain duplicate hostnames"""
        with open(self.OUTPUT_FILE, 'r') as f:
            lines = [line.strip() for line in f.readlines() if line.strip()]

        seen = set()
        duplicates = []
        for line in lines:
            if line in seen:
                duplicates.append(line)
            seen.add(line)

        assert not duplicates, \
            f"Duplicate hostnames found in output: {duplicates}"

    def test_output_is_sorted(self):
        """The output file must be sorted alphabetically"""
        with open(self.OUTPUT_FILE, 'r') as f:
            lines = [line.strip() for line in f.readlines() if line.strip()]

        sorted_lines = sorted(lines)

        assert lines == sorted_lines, \
            f"Output is not sorted alphabetically. First mismatch: expected '{sorted_lines[0]}' at position where '{lines[0]}' was found" if lines else "Output is empty"

    def test_line_count_matches_unique_hostnames(self):
        """Line count must match the number of unique hostnames in the source log"""
        # Get unique hostnames from source log
        with open(self.LOG_FILE, 'r') as f:
            source_hostnames = set()
            for line in f:
                parts = line.split()
                if len(parts) >= 4:
                    source_hostnames.add(parts[3])

        # Get hostnames from output file
        with open(self.OUTPUT_FILE, 'r') as f:
            output_lines = [line.strip() for line in f.readlines() if line.strip()]

        expected_count = len(source_hostnames)
        actual_count = len(output_lines)

        assert actual_count == expected_count, \
            f"Output has {actual_count} lines but source log has {expected_count} unique hostnames"


class TestOutputMatchesSource:
    """Tests to verify output is derived from the source log, not hardcoded"""

    OUTPUT_FILE = "/home/user/hostnames.txt"
    LOG_FILE = "/var/log/dns/queries.log"

    def test_output_matches_source_exactly(self):
        """Output must exactly match sorted unique hostnames from source log"""
        # Extract unique sorted hostnames from source log
        with open(self.LOG_FILE, 'r') as f:
            source_hostnames = set()
            for line in f:
                parts = line.split()
                if len(parts) >= 4:
                    source_hostnames.add(parts[3])

        expected_hostnames = sorted(source_hostnames)

        # Get hostnames from output file
        with open(self.OUTPUT_FILE, 'r') as f:
            actual_hostnames = [line.strip() for line in f.readlines() if line.strip()]

        # Compare sets first to identify missing/extra
        expected_set = set(expected_hostnames)
        actual_set = set(actual_hostnames)

        missing = expected_set - actual_set
        extra = actual_set - expected_set

        error_msg = ""
        if missing:
            error_msg += f"Missing hostnames: {sorted(missing)[:5]}{'...' if len(missing) > 5 else ''}\n"
        if extra:
            error_msg += f"Extra hostnames: {sorted(extra)[:5]}{'...' if len(extra) > 5 else ''}\n"

        assert not missing and not extra, \
            f"Output does not match source log hostnames.\n{error_msg}"

        # Also verify exact order
        assert actual_hostnames == expected_hostnames, \
            "Output hostnames are correct but not in expected sorted order"

    def test_all_entries_are_valid_hostnames(self):
        """All entries in output should look like valid hostnames"""
        with open(self.OUTPUT_FILE, 'r') as f:
            hostnames = [line.strip() for line in f.readlines() if line.strip()]

        invalid_entries = []
        for hostname in hostnames:
            # Basic hostname validation - should contain at least one dot and no spaces
            if ' ' in hostname or '\t' in hostname:
                invalid_entries.append((hostname, "contains whitespace"))
            elif '.' not in hostname:
                invalid_entries.append((hostname, "no dot found"))
            elif hostname.startswith('.') or hostname.endswith('.'):
                invalid_entries.append((hostname, "starts or ends with dot"))

        assert not invalid_entries, \
            f"Invalid hostname entries found: {invalid_entries[:5]}"


class TestSourceLogUnchanged:
    """Tests to verify the source log file was not modified"""

    LOG_FILE = "/var/log/dns/queries.log"

    def test_source_log_still_exists(self):
        """The source log file must still exist"""
        assert os.path.exists(self.LOG_FILE), \
            f"Source log file {self.LOG_FILE} no longer exists - it should not be deleted"

    def test_source_log_format_intact(self):
        """The source log file format should still be intact"""
        with open(self.LOG_FILE, 'r') as f:
            lines = f.readlines()

        # Check that at least some lines still have the expected format
        valid_format_count = 0
        for line in lines:
            parts = line.split()
            if len(parts) >= 6 and parts[2] == 'QUERY' and parts[4] == 'from':
                valid_format_count += 1

        # At least 90% of lines should still be in valid format
        assert valid_format_count >= len(lines) * 0.9, \
            f"Source log appears to have been modified - only {valid_format_count}/{len(lines)} lines have valid format"

    def test_source_log_has_expected_line_count(self):
        """The source log should still have approximately 200 lines"""
        with open(self.LOG_FILE, 'r') as f:
            lines = f.readlines()

        line_count = len(lines)
        assert 150 <= line_count <= 250, \
            f"Source log has {line_count} lines - may have been modified (expected ~200)"
