I'm trying to get our staging frontend up at /home/user/webapp before the 3pm deploy window. Running `./start.sh` and it just dies silently — no error, no listening port, nothing in the terminal. The script worked fine on the old box last week.

It's supposed to come up on port 8080. I checked and nothing else is using that port, so it's not a conflict. Config lives somewhere in that directory, pretty standard nginx setup I think? Just need it actually serving requests so QA can hit it.
