# test_final_state.py
"""
Tests to validate the final state after the student has fixed the nginx
configuration in /home/user/webapp and started the server on port 8080.
"""

import os
import subprocess
import socket
import time
import pytest


class TestNginxRunning:
    """Test that nginx is running and serving content."""

    def test_nginx_process_running_for_webapp(self):
        """Verify nginx process is running with webapp config."""
        result = subprocess.run(
            ["pgrep", "-f", "nginx.*webapp"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            "No nginx process running for webapp. Expected nginx to be running with webapp config."
        assert result.stdout.strip() != "", \
            "pgrep returned success but no PID found for nginx webapp process"

    def test_port_8080_is_listening(self):
        """Verify something is listening on port 8080."""
        result = subprocess.run(
            ["ss", "-tlnp"],
            capture_output=True,
            text=True
        )
        assert ":8080" in result.stdout, \
            "Nothing is listening on port 8080. Expected nginx to be listening on port 8080."

    def test_can_connect_to_port_8080(self):
        """Verify we can establish a TCP connection to port 8080."""
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(5)
        try:
            result = sock.connect_ex(('localhost', 8080))
            assert result == 0, \
                f"Cannot connect to localhost:8080. Connection failed with error code {result}"
        finally:
            sock.close()


class TestNginxServingContent:
    """Test that nginx is serving the expected content."""

    def test_curl_returns_staging_frontend(self):
        """Verify curl to localhost:8080 returns content with 'Staging Frontend'."""
        result = subprocess.run(
            ["curl", "-s", "http://localhost:8080/"],
            capture_output=True,
            text=True,
            timeout=10
        )
        assert result.returncode == 0, \
            f"curl to localhost:8080 failed with return code {result.returncode}"
        assert "Staging Frontend" in result.stdout, \
            f"Response from localhost:8080 does not contain 'Staging Frontend'. Got: {result.stdout[:500]}"

    def test_curl_returns_version_2_4_1(self):
        """Verify curl to localhost:8080 returns content with version 'v2.4.1'."""
        result = subprocess.run(
            ["curl", "-s", "http://localhost:8080/"],
            capture_output=True,
            text=True,
            timeout=10
        )
        assert result.returncode == 0, \
            f"curl to localhost:8080 failed with return code {result.returncode}"
        assert "v2.4.1" in result.stdout or "2.4.1" in result.stdout, \
            f"Response from localhost:8080 does not contain version '2.4.1'. Got: {result.stdout[:500]}"

    def test_curl_returns_html(self):
        """Verify curl to localhost:8080 returns HTML content."""
        result = subprocess.run(
            ["curl", "-s", "http://localhost:8080/"],
            capture_output=True,
            text=True,
            timeout=10
        )
        assert result.returncode == 0, \
            f"curl to localhost:8080 failed with return code {result.returncode}"
        # Check for HTML markers
        content_lower = result.stdout.lower()
        assert "<html" in content_lower or "<!doctype" in content_lower, \
            f"Response from localhost:8080 does not appear to be HTML. Got: {result.stdout[:500]}"


class TestNginxConfigFixed:
    """Test that the nginx configuration has been properly fixed."""

    def test_nginx_conf_still_exists(self):
        """Verify nginx.conf still exists in the conf directory."""
        nginx_conf = "/home/user/webapp/conf/nginx.conf"
        assert os.path.isfile(nginx_conf), \
            f"nginx.conf not found at {nginx_conf}. Config file should still exist."

    def test_nginx_conf_has_worker_connections(self):
        """Verify nginx.conf still contains worker_connections directive."""
        nginx_conf = "/home/user/webapp/conf/nginx.conf"
        with open(nginx_conf, 'r') as f:
            content = f.read()
        assert "worker_connections" in content, \
            "nginx.conf must still contain worker_connections directive (not deleted to avoid problem)"

    def test_nginx_conf_has_access_log(self):
        """Verify nginx.conf still contains access_log directive."""
        nginx_conf = "/home/user/webapp/conf/nginx.conf"
        with open(nginx_conf, 'r') as f:
            content = f.read()
        assert "access_log" in content, \
            "nginx.conf must still contain access_log directive (should fix log_format, not delete access_log)"

    def test_nginx_conf_has_events_block(self):
        """Verify nginx.conf has correct 'events' block (not 'event' typo)."""
        nginx_conf = "/home/user/webapp/conf/nginx.conf"
        with open(nginx_conf, 'r') as f:
            content = f.read()
        import re
        has_correct_events = re.search(r'\bevents\s*\{', content) is not None
        assert has_correct_events, \
            "nginx.conf should have correct 'events' block (the 'event' typo should be fixed)"

    def test_nginx_config_test_passes(self):
        """Verify nginx config test now passes."""
        result = subprocess.run(
            ["/usr/sbin/nginx", "-t", "-c", "/home/user/webapp/conf/nginx.conf",
             "-p", "/home/user/webapp"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            f"nginx -t still fails. Config errors remain: {result.stderr}"

    def test_nginx_conf_listens_on_8080(self):
        """Verify nginx.conf is configured to listen on port 8080."""
        nginx_conf = "/home/user/webapp/conf/nginx.conf"
        with open(nginx_conf, 'r') as f:
            content = f.read()
        import re
        # Match listen directive with 8080
        has_listen_8080 = re.search(r'listen\s+8080', content) is not None
        assert has_listen_8080, \
            "nginx.conf must have 'listen 8080' directive. Server must listen on port 8080."


class TestIndexHtmlUnchanged:
    """Test that the original index.html content is preserved."""

    def test_index_html_exists(self):
        """Verify index.html still exists."""
        index_html = "/home/user/webapp/html/index.html"
        assert os.path.isfile(index_html), \
            f"index.html not found at {index_html}"

    def test_index_html_contains_staging_frontend(self):
        """Verify index.html still contains the original content."""
        index_html = "/home/user/webapp/html/index.html"
        with open(index_html, 'r') as f:
            content = f.read()
        assert "Staging Frontend v2.4.1" in content, \
            "index.html content changed. Must still contain 'Staging Frontend v2.4.1'"


class TestIsActuallyNginx:
    """Test that it's actually nginx serving (not a substitute like python http.server)."""

    def test_server_header_is_nginx(self):
        """Verify the Server header indicates nginx."""
        result = subprocess.run(
            ["curl", "-sI", "http://localhost:8080/"],
            capture_output=True,
            text=True,
            timeout=10
        )
        assert result.returncode == 0, \
            f"curl -I to localhost:8080 failed with return code {result.returncode}"
        # Check for nginx in Server header
        headers_lower = result.stdout.lower()
        assert "nginx" in headers_lower, \
            f"Server header does not indicate nginx. Must use nginx, not a substitute. Headers: {result.stdout}"

    def test_nginx_master_process_exists(self):
        """Verify nginx master process is running."""
        result = subprocess.run(
            ["pgrep", "-a", "nginx"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            "No nginx processes found. Must use nginx to serve content."
        assert "nginx" in result.stdout, \
            f"pgrep output doesn't show nginx processes: {result.stdout}"


class TestWebappDirectoryIntegrity:
    """Test that the webapp directory structure is maintained."""

    def test_webapp_directory_exists(self):
        """Verify /home/user/webapp directory still exists."""
        assert os.path.isdir("/home/user/webapp"), \
            "Directory /home/user/webapp must still exist"

    def test_conf_directory_exists(self):
        """Verify conf directory still exists."""
        assert os.path.isdir("/home/user/webapp/conf"), \
            "Directory /home/user/webapp/conf must still exist"

    def test_html_directory_exists(self):
        """Verify html directory still exists."""
        assert os.path.isdir("/home/user/webapp/html"), \
            "Directory /home/user/webapp/html must still exist"

    def test_start_script_exists(self):
        """Verify start.sh still exists."""
        assert os.path.isfile("/home/user/webapp/start.sh"), \
            "start.sh must still exist in /home/user/webapp"
