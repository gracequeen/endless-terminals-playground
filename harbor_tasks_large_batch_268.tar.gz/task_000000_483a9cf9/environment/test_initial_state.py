# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the task of fixing the nginx configuration in /home/user/webapp.
"""

import os
import subprocess
import pytest


class TestWebappDirectoryStructure:
    """Test that the webapp directory and required files exist."""

    def test_webapp_directory_exists(self):
        """Verify /home/user/webapp directory exists."""
        assert os.path.isdir("/home/user/webapp"), \
            "Directory /home/user/webapp does not exist"

    def test_start_script_exists(self):
        """Verify start.sh exists in webapp directory."""
        start_sh = "/home/user/webapp/start.sh"
        assert os.path.isfile(start_sh), \
            f"start.sh script not found at {start_sh}"

    def test_start_script_is_executable(self):
        """Verify start.sh is executable."""
        start_sh = "/home/user/webapp/start.sh"
        assert os.access(start_sh, os.X_OK), \
            f"{start_sh} is not executable"

    def test_conf_directory_exists(self):
        """Verify conf directory exists."""
        conf_dir = "/home/user/webapp/conf"
        assert os.path.isdir(conf_dir), \
            f"Configuration directory not found at {conf_dir}"

    def test_nginx_conf_exists(self):
        """Verify nginx.conf exists in conf directory."""
        nginx_conf = "/home/user/webapp/conf/nginx.conf"
        assert os.path.isfile(nginx_conf), \
            f"nginx.conf not found at {nginx_conf}"

    def test_mime_types_exists(self):
        """Verify mime.types exists in conf directory."""
        mime_types = "/home/user/webapp/conf/mime.types"
        assert os.path.isfile(mime_types), \
            f"mime.types not found at {mime_types}"

    def test_html_directory_exists(self):
        """Verify html directory exists."""
        html_dir = "/home/user/webapp/html"
        assert os.path.isdir(html_dir), \
            f"HTML directory not found at {html_dir}"

    def test_index_html_exists(self):
        """Verify index.html exists in html directory."""
        index_html = "/home/user/webapp/html/index.html"
        assert os.path.isfile(index_html), \
            f"index.html not found at {index_html}"

    def test_index_html_contains_staging_frontend(self):
        """Verify index.html contains the expected content."""
        index_html = "/home/user/webapp/html/index.html"
        with open(index_html, 'r') as f:
            content = f.read()
        assert "Staging Frontend v2.4.1" in content, \
            "index.html does not contain expected 'Staging Frontend v2.4.1' text"

    def test_logs_directory_exists(self):
        """Verify logs directory exists."""
        logs_dir = "/home/user/webapp/logs"
        assert os.path.isdir(logs_dir), \
            f"Logs directory not found at {logs_dir}"

    def test_logs_directory_is_writable(self):
        """Verify logs directory is writable."""
        logs_dir = "/home/user/webapp/logs"
        assert os.access(logs_dir, os.W_OK), \
            f"Logs directory {logs_dir} is not writable"


class TestNginxInstallation:
    """Test that nginx is installed and available."""

    def test_nginx_binary_exists(self):
        """Verify nginx binary exists at expected location."""
        nginx_path = "/usr/sbin/nginx"
        assert os.path.isfile(nginx_path), \
            f"nginx binary not found at {nginx_path}"

    def test_nginx_is_executable(self):
        """Verify nginx binary is executable."""
        nginx_path = "/usr/sbin/nginx"
        assert os.access(nginx_path, os.X_OK), \
            f"nginx binary at {nginx_path} is not executable"

    def test_nginx_version_runs(self):
        """Verify nginx can report its version (basic functionality check)."""
        result = subprocess.run(
            ["/usr/sbin/nginx", "-v"],
            capture_output=True,
            text=True
        )
        # nginx -v outputs to stderr
        assert "nginx" in result.stderr.lower(), \
            "nginx -v did not return expected version information"


class TestNginxConfigHasIssues:
    """Test that the nginx config has the expected issues (bugs to be fixed)."""

    def test_nginx_conf_has_event_typo(self):
        """Verify nginx.conf has 'event' instead of 'events' (the bug)."""
        nginx_conf = "/home/user/webapp/conf/nginx.conf"
        with open(nginx_conf, 'r') as f:
            content = f.read()
        # Check for the typo - 'event' block without 's'
        # This is a bit tricky - we need to find 'event {' or 'event{' but not 'events'
        import re
        # Look for 'event' followed by whitespace and/or '{' but NOT 'events'
        has_event_typo = re.search(r'\bevent\s*\{', content) is not None
        has_correct_events = re.search(r'\bevents\s*\{', content) is not None
        assert has_event_typo and not has_correct_events, \
            "nginx.conf should have 'event' typo (missing 's') but appears to have correct 'events' block"

    def test_nginx_conf_has_worker_connections(self):
        """Verify nginx.conf contains worker_connections directive."""
        nginx_conf = "/home/user/webapp/conf/nginx.conf"
        with open(nginx_conf, 'r') as f:
            content = f.read()
        assert "worker_connections" in content, \
            "nginx.conf should contain worker_connections directive"

    def test_nginx_conf_has_access_log_with_main(self):
        """Verify nginx.conf has access_log with 'main' format (second bug)."""
        nginx_conf = "/home/user/webapp/conf/nginx.conf"
        with open(nginx_conf, 'r') as f:
            content = f.read()
        assert "access_log" in content and "main" in content, \
            "nginx.conf should contain access_log directive with 'main' format"

    def test_nginx_conf_missing_log_format_main(self):
        """Verify nginx.conf is missing log_format main definition."""
        nginx_conf = "/home/user/webapp/conf/nginx.conf"
        with open(nginx_conf, 'r') as f:
            content = f.read()
        # Check that log_format main is NOT defined
        import re
        has_log_format_main = re.search(r'log_format\s+main\s', content) is not None
        assert not has_log_format_main, \
            "nginx.conf should NOT have log_format main defined (this is the second bug)"

    def test_nginx_conf_has_listen_8080(self):
        """Verify nginx.conf is configured to listen on port 8080."""
        nginx_conf = "/home/user/webapp/conf/nginx.conf"
        with open(nginx_conf, 'r') as f:
            content = f.read()
        assert "listen 8080" in content or "listen  8080" in content, \
            "nginx.conf should contain 'listen 8080' directive"

    def test_nginx_config_test_fails(self):
        """Verify that nginx config test fails (confirming bugs exist)."""
        result = subprocess.run(
            ["/usr/sbin/nginx", "-t", "-c", "/home/user/webapp/conf/nginx.conf", 
             "-p", "/home/user/webapp"],
            capture_output=True,
            text=True
        )
        assert result.returncode != 0, \
            "nginx -t should fail due to config errors, but it succeeded"


class TestPort8080IsFree:
    """Test that port 8080 is not in use."""

    def test_port_8080_not_listening(self):
        """Verify nothing is currently listening on port 8080."""
        result = subprocess.run(
            ["ss", "-tlnp"],
            capture_output=True,
            text=True
        )
        assert ":8080" not in result.stdout, \
            "Port 8080 is already in use - it should be free"

    def test_no_nginx_webapp_process_running(self):
        """Verify no nginx process for webapp is currently running."""
        result = subprocess.run(
            ["pgrep", "-f", "nginx.*webapp"],
            capture_output=True,
            text=True
        )
        # pgrep returns 1 if no processes found, 0 if found
        assert result.returncode != 0, \
            "An nginx process for webapp is already running - it should not be"


class TestStartScriptFails:
    """Test that the start script currently fails."""

    def test_start_script_exits_with_error(self):
        """Verify start.sh exits with non-zero code."""
        result = subprocess.run(
            ["./start.sh"],
            capture_output=True,
            text=True,
            cwd="/home/user/webapp"
        )
        assert result.returncode != 0, \
            "start.sh should exit with error code due to nginx config issues"

    def test_start_script_no_output(self):
        """Verify start.sh produces no output (silent failure as described)."""
        result = subprocess.run(
            ["./start.sh"],
            capture_output=True,
            text=True,
            cwd="/home/user/webapp"
        )
        # The script should fail silently
        assert result.stdout == "" or result.stdout.strip() == "", \
            f"start.sh should produce no stdout, but got: {result.stdout}"


class TestCurlAvailable:
    """Test that curl is available for testing."""

    def test_curl_installed(self):
        """Verify curl is available."""
        result = subprocess.run(
            ["which", "curl"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, \
            "curl is not installed or not in PATH"


class TestWebappWritable:
    """Test that webapp directory is writable for fixes."""

    def test_webapp_directory_writable(self):
        """Verify /home/user/webapp is writable."""
        assert os.access("/home/user/webapp", os.W_OK), \
            "/home/user/webapp is not writable"

    def test_nginx_conf_writable(self):
        """Verify nginx.conf is writable."""
        nginx_conf = "/home/user/webapp/conf/nginx.conf"
        assert os.access(nginx_conf, os.W_OK), \
            f"{nginx_conf} is not writable"
