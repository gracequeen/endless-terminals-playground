# test_final_state.py
"""
Tests to validate the final state of the system after the student has completed the task.
This verifies that /home/user/perf-suite/run_tests.sh has PARALLEL_WORKERS=4 (changed from 64).
"""

import os
import stat
import subprocess
import pytest


class TestFinalState:
    """Test suite to validate final system state for the PARALLEL_WORKERS task."""

    SCRIPT_PATH = "/home/user/perf-suite/run_tests.sh"

    def test_script_file_exists(self):
        """Verify that the run_tests.sh script still exists."""
        assert os.path.exists(self.SCRIPT_PATH), (
            f"Script file does not exist: {self.SCRIPT_PATH}. "
            f"The file should not have been deleted."
        )

    def test_script_is_a_file(self):
        """Verify that run_tests.sh is still a regular file."""
        assert os.path.isfile(self.SCRIPT_PATH), (
            f"Path exists but is not a regular file: {self.SCRIPT_PATH}"
        )

    def test_script_remains_executable(self):
        """Verify that run_tests.sh is still executable after modification."""
        file_stat = os.stat(self.SCRIPT_PATH)
        is_executable = file_stat.st_mode & (stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
        assert is_executable, (
            f"Script is no longer executable: {self.SCRIPT_PATH}. "
            f"The file should remain executable after the modification."
        )

    def test_parallel_workers_set_to_4(self):
        """Verify that PARALLEL_WORKERS=4 exists in the script (exact match on its own line)."""
        result = subprocess.run(
            ["grep", "-E", "^PARALLEL_WORKERS=4$", self.SCRIPT_PATH],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"PARALLEL_WORKERS=4 not found as a standalone line in {self.SCRIPT_PATH}. "
            f"The task requires changing PARALLEL_WORKERS from 64 to 4."
        )

    def test_parallel_workers_64_removed(self):
        """Verify that PARALLEL_WORKERS=64 no longer exists in the script."""
        result = subprocess.run(
            ["grep", "-E", "^PARALLEL_WORKERS=64", self.SCRIPT_PATH],
            capture_output=True,
            text=True
        )
        assert result.returncode != 0, (
            f"PARALLEL_WORKERS=64 still exists in {self.SCRIPT_PATH}. "
            f"The old value (64) must be replaced, not just a new line added."
        )

    def test_parallel_workers_not_commented(self):
        """Verify that the PARALLEL_WORKERS=4 line is not commented out."""
        with open(self.SCRIPT_PATH, 'r') as f:
            content = f.read()

        lines = content.split('\n')
        found_uncommented = False
        for line in lines:
            stripped = line.strip()
            # Check for uncommented assignment (not starting with #)
            if stripped == "PARALLEL_WORKERS=4":
                found_uncommented = True
                break

        assert found_uncommented, (
            f"PARALLEL_WORKERS=4 is either missing or commented out in {self.SCRIPT_PATH}. "
            f"The assignment must be on its own line and not commented."
        )

    def test_variable_name_unchanged(self):
        """Verify that the variable is still named PARALLEL_WORKERS (not renamed)."""
        with open(self.SCRIPT_PATH, 'r') as f:
            content = f.read()

        # Check that PARALLEL_WORKERS assignment exists
        assert "PARALLEL_WORKERS=" in content, (
            f"PARALLEL_WORKERS variable assignment not found in {self.SCRIPT_PATH}. "
            f"The variable name should remain PARALLEL_WORKERS."
        )

    def test_script_still_uses_parallel_workers_variable(self):
        """Verify that the script still uses $PARALLEL_WORKERS variable."""
        with open(self.SCRIPT_PATH, 'r') as f:
            content = f.read()

        # Check for usage of the variable (either $PARALLEL_WORKERS or ${PARALLEL_WORKERS})
        uses_variable = "$PARALLEL_WORKERS" in content or "${PARALLEL_WORKERS}" in content
        assert uses_variable, (
            f"Script no longer uses $PARALLEL_WORKERS variable: {self.SCRIPT_PATH}. "
            f"The script should still reference this variable."
        )

    def test_only_one_parallel_workers_assignment(self):
        """Verify there's only one PARALLEL_WORKERS assignment (no duplicates added)."""
        with open(self.SCRIPT_PATH, 'r') as f:
            content = f.read()

        lines = content.split('\n')
        assignment_count = 0
        for line in lines:
            stripped = line.strip()
            # Count lines that are PARALLEL_WORKERS assignments (not commented)
            if stripped.startswith("PARALLEL_WORKERS=") and not stripped.startswith("#"):
                assignment_count += 1

        assert assignment_count == 1, (
            f"Found {assignment_count} PARALLEL_WORKERS assignments in {self.SCRIPT_PATH}. "
            f"There should be exactly one assignment (the modified one with value 4)."
        )

    def test_parallel_workers_4_near_top(self):
        """Verify that PARALLEL_WORKERS=4 appears near the top (within first 15 lines)."""
        with open(self.SCRIPT_PATH, 'r') as f:
            first_15_lines = [f.readline() for _ in range(15)]

        found = any("PARALLEL_WORKERS=4" in line for line in first_15_lines)
        assert found, (
            f"PARALLEL_WORKERS=4 not found within the first 15 lines of {self.SCRIPT_PATH}. "
            f"The variable should remain near the top of the script."
        )
