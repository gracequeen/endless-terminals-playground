# test_initial_state.py
"""
Tests to validate the initial state of the system before the student performs the task.
This verifies that /home/user/perf-suite/run_tests.sh exists with PARALLEL_WORKERS=64.
"""

import os
import stat
import subprocess
import pytest


class TestInitialState:
    """Test suite to validate initial system state for the PARALLEL_WORKERS task."""

    SCRIPT_PATH = "/home/user/perf-suite/run_tests.sh"

    def test_script_file_exists(self):
        """Verify that the run_tests.sh script exists."""
        assert os.path.exists(self.SCRIPT_PATH), (
            f"Script file does not exist: {self.SCRIPT_PATH}"
        )

    def test_script_is_a_file(self):
        """Verify that run_tests.sh is a regular file."""
        assert os.path.isfile(self.SCRIPT_PATH), (
            f"Path exists but is not a regular file: {self.SCRIPT_PATH}"
        )

    def test_script_is_executable(self):
        """Verify that run_tests.sh is executable."""
        file_stat = os.stat(self.SCRIPT_PATH)
        is_executable = file_stat.st_mode & (stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
        assert is_executable, (
            f"Script is not executable: {self.SCRIPT_PATH}"
        )

    def test_script_is_writable(self):
        """Verify that run_tests.sh is writable by the current user."""
        assert os.access(self.SCRIPT_PATH, os.W_OK), (
            f"Script is not writable: {self.SCRIPT_PATH}"
        )

    def test_parallel_workers_set_to_64(self):
        """Verify that PARALLEL_WORKERS=64 exists in the script."""
        result = subprocess.run(
            ["grep", "-E", "^PARALLEL_WORKERS=64$", self.SCRIPT_PATH],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"PARALLEL_WORKERS=64 not found in {self.SCRIPT_PATH}. "
            f"The initial state should have PARALLEL_WORKERS set to 64."
        )

    def test_parallel_workers_in_first_15_lines(self):
        """Verify that PARALLEL_WORKERS=64 appears near the top (within first 15 lines)."""
        with open(self.SCRIPT_PATH, 'r') as f:
            first_15_lines = [f.readline() for _ in range(15)]

        found = any("PARALLEL_WORKERS=64" in line for line in first_15_lines)
        assert found, (
            f"PARALLEL_WORKERS=64 not found within the first 15 lines of {self.SCRIPT_PATH}"
        )

    def test_parallel_workers_not_commented(self):
        """Verify that the PARALLEL_WORKERS=64 line is not commented out."""
        with open(self.SCRIPT_PATH, 'r') as f:
            content = f.read()

        # Check that there's an uncommented PARALLEL_WORKERS=64 line
        lines = content.split('\n')
        found_uncommented = False
        for line in lines:
            stripped = line.strip()
            if stripped == "PARALLEL_WORKERS=64":
                found_uncommented = True
                break

        assert found_uncommented, (
            f"PARALLEL_WORKERS=64 is either missing or commented out in {self.SCRIPT_PATH}"
        )

    def test_script_uses_parallel_workers_variable(self):
        """Verify that the script uses $PARALLEL_WORKERS variable."""
        with open(self.SCRIPT_PATH, 'r') as f:
            content = f.read()

        # Check for usage of the variable (either $PARALLEL_WORKERS or ${PARALLEL_WORKERS})
        uses_variable = "$PARALLEL_WORKERS" in content or "${PARALLEL_WORKERS}" in content
        assert uses_variable, (
            f"Script does not appear to use $PARALLEL_WORKERS variable: {self.SCRIPT_PATH}"
        )

    def test_bash_is_available(self):
        """Verify that bash is available on the system."""
        result = subprocess.run(
            ["which", "bash"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "bash is not available on this system"
        )

    def test_parent_directory_exists(self):
        """Verify that the parent directory /home/user/perf-suite exists."""
        parent_dir = os.path.dirname(self.SCRIPT_PATH)
        assert os.path.isdir(parent_dir), (
            f"Parent directory does not exist: {parent_dir}"
        )

    def test_parallel_workers_4_not_present(self):
        """Verify that PARALLEL_WORKERS=4 is NOT already in the script (task not done yet)."""
        result = subprocess.run(
            ["grep", "-E", "^PARALLEL_WORKERS=4$", self.SCRIPT_PATH],
            capture_output=True,
            text=True
        )
        assert result.returncode != 0, (
            f"PARALLEL_WORKERS=4 already exists in {self.SCRIPT_PATH}. "
            f"The initial state should have PARALLEL_WORKERS=64, not 4."
        )
