# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the SQLite archive task.
"""

import os
import sqlite3
import subprocess
import pytest


HOME = "/home/user"
SALES_DB = os.path.join(HOME, "sales.db")
ARCHIVE_DIR = os.path.join(HOME, "archive")
ARCHIVE_DB = os.path.join(ARCHIVE_DIR, "orders_2022.db")


class TestSalesDatabase:
    """Tests for the source sales.db database."""

    def test_sales_db_exists(self):
        """Verify /home/user/sales.db exists."""
        assert os.path.isfile(SALES_DB), f"Source database {SALES_DB} does not exist"

    def test_sales_db_readable(self):
        """Verify /home/user/sales.db is readable."""
        assert os.access(SALES_DB, os.R_OK), f"Source database {SALES_DB} is not readable"

    def test_sales_db_writable(self):
        """Verify /home/user/sales.db is writable."""
        assert os.access(SALES_DB, os.W_OK), f"Source database {SALES_DB} is not writable"

    def test_sales_db_is_valid_sqlite(self):
        """Verify /home/user/sales.db is a valid SQLite3 database."""
        try:
            conn = sqlite3.connect(SALES_DB)
            cursor = conn.cursor()
            cursor.execute("SELECT sqlite_version();")
            conn.close()
        except sqlite3.DatabaseError as e:
            pytest.fail(f"{SALES_DB} is not a valid SQLite3 database: {e}")

    def test_orders_table_exists(self):
        """Verify the orders table exists in sales.db."""
        conn = sqlite3.connect(SALES_DB)
        cursor = conn.cursor()
        cursor.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='orders';"
        )
        result = cursor.fetchone()
        conn.close()
        assert result is not None, "Table 'orders' does not exist in sales.db"

    def test_orders_table_schema(self):
        """Verify the orders table has the expected schema."""
        conn = sqlite3.connect(SALES_DB)
        cursor = conn.cursor()
        cursor.execute("PRAGMA table_info(orders);")
        columns = cursor.fetchall()
        conn.close()

        # Expected columns: id, customer_id, order_date, total, status
        column_names = [col[1] for col in columns]
        expected_columns = ["id", "customer_id", "order_date", "total", "status"]

        for expected in expected_columns:
            assert expected in column_names, (
                f"Column '{expected}' missing from orders table. "
                f"Found columns: {column_names}"
            )

    def test_orders_table_total_row_count(self):
        """Verify the orders table has exactly 847 rows."""
        conn = sqlite3.connect(SALES_DB)
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM orders;")
        count = cursor.fetchone()[0]
        conn.close()
        assert count == 847, (
            f"Expected 847 rows in orders table, found {count}"
        )

    def test_orders_2022_row_count(self):
        """Verify there are exactly 312 rows with order_date starting with '2022-'."""
        conn = sqlite3.connect(SALES_DB)
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM orders WHERE order_date LIKE '2022-%';")
        count = cursor.fetchone()[0]
        conn.close()
        assert count == 312, (
            f"Expected 312 rows with order_date LIKE '2022-%', found {count}"
        )


class TestArchiveDirectory:
    """Tests for the archive directory."""

    def test_archive_directory_exists(self):
        """Verify /home/user/archive/ directory exists."""
        assert os.path.isdir(ARCHIVE_DIR), (
            f"Archive directory {ARCHIVE_DIR} does not exist"
        )

    def test_archive_directory_writable(self):
        """Verify /home/user/archive/ directory is writable."""
        assert os.access(ARCHIVE_DIR, os.W_OK), (
            f"Archive directory {ARCHIVE_DIR} is not writable"
        )

    def test_archive_db_does_not_exist(self):
        """Verify /home/user/archive/orders_2022.db does not exist yet."""
        assert not os.path.exists(ARCHIVE_DB), (
            f"Archive database {ARCHIVE_DB} already exists - it should not exist initially"
        )


class TestSqliteCli:
    """Tests for sqlite3 CLI availability."""

    def test_sqlite3_cli_installed(self):
        """Verify sqlite3 CLI is installed and accessible."""
        result = subprocess.run(
            ["which", "sqlite3"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "sqlite3 CLI is not installed or not in PATH"
        )

    def test_sqlite3_cli_functional(self):
        """Verify sqlite3 CLI is functional."""
        result = subprocess.run(
            ["sqlite3", "--version"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"sqlite3 CLI is not functional: {result.stderr}"
        )
