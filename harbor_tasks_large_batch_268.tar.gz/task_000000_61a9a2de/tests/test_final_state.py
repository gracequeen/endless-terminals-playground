# test_final_state.py
"""
Tests to validate the final state of the OS/filesystem after the student
has completed the SQLite archive task.
"""

import os
import sqlite3
import pytest


HOME = "/home/user"
SALES_DB = os.path.join(HOME, "sales.db")
ARCHIVE_DIR = os.path.join(HOME, "archive")
ARCHIVE_DB = os.path.join(ARCHIVE_DIR, "orders_2022.db")


class TestArchiveDatabase:
    """Tests for the archive orders_2022.db database."""

    def test_archive_db_exists(self):
        """Verify /home/user/archive/orders_2022.db exists."""
        assert os.path.isfile(ARCHIVE_DB), (
            f"Archive database {ARCHIVE_DB} does not exist. "
            "The task requires creating this file with 2022 orders."
        )

    def test_archive_db_is_valid_sqlite(self):
        """Verify /home/user/archive/orders_2022.db is a valid SQLite3 database."""
        try:
            conn = sqlite3.connect(ARCHIVE_DB)
            cursor = conn.cursor()
            cursor.execute("SELECT sqlite_version();")
            conn.close()
        except sqlite3.DatabaseError as e:
            pytest.fail(f"{ARCHIVE_DB} is not a valid SQLite3 database: {e}")

    def test_archive_orders_table_exists(self):
        """Verify the orders table exists in orders_2022.db."""
        conn = sqlite3.connect(ARCHIVE_DB)
        cursor = conn.cursor()
        cursor.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='orders';"
        )
        result = cursor.fetchone()
        conn.close()
        assert result is not None, (
            "Table 'orders' does not exist in orders_2022.db. "
            "The archive must contain a table named 'orders'."
        )

    def test_archive_orders_table_schema(self):
        """Verify the orders table in archive has the same schema as source."""
        conn = sqlite3.connect(ARCHIVE_DB)
        cursor = conn.cursor()
        cursor.execute("PRAGMA table_info(orders);")
        columns = cursor.fetchall()
        conn.close()

        # Expected columns: id, customer_id, order_date, total, status
        column_info = {col[1]: col[2] for col in columns}  # name -> type
        expected_columns = {
            "id": "INTEGER",
            "customer_id": "INTEGER",
            "order_date": "TEXT",
            "total": "REAL",
            "status": "TEXT"
        }

        for col_name, col_type in expected_columns.items():
            assert col_name in column_info, (
                f"Column '{col_name}' missing from archive orders table. "
                f"Found columns: {list(column_info.keys())}"
            )
            assert column_info[col_name].upper() == col_type, (
                f"Column '{col_name}' has wrong type. "
                f"Expected {col_type}, found {column_info[col_name]}"
            )

    def test_archive_row_count_is_312(self):
        """Verify the archive orders table has exactly 312 rows."""
        conn = sqlite3.connect(ARCHIVE_DB)
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM orders;")
        count = cursor.fetchone()[0]
        conn.close()
        assert count == 312, (
            f"Expected exactly 312 rows in archive orders table, found {count}. "
            "The archive should contain all 2022 orders."
        )

    def test_archive_all_rows_are_2022(self):
        """Verify all rows in archive have order_date starting with '2022-'."""
        conn = sqlite3.connect(ARCHIVE_DB)
        cursor = conn.cursor()
        cursor.execute(
            "SELECT COUNT(*) FROM orders WHERE order_date NOT LIKE '2022-%';"
        )
        non_2022_count = cursor.fetchone()[0]
        conn.close()
        assert non_2022_count == 0, (
            f"Found {non_2022_count} rows in archive with order_date NOT from 2022. "
            "All archived rows should have order_date starting with '2022-'."
        )

    def test_archive_2022_row_count_matches(self):
        """Verify count of 2022 rows in archive matches expected."""
        conn = sqlite3.connect(ARCHIVE_DB)
        cursor = conn.cursor()
        cursor.execute(
            "SELECT COUNT(*) FROM orders WHERE order_date LIKE '2022-%';"
        )
        count_2022 = cursor.fetchone()[0]
        conn.close()
        assert count_2022 == 312, (
            f"Expected 312 rows with order_date LIKE '2022-%' in archive, found {count_2022}."
        )


class TestSourceDatabaseUnchanged:
    """Tests to verify the source sales.db is unchanged."""

    def test_sales_db_still_exists(self):
        """Verify /home/user/sales.db still exists."""
        assert os.path.isfile(SALES_DB), (
            f"Source database {SALES_DB} no longer exists. "
            "The original database should not be deleted."
        )

    def test_sales_db_is_valid_sqlite(self):
        """Verify /home/user/sales.db is still a valid SQLite3 database."""
        try:
            conn = sqlite3.connect(SALES_DB)
            cursor = conn.cursor()
            cursor.execute("SELECT sqlite_version();")
            conn.close()
        except sqlite3.DatabaseError as e:
            pytest.fail(f"{SALES_DB} is no longer a valid SQLite3 database: {e}")

    def test_sales_orders_table_still_exists(self):
        """Verify the orders table still exists in sales.db."""
        conn = sqlite3.connect(SALES_DB)
        cursor = conn.cursor()
        cursor.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='orders';"
        )
        result = cursor.fetchone()
        conn.close()
        assert result is not None, (
            "Table 'orders' no longer exists in sales.db. "
            "The original table should not be deleted."
        )

    def test_sales_orders_row_count_unchanged(self):
        """Verify the orders table in sales.db still has 847 rows."""
        conn = sqlite3.connect(SALES_DB)
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM orders;")
        count = cursor.fetchone()[0]
        conn.close()
        assert count == 847, (
            f"Expected 847 rows in source orders table, found {count}. "
            "The original table should be left alone - no rows should be deleted."
        )

    def test_sales_orders_2022_rows_still_present(self):
        """Verify the 2022 rows are still in the source database."""
        conn = sqlite3.connect(SALES_DB)
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM orders WHERE order_date LIKE '2022-%';")
        count = cursor.fetchone()[0]
        conn.close()
        assert count == 312, (
            f"Expected 312 rows with order_date LIKE '2022-%' in source, found {count}. "
            "The 2022 rows should remain in the original database."
        )

    def test_sales_orders_schema_unchanged(self):
        """Verify the orders table schema in sales.db is unchanged."""
        conn = sqlite3.connect(SALES_DB)
        cursor = conn.cursor()
        cursor.execute("PRAGMA table_info(orders);")
        columns = cursor.fetchall()
        conn.close()

        column_info = {col[1]: col[2] for col in columns}
        expected_columns = {
            "id": "INTEGER",
            "customer_id": "INTEGER",
            "order_date": "TEXT",
            "total": "REAL",
            "status": "TEXT"
        }

        for col_name, col_type in expected_columns.items():
            assert col_name in column_info, (
                f"Column '{col_name}' missing from source orders table. "
                f"Found columns: {list(column_info.keys())}. Schema should be unchanged."
            )
            assert column_info[col_name].upper() == col_type, (
                f"Column '{col_name}' type changed in source. "
                f"Expected {col_type}, found {column_info[col_name]}. Schema should be unchanged."
            )
