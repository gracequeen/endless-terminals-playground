# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the inventory-sync debugging task.
"""

import os
import subprocess
import sqlite3
import pytest


BASE_DIR = "/home/user/inventory-sync"


class TestDirectoryStructure:
    """Verify the expected directory structure exists."""

    def test_base_directory_exists(self):
        """The inventory-sync directory must exist."""
        assert os.path.isdir(BASE_DIR), f"Directory {BASE_DIR} does not exist"

    def test_src_directory_exists(self):
        """The src subdirectory must exist."""
        src_dir = os.path.join(BASE_DIR, "src")
        assert os.path.isdir(src_dir), f"Directory {src_dir} does not exist"

    def test_data_directory_exists(self):
        """The data subdirectory must exist."""
        data_dir = os.path.join(BASE_DIR, "data")
        assert os.path.isdir(data_dir), f"Directory {data_dir} does not exist"

    def test_output_directory_exists(self):
        """The output subdirectory must exist."""
        output_dir = os.path.join(BASE_DIR, "output")
        assert os.path.isdir(output_dir), f"Directory {output_dir} does not exist"

    def test_output_directory_is_writable(self):
        """The output directory must be writable."""
        output_dir = os.path.join(BASE_DIR, "output")
        assert os.access(output_dir, os.W_OK), f"Directory {output_dir} is not writable"


class TestRequiredFiles:
    """Verify all required files exist."""

    def test_run_sync_sh_exists(self):
        """The run_sync.sh script must exist."""
        script_path = os.path.join(BASE_DIR, "run_sync.sh")
        assert os.path.isfile(script_path), f"File {script_path} does not exist"

    def test_run_sync_sh_is_executable(self):
        """The run_sync.sh script must be executable."""
        script_path = os.path.join(BASE_DIR, "run_sync.sh")
        assert os.access(script_path, os.X_OK), f"File {script_path} is not executable"

    def test_config_env_exists(self):
        """The config.env file must exist."""
        config_path = os.path.join(BASE_DIR, "config.env")
        assert os.path.isfile(config_path), f"File {config_path} does not exist"

    def test_sync_py_exists(self):
        """The src/sync.py file must exist."""
        sync_path = os.path.join(BASE_DIR, "src", "sync.py")
        assert os.path.isfile(sync_path), f"File {sync_path} does not exist"

    def test_transforms_py_exists(self):
        """The src/transforms.py file must exist."""
        transforms_path = os.path.join(BASE_DIR, "src", "transforms.py")
        assert os.path.isfile(transforms_path), f"File {transforms_path} does not exist"

    def test_db_reader_py_exists(self):
        """The src/db_reader.py file must exist."""
        db_reader_path = os.path.join(BASE_DIR, "src", "db_reader.py")
        assert os.path.isfile(db_reader_path), f"File {db_reader_path} does not exist"

    def test_inventory_db_exists(self):
        """The data/inventory.db file must exist."""
        db_path = os.path.join(BASE_DIR, "data", "inventory.db")
        assert os.path.isfile(db_path), f"File {db_path} does not exist"


class TestDatabaseContent:
    """Verify the database has the expected content."""

    def test_database_is_valid_sqlite(self):
        """The inventory.db must be a valid SQLite database."""
        db_path = os.path.join(BASE_DIR, "data", "inventory.db")
        try:
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            cursor.execute("SELECT sqlite_version()")
            conn.close()
        except sqlite3.Error as e:
            pytest.fail(f"inventory.db is not a valid SQLite database: {e}")

    def test_items_table_exists(self):
        """The items table must exist in the database."""
        db_path = os.path.join(BASE_DIR, "data", "inventory.db")
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='items'")
        result = cursor.fetchone()
        conn.close()
        assert result is not None, "Table 'items' does not exist in inventory.db"

    def test_items_table_has_847_records(self):
        """The items table must contain exactly 847 records."""
        db_path = os.path.join(BASE_DIR, "data", "inventory.db")
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM items")
        count = cursor.fetchone()[0]
        conn.close()
        assert count == 847, f"Expected 847 records in items table, found {count}"


class TestScriptContent:
    """Verify the scripts have the expected structure and bugs."""

    def test_run_sync_sources_config_env(self):
        """run_sync.sh should source config.env."""
        script_path = os.path.join(BASE_DIR, "run_sync.sh")
        with open(script_path, 'r') as f:
            content = f.read()
        assert "config.env" in content, "run_sync.sh does not reference config.env"

    def test_run_sync_runs_sync_py(self):
        """run_sync.sh should run src/sync.py."""
        script_path = os.path.join(BASE_DIR, "run_sync.sh")
        with open(script_path, 'r') as f:
            content = f.read()
        assert "sync.py" in content, "run_sync.sh does not reference sync.py"

    def test_config_env_has_db_path(self):
        """config.env should set DB_PATH."""
        config_path = os.path.join(BASE_DIR, "config.env")
        with open(config_path, 'r') as f:
            content = f.read()
        assert "DB_PATH" in content, "config.env does not set DB_PATH"

    def test_config_env_has_transform_mode(self):
        """config.env should set TRANSFORM_MODE."""
        config_path = os.path.join(BASE_DIR, "config.env")
        with open(config_path, 'r') as f:
            content = f.read()
        assert "TRANSFORM_MODE" in content, "config.env does not set TRANSFORM_MODE"

    def test_sync_py_imports_sqlite3(self):
        """sync.py should import sqlite3."""
        sync_path = os.path.join(BASE_DIR, "src", "sync.py")
        with open(sync_path, 'r') as f:
            content = f.read()
        # Check if sqlite3 is imported (directly or via db_reader)
        has_sqlite_import = "sqlite3" in content or "db_reader" in content
        assert has_sqlite_import, "sync.py does not appear to use sqlite3 or db_reader"

    def test_sync_py_imports_transforms(self):
        """sync.py should import from transforms."""
        sync_path = os.path.join(BASE_DIR, "src", "sync.py")
        with open(sync_path, 'r') as f:
            content = f.read()
        assert "transforms" in content, "sync.py does not import transforms module"

    def test_transforms_py_has_mapping_import_bug(self):
        """transforms.py should have the collections.Mapping import (the bug)."""
        transforms_path = os.path.join(BASE_DIR, "src", "transforms.py")
        with open(transforms_path, 'r') as f:
            content = f.read()
        # Check for the buggy import pattern
        has_buggy_import = "from collections import" in content and "Mapping" in content
        assert has_buggy_import, "transforms.py does not have the expected Mapping import bug"


class TestPythonEnvironment:
    """Verify Python environment is as expected."""

    def test_python3_available(self):
        """Python 3 must be available."""
        result = subprocess.run(["python3", "--version"], capture_output=True, text=True)
        assert result.returncode == 0, "python3 is not available"

    def test_python_version_is_310_or_higher(self):
        """Python version should be 3.10+ (where collections.Mapping bug manifests)."""
        result = subprocess.run(["python3", "-c", "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')"], 
                                capture_output=True, text=True)
        version = result.stdout.strip()
        major, minor = map(int, version.split('.'))
        assert major == 3 and minor >= 10, f"Python version {version} is not 3.10+, the Mapping bug won't manifest"

    def test_sqlite3_module_available(self):
        """sqlite3 module must be available in Python."""
        result = subprocess.run(["python3", "-c", "import sqlite3"], capture_output=True, text=True)
        assert result.returncode == 0, "sqlite3 module is not available in Python"


class TestBugsPresent:
    """Verify the expected bugs are present in the initial state."""

    def test_run_sync_changes_to_src_directory(self):
        """run_sync.sh should cd to src directory (causing the path bug)."""
        script_path = os.path.join(BASE_DIR, "run_sync.sh")
        with open(script_path, 'r') as f:
            content = f.read()
        # Check for cd to src directory
        has_cd_to_src = "cd" in content and "src" in content
        assert has_cd_to_src, "run_sync.sh does not appear to change to src directory (expected bug)"

    def test_config_has_relative_db_path(self):
        """config.env should have relative DB_PATH (causing path resolution bug)."""
        config_path = os.path.join(BASE_DIR, "config.env")
        with open(config_path, 'r') as f:
            content = f.read()
        # Look for relative path pattern
        has_relative_path = "DB_PATH=./" in content or "DB_PATH=data/" in content
        assert has_relative_path, "config.env does not have relative DB_PATH (expected bug)"

    def test_config_has_legacy_transform_mode(self):
        """config.env should have TRANSFORM_MODE=legacy (causing the mode bug)."""
        config_path = os.path.join(BASE_DIR, "config.env")
        with open(config_path, 'r') as f:
            content = f.read()
        assert "TRANSFORM_MODE=legacy" in content or "TRANSFORM_MODE='legacy'" in content or 'TRANSFORM_MODE="legacy"' in content, \
            "config.env does not have TRANSFORM_MODE=legacy (expected bug)"


class TestSyncCurrentlyFails:
    """Verify that running the sync currently fails (bugs are present)."""

    def test_sync_script_fails(self):
        """Running run_sync.sh should currently fail due to bugs."""
        result = subprocess.run(
            ["./run_sync.sh"],
            cwd=BASE_DIR,
            capture_output=True,
            text=True,
            timeout=30
        )
        # The script should fail (non-zero exit code) or produce errors
        has_error = result.returncode != 0 or "Error" in result.stderr or "error" in result.stderr.lower() or "Traceback" in result.stderr
        assert has_error, "run_sync.sh should currently fail but it succeeded without errors"
