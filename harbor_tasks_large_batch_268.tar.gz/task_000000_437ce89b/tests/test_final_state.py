# test_final_state.py
"""
Tests to validate the final state of the OS/filesystem after the student
has completed the inventory-sync debugging task.
"""

import os
import subprocess
import sqlite3
import re
import pytest


BASE_DIR = "/home/user/inventory-sync"


class TestSyncExecutesSuccessfully:
    """Verify that the sync script now runs successfully."""

    def test_run_sync_exits_zero(self):
        """Running run_sync.sh should exit with code 0."""
        result = subprocess.run(
            ["./run_sync.sh"],
            cwd=BASE_DIR,
            capture_output=True,
            text=True,
            timeout=60
        )
        assert result.returncode == 0, (
            f"run_sync.sh exited with code {result.returncode}.\n"
            f"STDOUT:\n{result.stdout}\n"
            f"STDERR:\n{result.stderr}"
        )

    def test_no_python_exceptions_on_stderr(self):
        """Running run_sync.sh should not produce Python exceptions on stderr."""
        result = subprocess.run(
            ["./run_sync.sh"],
            cwd=BASE_DIR,
            capture_output=True,
            text=True,
            timeout=60
        )
        stderr_lower = result.stderr.lower()
        # Check for common Python exception indicators
        assert "traceback" not in stderr_lower, (
            f"Python traceback found in stderr:\n{result.stderr}"
        )
        assert "error" not in stderr_lower or result.returncode == 0, (
            f"Error found in stderr:\n{result.stderr}"
        )
        # Specifically check for the known bugs
        assert "importerror" not in stderr_lower, (
            f"ImportError found in stderr (Mapping import bug not fixed):\n{result.stderr}"
        )
        assert "operationalerror" not in stderr_lower, (
            f"OperationalError found in stderr (DB path bug not fixed):\n{result.stderr}"
        )


class TestReportGenerated:
    """Verify the sync report is generated correctly."""

    def test_sync_report_exists(self):
        """The sync_report.txt file must exist after running sync."""
        # First run the sync to ensure report is generated
        subprocess.run(
            ["./run_sync.sh"],
            cwd=BASE_DIR,
            capture_output=True,
            text=True,
            timeout=60
        )
        report_path = os.path.join(BASE_DIR, "output", "sync_report.txt")
        assert os.path.isfile(report_path), (
            f"Report file {report_path} does not exist after running sync"
        )

    def test_sync_report_contains_847_items_processed(self):
        """The sync_report.txt must contain 'Items processed: 847'."""
        # Run sync first
        subprocess.run(
            ["./run_sync.sh"],
            cwd=BASE_DIR,
            capture_output=True,
            text=True,
            timeout=60
        )
        report_path = os.path.join(BASE_DIR, "output", "sync_report.txt")
        assert os.path.isfile(report_path), f"Report file {report_path} does not exist"

        with open(report_path, 'r') as f:
            content = f.read()

        # Check for the exact format used by sync.py
        assert "Items processed: 847" in content, (
            f"Report does not contain 'Items processed: 847'.\n"
            f"Report content:\n{content}"
        )

    def test_sync_report_has_exactly_one_847_match(self):
        """The sync_report.txt should have exactly one occurrence of 847."""
        report_path = os.path.join(BASE_DIR, "output", "sync_report.txt")

        # Run sync first
        subprocess.run(
            ["./run_sync.sh"],
            cwd=BASE_DIR,
            capture_output=True,
            text=True,
            timeout=60
        )

        assert os.path.isfile(report_path), f"Report file {report_path} does not exist"

        with open(report_path, 'r') as f:
            content = f.read()

        count_847 = content.count("847")
        assert count_847 >= 1, (
            f"Report should contain '847' at least once, found {count_847} occurrences.\n"
            f"Report content:\n{content}"
        )


class TestDatabaseUnchanged:
    """Verify the database was not modified."""

    def test_database_still_exists(self):
        """The inventory.db file must still exist."""
        db_path = os.path.join(BASE_DIR, "data", "inventory.db")
        assert os.path.isfile(db_path), f"Database file {db_path} no longer exists"

    def test_database_still_has_847_records(self):
        """The items table must still contain exactly 847 records."""
        db_path = os.path.join(BASE_DIR, "data", "inventory.db")
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM items")
        count = cursor.fetchone()[0]
        conn.close()
        assert count == 847, (
            f"Database should still have 847 records, found {count}. "
            "Database was modified (not allowed)."
        )

    def test_database_verified_via_sqlite3_command(self):
        """Verify database record count using sqlite3 command line tool."""
        db_path = os.path.join(BASE_DIR, "data", "inventory.db")
        result = subprocess.run(
            ["sqlite3", db_path, "SELECT COUNT(*) FROM items"],
            capture_output=True,
            text=True,
            timeout=10
        )
        assert result.returncode == 0, f"sqlite3 command failed: {result.stderr}"
        count = int(result.stdout.strip())
        assert count == 847, (
            f"Database should have 847 records (verified via sqlite3 CLI), found {count}"
        )


class TestCodeIntegrity:
    """Verify the solution maintains code integrity (no hardcoding shortcuts)."""

    def test_sync_py_still_exists(self):
        """src/sync.py must still exist."""
        sync_path = os.path.join(BASE_DIR, "src", "sync.py")
        assert os.path.isfile(sync_path), f"File {sync_path} no longer exists"

    def test_sync_py_still_uses_sqlite3(self):
        """sync.py must still use sqlite3 (not hardcoded output)."""
        sync_path = os.path.join(BASE_DIR, "src", "sync.py")
        with open(sync_path, 'r') as f:
            content = f.read()

        # Check for sqlite3 usage either directly or via db_reader
        uses_sqlite = "sqlite3" in content or "db_reader" in content
        assert uses_sqlite, (
            "sync.py no longer references sqlite3 or db_reader. "
            "Solution must actually read from database, not hardcode output."
        )

    def test_sync_py_has_connect_call(self):
        """sync.py or db_reader.py must have a sqlite3 connect call."""
        sync_path = os.path.join(BASE_DIR, "src", "sync.py")
        db_reader_path = os.path.join(BASE_DIR, "src", "db_reader.py")

        has_connect = False

        if os.path.isfile(sync_path):
            with open(sync_path, 'r') as f:
                if "connect" in f.read():
                    has_connect = True

        if not has_connect and os.path.isfile(db_reader_path):
            with open(db_reader_path, 'r') as f:
                if "connect" in f.read():
                    has_connect = True

        assert has_connect, (
            "Neither sync.py nor db_reader.py contains a 'connect' call. "
            "Solution must actually connect to database."
        )

    def test_transforms_py_still_exists(self):
        """src/transforms.py must still exist."""
        transforms_path = os.path.join(BASE_DIR, "src", "transforms.py")
        assert os.path.isfile(transforms_path), f"File {transforms_path} no longer exists"

    def test_sync_py_still_imports_transforms(self):
        """sync.py must still import from transforms module."""
        sync_path = os.path.join(BASE_DIR, "src", "sync.py")
        with open(sync_path, 'r') as f:
            content = f.read()

        # Check for various import patterns
        imports_transforms = (
            "from transforms import" in content or
            "from .transforms import" in content or
            "import transforms" in content or
            "from src.transforms import" in content
        )
        assert imports_transforms, (
            "sync.py no longer imports transforms module. "
            "Solution must maintain the original code structure."
        )

    def test_run_sync_sh_still_exists(self):
        """run_sync.sh must still exist."""
        script_path = os.path.join(BASE_DIR, "run_sync.sh")
        assert os.path.isfile(script_path), f"File {script_path} no longer exists"

    def test_run_sync_sh_still_invokes_sync_py(self):
        """run_sync.sh must still invoke src/sync.py."""
        script_path = os.path.join(BASE_DIR, "run_sync.sh")
        with open(script_path, 'r') as f:
            content = f.read()

        assert "sync.py" in content, (
            "run_sync.sh no longer references sync.py. "
            "Solution must maintain the original execution approach."
        )


class TestBugsFixed:
    """Verify that the specific bugs have been addressed."""

    def test_transforms_mapping_import_fixed(self):
        """transforms.py should not have the broken collections.Mapping import."""
        transforms_path = os.path.join(BASE_DIR, "src", "transforms.py")
        with open(transforms_path, 'r') as f:
            content = f.read()

        # The buggy pattern: "from collections import Mapping" (without .abc)
        # Should be fixed to: "from collections.abc import Mapping"
        lines = content.split('\n')
        for line in lines:
            line_stripped = line.strip()
            if line_stripped.startswith('#'):
                continue
            # Check for the buggy import that doesn't use collections.abc
            if "from collections import" in line and "Mapping" in line:
                if "collections.abc" not in line:
                    pytest.fail(
                        f"transforms.py still has buggy import: '{line}'. "
                        "Should use 'from collections.abc import Mapping' for Python 3.10+"
                    )

    def test_transforms_can_be_imported(self):
        """transforms.py should be importable without errors."""
        result = subprocess.run(
            ["python3", "-c", "import sys; sys.path.insert(0, '/home/user/inventory-sync/src'); import transforms"],
            capture_output=True,
            text=True,
            timeout=10
        )
        assert result.returncode == 0, (
            f"transforms.py cannot be imported. Error:\n{result.stderr}"
        )


class TestEndToEndFunctionality:
    """End-to-end tests to verify complete functionality."""

    def test_full_sync_workflow(self):
        """Complete workflow: run sync, verify report has correct count."""
        # Clean up any existing report
        report_path = os.path.join(BASE_DIR, "output", "sync_report.txt")
        if os.path.exists(report_path):
            os.remove(report_path)

        # Run the sync
        result = subprocess.run(
            ["./run_sync.sh"],
            cwd=BASE_DIR,
            capture_output=True,
            text=True,
            timeout=60
        )

        # Verify exit code
        assert result.returncode == 0, (
            f"Sync failed with exit code {result.returncode}.\n"
            f"STDOUT:\n{result.stdout}\n"
            f"STDERR:\n{result.stderr}"
        )

        # Verify report exists
        assert os.path.isfile(report_path), "Report was not created"

        # Verify report content
        with open(report_path, 'r') as f:
            content = f.read()

        assert "Items processed: 847" in content, (
            f"Report does not show 847 items processed.\n"
            f"Report content:\n{content}"
        )

    def test_sync_is_repeatable(self):
        """Running sync multiple times should produce consistent results."""
        report_path = os.path.join(BASE_DIR, "output", "sync_report.txt")

        # Run twice
        for i in range(2):
            result = subprocess.run(
                ["./run_sync.sh"],
                cwd=BASE_DIR,
                capture_output=True,
                text=True,
                timeout=60
            )
            assert result.returncode == 0, f"Sync run {i+1} failed"

        # Check final report
        with open(report_path, 'r') as f:
            content = f.read()

        assert "Items processed: 847" in content, (
            "Report does not show correct count after multiple runs"
        )
