# test_final_state.py
"""
Tests to validate the final state of the filesystem after the student
has deleted old .tmp files (>30 days) from /home/user/data.
"""

import os
import subprocess
import time
from pathlib import Path


DATA_DIR = Path("/home/user/data")
MANIFEST_FILE = DATA_DIR / ".manifest"
THIRTY_DAYS_AGO = time.time() - (30 * 24 * 60 * 60)


def parse_manifest():
    """
    Parse the manifest file to get initial file information.
    Expected format per line: filepath|extension|age_category
    where age_category is 'old' (>30 days) or 'recent' (<=30 days)
    """
    manifest_data = {
        'old_tmp': [],      # .tmp files older than 30 days (should be deleted)
        'recent_tmp': [],   # .tmp files within 30 days (should remain)
        'non_tmp': []       # non-.tmp files (should remain regardless of age)
    }

    if not MANIFEST_FILE.exists():
        return manifest_data

    content = MANIFEST_FILE.read_text()
    for line in content.strip().split('\n'):
        if not line or line.startswith('#'):
            continue
        parts = line.split('|')
        if len(parts) >= 3:
            filepath, extension, age_category = parts[0], parts[1], parts[2]
            if extension == '.tmp':
                if age_category == 'old':
                    manifest_data['old_tmp'].append(filepath)
                else:
                    manifest_data['recent_tmp'].append(filepath)
            else:
                manifest_data['non_tmp'].append(filepath)

    return manifest_data


class TestNoOldTmpFilesRemain:
    """Verify all .tmp files older than 30 days have been deleted."""

    def test_find_command_returns_no_old_tmp_files(self):
        """Running find for old .tmp files should return no results."""
        result = subprocess.run(
            ['find', str(DATA_DIR), '-name', '*.tmp', '-mtime', '+30'],
            capture_output=True,
            text=True
        )
        found_files = [f for f in result.stdout.strip().split('\n') if f]
        assert len(found_files) == 0, (
            f"Found {len(found_files)} .tmp files older than 30 days that should have been deleted:\n"
            + '\n'.join(found_files[:10])  # Show first 10
        )

    def test_no_tmp_files_older_than_30_days(self):
        """Direct check: no .tmp files should have mtime > 30 days ago."""
        old_tmp_files = []
        for f in DATA_DIR.rglob("*.tmp"):
            if f.is_file():
                mtime = f.stat().st_mtime
                if mtime < THIRTY_DAYS_AGO:
                    old_tmp_files.append(str(f))

        assert len(old_tmp_files) == 0, (
            f"Found {len(old_tmp_files)} .tmp files older than 30 days that should have been deleted:\n"
            + '\n'.join(old_tmp_files[:10])
        )


class TestRecentTmpFilesPreserved:
    """Verify .tmp files modified within 30 days are preserved."""

    def test_recent_tmp_files_still_exist(self):
        """Recent .tmp files (<=30 days old) should still exist."""
        manifest_data = parse_manifest()
        recent_tmp_expected = manifest_data['recent_tmp']

        if not recent_tmp_expected:
            # If manifest parsing failed, fall back to checking at least some recent .tmp exist
            recent_tmp_files = []
            for f in DATA_DIR.rglob("*.tmp"):
                if f.is_file():
                    mtime = f.stat().st_mtime
                    if mtime >= THIRTY_DAYS_AGO:
                        recent_tmp_files.append(f)
            assert len(recent_tmp_files) >= 5, (
                f"Expected at least 5 recent .tmp files to remain, found {len(recent_tmp_files)}"
            )
        else:
            missing_files = []
            for filepath in recent_tmp_expected:
                if not Path(filepath).exists():
                    missing_files.append(filepath)

            assert len(missing_files) == 0, (
                f"Recent .tmp files (<=30 days old) were incorrectly deleted:\n"
                + '\n'.join(missing_files)
            )

    def test_correct_count_of_remaining_tmp_files(self):
        """The count of remaining .tmp files should match recent .tmp files from manifest."""
        manifest_data = parse_manifest()
        expected_count = len(manifest_data['recent_tmp'])

        if expected_count == 0:
            # Manifest parsing may have failed, skip strict count check
            return

        actual_tmp_files = list(DATA_DIR.rglob("*.tmp"))
        actual_count = len([f for f in actual_tmp_files if f.is_file()])

        assert actual_count == expected_count, (
            f"Expected {expected_count} .tmp files to remain (recent ones), "
            f"but found {actual_count}. "
            f"Either old files weren't deleted or recent files were incorrectly removed."
        )


class TestNonTmpFilesUnchanged:
    """Verify all non-.tmp files are preserved regardless of age."""

    def test_non_tmp_files_still_exist(self):
        """All non-.tmp files should still exist."""
        manifest_data = parse_manifest()
        non_tmp_expected = manifest_data['non_tmp']

        if not non_tmp_expected:
            # Fall back to checking non-.tmp files exist
            non_tmp_files = [
                p for p in DATA_DIR.rglob("*") 
                if p.is_file() and p.suffix != ".tmp" and p.name != ".manifest"
            ]
            assert len(non_tmp_files) >= 15, (
                f"Expected at least 15 non-.tmp files to remain, found {len(non_tmp_files)}"
            )
        else:
            missing_files = []
            for filepath in non_tmp_expected:
                if not Path(filepath).exists():
                    missing_files.append(filepath)

            assert len(missing_files) == 0, (
                f"Non-.tmp files were incorrectly deleted:\n"
                + '\n'.join(missing_files)
            )

    def test_correct_count_of_non_tmp_files(self):
        """The count of non-.tmp files should match initial count from manifest."""
        manifest_data = parse_manifest()
        expected_count = len(manifest_data['non_tmp'])

        if expected_count == 0:
            # Manifest parsing may have failed, skip strict count check
            return

        actual_non_tmp = [
            p for p in DATA_DIR.rglob("*") 
            if p.is_file() and p.suffix != ".tmp" and p.name != ".manifest"
        ]
        actual_count = len(actual_non_tmp)

        assert actual_count == expected_count, (
            f"Expected {expected_count} non-.tmp files, but found {actual_count}. "
            f"Non-.tmp files should not be deleted regardless of their age."
        )

    def test_old_non_tmp_files_preserved(self):
        """Old non-.tmp files (like .log files >30 days) must NOT be deleted."""
        # Check that there are still some old non-.tmp files
        old_non_tmp = []
        for f in DATA_DIR.rglob("*"):
            if f.is_file() and f.suffix != ".tmp" and f.name != ".manifest":
                mtime = f.stat().st_mtime
                if mtime < THIRTY_DAYS_AGO:
                    old_non_tmp.append(f)

        # We expect at least some old non-.tmp files to remain
        assert len(old_non_tmp) >= 5, (
            f"Expected at least 5 old non-.tmp files to remain (they should NOT be deleted), "
            f"found only {len(old_non_tmp)}. The task was to delete only .tmp files."
        )


class TestDirectoryStructurePreserved:
    """Verify the directory structure is preserved."""

    def test_data_directory_still_exists(self):
        """The /home/user/data directory should still exist."""
        assert DATA_DIR.exists(), f"Directory {DATA_DIR} no longer exists"
        assert DATA_DIR.is_dir(), f"{DATA_DIR} is no longer a directory"

    def test_manifest_file_preserved(self):
        """The manifest file should still exist."""
        assert MANIFEST_FILE.exists(), (
            f"Manifest file {MANIFEST_FILE} was deleted - only .tmp files should be removed"
        )

    def test_subdirectories_still_exist(self):
        """At least some subdirectory structure should remain."""
        subdirs = [p for p in DATA_DIR.rglob("*") if p.is_dir()]
        # Directories may be empty but should still exist (or at least some should)
        # Being lenient here as empty directories may or may not be removed
        assert DATA_DIR.is_dir(), "Main data directory should exist"


class TestTaskCompletionSummary:
    """Summary tests to verify the task was completed correctly."""

    def test_summary_old_tmp_deleted_recent_preserved(self):
        """
        Summary check: old .tmp files deleted, recent .tmp files preserved,
        all non-.tmp files preserved.
        """
        # Count current state
        current_tmp_files = list(DATA_DIR.rglob("*.tmp"))
        current_tmp_count = len([f for f in current_tmp_files if f.is_file()])

        current_non_tmp = [
            p for p in DATA_DIR.rglob("*") 
            if p.is_file() and p.suffix != ".tmp" and p.name != ".manifest"
        ]
        current_non_tmp_count = len(current_non_tmp)

        # Check no old .tmp files remain
        old_tmp_remaining = []
        for f in current_tmp_files:
            if f.is_file() and f.stat().st_mtime < THIRTY_DAYS_AGO:
                old_tmp_remaining.append(f)

        assert len(old_tmp_remaining) == 0, (
            f"Task incomplete: {len(old_tmp_remaining)} old .tmp files still exist"
        )

        # Check recent .tmp files exist
        assert current_tmp_count >= 5, (
            f"Task may have over-deleted: only {current_tmp_count} .tmp files remain, "
            f"expected at least 5 recent ones"
        )

        # Check non-.tmp files preserved
        assert current_non_tmp_count >= 15, (
            f"Task incorrectly deleted non-.tmp files: only {current_non_tmp_count} remain, "
            f"expected at least 15"
        )
