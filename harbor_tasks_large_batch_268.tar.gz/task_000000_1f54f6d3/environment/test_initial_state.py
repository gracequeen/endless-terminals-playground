# test_initial_state.py
"""
Tests to validate the initial state of the filesystem before the student
performs the task of deleting old .tmp files from /home/user/data.
"""

import os
import stat
import time
from pathlib import Path


DATA_DIR = Path("/home/user/data")
MANIFEST_FILE = DATA_DIR / ".manifest"
THIRTY_DAYS_AGO = time.time() - (30 * 24 * 60 * 60)


class TestDataDirectoryExists:
    """Verify /home/user/data exists and is writable."""

    def test_data_directory_exists(self):
        assert DATA_DIR.exists(), f"Directory {DATA_DIR} does not exist"

    def test_data_directory_is_directory(self):
        assert DATA_DIR.is_dir(), f"{DATA_DIR} exists but is not a directory"

    def test_data_directory_is_writable(self):
        assert os.access(DATA_DIR, os.W_OK), f"Directory {DATA_DIR} is not writable"


class TestManifestFile:
    """Verify the manifest file exists and is readable."""

    def test_manifest_exists(self):
        assert MANIFEST_FILE.exists(), f"Manifest file {MANIFEST_FILE} does not exist"

    def test_manifest_is_file(self):
        assert MANIFEST_FILE.is_file(), f"{MANIFEST_FILE} exists but is not a file"

    def test_manifest_is_readable(self):
        assert os.access(MANIFEST_FILE, os.R_OK), f"Manifest file {MANIFEST_FILE} is not readable"

    def test_manifest_has_content(self):
        content = MANIFEST_FILE.read_text()
        assert len(content) > 0, "Manifest file is empty"


class TestDirectoryStructure:
    """Verify the directory structure has proper depth and file distribution."""

    def test_has_nested_directories(self):
        """Verify there are subdirectories (nested structure)."""
        subdirs = [p for p in DATA_DIR.rglob("*") if p.is_dir()]
        assert len(subdirs) >= 3, (
            f"Expected at least 3 subdirectories for nested structure, found {len(subdirs)}"
        )

    def test_has_sufficient_depth(self):
        """Verify directory structure is at least 3 levels deep."""
        max_depth = 0
        for path in DATA_DIR.rglob("*"):
            if path.is_file() and path.name != ".manifest":
                relative = path.relative_to(DATA_DIR)
                depth = len(relative.parts)
                max_depth = max(max_depth, depth)

        assert max_depth >= 3, (
            f"Expected directory structure at least 3 levels deep, found max depth of {max_depth}"
        )


class TestFileDistribution:
    """Verify the correct distribution of files exists."""

    def get_all_files(self):
        """Get all files except manifest."""
        return [
            p for p in DATA_DIR.rglob("*") 
            if p.is_file() and p.name != ".manifest"
        ]

    def test_has_sufficient_total_files(self):
        """Verify there are approximately 50 files total."""
        files = self.get_all_files()
        assert len(files) >= 40, (
            f"Expected at least 40 files total (around 50), found {len(files)}"
        )

    def test_has_tmp_files(self):
        """Verify .tmp files exist."""
        tmp_files = [p for p in self.get_all_files() if p.suffix == ".tmp"]
        assert len(tmp_files) >= 20, (
            f"Expected at least 20 .tmp files, found {len(tmp_files)}"
        )

    def test_has_non_tmp_files(self):
        """Verify non-.tmp files exist."""
        non_tmp_files = [p for p in self.get_all_files() if p.suffix != ".tmp"]
        assert len(non_tmp_files) >= 15, (
            f"Expected at least 15 non-.tmp files, found {len(non_tmp_files)}"
        )

    def test_has_various_extensions(self):
        """Verify files with different extensions exist (.log, .dat, .txt, etc.)."""
        extensions = set(p.suffix for p in self.get_all_files())
        expected_extensions = {".tmp", ".log", ".txt"}
        found_expected = extensions & expected_extensions
        assert len(found_expected) >= 2, (
            f"Expected at least 2 different file extensions from {expected_extensions}, "
            f"found {extensions}"
        )


class TestTmpFileAges:
    """Verify .tmp files have the correct age distribution."""

    def get_tmp_files(self):
        """Get all .tmp files."""
        return [
            p for p in DATA_DIR.rglob("*.tmp") 
            if p.is_file()
        ]

    def test_has_old_tmp_files(self):
        """Verify there are .tmp files older than 30 days."""
        old_tmp_files = []
        for f in self.get_tmp_files():
            mtime = f.stat().st_mtime
            if mtime < THIRTY_DAYS_AGO:
                old_tmp_files.append(f)

        assert len(old_tmp_files) >= 15, (
            f"Expected at least 15 .tmp files older than 30 days, found {len(old_tmp_files)}"
        )

    def test_has_recent_tmp_files(self):
        """Verify there are .tmp files newer than 30 days (should not be deleted)."""
        recent_tmp_files = []
        for f in self.get_tmp_files():
            mtime = f.stat().st_mtime
            if mtime >= THIRTY_DAYS_AGO:
                recent_tmp_files.append(f)

        assert len(recent_tmp_files) >= 5, (
            f"Expected at least 5 .tmp files newer than 30 days, found {len(recent_tmp_files)}"
        )


class TestNonTmpFileAges:
    """Verify non-.tmp files exist with various ages."""

    def get_non_tmp_files(self):
        """Get all non-.tmp files except manifest."""
        return [
            p for p in DATA_DIR.rglob("*") 
            if p.is_file() and p.suffix != ".tmp" and p.name != ".manifest"
        ]

    def test_has_old_non_tmp_files(self):
        """Verify there are non-.tmp files older than 30 days (should NOT be deleted)."""
        old_non_tmp = []
        for f in self.get_non_tmp_files():
            mtime = f.stat().st_mtime
            if mtime < THIRTY_DAYS_AGO:
                old_non_tmp.append(f)

        assert len(old_non_tmp) >= 5, (
            f"Expected at least 5 non-.tmp files older than 30 days, found {len(old_non_tmp)}. "
            "These files should NOT be deleted by the task."
        )


class TestSpecificDirectories:
    """Verify expected directory structure elements exist."""

    def test_cache_directory_or_similar_exists(self):
        """Verify at least one typical subdirectory exists."""
        subdirs = [p.name for p in DATA_DIR.iterdir() if p.is_dir()]
        assert len(subdirs) >= 1, (
            f"Expected at least one subdirectory in {DATA_DIR}, found none"
        )

    def test_files_scattered_across_subdirs(self):
        """Verify .tmp files are scattered across multiple directories."""
        tmp_file_dirs = set()
        for f in DATA_DIR.rglob("*.tmp"):
            if f.is_file():
                tmp_file_dirs.add(f.parent)

        assert len(tmp_file_dirs) >= 3, (
            f"Expected .tmp files in at least 3 different directories, "
            f"found them in {len(tmp_file_dirs)} directories"
        )
