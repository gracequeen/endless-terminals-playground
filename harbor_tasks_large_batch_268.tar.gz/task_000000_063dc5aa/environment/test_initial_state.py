# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the awk task to extract hostname and mem_gb columns from a CSV.
"""

import os
import subprocess
import pytest


HOME_DIR = "/home/user"
CAPACITY_DIR = "/home/user/capacity"
INPUT_CSV = "/home/user/capacity/vms.csv"
OUTPUT_TSV = "/home/user/capacity/mem_report.tsv"

EXPECTED_CSV_CONTENT = """hostname,vcpus,mem_gb,disk_gb
web-prod-01,4,16,100
web-prod-02,4,16,100
db-primary,8,64,500
db-replica,8,64,500
cache-01,2,32,50
worker-01,16,128,200
worker-02,16,128,200
"""


class TestInitialState:
    """Tests to verify the initial state before the task is performed."""

    def test_capacity_directory_exists(self):
        """Verify that /home/user/capacity/ directory exists."""
        assert os.path.isdir(CAPACITY_DIR), (
            f"Directory {CAPACITY_DIR} does not exist. "
            "The capacity directory must exist before the task can be performed."
        )

    def test_capacity_directory_is_writable(self):
        """Verify that /home/user/capacity/ directory is writable."""
        assert os.access(CAPACITY_DIR, os.W_OK), (
            f"Directory {CAPACITY_DIR} is not writable. "
            "The capacity directory must be writable to create the output file."
        )

    def test_input_csv_exists(self):
        """Verify that the input CSV file exists."""
        assert os.path.isfile(INPUT_CSV), (
            f"Input file {INPUT_CSV} does not exist. "
            "The vms.csv file must exist as the source data for the task."
        )

    def test_input_csv_is_readable(self):
        """Verify that the input CSV file is readable."""
        assert os.access(INPUT_CSV, os.R_OK), (
            f"Input file {INPUT_CSV} is not readable. "
            "The vms.csv file must be readable to extract data from it."
        )

    def test_input_csv_content(self):
        """Verify that the input CSV has the expected content."""
        with open(INPUT_CSV, 'r') as f:
            actual_content = f.read()

        assert actual_content == EXPECTED_CSV_CONTENT, (
            f"Content of {INPUT_CSV} does not match expected content.\n"
            f"Expected:\n{EXPECTED_CSV_CONTENT}\n"
            f"Actual:\n{actual_content}"
        )

    def test_input_csv_has_correct_header(self):
        """Verify that the CSV has the correct header row."""
        with open(INPUT_CSV, 'r') as f:
            header = f.readline().strip()

        expected_header = "hostname,vcpus,mem_gb,disk_gb"
        assert header == expected_header, (
            f"CSV header does not match expected format.\n"
            f"Expected: {expected_header}\n"
            f"Actual: {header}"
        )

    def test_input_csv_has_correct_number_of_rows(self):
        """Verify that the CSV has the expected number of data rows (7 + header)."""
        with open(INPUT_CSV, 'r') as f:
            lines = f.readlines()

        # 1 header + 7 data rows = 8 lines total
        assert len(lines) == 8, (
            f"CSV should have 8 lines (1 header + 7 data rows), "
            f"but has {len(lines)} lines."
        )

    def test_output_tsv_does_not_exist(self):
        """Verify that the output TSV file does not exist yet."""
        assert not os.path.exists(OUTPUT_TSV), (
            f"Output file {OUTPUT_TSV} already exists. "
            "The output file should not exist before the task is performed."
        )

    def test_awk_is_available(self):
        """Verify that awk command is available."""
        result = subprocess.run(
            ["which", "awk"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "awk command is not available. "
            "awk must be installed to perform this task."
        )

    def test_awk_is_executable(self):
        """Verify that awk can be executed."""
        result = subprocess.run(
            ["awk", "--version"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "awk command cannot be executed. "
            "awk must be functional to perform this task."
        )

    def test_sed_is_available(self):
        """Verify that sed command is available."""
        result = subprocess.run(
            ["which", "sed"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "sed command is not available. "
            "sed must be installed as an alternative tool."
        )

    def test_sed_is_executable(self):
        """Verify that sed can be executed."""
        result = subprocess.run(
            ["sed", "--version"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            "sed command cannot be executed. "
            "sed must be functional as an alternative tool."
        )
