# test_final_state.py
"""
Tests to validate the final state of the OS/filesystem after the student
has completed the awk task to extract hostname and mem_gb columns from a CSV.
"""

import os
import subprocess
import pytest


CAPACITY_DIR = "/home/user/capacity"
INPUT_CSV = "/home/user/capacity/vms.csv"
OUTPUT_TSV = "/home/user/capacity/mem_report.tsv"

EXPECTED_CSV_CONTENT = """hostname,vcpus,mem_gb,disk_gb
web-prod-01,4,16,100
web-prod-02,4,16,100
db-primary,8,64,500
db-replica,8,64,500
cache-01,2,32,50
worker-01,16,128,200
worker-02,16,128,200
"""

# Expected TSV content with tabs (represented explicitly)
EXPECTED_TSV_LINES = [
    ("hostname", "mem_gb"),
    ("web-prod-01", "16"),
    ("web-prod-02", "16"),
    ("db-primary", "64"),
    ("db-replica", "64"),
    ("cache-01", "32"),
    ("worker-01", "128"),
    ("worker-02", "128"),
]


class TestFinalState:
    """Tests to verify the final state after the task is performed."""

    def test_output_tsv_exists(self):
        """Verify that the output TSV file exists."""
        assert os.path.isfile(OUTPUT_TSV), (
            f"Output file {OUTPUT_TSV} does not exist. "
            "The mem_report.tsv file must be created by the task."
        )

    def test_output_tsv_is_readable(self):
        """Verify that the output TSV file is readable."""
        assert os.access(OUTPUT_TSV, os.R_OK), (
            f"Output file {OUTPUT_TSV} is not readable."
        )

    def test_output_tsv_has_correct_number_of_lines(self):
        """Verify that the TSV has the expected number of lines (header + 7 data rows)."""
        with open(OUTPUT_TSV, 'r') as f:
            content = f.read()

        # Remove trailing newline for counting non-empty lines
        lines = [line for line in content.split('\n') if line]

        assert len(lines) == 8, (
            f"TSV should have 8 lines (1 header + 7 data rows), "
            f"but has {len(lines)} non-empty lines."
        )

    def test_output_tsv_ends_with_newline(self):
        """Verify that the TSV file ends with a newline."""
        with open(OUTPUT_TSV, 'r') as f:
            content = f.read()

        assert content.endswith('\n'), (
            "Output TSV file must end with a newline character."
        )

    def test_output_tsv_lines_are_tab_separated(self):
        """Verify that each line has exactly one tab character between fields."""
        with open(OUTPUT_TSV, 'r') as f:
            lines = f.read().strip().split('\n')

        for i, line in enumerate(lines):
            tab_count = line.count('\t')
            assert tab_count == 1, (
                f"Line {i + 1} should have exactly 1 tab character, "
                f"but has {tab_count}. Line content: {repr(line)}"
            )

    def test_output_tsv_has_correct_header(self):
        """Verify that the TSV has the correct header row."""
        with open(OUTPUT_TSV, 'r') as f:
            header = f.readline().strip()

        fields = header.split('\t')
        assert len(fields) == 2, (
            f"Header should have 2 fields, but has {len(fields)}. "
            f"Header: {repr(header)}"
        )
        assert fields[0] == "hostname", (
            f"First header field should be 'hostname', but is '{fields[0]}'"
        )
        assert fields[1] == "mem_gb", (
            f"Second header field should be 'mem_gb', but is '{fields[1]}'"
        )

    def test_output_tsv_has_correct_content(self):
        """Verify that the TSV has the correct content for all rows."""
        with open(OUTPUT_TSV, 'r') as f:
            lines = f.read().strip().split('\n')

        assert len(lines) == len(EXPECTED_TSV_LINES), (
            f"Expected {len(EXPECTED_TSV_LINES)} lines, but got {len(lines)}"
        )

        for i, (line, expected) in enumerate(zip(lines, EXPECTED_TSV_LINES)):
            fields = line.split('\t')
            expected_hostname, expected_mem = expected

            assert len(fields) == 2, (
                f"Line {i + 1} should have 2 fields, but has {len(fields)}. "
                f"Line: {repr(line)}"
            )
            assert fields[0] == expected_hostname, (
                f"Line {i + 1}: hostname should be '{expected_hostname}', "
                f"but is '{fields[0]}'"
            )
            assert fields[1] == expected_mem, (
                f"Line {i + 1}: mem_gb should be '{expected_mem}', "
                f"but is '{fields[1]}'"
            )

    def test_input_csv_unchanged(self):
        """Verify that the original CSV file remains unchanged."""
        with open(INPUT_CSV, 'r') as f:
            actual_content = f.read()

        assert actual_content == EXPECTED_CSV_CONTENT, (
            f"Content of {INPUT_CSV} has been modified. "
            "The original CSV file should remain unchanged.\n"
            f"Expected:\n{EXPECTED_CSV_CONTENT}\n"
            f"Actual:\n{actual_content}"
        )

    def test_output_derived_from_csv(self):
        """
        Anti-shortcut test: Verify that output is derived from CSV by checking
        that the hostnames and mem_gb values in the TSV match those in the CSV.
        """
        # Parse the CSV
        with open(INPUT_CSV, 'r') as f:
            csv_lines = f.read().strip().split('\n')

        csv_data = []
        for line in csv_lines[1:]:  # Skip header
            parts = line.split(',')
            csv_data.append((parts[0], parts[2]))  # hostname, mem_gb

        # Parse the TSV
        with open(OUTPUT_TSV, 'r') as f:
            tsv_lines = f.read().strip().split('\n')

        tsv_data = []
        for line in tsv_lines[1:]:  # Skip header
            parts = line.split('\t')
            tsv_data.append((parts[0], parts[1]))

        assert csv_data == tsv_data, (
            "TSV data does not match the corresponding columns from the CSV.\n"
            f"CSV hostname,mem_gb pairs: {csv_data}\n"
            f"TSV hostname,mem_gb pairs: {tsv_data}"
        )

    def test_no_extra_whitespace_in_fields(self):
        """Verify that fields don't have leading/trailing whitespace."""
        with open(OUTPUT_TSV, 'r') as f:
            lines = f.read().strip().split('\n')

        for i, line in enumerate(lines):
            fields = line.split('\t')
            for j, field in enumerate(fields):
                assert field == field.strip(), (
                    f"Line {i + 1}, field {j + 1} has extra whitespace. "
                    f"Field: {repr(field)}"
                )

    def test_no_comma_separators_in_output(self):
        """Verify that the output uses tabs, not commas."""
        with open(OUTPUT_TSV, 'r') as f:
            content = f.read()

        # The output should not have commas as field separators
        # (commas might appear in data but not between hostname and mem_gb)
        lines = content.strip().split('\n')
        for i, line in enumerate(lines):
            # Each line should have exactly 2 fields when split by tab
            # and should not be splittable into 2 fields by comma in the expected way
            if ',' in line and '\t' not in line:
                pytest.fail(
                    f"Line {i + 1} appears to use comma separator instead of tab. "
                    f"Line: {repr(line)}"
                )
