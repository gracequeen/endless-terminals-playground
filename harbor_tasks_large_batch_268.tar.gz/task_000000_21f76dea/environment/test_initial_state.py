# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the task of creating a script to strip YAML frontmatter from markdown files.
"""

import os
import subprocess
import pytest


HOME_DIR = "/home/user"
DOCS_DIR = "/home/user/docs"
SCRIPT_PATH = "/home/user/strip_frontmatter.sh"


class TestDirectoriesExist:
    """Test that required directories exist."""

    def test_home_directory_exists(self):
        """Home directory /home/user must exist."""
        assert os.path.isdir(HOME_DIR), f"Home directory {HOME_DIR} does not exist"

    def test_docs_directory_exists(self):
        """Docs directory /home/user/docs must exist."""
        assert os.path.isdir(DOCS_DIR), f"Docs directory {DOCS_DIR} does not exist"

    def test_home_directory_is_writable(self):
        """Home directory must be writable."""
        assert os.access(HOME_DIR, os.W_OK), f"Home directory {HOME_DIR} is not writable"


class TestMarkdownFilesExist:
    """Test that the required markdown files exist with correct content."""

    def test_intro_md_exists(self):
        """intro.md must exist in /home/user/docs."""
        filepath = os.path.join(DOCS_DIR, "intro.md")
        assert os.path.isfile(filepath), f"File {filepath} does not exist"

    def test_setup_md_exists(self):
        """setup.md must exist in /home/user/docs."""
        filepath = os.path.join(DOCS_DIR, "setup.md")
        assert os.path.isfile(filepath), f"File {filepath} does not exist"

    def test_reference_md_exists(self):
        """reference.md must exist in /home/user/docs."""
        filepath = os.path.join(DOCS_DIR, "reference.md")
        assert os.path.isfile(filepath), f"File {filepath} does not exist"


class TestMarkdownFilesHaveFrontmatter:
    """Test that markdown files contain YAML frontmatter that needs to be stripped."""

    def test_intro_md_has_frontmatter(self):
        """intro.md must contain YAML frontmatter with --- delimiters."""
        filepath = os.path.join(DOCS_DIR, "intro.md")
        with open(filepath, 'r') as f:
            content = f.read()
        assert content.startswith('---'), f"{filepath} does not start with '---' frontmatter delimiter"
        # Check for closing delimiter (should have at least 2 occurrences of ---)
        assert content.count('---') >= 2, f"{filepath} does not have complete frontmatter (missing closing '---')"
        assert 'title: Introduction' in content, f"{filepath} missing expected 'title: Introduction' in frontmatter"
        assert 'author: Jane Doe' in content, f"{filepath} missing expected 'author: Jane Doe' in frontmatter"

    def test_setup_md_has_frontmatter(self):
        """setup.md must contain YAML frontmatter with --- delimiters."""
        filepath = os.path.join(DOCS_DIR, "setup.md")
        with open(filepath, 'r') as f:
            content = f.read()
        assert content.startswith('---'), f"{filepath} does not start with '---' frontmatter delimiter"
        assert content.count('---') >= 2, f"{filepath} does not have complete frontmatter (missing closing '---')"
        assert 'title: Setup Guide' in content, f"{filepath} missing expected 'title: Setup Guide' in frontmatter"
        assert 'tags:' in content, f"{filepath} missing expected 'tags:' in frontmatter"

    def test_reference_md_has_frontmatter(self):
        """reference.md must contain YAML frontmatter with --- delimiters."""
        filepath = os.path.join(DOCS_DIR, "reference.md")
        with open(filepath, 'r') as f:
            content = f.read()
        assert content.startswith('---'), f"{filepath} does not start with '---' frontmatter delimiter"
        assert content.count('---') >= 2, f"{filepath} does not have complete frontmatter (missing closing '---')"
        assert 'title: API Reference' in content, f"{filepath} missing expected 'title: API Reference' in frontmatter"


class TestMarkdownFilesHaveContent:
    """Test that markdown files contain the expected documentation content."""

    def test_intro_md_has_content(self):
        """intro.md must contain the Introduction heading and content."""
        filepath = os.path.join(DOCS_DIR, "intro.md")
        with open(filepath, 'r') as f:
            content = f.read()
        assert '# Introduction' in content, f"{filepath} missing '# Introduction' heading"
        assert 'Welcome to the documentation.' in content, f"{filepath} missing expected content"

    def test_setup_md_has_content(self):
        """setup.md must contain the Setup Guide heading and content."""
        filepath = os.path.join(DOCS_DIR, "setup.md")
        with open(filepath, 'r') as f:
            content = f.read()
        assert '# Setup Guide' in content, f"{filepath} missing '# Setup Guide' heading"
        assert 'Follow these steps to get started.' in content, f"{filepath} missing expected content"
        assert '## Prerequisites' in content, f"{filepath} missing '## Prerequisites' section"
        assert 'Python 3.8+' in content, f"{filepath} missing Python version requirement"

    def test_reference_md_has_content(self):
        """reference.md must contain the API Reference heading and content."""
        filepath = os.path.join(DOCS_DIR, "reference.md")
        with open(filepath, 'r') as f:
            content = f.read()
        assert '# API Reference' in content, f"{filepath} missing '# API Reference' heading"
        assert '## Methods' in content, f"{filepath} missing '## Methods' section"
        assert 'get_data()' in content, f"{filepath} missing 'get_data()' method documentation"


class TestScriptDoesNotExist:
    """Test that the script to be created does not exist yet."""

    def test_strip_frontmatter_script_does_not_exist(self):
        """The strip_frontmatter.sh script should not exist initially."""
        assert not os.path.exists(SCRIPT_PATH), \
            f"Script {SCRIPT_PATH} already exists - it should be created by the student"


class TestRequiredToolsAvailable:
    """Test that required tools (bash, sed, awk, perl) are available."""

    def test_bash_available(self):
        """bash must be available."""
        result = subprocess.run(['which', 'bash'], capture_output=True)
        assert result.returncode == 0, "bash is not available on this system"

    def test_sed_available(self):
        """sed must be available."""
        result = subprocess.run(['which', 'sed'], capture_output=True)
        assert result.returncode == 0, "sed is not available on this system"

    def test_awk_available(self):
        """awk must be available."""
        result = subprocess.run(['which', 'awk'], capture_output=True)
        assert result.returncode == 0, "awk is not available on this system"

    def test_perl_available(self):
        """perl must be available."""
        result = subprocess.run(['which', 'perl'], capture_output=True)
        assert result.returncode == 0, "perl is not available on this system"


class TestOnlyExpectedFilesInDocs:
    """Test that only the expected markdown files are in the docs directory."""

    def test_exactly_three_md_files(self):
        """There should be exactly three .md files in /home/user/docs."""
        md_files = [f for f in os.listdir(DOCS_DIR) if f.endswith('.md')]
        expected_files = {'intro.md', 'setup.md', 'reference.md'}
        assert set(md_files) == expected_files, \
            f"Expected exactly {expected_files} in {DOCS_DIR}, but found {set(md_files)}"
