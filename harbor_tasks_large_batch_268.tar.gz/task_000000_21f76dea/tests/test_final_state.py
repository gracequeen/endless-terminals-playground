# test_final_state.py
"""
Tests to validate the final state of the OS/filesystem after the student
has created a script to strip YAML frontmatter from markdown files and run it.
"""

import os
import subprocess
import stat
import pytest


HOME_DIR = "/home/user"
DOCS_DIR = "/home/user/docs"
SCRIPT_PATH = "/home/user/strip_frontmatter.sh"


class TestScriptExists:
    """Test that the script exists and is executable."""

    def test_script_file_exists(self):
        """The strip_frontmatter.sh script must exist."""
        assert os.path.isfile(SCRIPT_PATH), \
            f"Script {SCRIPT_PATH} does not exist - student needs to create it"

    def test_script_is_executable(self):
        """The strip_frontmatter.sh script must be executable."""
        assert os.path.isfile(SCRIPT_PATH), \
            f"Script {SCRIPT_PATH} does not exist"
        file_stat = os.stat(SCRIPT_PATH)
        is_executable = bool(file_stat.st_mode & (stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH))
        assert is_executable, \
            f"Script {SCRIPT_PATH} exists but is not executable (chmod +x needed)"

    def test_script_runs_successfully(self):
        """Running the script with bash should exit with code 0."""
        result = subprocess.run(
            ['bash', SCRIPT_PATH],
            capture_output=True,
            text=True,
            cwd=HOME_DIR
        )
        assert result.returncode == 0, \
            f"Script {SCRIPT_PATH} failed with exit code {result.returncode}. " \
            f"Stderr: {result.stderr}"


class TestMarkdownFilesStillExist:
    """Test that all three markdown files still exist after script execution."""

    def test_intro_md_exists(self):
        """intro.md must still exist in /home/user/docs."""
        filepath = os.path.join(DOCS_DIR, "intro.md")
        assert os.path.isfile(filepath), \
            f"File {filepath} no longer exists after running the script"

    def test_setup_md_exists(self):
        """setup.md must still exist in /home/user/docs."""
        filepath = os.path.join(DOCS_DIR, "setup.md")
        assert os.path.isfile(filepath), \
            f"File {filepath} no longer exists after running the script"

    def test_reference_md_exists(self):
        """reference.md must still exist in /home/user/docs."""
        filepath = os.path.join(DOCS_DIR, "reference.md")
        assert os.path.isfile(filepath), \
            f"File {filepath} no longer exists after running the script"


class TestFrontmatterRemoved:
    """Test that YAML frontmatter has been completely removed from all files."""

    def test_no_triple_dash_in_intro(self):
        """intro.md should not contain '---' after frontmatter removal."""
        filepath = os.path.join(DOCS_DIR, "intro.md")
        with open(filepath, 'r') as f:
            content = f.read()
        assert '---' not in content, \
            f"{filepath} still contains '---' - frontmatter was not fully removed"

    def test_no_triple_dash_in_setup(self):
        """setup.md should not contain '---' after frontmatter removal."""
        filepath = os.path.join(DOCS_DIR, "setup.md")
        with open(filepath, 'r') as f:
            content = f.read()
        assert '---' not in content, \
            f"{filepath} still contains '---' - frontmatter was not fully removed"

    def test_no_triple_dash_in_reference(self):
        """reference.md should not contain '---' after frontmatter removal."""
        filepath = os.path.join(DOCS_DIR, "reference.md")
        with open(filepath, 'r') as f:
            content = f.read()
        assert '---' not in content, \
            f"{filepath} still contains '---' - frontmatter was not fully removed"

    def test_grep_finds_no_frontmatter_delimiters(self):
        """grep for '^---' should return no matches in any .md file."""
        result = subprocess.run(
            ['grep', '-l', '^---'] + [
                os.path.join(DOCS_DIR, 'intro.md'),
                os.path.join(DOCS_DIR, 'setup.md'),
                os.path.join(DOCS_DIR, 'reference.md')
            ],
            capture_output=True,
            text=True
        )
        # grep returns 1 when no matches found, which is what we want
        assert result.returncode != 0, \
            f"Files still contain frontmatter delimiters: {result.stdout.strip()}"


class TestYamlMetadataRemoved:
    """Test that YAML metadata fields have been removed."""

    def test_no_title_field_in_files(self):
        """No file should contain 'title:' YAML field."""
        for filename in ['intro.md', 'setup.md', 'reference.md']:
            filepath = os.path.join(DOCS_DIR, filename)
            with open(filepath, 'r') as f:
                content = f.read()
            assert 'title:' not in content, \
                f"{filepath} still contains 'title:' - frontmatter not fully removed"

    def test_no_author_field_in_intro(self):
        """intro.md should not contain 'author:' YAML field."""
        filepath = os.path.join(DOCS_DIR, "intro.md")
        with open(filepath, 'r') as f:
            content = f.read()
        assert 'author:' not in content, \
            f"{filepath} still contains 'author:' - frontmatter not fully removed"

    def test_no_date_field_in_intro(self):
        """intro.md should not contain 'date:' YAML field."""
        filepath = os.path.join(DOCS_DIR, "intro.md")
        with open(filepath, 'r') as f:
            content = f.read()
        assert 'date:' not in content, \
            f"{filepath} still contains 'date:' - frontmatter not fully removed"

    def test_no_tags_field_in_setup(self):
        """setup.md should not contain 'tags:' YAML field."""
        filepath = os.path.join(DOCS_DIR, "setup.md")
        with open(filepath, 'r') as f:
            content = f.read()
        assert 'tags:' not in content, \
            f"{filepath} still contains 'tags:' - frontmatter not fully removed"


class TestDocumentationContentPreserved:
    """Test that the actual documentation content is still intact."""

    def test_intro_heading_preserved(self):
        """intro.md must still contain '# Introduction' heading."""
        filepath = os.path.join(DOCS_DIR, "intro.md")
        with open(filepath, 'r') as f:
            content = f.read()
        assert '# Introduction' in content, \
            f"{filepath} is missing '# Introduction' heading - content was incorrectly modified"

    def test_intro_content_preserved(self):
        """intro.md must still contain the welcome message."""
        filepath = os.path.join(DOCS_DIR, "intro.md")
        with open(filepath, 'r') as f:
            content = f.read()
        assert 'Welcome to the documentation.' in content, \
            f"{filepath} is missing expected content - documentation was incorrectly modified"

    def test_setup_heading_preserved(self):
        """setup.md must still contain '# Setup Guide' heading."""
        filepath = os.path.join(DOCS_DIR, "setup.md")
        with open(filepath, 'r') as f:
            content = f.read()
        assert '# Setup Guide' in content, \
            f"{filepath} is missing '# Setup Guide' heading - content was incorrectly modified"

    def test_setup_content_preserved(self):
        """setup.md must still contain all expected content."""
        filepath = os.path.join(DOCS_DIR, "setup.md")
        with open(filepath, 'r') as f:
            content = f.read()
        assert 'Follow these steps to get started.' in content, \
            f"{filepath} is missing expected content"
        assert '## Prerequisites' in content, \
            f"{filepath} is missing '## Prerequisites' section"
        assert 'Python 3.8+' in content, \
            f"{filepath} is missing Python version requirement"

    def test_reference_heading_preserved(self):
        """reference.md must still contain '# API Reference' heading."""
        filepath = os.path.join(DOCS_DIR, "reference.md")
        with open(filepath, 'r') as f:
            content = f.read()
        assert '# API Reference' in content, \
            f"{filepath} is missing '# API Reference' heading - content was incorrectly modified"

    def test_reference_content_preserved(self):
        """reference.md must still contain all expected content."""
        filepath = os.path.join(DOCS_DIR, "reference.md")
        with open(filepath, 'r') as f:
            content = f.read()
        assert '## Methods' in content, \
            f"{filepath} is missing '## Methods' section"
        assert 'get_data()' in content, \
            f"{filepath} is missing 'get_data()' method documentation"
        assert 'Returns the data.' in content, \
            f"{filepath} is missing method description"


class TestFileStructure:
    """Test the structure of the processed files."""

    def test_intro_starts_correctly(self):
        """intro.md should start with blank line(s) followed by '# Introduction'."""
        filepath = os.path.join(DOCS_DIR, "intro.md")
        with open(filepath, 'r') as f:
            content = f.read()
        # Content should have the heading somewhere near the start (after potential blank lines)
        lines = content.split('\n')
        # Find first non-empty line
        first_content_line = None
        for line in lines:
            if line.strip():
                first_content_line = line
                break
        assert first_content_line == '# Introduction', \
            f"{filepath} first non-empty line should be '# Introduction', got: '{first_content_line}'"

    def test_setup_starts_correctly(self):
        """setup.md should start with blank line(s) followed by '# Setup Guide'."""
        filepath = os.path.join(DOCS_DIR, "setup.md")
        with open(filepath, 'r') as f:
            content = f.read()
        lines = content.split('\n')
        first_content_line = None
        for line in lines:
            if line.strip():
                first_content_line = line
                break
        assert first_content_line == '# Setup Guide', \
            f"{filepath} first non-empty line should be '# Setup Guide', got: '{first_content_line}'"

    def test_reference_starts_correctly(self):
        """reference.md should start with blank line(s) followed by '# API Reference'."""
        filepath = os.path.join(DOCS_DIR, "reference.md")
        with open(filepath, 'r') as f:
            content = f.read()
        lines = content.split('\n')
        first_content_line = None
        for line in lines:
            if line.strip():
                first_content_line = line
                break
        assert first_content_line == '# API Reference', \
            f"{filepath} first non-empty line should be '# API Reference', got: '{first_content_line}'"
