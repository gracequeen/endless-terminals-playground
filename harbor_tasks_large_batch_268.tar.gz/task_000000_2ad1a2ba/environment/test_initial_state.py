# test_initial_state.py
"""
Tests to validate the initial state of the webhook ingestion pipeline
before the student performs any fixes.
"""

import json
import os
import re
import subprocess
import pytest

BASE_DIR = "/home/user/webhook-ingest"
INCOMING_DIR = os.path.join(BASE_DIR, "data/incoming")
NORMALIZED_DIR = os.path.join(BASE_DIR, "data/normalized")
NORMALIZE_SCRIPT = os.path.join(BASE_DIR, "normalize.py")
VALIDATE_SCRIPT = os.path.join(BASE_DIR, "validate.sh")
SCHEMA_FILE = os.path.join(BASE_DIR, "schema.json")


class TestDirectoryStructure:
    """Test that the required directory structure exists."""

    def test_base_directory_exists(self):
        assert os.path.isdir(BASE_DIR), f"Base directory {BASE_DIR} does not exist"

    def test_incoming_directory_exists(self):
        assert os.path.isdir(INCOMING_DIR), f"Incoming directory {INCOMING_DIR} does not exist"

    def test_normalized_directory_exists(self):
        assert os.path.isdir(NORMALIZED_DIR), f"Normalized directory {NORMALIZED_DIR} does not exist"


class TestRequiredFiles:
    """Test that all required files exist."""

    def test_normalize_script_exists(self):
        assert os.path.isfile(NORMALIZE_SCRIPT), f"normalize.py script not found at {NORMALIZE_SCRIPT}"

    def test_validate_script_exists(self):
        assert os.path.isfile(VALIDATE_SCRIPT), f"validate.sh script not found at {VALIDATE_SCRIPT}"

    def test_schema_file_exists(self):
        assert os.path.isfile(SCHEMA_FILE), f"schema.json not found at {SCHEMA_FILE}"

    def test_normalize_script_is_readable(self):
        assert os.access(NORMALIZE_SCRIPT, os.R_OK), f"normalize.py is not readable"

    def test_validate_script_is_executable(self):
        assert os.access(VALIDATE_SCRIPT, os.X_OK), f"validate.sh is not executable"


class TestIncomingPayloadFiles:
    """Test that all 8 incoming JSON payload files exist and have correct structure."""

    EXPECTED_FILES = [f"webhook_{i:03d}.json" for i in range(1, 9)]

    def test_all_incoming_files_exist(self):
        """Verify all 8 webhook JSON files exist in incoming directory."""
        existing_files = os.listdir(INCOMING_DIR)
        for filename in self.EXPECTED_FILES:
            assert filename in existing_files, f"Missing incoming file: {filename}"

    def test_exactly_eight_json_files(self):
        """Verify there are exactly 8 JSON files in incoming directory."""
        json_files = [f for f in os.listdir(INCOMING_DIR) if f.endswith('.json')]
        assert len(json_files) == 8, f"Expected 8 JSON files in incoming, found {len(json_files)}"

    @pytest.mark.parametrize("filename", [f"webhook_{i:03d}.json" for i in range(1, 9)])
    def test_incoming_file_is_valid_json(self, filename):
        """Verify each incoming file is valid JSON."""
        filepath = os.path.join(INCOMING_DIR, filename)
        with open(filepath, 'r') as f:
            try:
                data = json.load(f)
            except json.JSONDecodeError as e:
                pytest.fail(f"File {filename} is not valid JSON: {e}")

    @pytest.mark.parametrize("filename", [f"webhook_{i:03d}.json" for i in range(1, 9)])
    def test_incoming_file_has_required_fields(self, filename):
        """Verify each incoming file has the required structure."""
        filepath = os.path.join(INCOMING_DIR, filename)
        with open(filepath, 'r') as f:
            data = json.load(f)

        required_fields = ["customer_id", "event", "timestamp", "data"]
        for field in required_fields:
            assert field in data, f"File {filename} missing required field: {field}"

    @pytest.mark.parametrize("filename", [f"webhook_{i:03d}.json" for i in range(1, 9)])
    def test_incoming_customer_id_format(self, filename):
        """Verify customer_id has the basic CUS-XXXXX-YY pattern (may have case issues)."""
        filepath = os.path.join(INCOMING_DIR, filename)
        with open(filepath, 'r') as f:
            data = json.load(f)

        customer_id = data.get("customer_id", "")
        # Check basic pattern (case-insensitive)
        pattern = re.compile(r'^CUS-[0-9]{5}-[A-Za-z]{2}$')
        assert pattern.match(customer_id), f"File {filename} has malformed customer_id: {customer_id}"


class TestSchemaFile:
    """Test that schema.json is valid and contains the expected pattern."""

    def test_schema_is_valid_json(self):
        """Verify schema.json is valid JSON."""
        with open(SCHEMA_FILE, 'r') as f:
            try:
                schema = json.load(f)
            except json.JSONDecodeError as e:
                pytest.fail(f"schema.json is not valid JSON: {e}")

    def test_schema_has_customer_id_pattern(self):
        """Verify schema defines the customer_id pattern."""
        with open(SCHEMA_FILE, 'r') as f:
            schema = json.load(f)

        # The schema should contain the pattern for customer_id
        schema_str = json.dumps(schema)
        assert "CUS-" in schema_str, "Schema should reference CUS- pattern for customer_id"
        assert "[A-Z]" in schema_str, "Schema should require uppercase letters in customer_id suffix"


class TestNormalizeScript:
    """Test that normalize.py has the expected bug characteristics."""

    def test_normalize_script_contains_lower_call(self):
        """Verify normalize.py contains a .lower() call that causes the bug."""
        with open(NORMALIZE_SCRIPT, 'r') as f:
            content = f.read()

        assert ".lower()" in content, "normalize.py should contain .lower() call (the bug)"

    def test_normalize_script_contains_regex_sub(self):
        """Verify normalize.py uses re.sub for sanitization."""
        with open(NORMALIZE_SCRIPT, 'r') as f:
            content = f.read()

        assert "re.sub" in content, "normalize.py should contain re.sub for sanitization"

    def test_normalize_script_is_python(self):
        """Verify normalize.py has valid Python syntax."""
        result = subprocess.run(
            ["python3", "-m", "py_compile", NORMALIZE_SCRIPT],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, f"normalize.py has syntax errors: {result.stderr}"


class TestValidateScript:
    """Test that validate.sh is properly configured."""

    def test_validate_script_references_schema(self):
        """Verify validate.sh references the schema file."""
        with open(VALIDATE_SCRIPT, 'r') as f:
            content = f.read()

        assert "schema" in content.lower(), "validate.sh should reference schema for validation"

    def test_validate_script_is_bash(self):
        """Verify validate.sh has bash shebang or is executable as bash."""
        with open(VALIDATE_SCRIPT, 'r') as f:
            first_line = f.readline()

        # Should have shebang or be a valid bash script
        result = subprocess.run(
            ["bash", "-n", VALIDATE_SCRIPT],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, f"validate.sh has bash syntax errors: {result.stderr}"


class TestSystemRequirements:
    """Test that required system tools are available."""

    def test_python3_available(self):
        """Verify Python 3 is installed."""
        result = subprocess.run(["python3", "--version"], capture_output=True, text=True)
        assert result.returncode == 0, "Python 3 is not available"
        assert "Python 3" in result.stdout, f"Unexpected Python version: {result.stdout}"

    def test_bash_available(self):
        """Verify bash is installed."""
        result = subprocess.run(["bash", "--version"], capture_output=True, text=True)
        assert result.returncode == 0, "bash is not available"

    def test_jq_available(self):
        """Verify jq is installed."""
        result = subprocess.run(["jq", "--version"], capture_output=True, text=True)
        assert result.returncode == 0, "jq is not available"

    def test_json_module_available(self):
        """Verify Python json module is available."""
        result = subprocess.run(
            ["python3", "-c", "import json"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "Python json module not available"

    def test_re_module_available(self):
        """Verify Python re module is available."""
        result = subprocess.run(
            ["python3", "-c", "import re"],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, "Python re module not available"


class TestDirectoryPermissions:
    """Test that directories have appropriate permissions."""

    def test_base_directory_writable(self):
        """Verify base directory is writable."""
        assert os.access(BASE_DIR, os.W_OK), f"{BASE_DIR} is not writable"

    def test_normalized_directory_writable(self):
        """Verify normalized directory is writable."""
        assert os.access(NORMALIZED_DIR, os.W_OK), f"{NORMALIZED_DIR} is not writable"

    def test_incoming_directory_readable(self):
        """Verify incoming directory is readable."""
        assert os.access(INCOMING_DIR, os.R_OK), f"{INCOMING_DIR} is not readable"


class TestIncomingDataCharacteristics:
    """Test specific characteristics of incoming data mentioned in the task."""

    def test_some_files_have_lowercase_suffix(self):
        """Verify some incoming files have lowercase suffixes (the red herring)."""
        lowercase_count = 0
        for i in range(1, 9):
            filepath = os.path.join(INCOMING_DIR, f"webhook_{i:03d}.json")
            with open(filepath, 'r') as f:
                data = json.load(f)
            customer_id = data.get("customer_id", "")
            suffix = customer_id.split("-")[-1] if "-" in customer_id else ""
            if suffix and suffix.islower():
                lowercase_count += 1

        assert lowercase_count == 4, f"Expected 4 files with lowercase suffixes, found {lowercase_count}"

    def test_some_files_have_uppercase_suffix(self):
        """Verify some incoming files have uppercase suffixes (valid input)."""
        uppercase_count = 0
        for i in range(1, 9):
            filepath = os.path.join(INCOMING_DIR, f"webhook_{i:03d}.json")
            with open(filepath, 'r') as f:
                data = json.load(f)
            customer_id = data.get("customer_id", "")
            suffix = customer_id.split("-")[-1] if "-" in customer_id else ""
            if suffix and suffix.isupper():
                uppercase_count += 1

        assert uppercase_count == 4, f"Expected 4 files with uppercase suffixes, found {uppercase_count}"
