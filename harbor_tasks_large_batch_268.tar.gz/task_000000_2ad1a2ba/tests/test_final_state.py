# test_final_state.py
"""
Tests to validate the final state of the webhook ingestion pipeline
after the student has completed the fix.
"""

import json
import os
import re
import subprocess
import pytest

BASE_DIR = "/home/user/webhook-ingest"
INCOMING_DIR = os.path.join(BASE_DIR, "data/incoming")
NORMALIZED_DIR = os.path.join(BASE_DIR, "data/normalized")
NORMALIZE_SCRIPT = os.path.join(BASE_DIR, "normalize.py")
VALIDATE_SCRIPT = os.path.join(BASE_DIR, "validate.sh")
SCHEMA_FILE = os.path.join(BASE_DIR, "schema.json")

CUSTOMER_ID_PATTERN = re.compile(r'^CUS-[0-9]{5}-[A-Z]{2}$')


class TestNormalizeScriptExecution:
    """Test that normalize.py runs successfully."""

    def test_normalize_script_exits_zero(self):
        """Verify normalize.py exits with code 0."""
        result = subprocess.run(
            ["python3", NORMALIZE_SCRIPT],
            capture_output=True,
            text=True,
            cwd=BASE_DIR
        )
        assert result.returncode == 0, (
            f"normalize.py failed with exit code {result.returncode}.\n"
            f"stdout: {result.stdout}\n"
            f"stderr: {result.stderr}"
        )


class TestValidateScriptExecution:
    """Test that validate.sh runs successfully after normalization."""

    def test_validate_script_exits_zero(self):
        """Verify validate.sh exits with code 0 (all files pass validation)."""
        # First run normalize to ensure normalized files exist
        subprocess.run(
            ["python3", NORMALIZE_SCRIPT],
            capture_output=True,
            cwd=BASE_DIR
        )

        result = subprocess.run(
            ["bash", VALIDATE_SCRIPT],
            capture_output=True,
            text=True,
            cwd=BASE_DIR
        )
        assert result.returncode == 0, (
            f"validate.sh failed with exit code {result.returncode}.\n"
            f"stdout: {result.stdout}\n"
            f"stderr: {result.stderr}\n"
            "This means some normalized files failed schema validation."
        )


class TestNormalizedFilesExist:
    """Test that all 8 normalized files exist."""

    def test_normalized_directory_has_eight_files(self):
        """Verify exactly 8 JSON files exist in normalized directory."""
        # Run normalize first
        subprocess.run(
            ["python3", NORMALIZE_SCRIPT],
            capture_output=True,
            cwd=BASE_DIR
        )

        json_files = [f for f in os.listdir(NORMALIZED_DIR) if f.endswith('.json')]
        assert len(json_files) == 8, (
            f"Expected 8 JSON files in normalized directory, found {len(json_files)}.\n"
            f"Files present: {json_files}"
        )

    @pytest.mark.parametrize("file_num", range(1, 9))
    def test_normalized_file_exists(self, file_num):
        """Verify each expected normalized file exists."""
        # Run normalize first
        subprocess.run(
            ["python3", NORMALIZE_SCRIPT],
            capture_output=True,
            cwd=BASE_DIR
        )

        # Check for files with common naming patterns
        possible_names = [
            f"webhook_{file_num:03d}.json",
            f"webhook_{file_num}.json",
            f"normalized_webhook_{file_num:03d}.json",
        ]

        existing_files = os.listdir(NORMALIZED_DIR)
        found = any(name in existing_files for name in possible_names)

        # If specific naming doesn't work, just check we have 8 files total
        if not found:
            json_files = [f for f in existing_files if f.endswith('.json')]
            assert len(json_files) >= file_num, (
                f"Expected at least {file_num} normalized files, found {len(json_files)}"
            )


class TestCustomerIdFormat:
    """Test that all customer_ids in normalized files match the required pattern."""

    def test_all_customer_ids_valid_format(self):
        """Verify all 8 normalized files have valid customer_id format."""
        # Run normalize first
        subprocess.run(
            ["python3", NORMALIZE_SCRIPT],
            capture_output=True,
            cwd=BASE_DIR
        )

        json_files = [f for f in os.listdir(NORMALIZED_DIR) if f.endswith('.json')]
        assert len(json_files) == 8, f"Expected 8 files, found {len(json_files)}"

        invalid_files = []
        for filename in json_files:
            filepath = os.path.join(NORMALIZED_DIR, filename)
            with open(filepath, 'r') as f:
                data = json.load(f)

            customer_id = data.get("customer_id", "")
            if not CUSTOMER_ID_PATTERN.match(customer_id):
                invalid_files.append((filename, customer_id))

        assert not invalid_files, (
            f"The following files have invalid customer_id format:\n" +
            "\n".join(f"  {fname}: '{cid}' (should match ^CUS-[0-9]{{5}}-[A-Z]{{2}}$)" 
                     for fname, cid in invalid_files)
        )

    @pytest.mark.parametrize("file_idx", range(8))
    def test_individual_customer_id_valid(self, file_idx):
        """Verify each normalized file has a valid customer_id."""
        # Run normalize first
        subprocess.run(
            ["python3", NORMALIZE_SCRIPT],
            capture_output=True,
            cwd=BASE_DIR
        )

        json_files = sorted([f for f in os.listdir(NORMALIZED_DIR) if f.endswith('.json')])
        if file_idx >= len(json_files):
            pytest.skip(f"Only {len(json_files)} files found")

        filename = json_files[file_idx]
        filepath = os.path.join(NORMALIZED_DIR, filename)

        with open(filepath, 'r') as f:
            data = json.load(f)

        customer_id = data.get("customer_id", "")
        assert CUSTOMER_ID_PATTERN.match(customer_id), (
            f"File {filename} has invalid customer_id: '{customer_id}'\n"
            f"Expected format: CUS-XXXXX-YY where YY is two UPPERCASE letters"
        )


class TestNormalizedFileStructure:
    """Test that normalized files preserve required fields."""

    def test_all_required_fields_preserved(self):
        """Verify all normalized files have customer_id, event, timestamp, and data fields."""
        # Run normalize first
        subprocess.run(
            ["python3", NORMALIZE_SCRIPT],
            capture_output=True,
            cwd=BASE_DIR
        )

        required_fields = ["customer_id", "event", "timestamp", "data"]
        json_files = [f for f in os.listdir(NORMALIZED_DIR) if f.endswith('.json')]

        missing_fields = []
        for filename in json_files:
            filepath = os.path.join(NORMALIZED_DIR, filename)
            with open(filepath, 'r') as f:
                data = json.load(f)

            for field in required_fields:
                if field not in data:
                    missing_fields.append((filename, field))

        assert not missing_fields, (
            f"The following files are missing required fields:\n" +
            "\n".join(f"  {fname}: missing '{field}'" for fname, field in missing_fields)
        )


class TestOriginalFilesUnchanged:
    """Test that original incoming files are not modified."""

    def test_incoming_files_still_exist(self):
        """Verify all 8 incoming files still exist."""
        json_files = [f for f in os.listdir(INCOMING_DIR) if f.endswith('.json')]
        assert len(json_files) == 8, (
            f"Expected 8 files in incoming directory, found {len(json_files)}.\n"
            "Original files should not be deleted."
        )

    def test_incoming_files_still_have_original_structure(self):
        """Verify incoming files still have the expected JSON structure."""
        for i in range(1, 9):
            filepath = os.path.join(INCOMING_DIR, f"webhook_{i:03d}.json")
            assert os.path.isfile(filepath), f"Original file {filepath} is missing"

            with open(filepath, 'r') as f:
                data = json.load(f)

            assert "customer_id" in data, f"Original file webhook_{i:03d}.json missing customer_id"


class TestSchemaUnchanged:
    """Test that schema.json was not modified."""

    def test_schema_still_requires_uppercase(self):
        """Verify schema.json still requires uppercase letters in customer_id suffix."""
        with open(SCHEMA_FILE, 'r') as f:
            schema = json.load(f)

        schema_str = json.dumps(schema)
        assert "[A-Z]" in schema_str, (
            "schema.json appears to have been modified to accept lowercase.\n"
            "The schema should require uppercase letters [A-Z] in customer_id suffix."
        )


class TestValidateScriptUnchanged:
    """Test that validate.sh was not modified to skip validation."""

    def test_validate_script_still_validates(self):
        """Verify validate.sh still performs actual validation."""
        with open(VALIDATE_SCRIPT, 'r') as f:
            content = f.read()

        # Should still reference schema or jsonschema
        assert "schema" in content.lower() or "valid" in content.lower(), (
            "validate.sh appears to have been modified to skip validation"
        )

        # Should not just exit 0 unconditionally
        lines = [l.strip() for l in content.split('\n') if l.strip() and not l.strip().startswith('#')]
        if len(lines) <= 2 and any('exit 0' in l for l in lines):
            pytest.fail("validate.sh appears to have been gutted to just 'exit 0'")


class TestEndToEndPipeline:
    """Test the complete pipeline end-to-end."""

    def test_full_pipeline_succeeds(self):
        """Run normalize.py then validate.sh and verify both succeed."""
        # Run normalize
        norm_result = subprocess.run(
            ["python3", NORMALIZE_SCRIPT],
            capture_output=True,
            text=True,
            cwd=BASE_DIR
        )
        assert norm_result.returncode == 0, (
            f"normalize.py failed: {norm_result.stderr}"
        )

        # Run validate
        val_result = subprocess.run(
            ["bash", VALIDATE_SCRIPT],
            capture_output=True,
            text=True,
            cwd=BASE_DIR
        )
        assert val_result.returncode == 0, (
            f"validate.sh failed after normalization: {val_result.stderr}\n{val_result.stdout}"
        )

    def test_grep_check_all_valid_customer_ids(self):
        """Use grep to verify all normalized files have exactly one valid customer_id."""
        # Run normalize first
        subprocess.run(
            ["python3", NORMALIZE_SCRIPT],
            capture_output=True,
            cwd=BASE_DIR
        )

        # Check each file has a valid customer_id
        json_files = [f for f in os.listdir(NORMALIZED_DIR) if f.endswith('.json')]

        for filename in json_files:
            filepath = os.path.join(NORMALIZED_DIR, filename)
            with open(filepath, 'r') as f:
                content = f.read()

            # Count matches of valid customer_id pattern
            matches = re.findall(r'"customer_id"\s*:\s*"CUS-[0-9]{5}-[A-Z]{2}"', content)
            assert len(matches) == 1, (
                f"File {filename} should have exactly one valid customer_id.\n"
                f"Found {len(matches)} matches. Content: {content[:200]}..."
            )


class TestLowercaseSuffixesFixed:
    """Test that files with originally lowercase suffixes are now uppercase."""

    def test_no_lowercase_suffixes_in_normalized(self):
        """Verify no normalized files have lowercase letters in customer_id suffix."""
        # Run normalize first
        subprocess.run(
            ["python3", NORMALIZE_SCRIPT],
            capture_output=True,
            cwd=BASE_DIR
        )

        lowercase_found = []
        json_files = [f for f in os.listdir(NORMALIZED_DIR) if f.endswith('.json')]

        for filename in json_files:
            filepath = os.path.join(NORMALIZED_DIR, filename)
            with open(filepath, 'r') as f:
                data = json.load(f)

            customer_id = data.get("customer_id", "")
            if customer_id:
                # Extract the suffix (last part after final hyphen)
                parts = customer_id.split("-")
                if len(parts) >= 3:
                    suffix = parts[-1]
                    if any(c.islower() for c in suffix):
                        lowercase_found.append((filename, customer_id))

        assert not lowercase_found, (
            f"The following files still have lowercase in customer_id suffix:\n" +
            "\n".join(f"  {fname}: '{cid}'" for fname, cid in lowercase_found) +
            "\nThe normalization should uppercase the suffix."
        )
