I'm testing our backup verification script at /home/user/backup-verify/check.py — it's supposed to walk a directory tree, compute checksums, and compare against a manifest to catch corruption. Problem is it keeps missing files that I *know* are bad. I seeded /home/user/backup-verify/testdata with some intentionally corrupted files and a matching manifest, ran the script, and it reports everything's fine. Zero mismatches. But there are definitely at least 3 files in there with wrong checksums — I corrupted them myself.

    Script exits 0, prints "All files verified successfully", and I'm sitting here looking at files that absolutely don't match their manifest entries. Feels like maybe it's not actually reading some of them? Or the comparison logic is off? I've stared at the code for an hour and I'm not seeing it.

    Need this actually catching corruption before I trust it on real backups.
