# test_initial_state.py
"""
Tests to validate the initial state before the student fixes the backup verification script.
Verifies that the buggy script, test data, and corrupted files are all in place.
"""

import os
import json
import hashlib
import subprocess
import pytest


BASE_DIR = "/home/user/backup-verify"
SCRIPT_PATH = os.path.join(BASE_DIR, "check.py")
TESTDATA_DIR = os.path.join(BASE_DIR, "testdata")
MANIFEST_PATH = os.path.join(TESTDATA_DIR, "manifest.json")

# The three intentionally corrupted files
CORRUPTED_FILES = [
    "testdata/archives/2024/jan/backup-001.tar.gz",
    "testdata/logs/system.log",
    "testdata/db/snapshots/users.db",
]


class TestDirectoryStructure:
    """Test that the required directories exist."""

    def test_backup_verify_dir_exists(self):
        assert os.path.isdir(BASE_DIR), f"Directory {BASE_DIR} does not exist"

    def test_testdata_dir_exists(self):
        assert os.path.isdir(TESTDATA_DIR), f"Directory {TESTDATA_DIR} does not exist"

    def test_script_exists(self):
        assert os.path.isfile(SCRIPT_PATH), f"Script {SCRIPT_PATH} does not exist"

    def test_manifest_exists(self):
        assert os.path.isfile(MANIFEST_PATH), f"Manifest {MANIFEST_PATH} does not exist"


class TestScriptContent:
    """Test that the script has the expected buggy characteristics."""

    def test_script_is_python(self):
        with open(SCRIPT_PATH, 'r') as f:
            content = f.read()
        # Should be a Python script
        assert 'import' in content or 'def ' in content, "Script doesn't appear to be Python code"

    def test_script_uses_hashlib(self):
        with open(SCRIPT_PATH, 'r') as f:
            content = f.read()
        assert 'hashlib' in content, "Script should use hashlib for checksums"

    def test_script_uses_sha256(self):
        with open(SCRIPT_PATH, 'r') as f:
            content = f.read()
        assert 'sha256' in content.lower(), "Script should use SHA256 for checksums"

    def test_script_uses_os_walk(self):
        with open(SCRIPT_PATH, 'r') as f:
            content = f.read()
        assert 'os.walk' in content, "Script should use os.walk() to traverse directories"


class TestManifestStructure:
    """Test that the manifest has the expected structure."""

    def test_manifest_is_valid_json(self):
        with open(MANIFEST_PATH, 'r') as f:
            try:
                manifest = json.load(f)
            except json.JSONDecodeError as e:
                pytest.fail(f"Manifest is not valid JSON: {e}")
        assert isinstance(manifest, dict), "Manifest should be a dictionary"

    def test_manifest_has_entries(self):
        with open(MANIFEST_PATH, 'r') as f:
            manifest = json.load(f)
        assert len(manifest) >= 40, f"Manifest should have ~40 entries, found {len(manifest)}"

    def test_manifest_values_are_hex_hashes(self):
        with open(MANIFEST_PATH, 'r') as f:
            manifest = json.load(f)
        for key, value in manifest.items():
            assert isinstance(value, str), f"Manifest value for {key} should be string"
            assert len(value) == 64, f"SHA256 hex should be 64 chars, got {len(value)} for {key}"
            try:
                int(value, 16)
            except ValueError:
                pytest.fail(f"Manifest value for {key} is not valid hex: {value}")


class TestCorruptedFilesExist:
    """Test that the corrupted files exist in the testdata directory."""

    @pytest.mark.parametrize("rel_path", CORRUPTED_FILES)
    def test_corrupted_file_exists(self, rel_path):
        # rel_path starts with "testdata/", so we need to join with BASE_DIR
        full_path = os.path.join(BASE_DIR, rel_path)
        assert os.path.isfile(full_path), f"Corrupted file {full_path} does not exist"


class TestCorruptedFilesInManifest:
    """Test that the corrupted files have entries in the manifest."""

    def test_corrupted_files_have_manifest_entries(self):
        with open(MANIFEST_PATH, 'r') as f:
            manifest = json.load(f)

        # The manifest keys might be relative to testdata/ or include testdata/
        # We need to check for various possible key formats
        for rel_path in CORRUPTED_FILES:
            # Try different key formats
            possible_keys = [
                rel_path,  # testdata/archives/2024/jan/backup-001.tar.gz
                rel_path.replace("testdata/", ""),  # archives/2024/jan/backup-001.tar.gz
                "/" + rel_path,  # /testdata/archives/2024/jan/backup-001.tar.gz
                "/" + rel_path.replace("testdata/", ""),  # /archives/2024/jan/backup-001.tar.gz
            ]

            found = any(key in manifest for key in possible_keys)
            assert found, f"Corrupted file {rel_path} should have an entry in manifest (tried keys: {possible_keys})"


class TestCorruptedFilesActuallyCorrupted:
    """Test that the corrupted files don't match their manifest checksums."""

    def test_corrupted_files_have_wrong_checksums(self):
        with open(MANIFEST_PATH, 'r') as f:
            manifest = json.load(f)

        mismatches_found = 0

        for rel_path in CORRUPTED_FILES:
            full_path = os.path.join(BASE_DIR, rel_path)

            # Compute actual checksum
            sha256 = hashlib.sha256()
            with open(full_path, 'rb') as f:
                for chunk in iter(lambda: f.read(8192), b''):
                    sha256.update(chunk)
            actual_hash = sha256.hexdigest()

            # Find the manifest entry (try different key formats)
            possible_keys = [
                rel_path,
                rel_path.replace("testdata/", ""),
                "/" + rel_path,
                "/" + rel_path.replace("testdata/", ""),
            ]

            manifest_hash = None
            for key in possible_keys:
                if key in manifest:
                    manifest_hash = manifest[key]
                    break

            if manifest_hash is not None and actual_hash != manifest_hash:
                mismatches_found += 1

        assert mismatches_found == 3, f"Expected 3 corrupted files with wrong checksums, found {mismatches_found}"


class TestTestdataHasEnoughFiles:
    """Test that testdata has approximately 40 files."""

    def test_testdata_file_count(self):
        file_count = 0
        for root, dirs, files in os.walk(TESTDATA_DIR):
            for f in files:
                if f != "manifest.json":
                    file_count += 1

        assert file_count >= 35, f"Expected ~40 files in testdata (excluding manifest), found {file_count}"


class TestBuggyScriptBehavior:
    """Test that the current script exhibits the buggy behavior."""

    def test_script_exits_zero_despite_corruption(self):
        """The buggy script should exit 0 even though there are corrupted files."""
        result = subprocess.run(
            ["python3", SCRIPT_PATH, TESTDATA_DIR],
            capture_output=True,
            text=True,
            cwd=BASE_DIR
        )
        assert result.returncode == 0, (
            f"Buggy script should exit 0 (it has bugs that hide corruption). "
            f"Got exit code {result.returncode}. stderr: {result.stderr}"
        )

    def test_script_reports_success(self):
        """The buggy script should report success."""
        result = subprocess.run(
            ["python3", SCRIPT_PATH, TESTDATA_DIR],
            capture_output=True,
            text=True,
            cwd=BASE_DIR
        )
        combined_output = result.stdout + result.stderr
        # Should contain some success message
        assert "success" in combined_output.lower() or "verified" in combined_output.lower() or result.returncode == 0, (
            f"Buggy script should report success. Output: {combined_output}"
        )

    def test_script_does_not_report_corrupted_files(self):
        """The buggy script should NOT report the corrupted files."""
        result = subprocess.run(
            ["python3", SCRIPT_PATH, TESTDATA_DIR],
            capture_output=True,
            text=True,
            cwd=BASE_DIR
        )
        combined_output = result.stdout + result.stderr

        # The buggy script should not identify these as mismatches
        corrupted_basenames = ["backup-001.tar.gz", "system.log", "users.db"]

        # Check that the script doesn't report these as failures/mismatches
        # (it might mention them in other contexts, but not as checksum failures)
        failure_indicators = ["mismatch", "failed", "corrupt", "error", "invalid", "wrong"]

        for basename in corrupted_basenames:
            for indicator in failure_indicators:
                # If the basename appears near a failure indicator, the bug might be fixed
                if basename in combined_output and indicator in combined_output.lower():
                    # This is a rough check - the buggy script shouldn't report these
                    pass  # We'll rely on exit code check primarily


class TestDirectoryWritable:
    """Test that the backup-verify directory is writable."""

    def test_backup_verify_is_writable(self):
        test_file = os.path.join(BASE_DIR, ".write_test")
        try:
            with open(test_file, 'w') as f:
                f.write("test")
            os.remove(test_file)
        except (IOError, OSError) as e:
            pytest.fail(f"Directory {BASE_DIR} is not writable: {e}")


class TestPythonVersion:
    """Test that Python 3.11+ is available."""

    def test_python_version(self):
        result = subprocess.run(
            ["python3", "--version"],
            capture_output=True,
            text=True
        )
        version_str = result.stdout.strip()
        # Parse version like "Python 3.11.4"
        parts = version_str.replace("Python ", "").split(".")
        major = int(parts[0])
        minor = int(parts[1])

        assert major >= 3 and minor >= 11, f"Python 3.11+ required, found {version_str}"
