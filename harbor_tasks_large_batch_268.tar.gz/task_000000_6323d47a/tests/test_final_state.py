# test_final_state.py
"""
Tests to validate the final state after the student fixes the backup verification script.
Verifies that the script correctly detects corrupted files and meets all requirements.
"""

import os
import json
import hashlib
import subprocess
import re
import pytest


BASE_DIR = "/home/user/backup-verify"
SCRIPT_PATH = os.path.join(BASE_DIR, "check.py")
TESTDATA_DIR = os.path.join(BASE_DIR, "testdata")
MANIFEST_PATH = os.path.join(TESTDATA_DIR, "manifest.json")

# The three intentionally corrupted files (basenames for output checking)
CORRUPTED_BASENAMES = ["backup-001.tar.gz", "system.log", "users.db"]

# Full relative paths of corrupted files
CORRUPTED_FILES = [
    "testdata/archives/2024/jan/backup-001.tar.gz",
    "testdata/logs/system.log",
    "testdata/db/snapshots/users.db",
]


class TestScriptExitsNonZero:
    """Test that the fixed script exits non-zero when corruption is detected."""

    def test_script_exits_nonzero_with_corrupted_files(self):
        """The fixed script should exit non-zero when there are corrupted files."""
        result = subprocess.run(
            ["python3", SCRIPT_PATH, TESTDATA_DIR],
            capture_output=True,
            text=True,
            cwd=BASE_DIR
        )
        assert result.returncode != 0, (
            f"Script should exit non-zero when corruption is detected. "
            f"Got exit code {result.returncode}.\n"
            f"stdout: {result.stdout}\n"
            f"stderr: {result.stderr}"
        )


class TestScriptReportsCorruptedFiles:
    """Test that the fixed script reports all three corrupted files."""

    def test_reports_backup_tar_gz(self):
        """Script should report backup-001.tar.gz as corrupted."""
        result = subprocess.run(
            ["python3", SCRIPT_PATH, TESTDATA_DIR],
            capture_output=True,
            text=True,
            cwd=BASE_DIR
        )
        combined_output = result.stdout + result.stderr
        assert "backup-001.tar.gz" in combined_output, (
            f"Script should report backup-001.tar.gz as corrupted.\n"
            f"Output: {combined_output}"
        )

    def test_reports_system_log(self):
        """Script should report system.log as corrupted."""
        result = subprocess.run(
            ["python3", SCRIPT_PATH, TESTDATA_DIR],
            capture_output=True,
            text=True,
            cwd=BASE_DIR
        )
        combined_output = result.stdout + result.stderr
        assert "system.log" in combined_output, (
            f"Script should report system.log as corrupted.\n"
            f"Output: {combined_output}"
        )

    def test_reports_users_db(self):
        """Script should report users.db as corrupted."""
        result = subprocess.run(
            ["python3", SCRIPT_PATH, TESTDATA_DIR],
            capture_output=True,
            text=True,
            cwd=BASE_DIR
        )
        combined_output = result.stdout + result.stderr
        assert "users.db" in combined_output, (
            f"Script should report users.db as corrupted.\n"
            f"Output: {combined_output}"
        )


class TestNoHardcodedFilenames:
    """Test that corrupted filenames are not hardcoded in the script."""

    def test_no_hardcoded_corrupted_filenames(self):
        """The script must not hardcode the corrupted filenames."""
        result = subprocess.run(
            ["grep", "-E", r"backup-001|system\.log|users\.db", SCRIPT_PATH],
            capture_output=True,
            text=True
        )
        assert result.returncode != 0, (
            f"Script must not hardcode corrupted filenames. "
            f"Found matches:\n{result.stdout}"
        )


class TestBinaryModeForChecksumming:
    """Test that the script opens files in binary mode for checksumming."""

    def test_uses_binary_mode(self):
        """Script must open files in binary mode ('rb') for checksumming."""
        with open(SCRIPT_PATH, 'r') as f:
            content = f.read()

        # Check for 'rb' in open calls
        assert "'rb'" in content or '"rb"' in content, (
            "Script must open files in binary mode ('rb') for checksumming. "
            "No 'rb' mode found in script."
        )


class TestNoFalsePositives:
    """Test that the script doesn't report false positives on good files."""

    def test_exactly_three_mismatches(self):
        """Script should detect exactly 3 corrupted files, no more."""
        result = subprocess.run(
            ["python3", SCRIPT_PATH, TESTDATA_DIR],
            capture_output=True,
            text=True,
            cwd=BASE_DIR
        )
        combined_output = result.stdout + result.stderr

        # Count how many of our corrupted files are mentioned
        corrupted_mentioned = sum(
            1 for basename in CORRUPTED_BASENAMES 
            if basename in combined_output
        )

        assert corrupted_mentioned == 3, (
            f"Script should report exactly 3 corrupted files. "
            f"Found {corrupted_mentioned} of the expected corrupted files mentioned.\n"
            f"Output: {combined_output}"
        )

        # Also verify no other files are reported as mismatches
        # Load manifest to get all file basenames
        with open(MANIFEST_PATH, 'r') as f:
            manifest = json.load(f)

        # Get all basenames from manifest
        all_basenames = set()
        for key in manifest.keys():
            basename = os.path.basename(key)
            all_basenames.add(basename)

        # Check that good files aren't reported as failures
        good_basenames = all_basenames - set(CORRUPTED_BASENAMES)

        # Look for failure indicators near good file names
        failure_patterns = [
            r"mismatch.*{}",
            r"{}.*mismatch",
            r"failed.*{}",
            r"{}.*failed",
            r"corrupt.*{}",
            r"{}.*corrupt",
            r"invalid.*{}",
            r"{}.*invalid",
        ]

        false_positives = []
        for basename in good_basenames:
            # Skip manifest.json itself
            if basename == "manifest.json":
                continue
            for pattern in failure_patterns:
                regex = pattern.format(re.escape(basename))
                if re.search(regex, combined_output, re.IGNORECASE):
                    false_positives.append(basename)
                    break

        # This is a heuristic check - if many good files appear with failure words, something's wrong
        assert len(false_positives) <= 2, (
            f"Script may have false positives. Good files appearing with failure indicators: {false_positives}\n"
            f"Output: {combined_output}"
        )


class TestScriptStillPerformsRealVerification:
    """Test that the script performs actual SHA256 verification."""

    def test_script_uses_sha256(self):
        """Script should use SHA256 for checksumming."""
        with open(SCRIPT_PATH, 'r') as f:
            content = f.read()
        assert 'sha256' in content.lower(), (
            "Script must use SHA256 for checksum verification."
        )

    def test_script_uses_hashlib(self):
        """Script should use hashlib for checksumming."""
        with open(SCRIPT_PATH, 'r') as f:
            content = f.read()
        assert 'hashlib' in content, (
            "Script must use hashlib for checksum verification."
        )


class TestTestdataUnchanged:
    """Test that testdata directory structure and files are unchanged."""

    def test_manifest_unchanged(self):
        """Manifest should still be valid JSON with expected structure."""
        with open(MANIFEST_PATH, 'r') as f:
            manifest = json.load(f)

        assert isinstance(manifest, dict), "Manifest should be a dictionary"
        assert len(manifest) >= 35, f"Manifest should have ~40 entries, found {len(manifest)}"

        # Verify hash format
        for key, value in manifest.items():
            assert len(value) == 64, f"SHA256 hex should be 64 chars for {key}"
            int(value, 16)  # Should be valid hex

    def test_corrupted_files_still_exist(self):
        """Corrupted files should still exist."""
        for rel_path in CORRUPTED_FILES:
            full_path = os.path.join(BASE_DIR, rel_path)
            assert os.path.isfile(full_path), f"Corrupted file {full_path} should still exist"

    def test_corrupted_files_still_corrupted(self):
        """Corrupted files should still have wrong checksums."""
        with open(MANIFEST_PATH, 'r') as f:
            manifest = json.load(f)

        mismatches = 0
        for rel_path in CORRUPTED_FILES:
            full_path = os.path.join(BASE_DIR, rel_path)

            # Compute actual checksum
            sha256 = hashlib.sha256()
            with open(full_path, 'rb') as f:
                for chunk in iter(lambda: f.read(8192), b''):
                    sha256.update(chunk)
            actual_hash = sha256.hexdigest()

            # Find manifest entry
            possible_keys = [
                rel_path,
                rel_path.replace("testdata/", ""),
                "/" + rel_path,
                "/" + rel_path.replace("testdata/", ""),
            ]

            manifest_hash = None
            for key in possible_keys:
                if key in manifest:
                    manifest_hash = manifest[key]
                    break

            if manifest_hash and actual_hash != manifest_hash:
                mismatches += 1

        assert mismatches == 3, (
            f"All 3 corrupted files should still have wrong checksums, found {mismatches}"
        )


class TestScriptHandlesFreshManifest:
    """Test that script would report 0 mismatches if manifest matched all files."""

    def test_script_logic_is_correct(self):
        """
        Verify the script's logic by checking it can correctly identify mismatches.
        We do this by verifying it found exactly the 3 known corrupted files.
        """
        result = subprocess.run(
            ["python3", SCRIPT_PATH, TESTDATA_DIR],
            capture_output=True,
            text=True,
            cwd=BASE_DIR
        )
        combined_output = result.stdout + result.stderr

        # All three corrupted files should be mentioned
        for basename in CORRUPTED_BASENAMES:
            assert basename in combined_output, (
                f"Script should detect {basename} as corrupted.\n"
                f"Output: {combined_output}"
            )

        # Exit code should be non-zero
        assert result.returncode != 0, (
            f"Script should exit non-zero with corrupted files. "
            f"Exit code: {result.returncode}"
        )


class TestScriptIsExecutable:
    """Test that the script can be executed."""

    def test_script_runs_without_syntax_error(self):
        """Script should run without Python syntax errors."""
        result = subprocess.run(
            ["python3", "-m", "py_compile", SCRIPT_PATH],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, (
            f"Script has syntax errors:\n{result.stderr}"
        )

    def test_script_accepts_directory_argument(self):
        """Script should accept a directory argument."""
        result = subprocess.run(
            ["python3", SCRIPT_PATH, TESTDATA_DIR],
            capture_output=True,
            text=True,
            cwd=BASE_DIR,
            timeout=30
        )
        # Should complete without crashing (exit code doesn't matter here)
        # If it crashes with an exception, stderr will show it
        assert "Traceback" not in result.stderr or result.returncode != 0, (
            f"Script crashed with exception:\n{result.stderr}"
        )
