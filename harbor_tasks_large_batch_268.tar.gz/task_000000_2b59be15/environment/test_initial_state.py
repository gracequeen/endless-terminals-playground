# test_initial_state.py
"""
Tests to validate the initial state before the student performs the Dockerfile optimization task.
"""

import os
import pytest


HOME_DIR = "/home/user"
APP_DIR = "/home/user/app"
DOCKERFILE_PATH = "/home/user/app/Dockerfile"
GO_MOD_PATH = "/home/user/app/go.mod"
GO_SUM_PATH = "/home/user/app/go.sum"
MAIN_GO_PATH = "/home/user/app/cmd/server/main.go"


class TestDirectoryStructure:
    """Test that the required directories exist."""

    def test_home_directory_exists(self):
        """Verify /home/user exists."""
        assert os.path.isdir(HOME_DIR), f"Home directory {HOME_DIR} does not exist"

    def test_app_directory_exists(self):
        """Verify /home/user/app directory exists."""
        assert os.path.isdir(APP_DIR), f"App directory {APP_DIR} does not exist"

    def test_cmd_server_directory_exists(self):
        """Verify /home/user/app/cmd/server directory exists."""
        cmd_server_dir = os.path.join(APP_DIR, "cmd", "server")
        assert os.path.isdir(cmd_server_dir), f"Directory {cmd_server_dir} does not exist"

    def test_app_directory_is_writable(self):
        """Verify /home/user/app is writable."""
        assert os.access(APP_DIR, os.W_OK), f"App directory {APP_DIR} is not writable"


class TestDockerfileExists:
    """Test that the Dockerfile exists with expected initial content."""

    def test_dockerfile_exists(self):
        """Verify Dockerfile exists at /home/user/app/Dockerfile."""
        assert os.path.isfile(DOCKERFILE_PATH), f"Dockerfile not found at {DOCKERFILE_PATH}"

    def test_dockerfile_is_readable(self):
        """Verify Dockerfile is readable."""
        assert os.access(DOCKERFILE_PATH, os.R_OK), f"Dockerfile at {DOCKERFILE_PATH} is not readable"

    def test_dockerfile_uses_golang_base(self):
        """Verify Dockerfile uses golang:1.21 as base image."""
        with open(DOCKERFILE_PATH, 'r') as f:
            content = f.read()
        assert "FROM golang:1.21" in content, \
            "Dockerfile should use 'FROM golang:1.21' as the base image in initial state"

    def test_dockerfile_has_single_from(self):
        """Verify Dockerfile has only one FROM instruction (not multi-stage yet)."""
        with open(DOCKERFILE_PATH, 'r') as f:
            content = f.read()
        from_count = sum(1 for line in content.split('\n') 
                        if line.strip().upper().startswith('FROM '))
        assert from_count == 1, \
            f"Initial Dockerfile should have exactly 1 FROM instruction, found {from_count}"

    def test_dockerfile_has_go_build(self):
        """Verify Dockerfile contains go build command."""
        with open(DOCKERFILE_PATH, 'r') as f:
            content = f.read()
        assert "go build" in content, \
            "Dockerfile should contain 'go build' command"

    def test_dockerfile_builds_server(self):
        """Verify Dockerfile builds the server from ./cmd/server."""
        with open(DOCKERFILE_PATH, 'r') as f:
            content = f.read()
        assert "./cmd/server" in content or "cmd/server" in content, \
            "Dockerfile should build from ./cmd/server"

    def test_dockerfile_exposes_8080(self):
        """Verify Dockerfile exposes port 8080."""
        with open(DOCKERFILE_PATH, 'r') as f:
            content = f.read()
        assert "EXPOSE 8080" in content or "expose 8080" in content.lower(), \
            "Dockerfile should expose port 8080"

    def test_dockerfile_has_cmd(self):
        """Verify Dockerfile has CMD instruction."""
        with open(DOCKERFILE_PATH, 'r') as f:
            content = f.read()
        has_cmd = "CMD" in content.upper()
        assert has_cmd, "Dockerfile should have CMD instruction"

    def test_dockerfile_not_multistage(self):
        """Verify Dockerfile is NOT already multi-stage (no 'AS' in FROM)."""
        with open(DOCKERFILE_PATH, 'r') as f:
            content = f.read()
        # Check for FROM ... AS pattern (case insensitive)
        lines = content.split('\n')
        for line in lines:
            stripped = line.strip().upper()
            if stripped.startswith('FROM ') and ' AS ' in stripped:
                pytest.fail("Initial Dockerfile should NOT be multi-stage (should not have 'FROM ... AS')")


class TestGoModuleFiles:
    """Test that Go module files exist."""

    def test_go_mod_exists(self):
        """Verify go.mod exists."""
        assert os.path.isfile(GO_MOD_PATH), f"go.mod not found at {GO_MOD_PATH}"

    def test_go_sum_exists(self):
        """Verify go.sum exists."""
        assert os.path.isfile(GO_SUM_PATH), f"go.sum not found at {GO_SUM_PATH}"

    def test_main_go_exists(self):
        """Verify main.go exists in cmd/server."""
        assert os.path.isfile(MAIN_GO_PATH), f"main.go not found at {MAIN_GO_PATH}"

    def test_go_mod_is_valid(self):
        """Verify go.mod contains module declaration."""
        with open(GO_MOD_PATH, 'r') as f:
            content = f.read()
        assert "module" in content, "go.mod should contain a module declaration"

    def test_main_go_has_package_main(self):
        """Verify main.go has package main declaration."""
        with open(MAIN_GO_PATH, 'r') as f:
            content = f.read()
        assert "package main" in content, "main.go should have 'package main' declaration"

    def test_main_go_has_main_func(self):
        """Verify main.go has main function."""
        with open(MAIN_GO_PATH, 'r') as f:
            content = f.read()
        assert "func main()" in content, "main.go should have 'func main()' function"


class TestNoDockerRequired:
    """Verify that Docker is not required for this task (grader evaluates Dockerfile content)."""

    def test_dockerfile_is_text_file(self):
        """Verify Dockerfile is a regular text file that can be evaluated."""
        assert os.path.isfile(DOCKERFILE_PATH), f"Dockerfile must exist at {DOCKERFILE_PATH}"
        # Try to read it as text
        try:
            with open(DOCKERFILE_PATH, 'r', encoding='utf-8') as f:
                content = f.read()
            assert len(content) > 0, "Dockerfile should not be empty"
        except UnicodeDecodeError:
            pytest.fail("Dockerfile should be a valid text file")
