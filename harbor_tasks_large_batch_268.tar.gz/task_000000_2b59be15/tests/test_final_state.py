# test_final_state.py
"""
Tests to validate the final state after the student has completed the Dockerfile optimization task.
The Dockerfile should now use a multi-stage build with a minimal final image.
"""

import os
import re
import pytest


APP_DIR = "/home/user/app"
DOCKERFILE_PATH = "/home/user/app/Dockerfile"
GO_MOD_PATH = "/home/user/app/go.mod"
GO_SUM_PATH = "/home/user/app/go.sum"
MAIN_GO_PATH = "/home/user/app/cmd/server/main.go"


class TestDockerfileExists:
    """Test that the Dockerfile exists and is readable."""

    def test_dockerfile_exists(self):
        """Verify Dockerfile exists at /home/user/app/Dockerfile."""
        assert os.path.isfile(DOCKERFILE_PATH), f"Dockerfile not found at {DOCKERFILE_PATH}"

    def test_dockerfile_is_readable(self):
        """Verify Dockerfile is readable."""
        assert os.access(DOCKERFILE_PATH, os.R_OK), f"Dockerfile at {DOCKERFILE_PATH} is not readable"

    def test_dockerfile_not_empty(self):
        """Verify Dockerfile is not empty."""
        with open(DOCKERFILE_PATH, 'r') as f:
            content = f.read()
        assert len(content.strip()) > 0, "Dockerfile should not be empty"


class TestMultiStageBuild:
    """Test that the Dockerfile uses a proper multi-stage build."""

    def test_dockerfile_has_exactly_two_from_instructions(self):
        """Verify Dockerfile has exactly 2 FROM instructions for multi-stage build."""
        with open(DOCKERFILE_PATH, 'r') as f:
            content = f.read()

        # Count FROM instructions (lines starting with FROM, case-insensitive)
        from_count = 0
        for line in content.split('\n'):
            stripped = line.strip()
            if stripped.upper().startswith('FROM '):
                from_count += 1

        assert from_count == 2, \
            f"Dockerfile must have exactly 2 FROM instructions for multi-stage build, found {from_count}"

    def test_dockerfile_has_build_stage_with_as(self):
        """Verify Dockerfile has a named build stage (FROM ... AS ...)."""
        with open(DOCKERFILE_PATH, 'r') as f:
            content = f.read()

        # Check for FROM ... AS pattern (case-insensitive)
        pattern = re.compile(r'FROM\s+\S+\s+AS\s+\S+', re.IGNORECASE)
        match = pattern.search(content)

        assert match is not None, \
            "Dockerfile must contain a named build stage with 'FROM <image> AS <name>' syntax"

    def test_dockerfile_uses_copy_from(self):
        """Verify Dockerfile uses COPY --from= to transfer binary between stages."""
        with open(DOCKERFILE_PATH, 'r') as f:
            content = f.read()

        # Check for COPY --from= pattern (case-insensitive)
        pattern = re.compile(r'COPY\s+--from=', re.IGNORECASE)
        match = pattern.search(content)

        assert match is not None, \
            "Dockerfile must use 'COPY --from=<stage>' to copy the binary from the build stage"


class TestBuildStage:
    """Test that the build stage is properly configured."""

    def test_first_stage_uses_golang(self):
        """Verify the first FROM uses a golang image."""
        with open(DOCKERFILE_PATH, 'r') as f:
            content = f.read()

        # Find the first FROM instruction
        for line in content.split('\n'):
            stripped = line.strip()
            if stripped.upper().startswith('FROM '):
                # First FROM should reference golang
                assert 'golang' in stripped.lower(), \
                    f"First stage should use a golang image, found: {stripped}"
                break

    def test_dockerfile_has_go_build(self):
        """Verify Dockerfile still contains go build command."""
        with open(DOCKERFILE_PATH, 'r') as f:
            content = f.read()

        assert "go build" in content.lower(), \
            "Dockerfile must contain 'go build' command to compile the binary"

    def test_dockerfile_builds_cmd_server(self):
        """Verify Dockerfile builds from ./cmd/server."""
        with open(DOCKERFILE_PATH, 'r') as f:
            content = f.read()

        # Check for cmd/server in the build command
        assert "cmd/server" in content, \
            "Dockerfile must build the binary from cmd/server"


class TestFinalStage:
    """Test that the final stage uses a minimal base image."""

    def test_final_stage_uses_minimal_base(self):
        """Verify the final FROM uses a minimal base image (alpine, scratch, distroless, or busybox)."""
        with open(DOCKERFILE_PATH, 'r') as f:
            content = f.read()

        # Find all FROM instructions and get the last one
        from_lines = []
        for line in content.split('\n'):
            stripped = line.strip()
            if stripped.upper().startswith('FROM '):
                from_lines.append(stripped)

        assert len(from_lines) >= 2, "Dockerfile must have at least 2 FROM instructions"

        final_from = from_lines[-1].lower()

        # Check that final FROM is NOT golang
        assert 'golang' not in final_from, \
            f"Final stage must NOT use golang image, found: {from_lines[-1]}"

        # Check that final FROM uses a minimal base
        minimal_bases = ['alpine', 'scratch', 'distroless', 'busybox', 'gcr.io/distroless']
        is_minimal = any(base in final_from for base in minimal_bases)

        assert is_minimal, \
            f"Final stage must use a minimal base image (alpine, scratch, distroless, or busybox), found: {from_lines[-1]}"


class TestRuntimeConfiguration:
    """Test that runtime configuration is preserved."""

    def test_dockerfile_exposes_8080(self):
        """Verify Dockerfile still exposes port 8080."""
        with open(DOCKERFILE_PATH, 'r') as f:
            content = f.read()

        # Check for EXPOSE 8080 (case-insensitive)
        pattern = re.compile(r'EXPOSE\s+8080', re.IGNORECASE)
        match = pattern.search(content)

        assert match is not None, \
            "Dockerfile must expose port 8080"

    def test_dockerfile_has_cmd_or_entrypoint(self):
        """Verify Dockerfile has CMD or ENTRYPOINT to run the server."""
        with open(DOCKERFILE_PATH, 'r') as f:
            content = f.read()

        content_upper = content.upper()
        has_cmd = 'CMD ' in content_upper or 'CMD[' in content_upper.replace(' ', '')
        has_entrypoint = 'ENTRYPOINT ' in content_upper or 'ENTRYPOINT[' in content_upper.replace(' ', '')

        assert has_cmd or has_entrypoint, \
            "Dockerfile must have CMD or ENTRYPOINT instruction to run the server binary"

    def test_dockerfile_runs_server_binary(self):
        """Verify CMD or ENTRYPOINT references the server binary."""
        with open(DOCKERFILE_PATH, 'r') as f:
            content = f.read()

        # Look for server in CMD or ENTRYPOINT lines
        has_server_reference = False
        for line in content.split('\n'):
            stripped = line.strip().upper()
            if stripped.startswith('CMD ') or stripped.startswith('ENTRYPOINT '):
                # Check if it references a server binary
                line_lower = line.lower()
                if 'server' in line_lower or '/app' in line_lower:
                    has_server_reference = True
                    break

        assert has_server_reference, \
            "CMD or ENTRYPOINT should reference the server binary"


class TestGoSourceFilesUnchanged:
    """Test that Go source files remain unchanged."""

    def test_go_mod_exists(self):
        """Verify go.mod still exists."""
        assert os.path.isfile(GO_MOD_PATH), f"go.mod not found at {GO_MOD_PATH}"

    def test_go_sum_exists(self):
        """Verify go.sum still exists."""
        assert os.path.isfile(GO_SUM_PATH), f"go.sum not found at {GO_SUM_PATH}"

    def test_main_go_exists(self):
        """Verify main.go still exists in cmd/server."""
        assert os.path.isfile(MAIN_GO_PATH), f"main.go not found at {MAIN_GO_PATH}"

    def test_go_mod_has_module(self):
        """Verify go.mod still contains module declaration."""
        with open(GO_MOD_PATH, 'r') as f:
            content = f.read()
        assert "module" in content, "go.mod should contain a module declaration"

    def test_main_go_has_package_main(self):
        """Verify main.go still has package main declaration."""
        with open(MAIN_GO_PATH, 'r') as f:
            content = f.read()
        assert "package main" in content, "main.go should have 'package main' declaration"


class TestDockerfileSyntax:
    """Test that the Dockerfile has valid syntax structure."""

    def test_dockerfile_copy_from_references_build_stage(self):
        """Verify COPY --from references a valid build stage name."""
        with open(DOCKERFILE_PATH, 'r') as f:
            content = f.read()

        # Extract build stage name from first FROM ... AS ...
        stage_name = None
        for line in content.split('\n'):
            stripped = line.strip()
            match = re.match(r'FROM\s+\S+\s+AS\s+(\S+)', stripped, re.IGNORECASE)
            if match:
                stage_name = match.group(1).lower()
                break

        assert stage_name is not None, "Could not find build stage name"

        # Check that COPY --from references this stage (or stage index 0)
        copy_from_pattern = re.compile(r'COPY\s+--from=(\S+)', re.IGNORECASE)
        copy_matches = copy_from_pattern.findall(content)

        assert len(copy_matches) > 0, "No COPY --from= found"

        # At least one COPY --from should reference the build stage
        valid_reference = False
        for ref in copy_matches:
            ref_lower = ref.lower()
            if ref_lower == stage_name or ref_lower == '0' or ref_lower == 'builder' or ref_lower == 'build':
                valid_reference = True
                break

        assert valid_reference, \
            f"COPY --from should reference the build stage '{stage_name}' or a valid stage index"
