# test_final_state.py
"""
Tests to validate the final state after the student fixes the token vulnerability.
"""

import os
import subprocess
import re
import pytest


HOME = "/home/user"
WEBAPP_DIR = os.path.join(HOME, "webapp")


class TestWebappFilesStillExist:
    """Verify all required files still exist after the fix."""

    def test_webapp_directory_exists(self):
        assert os.path.isdir(WEBAPP_DIR), f"Directory {WEBAPP_DIR} does not exist"

    def test_app_py_exists(self):
        app_path = os.path.join(WEBAPP_DIR, "app.py")
        assert os.path.isfile(app_path), f"Main Flask app {app_path} does not exist"

    def test_tokens_py_exists(self):
        tokens_path = os.path.join(WEBAPP_DIR, "tokens.py")
        assert os.path.isfile(tokens_path), f"Token module {tokens_path} does not exist"

    def test_test_tokens_py_exists(self):
        test_path = os.path.join(WEBAPP_DIR, "test_tokens.py")
        assert os.path.isfile(test_path), f"QA test script {test_path} does not exist"

    def test_users_db_exists(self):
        db_path = os.path.join(WEBAPP_DIR, "users.db")
        assert os.path.isfile(db_path), f"Database {db_path} does not exist"


class TestVulnerabilityRemoved:
    """Verify that the insecure random module is no longer used for token generation."""

    def test_no_random_seed_in_tokens(self):
        tokens_path = os.path.join(WEBAPP_DIR, "tokens.py")
        result = subprocess.run(
            ['grep', '-E', r'random\.seed', tokens_path],
            capture_output=True, text=True
        )
        assert result.returncode != 0, (
            "tokens.py still contains 'random.seed' - the vulnerability has not been fixed. "
            f"Found: {result.stdout.strip()}"
        )

    def test_no_random_choices_in_tokens(self):
        tokens_path = os.path.join(WEBAPP_DIR, "tokens.py")
        result = subprocess.run(
            ['grep', '-E', r'random\.choices', tokens_path],
            capture_output=True, text=True
        )
        assert result.returncode != 0, (
            "tokens.py still contains 'random.choices' - insecure random module still in use. "
            f"Found: {result.stdout.strip()}"
        )

    def test_no_random_random_in_tokens(self):
        tokens_path = os.path.join(WEBAPP_DIR, "tokens.py")
        result = subprocess.run(
            ['grep', '-E', r'random\.random', tokens_path],
            capture_output=True, text=True
        )
        assert result.returncode != 0, (
            "tokens.py still contains 'random.random' - insecure random module still in use. "
            f"Found: {result.stdout.strip()}"
        )


class TestSecureRandomnessUsed:
    """Verify that cryptographically secure randomness is now used."""

    def test_uses_secrets_or_urandom(self):
        tokens_path = os.path.join(WEBAPP_DIR, "tokens.py")
        with open(tokens_path, 'r') as f:
            content = f.read()

        uses_secrets = 'secrets' in content
        uses_urandom = 'os.urandom' in content or 'urandom' in content
        uses_systemrandom = 'SystemRandom' in content

        assert uses_secrets or uses_urandom or uses_systemrandom, (
            "tokens.py should use cryptographically secure randomness "
            "(secrets module, os.urandom, or random.SystemRandom)"
        )


class TestAppStillWorks:
    """Verify the Flask app still starts and imports without errors."""

    def test_app_imports_successfully(self):
        result = subprocess.run(
            ['python3', '-c', 'import sys; sys.path.insert(0, "/home/user/webapp"); import app'],
            capture_output=True, text=True,
            cwd=WEBAPP_DIR
        )
        assert result.returncode == 0, f"app.py fails to import after fix: {result.stderr}"

    def test_tokens_imports_successfully(self):
        result = subprocess.run(
            ['python3', '-c', 'import sys; sys.path.insert(0, "/home/user/webapp"); import tokens'],
            capture_output=True, text=True,
            cwd=WEBAPP_DIR
        )
        assert result.returncode == 0, f"tokens.py fails to import after fix: {result.stderr}"

    def test_app_starts_without_crash(self):
        """Test that the app can start (will timeout but shouldn't crash on import)."""
        result = subprocess.run(
            ['timeout', '3', 'python3', 'app.py'],
            capture_output=True, text=True,
            cwd=WEBAPP_DIR
        )
        # Exit code 124 means timeout (expected since Flask runs indefinitely)
        # Exit code 0 is also fine if app exits cleanly
        # Any other exit code indicates a crash
        assert result.returncode in [0, 124], (
            f"app.py crashed on startup. Exit code: {result.returncode}, "
            f"stderr: {result.stderr}, stdout: {result.stdout}"
        )


class TestRoutesStillExist:
    """Verify the required routes still exist in app.py."""

    def test_forgot_route_exists(self):
        app_path = os.path.join(WEBAPP_DIR, "app.py")
        with open(app_path, 'r') as f:
            content = f.read()
        assert '/forgot' in content, (
            "app.py no longer contains /forgot route - functionality was removed instead of fixed"
        )

    def test_reset_route_exists(self):
        app_path = os.path.join(WEBAPP_DIR, "app.py")
        with open(app_path, 'r') as f:
            content = f.read()
        assert '/reset/' in content or '/reset/<' in content, (
            "app.py no longer contains /reset/<token> route - functionality was removed instead of fixed"
        )


class TestTokenGenerationFunction:
    """Verify the token generation function still works and produces valid tokens."""

    def test_generate_reset_token_exists(self):
        result = subprocess.run(
            ['python3', '-c', '''
import sys
sys.path.insert(0, "/home/user/webapp")
from tokens import generate_reset_token
token = generate_reset_token("test@example.com")
print(token)
'''],
            capture_output=True, text=True,
            cwd=WEBAPP_DIR
        )
        assert result.returncode == 0, (
            f"generate_reset_token function is broken: {result.stderr}"
        )

    def test_token_length_is_32(self):
        result = subprocess.run(
            ['python3', '-c', '''
import sys
sys.path.insert(0, "/home/user/webapp")
from tokens import generate_reset_token
token = generate_reset_token("test@example.com")
print(len(token))
'''],
            capture_output=True, text=True,
            cwd=WEBAPP_DIR
        )
        assert result.returncode == 0, f"Failed to generate token: {result.stderr}"
        token_length = int(result.stdout.strip())
        assert token_length == 32, (
            f"Token length should be 32 characters (DB constraint), but got {token_length}"
        )

    def test_tokens_are_unique(self):
        """Generate multiple tokens and verify they're all different."""
        result = subprocess.run(
            ['python3', '-c', '''
import sys
sys.path.insert(0, "/home/user/webapp")
from tokens import generate_reset_token
tokens = [generate_reset_token("test@example.com") for _ in range(10)]
print(len(set(tokens)))
'''],
            capture_output=True, text=True,
            cwd=WEBAPP_DIR
        )
        assert result.returncode == 0, f"Failed to generate tokens: {result.stderr}"
        unique_count = int(result.stdout.strip())
        assert unique_count == 10, (
            f"Generated 10 tokens but only {unique_count} were unique - "
            "tokens may still be predictable"
        )


class TestQAExploitFails:
    """The main test: QA's exploit script should now fail (exit 0 = exploit doesn't work)."""

    def test_qa_test_script_passes(self):
        """
        Run the QA test script. It exits 0 if tokens are NOT predictable (exploit fails).
        This is the key test that validates the fix.
        """
        result = subprocess.run(
            ['python3', 'test_tokens.py'],
            capture_output=True, text=True,
            cwd=WEBAPP_DIR,
            timeout=60  # Give it enough time to run the exploit attempts
        )
        assert result.returncode == 0, (
            f"QA exploit test failed (exit code {result.returncode}). "
            f"The tokens are still predictable!\n"
            f"stdout: {result.stdout}\n"
            f"stderr: {result.stderr}"
        )
