# test_initial_state.py
"""
Tests to validate the initial state before the student fixes the token vulnerability.
"""

import os
import subprocess
import pytest


HOME = "/home/user"
WEBAPP_DIR = os.path.join(HOME, "webapp")


class TestWebappDirectoryExists:
    """Verify the webapp directory and required files exist."""

    def test_webapp_directory_exists(self):
        assert os.path.isdir(WEBAPP_DIR), f"Directory {WEBAPP_DIR} does not exist"

    def test_app_py_exists(self):
        app_path = os.path.join(WEBAPP_DIR, "app.py")
        assert os.path.isfile(app_path), f"Main Flask app {app_path} does not exist"

    def test_tokens_py_exists(self):
        tokens_path = os.path.join(WEBAPP_DIR, "tokens.py")
        assert os.path.isfile(tokens_path), f"Token module {tokens_path} does not exist"

    def test_test_tokens_py_exists(self):
        test_path = os.path.join(WEBAPP_DIR, "test_tokens.py")
        assert os.path.isfile(test_path), f"QA test script {test_path} does not exist"

    def test_users_db_exists(self):
        db_path = os.path.join(WEBAPP_DIR, "users.db")
        assert os.path.isfile(db_path), f"Database {db_path} does not exist"


class TestTokensModuleHasVulnerability:
    """Verify that tokens.py contains the vulnerable code that needs to be fixed."""

    def test_tokens_uses_random_seed(self):
        tokens_path = os.path.join(WEBAPP_DIR, "tokens.py")
        with open(tokens_path, 'r') as f:
            content = f.read()
        assert 'random.seed' in content, (
            "tokens.py should contain 'random.seed' - this is the vulnerability to fix"
        )

    def test_tokens_uses_random_choices(self):
        tokens_path = os.path.join(WEBAPP_DIR, "tokens.py")
        with open(tokens_path, 'r') as f:
            content = f.read()
        assert 'random.choices' in content, (
            "tokens.py should contain 'random.choices' - this is part of the insecure token generation"
        )

    def test_tokens_uses_time_for_seed(self):
        tokens_path = os.path.join(WEBAPP_DIR, "tokens.py")
        with open(tokens_path, 'r') as f:
            content = f.read()
        assert 'time.time()' in content or 'time.time(' in content, (
            "tokens.py should use time.time() for seeding - this makes tokens predictable"
        )


class TestAppPyHasRequiredRoutes:
    """Verify app.py contains the expected routes."""

    def test_app_has_forgot_route(self):
        app_path = os.path.join(WEBAPP_DIR, "app.py")
        with open(app_path, 'r') as f:
            content = f.read()
        assert '/forgot' in content, "app.py should contain /forgot route"

    def test_app_has_reset_route(self):
        app_path = os.path.join(WEBAPP_DIR, "app.py")
        with open(app_path, 'r') as f:
            content = f.read()
        assert '/reset/' in content or '/reset/<' in content, (
            "app.py should contain /reset/<token> route"
        )


class TestPythonEnvironment:
    """Verify Python and required modules are available."""

    def test_python3_available(self):
        result = subprocess.run(['python3', '--version'], capture_output=True, text=True)
        assert result.returncode == 0, "Python 3 is not available"

    def test_flask_importable(self):
        result = subprocess.run(
            ['python3', '-c', 'import flask; print(flask.__version__)'],
            capture_output=True, text=True
        )
        assert result.returncode == 0, f"Flask is not installed: {result.stderr}"

    def test_secrets_module_available(self):
        result = subprocess.run(
            ['python3', '-c', 'import secrets; print(secrets.token_hex(16))'],
            capture_output=True, text=True
        )
        assert result.returncode == 0, "secrets module is not available"


class TestAppCanImport:
    """Verify the Flask app can be imported without errors."""

    def test_app_imports_successfully(self):
        result = subprocess.run(
            ['python3', '-c', 'import sys; sys.path.insert(0, "/home/user/webapp"); import app'],
            capture_output=True, text=True,
            cwd=WEBAPP_DIR
        )
        assert result.returncode == 0, f"app.py fails to import: {result.stderr}"

    def test_tokens_imports_successfully(self):
        result = subprocess.run(
            ['python3', '-c', 'import sys; sys.path.insert(0, "/home/user/webapp"); import tokens'],
            capture_output=True, text=True,
            cwd=WEBAPP_DIR
        )
        assert result.returncode == 0, f"tokens.py fails to import: {result.stderr}"


class TestTestScriptExists:
    """Verify the QA test script is properly set up."""

    def test_test_tokens_is_executable_python(self):
        test_path = os.path.join(WEBAPP_DIR, "test_tokens.py")
        result = subprocess.run(
            ['python3', '-m', 'py_compile', test_path],
            capture_output=True, text=True
        )
        assert result.returncode == 0, f"test_tokens.py has syntax errors: {result.stderr}"


class TestDirectoryWritable:
    """Verify the webapp directory is writable for the fix."""

    def test_webapp_dir_writable(self):
        assert os.access(WEBAPP_DIR, os.W_OK), f"{WEBAPP_DIR} is not writable"

    def test_tokens_py_writable(self):
        tokens_path = os.path.join(WEBAPP_DIR, "tokens.py")
        assert os.access(tokens_path, os.W_OK), f"{tokens_path} is not writable"
