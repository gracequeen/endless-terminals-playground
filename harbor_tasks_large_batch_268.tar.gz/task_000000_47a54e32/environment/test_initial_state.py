# test_initial_state.py
"""
Tests to validate the initial state of the system before the student performs
the task of converting semicolon delimiters to commas in /home/user/data/sales.csv
"""

import os
import subprocess
import pytest


class TestInitialState:
    """Test suite to verify the initial state before the delimiter conversion task."""

    CSV_PATH = "/home/user/data/sales.csv"

    def test_data_directory_exists(self):
        """Verify that /home/user/data directory exists."""
        data_dir = "/home/user/data"
        assert os.path.isdir(data_dir), f"Directory {data_dir} does not exist"

    def test_sales_csv_exists(self):
        """Verify that the sales.csv file exists."""
        assert os.path.isfile(self.CSV_PATH), f"File {self.CSV_PATH} does not exist"

    def test_sales_csv_is_readable(self):
        """Verify that the sales.csv file is readable."""
        assert os.access(self.CSV_PATH, os.R_OK), f"File {self.CSV_PATH} is not readable"

    def test_sales_csv_is_writable(self):
        """Verify that the sales.csv file is writable by the agent user."""
        assert os.access(self.CSV_PATH, os.W_OK), f"File {self.CSV_PATH} is not writable"

    def test_sales_csv_has_47_lines(self):
        """Verify that the sales.csv file has exactly 47 lines."""
        with open(self.CSV_PATH, 'r') as f:
            line_count = sum(1 for _ in f)
        assert line_count == 47, f"Expected 47 lines in {self.CSV_PATH}, but found {line_count}"

    def test_sales_csv_uses_semicolon_delimiters(self):
        """Verify that the file currently uses semicolons as delimiters."""
        with open(self.CSV_PATH, 'r') as f:
            content = f.read()
        assert ';' in content, f"File {self.CSV_PATH} does not contain semicolons - may already be converted"

    def test_sales_csv_header_is_semicolon_delimited(self):
        """Verify that the header line uses semicolons."""
        with open(self.CSV_PATH, 'r') as f:
            header = f.readline().strip()
        expected_header = "date;region;product;units;revenue"
        assert header == expected_header, (
            f"Expected header to be '{expected_header}', but got '{header}'"
        )

    def test_sales_csv_has_data_rows_with_semicolons(self):
        """Verify that data rows use semicolons as delimiters."""
        with open(self.CSV_PATH, 'r') as f:
            lines = f.readlines()

        # Check second line (first data row)
        if len(lines) > 1:
            first_data_row = lines[1].strip()
            assert ';' in first_data_row, (
                f"First data row does not contain semicolons: '{first_data_row}'"
            )
            # Verify it has the expected structure (5 fields)
            fields = first_data_row.split(';')
            assert len(fields) == 5, (
                f"Expected 5 fields in data row, but found {len(fields)}: '{first_data_row}'"
            )

    def test_sed_is_available(self):
        """Verify that sed command is available."""
        result = subprocess.run(['which', 'sed'], capture_output=True, text=True)
        assert result.returncode == 0, "sed command is not available on this system"

    def test_awk_is_available(self):
        """Verify that awk command is available."""
        result = subprocess.run(['which', 'awk'], capture_output=True, text=True)
        assert result.returncode == 0, "awk command is not available on this system"

    def test_all_lines_have_semicolons(self):
        """Verify that all lines in the file contain semicolons (as delimiters)."""
        with open(self.CSV_PATH, 'r') as f:
            lines = f.readlines()

        for i, line in enumerate(lines, 1):
            line = line.strip()
            if line:  # Skip empty lines if any
                assert ';' in line, (
                    f"Line {i} does not contain semicolons: '{line}'"
                )

    def test_file_does_not_already_use_commas_as_delimiters(self):
        """Verify that the file is not already comma-delimited in the header."""
        with open(self.CSV_PATH, 'r') as f:
            header = f.readline().strip()

        # The header should NOT be comma-delimited yet
        comma_header = "date,region,product,units,revenue"
        assert header != comma_header, (
            f"File appears to already be comma-delimited. Header is: '{header}'"
        )


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
