# test_final_state.py
"""
Tests to validate the final state of the system after the student has completed
the task of converting semicolon delimiters to commas in /home/user/data/sales.csv
"""

import os
import subprocess
import pytest


class TestFinalState:
    """Test suite to verify the final state after the delimiter conversion task."""

    CSV_PATH = "/home/user/data/sales.csv"

    def test_sales_csv_exists(self):
        """Verify that the sales.csv file still exists after conversion."""
        assert os.path.isfile(self.CSV_PATH), f"File {self.CSV_PATH} does not exist"

    def test_sales_csv_has_47_lines(self):
        """Verify that the sales.csv file still has exactly 47 lines."""
        with open(self.CSV_PATH, 'r') as f:
            line_count = sum(1 for _ in f)
        assert line_count == 47, (
            f"Expected 47 lines in {self.CSV_PATH}, but found {line_count}. "
            "Line count should remain unchanged after conversion."
        )

    def test_sales_csv_header_is_comma_delimited(self):
        """Verify that the header line now uses commas as delimiters."""
        with open(self.CSV_PATH, 'r') as f:
            header = f.readline().strip()
        expected_header = "date,region,product,units,revenue"
        assert header == expected_header, (
            f"Expected header to be '{expected_header}', but got '{header}'. "
            "The semicolons should be replaced with commas."
        )

    def test_no_semicolons_remain_in_file(self):
        """Verify that no semicolons remain in the file."""
        with open(self.CSV_PATH, 'r') as f:
            content = f.read()
        assert ';' not in content, (
            f"File {self.CSV_PATH} still contains semicolons. "
            "All semicolons should be replaced with commas."
        )

    def test_grep_semicolon_returns_no_matches(self):
        """Verify that grep for semicolons returns no matches (exit code 1)."""
        result = subprocess.run(
            ['grep', ';', self.CSV_PATH],
            capture_output=True,
            text=True
        )
        assert result.returncode == 1, (
            f"Expected 'grep ; {self.CSV_PATH}' to return exit code 1 (no matches), "
            f"but got exit code {result.returncode}. "
            "This indicates semicolons still exist in the file."
        )

    def test_head_outputs_correct_header(self):
        """Verify that head -1 outputs the correct comma-delimited header."""
        result = subprocess.run(
            ['head', '-1', self.CSV_PATH],
            capture_output=True,
            text=True
        )
        expected_header = "date,region,product,units,revenue"
        actual_header = result.stdout.strip()
        assert actual_header == expected_header, (
            f"Expected 'head -1 {self.CSV_PATH}' to output '{expected_header}', "
            f"but got '{actual_header}'."
        )

    def test_wc_outputs_47_lines(self):
        """Verify that wc -l outputs 47 lines."""
        result = subprocess.run(
            ['wc', '-l'],
            stdin=open(self.CSV_PATH, 'r'),
            capture_output=True,
            text=True
        )
        line_count = int(result.stdout.strip())
        assert line_count == 47, (
            f"Expected 'wc -l < {self.CSV_PATH}' to output 47, "
            f"but got {line_count}."
        )

    def test_all_lines_have_commas(self):
        """Verify that all non-empty lines contain commas as delimiters."""
        with open(self.CSV_PATH, 'r') as f:
            lines = f.readlines()

        for i, line in enumerate(lines, 1):
            line = line.strip()
            if line:  # Skip empty lines if any
                assert ',' in line, (
                    f"Line {i} does not contain commas: '{line}'. "
                    "All lines should use commas as delimiters."
                )

    def test_data_rows_have_five_comma_separated_fields(self):
        """Verify that data rows have exactly 5 comma-separated fields."""
        with open(self.CSV_PATH, 'r') as f:
            lines = f.readlines()

        for i, line in enumerate(lines, 1):
            line = line.strip()
            if line:
                fields = line.split(',')
                assert len(fields) == 5, (
                    f"Line {i} has {len(fields)} fields instead of 5: '{line}'. "
                    "Each line should have exactly 5 comma-separated fields."
                )

    def test_file_contains_expected_column_names(self):
        """Verify that the header contains all expected column names."""
        with open(self.CSV_PATH, 'r') as f:
            header = f.readline().strip()

        expected_columns = ['date', 'region', 'product', 'units', 'revenue']
        actual_columns = header.split(',')

        assert actual_columns == expected_columns, (
            f"Expected columns {expected_columns}, but got {actual_columns}. "
            "Column names should be preserved after conversion."
        )

    def test_file_is_valid_csv_format(self):
        """Verify that the file can be parsed as a valid CSV with commas."""
        import csv

        try:
            with open(self.CSV_PATH, 'r', newline='') as f:
                reader = csv.reader(f, delimiter=',')
                rows = list(reader)

            assert len(rows) == 47, (
                f"CSV reader found {len(rows)} rows, expected 47."
            )

            # Check that all rows have 5 columns
            for i, row in enumerate(rows, 1):
                assert len(row) == 5, (
                    f"Row {i} has {len(row)} columns instead of 5: {row}"
                )

        except csv.Error as e:
            pytest.fail(f"File is not a valid CSV: {e}")


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
