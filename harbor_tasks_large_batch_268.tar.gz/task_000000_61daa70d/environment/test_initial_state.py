# test_initial_state.py
"""
Tests to validate the initial state of the OS/filesystem before the student
performs the cron debugging task for translation sync.
"""

import os
import subprocess
import pytest


# === Path Constants ===
HOME = "/home/user"
L10N_DIR = os.path.join(HOME, "l10n")
UPSTREAM_DIR = os.path.join(HOME, "upstream")
RELEASE_DIR = os.path.join(HOME, "release")
CACHE_DIR = os.path.join(L10N_DIR, ".cache")

SYNC_SCRIPT = os.path.join(L10N_DIR, "sync.sh")
SYNC_LOG = os.path.join(L10N_DIR, "sync.log")

UPSTREAM_FR_PO = os.path.join(UPSTREAM_DIR, "fr_FR.po")
CACHE_FR_PO = os.path.join(CACHE_DIR, "fr_FR.po")
RELEASE_FR_MO = os.path.join(RELEASE_DIR, "fr_FR.mo")


class TestDirectoriesExist:
    """Verify all required directories exist."""

    def test_l10n_directory_exists(self):
        assert os.path.isdir(L10N_DIR), f"Directory {L10N_DIR} must exist"

    def test_upstream_directory_exists(self):
        assert os.path.isdir(UPSTREAM_DIR), f"Directory {UPSTREAM_DIR} must exist"

    def test_release_directory_exists(self):
        assert os.path.isdir(RELEASE_DIR), f"Directory {RELEASE_DIR} must exist"

    def test_cache_directory_exists(self):
        assert os.path.isdir(CACHE_DIR), f"Directory {CACHE_DIR} must exist"


class TestSyncScriptExists:
    """Verify the sync script exists and is executable."""

    def test_sync_script_exists(self):
        assert os.path.isfile(SYNC_SCRIPT), f"Sync script {SYNC_SCRIPT} must exist"

    def test_sync_script_is_executable(self):
        assert os.access(SYNC_SCRIPT, os.X_OK), f"Sync script {SYNC_SCRIPT} must be executable"

    def test_sync_script_is_bash_script(self):
        with open(SYNC_SCRIPT, 'r') as f:
            first_line = f.readline().strip()
        assert first_line.startswith("#!/bin/bash"), f"Sync script should be a bash script, got: {first_line}"


class TestUpstreamFiles:
    """Verify upstream .po files exist with expected content."""

    def test_upstream_fr_po_exists(self):
        assert os.path.isfile(UPSTREAM_FR_PO), f"Upstream file {UPSTREAM_FR_PO} must exist"

    def test_upstream_fr_po_contains_v2_translation(self):
        with open(UPSTREAM_FR_PO, 'r') as f:
            content = f.read()
        assert 'msgid "dashboard_title"' in content, \
            f"{UPSTREAM_FR_PO} must contain msgid 'dashboard_title'"
        assert 'msgstr "Tableau de Bord v2"' in content, \
            f"{UPSTREAM_FR_PO} must contain the v2 translation 'Tableau de Bord v2'"


class TestCacheFiles:
    """Verify cache .po files exist with OLD content (the bug condition)."""

    def test_cache_fr_po_exists(self):
        assert os.path.isfile(CACHE_FR_PO), f"Cache file {CACHE_FR_PO} must exist"

    def test_cache_fr_po_contains_old_translation(self):
        with open(CACHE_FR_PO, 'r') as f:
            content = f.read()
        assert 'msgid "dashboard_title"' in content, \
            f"{CACHE_FR_PO} must contain msgid 'dashboard_title'"
        # The cache should have the OLD version (without v2)
        assert 'msgstr "Tableau de Bord"' in content, \
            f"{CACHE_FR_PO} must contain the OLD translation 'Tableau de Bord' (not v2)"
        # Make sure it's NOT the v2 version
        assert 'Tableau de Bord v2' not in content, \
            f"{CACHE_FR_PO} should contain OLD translation, not v2"


class TestReleaseFiles:
    """Verify release .mo files exist and are stale (contain old translation)."""

    def test_release_fr_mo_exists(self):
        assert os.path.isfile(RELEASE_FR_MO), f"Release file {RELEASE_FR_MO} must exist"

    def test_release_fr_mo_contains_old_translation(self):
        # Use msgunfmt to decompile the .mo file and check content
        result = subprocess.run(
            ["msgunfmt", RELEASE_FR_MO],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, f"msgunfmt failed on {RELEASE_FR_MO}: {result.stderr}"
        content = result.stdout
        assert 'msgid "dashboard_title"' in content, \
            f"{RELEASE_FR_MO} must contain msgid 'dashboard_title'"
        # The .mo should have the OLD version (stale)
        assert 'msgstr "Tableau de Bord"' in content, \
            f"{RELEASE_FR_MO} must contain the OLD translation 'Tableau de Bord'"
        # Should NOT have v2 yet
        assert 'Tableau de Bord v2' not in content, \
            f"{RELEASE_FR_MO} should be stale (contain old translation, not v2)"


class TestCrontabEntries:
    """Verify the crontab has both the problematic and the sync entries."""

    def test_crontab_exists(self):
        result = subprocess.run(["crontab", "-l"], capture_output=True, text=True)
        # crontab -l returns 0 if there's a crontab, 1 if no crontab
        assert result.returncode == 0, "User must have a crontab configured"

    def test_crontab_has_sync_script_entry(self):
        result = subprocess.run(["crontab", "-l"], capture_output=True, text=True)
        assert result.returncode == 0, "Failed to read crontab"
        crontab_content = result.stdout
        # Check for the sync.sh entry
        assert "sync.sh" in crontab_content, \
            "Crontab must contain an entry for sync.sh"
        assert "0 * * * *" in crontab_content, \
            "Crontab must have an hourly entry (0 * * * *)"

    def test_crontab_has_problematic_cp_entry(self):
        """The bug: there's a cp command that copies cache back to upstream."""
        result = subprocess.run(["crontab", "-l"], capture_output=True, text=True)
        assert result.returncode == 0, "Failed to read crontab"
        crontab_content = result.stdout
        # Check for the problematic cp entry
        assert "cp" in crontab_content and ".cache" in crontab_content and "upstream" in crontab_content, \
            "Crontab must contain the problematic 'cp .cache upstream' entry (this is the bug)"


class TestRequiredTools:
    """Verify required tools are available."""

    def test_msgfmt_available(self):
        result = subprocess.run(["which", "msgfmt"], capture_output=True, text=True)
        assert result.returncode == 0, "msgfmt must be available (gettext package)"

    def test_msgunfmt_available(self):
        result = subprocess.run(["which", "msgunfmt"], capture_output=True, text=True)
        assert result.returncode == 0, "msgunfmt must be available (gettext package)"

    def test_diff_available(self):
        result = subprocess.run(["which", "diff"], capture_output=True, text=True)
        assert result.returncode == 0, "diff must be available"

    def test_python3_available(self):
        result = subprocess.run(["which", "python3"], capture_output=True, text=True)
        assert result.returncode == 0, "python3 must be available"


class TestSyncLogExists:
    """Verify the sync log exists and shows the 'unchanged' pattern."""

    def test_sync_log_exists(self):
        assert os.path.isfile(SYNC_LOG), f"Sync log {SYNC_LOG} must exist"

    def test_sync_log_shows_unchanged_entries(self):
        with open(SYNC_LOG, 'r') as f:
            content = f.read()
        # The log should show that fr_FR was marked as unchanged (the symptom of the bug)
        assert "unchanged" in content.lower() or "skipping" in content.lower(), \
            f"Sync log should contain 'unchanged' or 'skipping' entries showing the bug symptom"


class TestFileDiscrepancy:
    """Verify the cache and upstream files are different (the core bug condition)."""

    def test_cache_and_upstream_differ(self):
        """The cache should have old content, upstream should have new content."""
        result = subprocess.run(
            ["diff", "-q", CACHE_FR_PO, UPSTREAM_FR_PO],
            capture_output=True,
            text=True
        )
        # diff -q returns 1 if files differ, 0 if same
        assert result.returncode == 1, \
            f"Cache and upstream fr_FR.po should differ (cache=old, upstream=new with v2)"


class TestWritePermissions:
    """Verify paths are writable as stated in the task."""

    def test_l10n_dir_writable(self):
        assert os.access(L10N_DIR, os.W_OK), f"{L10N_DIR} must be writable"

    def test_upstream_dir_writable(self):
        assert os.access(UPSTREAM_DIR, os.W_OK), f"{UPSTREAM_DIR} must be writable"

    def test_release_dir_writable(self):
        assert os.access(RELEASE_DIR, os.W_OK), f"{RELEASE_DIR} must be writable"

    def test_cache_dir_writable(self):
        assert os.access(CACHE_DIR, os.W_OK), f"{CACHE_DIR} must be writable"
