I've got a cron setup for translation sync at /home/user/l10n — it's supposed to pull updated .po files from /home/user/upstream every hour, compile them to .mo, and drop them in /home/user/release. The weird part is that it *runs* fine (I can see it in the logs at /home/user/l10n/sync.log, no errors), but the .mo files in release are always stale. Like, I updated fr_FR.po in upstream two days ago with a new msgstr for "dashboard_title" and the compiled .mo still has the old text.

I ran the sync script manually and it worked — fresh .mo, correct string. But whatever cron is doing, it's not actually picking up changes. The crontab is there, the script runs, msgfmt gets called, no errors anywhere. I'm losing my mind a little.

Need the hourly job to actually produce current .mo files. The fr_FR dashboard_title thing is the canary — if that's right, the rest should follow.
