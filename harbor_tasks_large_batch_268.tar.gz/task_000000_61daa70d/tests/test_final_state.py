# test_final_state.py
"""
Tests to validate the final state of the OS/filesystem after the student
has completed the cron debugging task for translation sync.

Expected final state:
- The problematic crontab entry (the cp that overwrites upstream) is removed.
- /home/user/release/fr_FR.mo contains the string "Tableau de Bord v2" for msgid "dashboard_title".
- The hourly sync cron entry for sync.sh still exists and is functional.
- /home/user/l10n/.cache/fr_FR.po matches /home/user/upstream/fr_FR.po (contains v2 string).
- /home/user/upstream/fr_FR.po unchanged (still contains the v2 translation).
- sync.sh script logic preserved.
"""

import os
import subprocess
import pytest


# === Path Constants ===
HOME = "/home/user"
L10N_DIR = os.path.join(HOME, "l10n")
UPSTREAM_DIR = os.path.join(HOME, "upstream")
RELEASE_DIR = os.path.join(HOME, "release")
CACHE_DIR = os.path.join(L10N_DIR, ".cache")

SYNC_SCRIPT = os.path.join(L10N_DIR, "sync.sh")
SYNC_LOG = os.path.join(L10N_DIR, "sync.log")

UPSTREAM_FR_PO = os.path.join(UPSTREAM_DIR, "fr_FR.po")
CACHE_FR_PO = os.path.join(CACHE_DIR, "fr_FR.po")
RELEASE_FR_MO = os.path.join(RELEASE_DIR, "fr_FR.mo")


class TestCrontabFixed:
    """Verify the crontab has been fixed - problematic entry removed, sync entry preserved."""

    def test_crontab_exists(self):
        """User should still have a crontab."""
        result = subprocess.run(["crontab", "-l"], capture_output=True, text=True)
        assert result.returncode == 0, "User must still have a crontab configured"

    def test_problematic_cp_entry_removed(self):
        """The cp command that copies cache back to upstream must be removed."""
        result = subprocess.run(["crontab", "-l"], capture_output=True, text=True)
        assert result.returncode == 0, "Failed to read crontab"

        # Filter out comment lines and check for the problematic pattern
        lines = result.stdout.strip().split('\n')
        non_comment_lines = [line for line in lines if line.strip() and not line.strip().startswith('#')]

        for line in non_comment_lines:
            # Check if this line contains the problematic cp pattern
            if 'cp' in line and '.cache' in line and 'upstream' in line:
                pytest.fail(
                    f"Crontab still contains the problematic 'cp .cache upstream' entry: {line}\n"
                    "This entry must be removed to fix the sync issue."
                )

    def test_sync_script_cron_entry_preserved(self):
        """The sync.sh cron entry must still exist."""
        result = subprocess.run(["crontab", "-l"], capture_output=True, text=True)
        assert result.returncode == 0, "Failed to read crontab"
        crontab_content = result.stdout

        # Check for sync.sh entry
        assert "sync.sh" in crontab_content, \
            "Crontab must still contain an entry for sync.sh - the sync job should not be removed"

    def test_sync_cron_is_hourly(self):
        """The sync.sh entry should run hourly."""
        result = subprocess.run(["crontab", "-l"], capture_output=True, text=True)
        assert result.returncode == 0, "Failed to read crontab"

        lines = result.stdout.strip().split('\n')
        sync_lines = [line for line in lines if 'sync.sh' in line and not line.strip().startswith('#')]

        assert len(sync_lines) > 0, "No active sync.sh cron entry found"

        # Check that at least one sync.sh entry has hourly schedule
        has_hourly = False
        for line in sync_lines:
            # Hourly pattern: minute * * * * (e.g., "0 * * * *" or similar)
            parts = line.split()
            if len(parts) >= 5:
                # Check if it's an hourly pattern (second field is *)
                if parts[1] == '*':
                    has_hourly = True
                    break

        assert has_hourly, \
            f"sync.sh cron entry should be hourly (e.g., '0 * * * *'), found: {sync_lines}"


class TestReleaseMoFileUpdated:
    """Verify the release .mo file contains the updated v2 translation."""

    def test_release_fr_mo_exists(self):
        """The release .mo file must exist."""
        assert os.path.isfile(RELEASE_FR_MO), f"Release file {RELEASE_FR_MO} must exist"

    def test_release_fr_mo_contains_v2_translation(self):
        """The .mo file must contain the updated 'Tableau de Bord v2' translation."""
        result = subprocess.run(
            ["msgunfmt", RELEASE_FR_MO],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0, f"msgunfmt failed on {RELEASE_FR_MO}: {result.stderr}"
        content = result.stdout

        assert 'msgid "dashboard_title"' in content, \
            f"{RELEASE_FR_MO} must contain msgid 'dashboard_title'"

        assert 'Tableau de Bord v2' in content, \
            f"{RELEASE_FR_MO} must contain the updated translation 'Tableau de Bord v2'. " \
            f"Current content shows: {content}"

    def test_release_fr_mo_via_grep_pattern(self):
        """Verify using the specific grep pattern from the task description."""
        result = subprocess.run(
            ["bash", "-c", f"msgunfmt {RELEASE_FR_MO} 2>/dev/null | grep -A1 'dashboard_title'"],
            capture_output=True,
            text=True
        )

        output = result.stdout
        assert 'Tableau de Bord v2' in output, \
            f"Expected 'Tableau de Bord v2' in msgstr for dashboard_title, got: {output}"


class TestCacheFileUpdated:
    """Verify the cache .po file has been updated to match upstream."""

    def test_cache_fr_po_exists(self):
        """The cache file must exist."""
        assert os.path.isfile(CACHE_FR_PO), f"Cache file {CACHE_FR_PO} must exist"

    def test_cache_fr_po_contains_v2_translation(self):
        """The cache must now contain the v2 translation."""
        with open(CACHE_FR_PO, 'r') as f:
            content = f.read()

        assert 'msgid "dashboard_title"' in content, \
            f"{CACHE_FR_PO} must contain msgid 'dashboard_title'"

        assert 'Tableau de Bord v2' in content, \
            f"{CACHE_FR_PO} must contain the updated translation 'Tableau de Bord v2'. " \
            f"Cache should be updated to match upstream."

    def test_cache_matches_upstream(self):
        """The cache and upstream fr_FR.po should now be identical (or semantically equivalent)."""
        result = subprocess.run(
            ["diff", "-q", CACHE_FR_PO, UPSTREAM_FR_PO],
            capture_output=True,
            text=True
        )
        # diff -q returns 0 if files are the same
        assert result.returncode == 0, \
            f"Cache {CACHE_FR_PO} should match upstream {UPSTREAM_FR_PO}. " \
            f"The sync mechanism should have updated the cache."


class TestUpstreamPreserved:
    """Verify upstream files are unchanged (invariant)."""

    def test_upstream_fr_po_exists(self):
        """Upstream file must still exist."""
        assert os.path.isfile(UPSTREAM_FR_PO), f"Upstream file {UPSTREAM_FR_PO} must exist"

    def test_upstream_fr_po_still_contains_v2(self):
        """Upstream must still contain the v2 translation (not overwritten)."""
        with open(UPSTREAM_FR_PO, 'r') as f:
            content = f.read()

        assert 'msgid "dashboard_title"' in content, \
            f"{UPSTREAM_FR_PO} must contain msgid 'dashboard_title'"

        assert 'Tableau de Bord v2' in content, \
            f"{UPSTREAM_FR_PO} must still contain 'Tableau de Bord v2'. " \
            f"Upstream should not have been modified."


class TestSyncScriptPreserved:
    """Verify the sync script is preserved and functional."""

    def test_sync_script_exists(self):
        """The sync script must still exist."""
        assert os.path.isfile(SYNC_SCRIPT), f"Sync script {SYNC_SCRIPT} must exist"

    def test_sync_script_is_executable(self):
        """The sync script must be executable."""
        assert os.access(SYNC_SCRIPT, os.X_OK), f"Sync script {SYNC_SCRIPT} must be executable"

    def test_sync_script_contains_caching_logic(self):
        """The sync script should still have its caching mechanism."""
        with open(SYNC_SCRIPT, 'r') as f:
            content = f.read()

        # Check for key elements of the caching logic
        assert 'CACHE' in content or '.cache' in content, \
            "Sync script should still contain caching logic"
        assert 'diff' in content, \
            "Sync script should still use diff for change detection"
        assert 'msgfmt' in content, \
            "Sync script should still use msgfmt for compilation"


class TestDirectoriesIntact:
    """Verify all required directories still exist."""

    def test_l10n_directory_exists(self):
        assert os.path.isdir(L10N_DIR), f"Directory {L10N_DIR} must exist"

    def test_upstream_directory_exists(self):
        assert os.path.isdir(UPSTREAM_DIR), f"Directory {UPSTREAM_DIR} must exist"

    def test_release_directory_exists(self):
        assert os.path.isdir(RELEASE_DIR), f"Directory {RELEASE_DIR} must exist"

    def test_cache_directory_exists(self):
        assert os.path.isdir(CACHE_DIR), f"Directory {CACHE_DIR} must exist"


class TestAntiShortcutGuards:
    """Tests to ensure the fix was done properly, not via shortcuts."""

    def test_crontab_no_cp_cache_upstream_line(self):
        """
        Anti-shortcut: Verify crontab -l | grep -v '^#' | grep 'cp.*\.cache.*upstream' 
        returns no output.
        """
        result = subprocess.run(
            ["bash", "-c", "crontab -l | grep -v '^#' | grep 'cp.*\\.cache.*upstream'"],
            capture_output=True,
            text=True
        )
        # grep returns 1 if no match found (which is what we want)
        assert result.returncode == 1 or result.stdout.strip() == "", \
            f"Crontab still contains problematic cp line: {result.stdout}"

    def test_mo_file_not_manually_created_from_upstream(self):
        """
        The .mo should be generated through the sync mechanism (cache updated).
        If cache doesn't match upstream but .mo has v2, it was done manually.
        """
        # First check if cache matches upstream
        diff_result = subprocess.run(
            ["diff", "-q", CACHE_FR_PO, UPSTREAM_FR_PO],
            capture_output=True,
            text=True
        )

        # Then check if .mo has v2
        mo_result = subprocess.run(
            ["msgunfmt", RELEASE_FR_MO],
            capture_output=True,
            text=True
        )

        has_v2_in_mo = 'Tableau de Bord v2' in mo_result.stdout
        cache_matches_upstream = diff_result.returncode == 0

        # If .mo has v2, cache must also be updated (proving sync mechanism was used)
        if has_v2_in_mo:
            assert cache_matches_upstream, \
                "The .mo file has v2 but cache doesn't match upstream. " \
                "The fix must use the proper sync mechanism (run sync.sh after fixing cron), " \
                "not manually compile from upstream."


class TestFutureHourlyRunsWillWork:
    """Verify that future hourly runs will work correctly."""

    def test_sync_script_runs_successfully(self):
        """Running sync.sh should succeed without errors."""
        result = subprocess.run(
            ["bash", SYNC_SCRIPT],
            capture_output=True,
            text=True,
            cwd=L10N_DIR
        )
        assert result.returncode == 0, \
            f"sync.sh should run successfully. stderr: {result.stderr}"

    def test_sync_produces_correct_mo_after_upstream_change(self):
        """
        Simulate a future change: modify upstream, run sync, verify .mo updates.
        Then restore original state.
        """
        # Save original upstream content
        with open(UPSTREAM_FR_PO, 'r') as f:
            original_content = f.read()

        try:
            # Modify upstream with a test string
            test_content = original_content.replace('Tableau de Bord v2', 'Tableau de Bord v3-test')
            with open(UPSTREAM_FR_PO, 'w') as f:
                f.write(test_content)

            # Run sync
            result = subprocess.run(
                ["bash", SYNC_SCRIPT],
                capture_output=True,
                text=True,
                cwd=L10N_DIR
            )
            assert result.returncode == 0, f"sync.sh failed: {result.stderr}"

            # Check .mo has the new string
            mo_result = subprocess.run(
                ["msgunfmt", RELEASE_FR_MO],
                capture_output=True,
                text=True
            )
            assert 'Tableau de Bord v3-test' in mo_result.stdout, \
                "After modifying upstream and running sync, .mo should have new content. " \
                "This proves the sync mechanism works for future runs."

        finally:
            # Restore original content
            with open(UPSTREAM_FR_PO, 'w') as f:
                f.write(original_content)

            # Run sync again to restore .mo
            subprocess.run(
                ["bash", SYNC_SCRIPT],
                capture_output=True,
                text=True,
                cwd=L10N_DIR
            )
